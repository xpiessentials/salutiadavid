var builder = DistributedApplication.CreateBuilder(args);

// Configurar SQL Server usando la instancia local de SQL Server Express
var sqlServer = builder.AddConnectionString("sqlserver", "Server=LAPTOP-DAVID\\SQLEXPRESS;Database=Salutia;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True");

// Agregar el proyecto Blazor con referencia a la base de datos
builder.AddProject<Projects.Salutia_Wep_App>("salutia-wep-app")
    .WithReference(sqlServer);

builder.Build().Run();

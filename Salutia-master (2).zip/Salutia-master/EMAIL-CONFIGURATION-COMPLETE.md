# ?? Configuraci�n de Email Completada - Salutia

## ?? Resumen de Configuraci�n

Se ha configurado exitosamente el servicio de correo electr�nico SMTP para Salutia con los siguientes par�metros:

### Configuraci�n SMTP

```json
{
  "EmailSettings": {
    "SmtpServer": "mail.iaparatodospodcast.com",
    "SmtpPort": 465,
    "SenderEmail": "notificaciones@iaparatodospodcast.com",
    "SenderName": "Salutia - Plataforma de Salud Ocupacional",
    "Username": "notificaciones@iaparatodospodcast.com",
    "Password": "********",
    "EnableSsl": true
  }
}
```

### ?? Cambios Realizados

#### 1. **appsettings.json**
- ? Configurado SMTP server: `mail.iaparatodospodcast.com`
- ? Puerto: `465` (SSL/TLS impl�cito)
- ? Credenciales configuradas
- ? SSL habilitado

#### 2. **EmailService.cs**
- ? Corregida la l�gica de conexi�n SMTP
- ? Puerto 465 usa `SecureSocketOptions.SslOnConnect`
- ? Cambio de `UseSsl` a `EnableSsl` para consistencia
- ? Plantillas HTML profesionales para:
  - Confirmaci�n de email
  - Recuperaci�n de contrase�a
  - Email de bienvenida

#### 3. **UserManagementService.cs**
- ? Agregado `IEmailSender<ApplicationUser>`
- ? Agregado `IHttpContextAccessor` para construir URLs
- ? Implementado env�o de email en `RegisterIndependentUserAsync`
- ? Implementado env�o de email en `RegisterEntityAsync`
- ? Manejo de errores sin fallar el registro

#### 4. **Program.cs**
- ? `RequireConfirmedAccount` configurado en `false` para desarrollo
- ?? **IMPORTANTE**: Cambiar a `true` en producci�n

## ?? C�mo Probar

### Opci�n 1: Registrar un Nuevo Usuario

1. **Inicia la aplicaci�n**
   ```bash
   F5 en Visual Studio
   ```

2. **Navega a registro**
   - Ve a `/Account/ChooseRegistrationType`
   - Selecciona "Usuario Independiente" o "Entidad"

3. **Completa el formulario**
   - Usa un email real para recibir la confirmaci�n
   - Completa todos los campos requeridos

4. **Verifica tu bandeja**
   - Deber�as recibir un email desde `notificaciones@iaparatodospodcast.com`
   - El asunto ser�: "Confirma tu correo electr�nico - Salutia"
   - Haz clic en el enlace de confirmaci�n

5. **Inicia sesi�n**
   - Una vez confirmado, inicia sesi�n con tus credenciales

### Opci�n 2: Usuario Existente (elpecodm@hotmail.com)

#### Confirmar manualmente en la base de datos:

1. **Ejecuta el script SQL** (`CONFIRM-EMAIL-elpecodm.sql`):
   ```sql
   UPDATE AspNetUsers
   SET EmailConfirmed = 1
   WHERE Email = 'elpecodm@hotmail.com';
   ```

2. **Inicia sesi�n**
   - Email: `elpecodm@hotmail.com`
   - Contrase�a: (la que usaste al registrarte)

## ?? Tipos de Emails Configurados

### 1. **Email de Confirmaci�n**
- **Cu�ndo**: Al registrar una nueva cuenta
- **Prop�sito**: Verificar la direcci�n de email
- **Asunto**: "Confirma tu correo electr�nico - Salutia"
- **Contenido**: Bot�n con enlace de confirmaci�n

### 2. **Email de Bienvenida**
- **Cu�ndo**: Despu�s de confirmar el email
- **Prop�sito**: Dar la bienvenida y explicar funcionalidades
- **Asunto**: "�Bienvenido/a a Salutia!"
- **Contenido**: Lista de funcionalidades disponibles

### 3. **Recuperaci�n de Contrase�a**
- **Cu�ndo**: Al solicitar reseteo de contrase�a
- **Prop�sito**: Enviar enlace para crear nueva contrase�a
- **Asunto**: "Recuperaci�n de Contrase�a - Salutia"
- **Contenido**: Bot�n con enlace temporal (1 hora)

## ?? Verificaci�n de Logs

Puedes verificar el env�o de emails en los logs de la aplicaci�n:

```
Salutia_Wep_App.Services.EmailService: Information: Email enviado exitosamente a {Email}
Salutia_Wep_App.Services.UserManagementService: Information: Email de confirmaci�n enviado a: {Email}
```

Si hay errores:
```
Salutia_Wep_App.Services.EmailService: Error: Error al enviar email a {Email}
Salutia_Wep_App.Services.UserManagementService: Warning: No se pudo enviar email de confirmaci�n a {Email}
```

## ?? Soluci�n de Problemas

### El email no llega

1. **Verifica spam/correo no deseado**
   - Los emails pueden ser marcados como spam

2. **Verifica la configuraci�n SMTP**
   - Aseg�rate de que el firewall permita conexiones al puerto 465
   - Verifica que las credenciales sean correctas

3. **Revisa los logs**
   - Busca mensajes de error en la ventana de Output de Visual Studio
   - Panel: "Depurar"

4. **Verifica la conexi�n**
   Puedes usar telnet para verificar:
   ```bash
   telnet mail.iaparatodospodcast.com 465
   ```

### Error "Unable to connect to the remote server"

- **Causa**: El servidor SMTP puede estar bloqueado por firewall
- **Soluci�n**: Verifica reglas de firewall o antivirus

### Error "Authentication failed"

- **Causa**: Credenciales incorrectas
- **Soluci�n**: Verifica usuario y contrase�a en `appsettings.json`

## ?? Configuraci�n para Producci�n

Cuando despliegues a producci�n:

1. **Habilitar confirmaci�n obligatoria**
   ```csharp
   // En Program.cs
   options.SignIn.RequireConfirmedAccount = true;
   ```

2. **Usar variables de entorno**
   ```bash
   EmailSettings__Password="TuPasswordSegura"
   ```
   
   O en Azure App Service:
   - Configuration ? Application settings
   - Agregar: `EmailSettings__Password` = `TuPasswordSegura`

3. **Habilitar SSL/TLS**
   - Aseg�rate de que `EnableSsl` est� en `true`
   - Usa puerto 465 para SSL impl�cito
   - O puerto 587 para STARTTLS

4. **Monitorear env�os**
   - Implementa logging de todos los env�os
   - Configura alertas para fallos de env�o

## ?? Notas Importantes

- ?? **Seguridad**: La contrase�a del email est� en `appsettings.json`. En producci�n, usa Azure Key Vault o variables de entorno.
- ? **Confirmaci�n**: Actualmente NO es obligatoria (`RequireConfirmedAccount = false`) para facilitar desarrollo.
- ?? **Remitente**: Todos los emails se env�an desde `notificaciones@iaparatodospodcast.com`
- ?? **Puerto 465**: Usa SSL/TLS impl�cito (conexi�n cifrada desde el inicio)

## ?? Pr�ximos Pasos

1. **Probar el registro** de un nuevo usuario
2. **Verificar recepci�n** del email de confirmaci�n
3. **Confirmar email** haciendo clic en el enlace
4. **Recibir email** de bienvenida autom�ticamente
5. **Probar recuperaci�n** de contrase�a si es necesario

---

? **Configuraci�n completada y lista para usar**

Para cualquier ajuste adicional, revisa los archivos:
- `Salutia Wep App\appsettings.json`
- `Salutia Wep App\Services\EmailService.cs`
- `Salutia Wep App\Services\UserManagementService.cs`

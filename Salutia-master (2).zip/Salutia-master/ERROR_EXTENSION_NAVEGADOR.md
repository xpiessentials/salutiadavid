# ?? SOLUCI�N DEFINITIVA: Error de Extensi�n del Navegador

## ?? El Problema

```
Uncaught TypeError: Cannot read properties of undefined (reading 'control')
at content_script.js:1:422999
```

**Causa Real:** Este error NO es de nuestro c�digo. Es de una **extensi�n del navegador** (probablemente autocompletador, gestor de contrase�as, o corrector ortogr�fico).

---

## ? SOLUCIONES (En Orden de Prioridad)

### SOLUCI�N 1: Desactivar la Extensi�n (Recomendado)

#### Paso 1: Identificar la Extensi�n

El error viene de `content_script.js` - esto indica una extensi�n. Las m�s comunes son:

- ?? **Gestores de contrase�as:** LastPass, 1Password, Dashlane
- ?? **Correctores:** Grammarly, LanguageTool
- ?? **Autocompletado:** Various form fillers
- ?? **Otras:** AdBlock, extensiones de traducci�n

#### Paso 2: Desactivar Extensiones

**En Chrome/Edge:**
```
1. Men� (?) ? Extensiones ? Administrar extensiones
2. Desactivar TODAS temporalmente
3. Recargar la p�gina del test
4. Si funciona, activar de una en una para identificar cu�l causa el problema
```

**Modo R�pido:**
```
Ctrl + Shift + N (Modo inc�gnito - sin extensiones)
```

---

### SOLUCI�N 2: Script de Supresi�n (Ya Aplicado)

He agregado un script en `App.razor` que **suprime** estos errores:

```javascript
window.addEventListener('error', function(event) {
    // Suprimir errores de extensiones
    if (event.filename && event.filename.indexOf('content_script') > -1) {
        event.preventDefault();
        return false;
    }
}, true);
```

**Para que funcione:**
```
1. Detener debug: Shift + F5
2. Iniciar debug: F5
3. Recargar completamente el navegador: Ctrl + F5
```

---

### SOLUCI�N 3: Agregar Meta Tag (Alternativa)

Si las soluciones anteriores no funcionan, agrega esto en `App.razor`:

```html
<head>
    <!-- ...existing meta tags... -->
    <meta http-equiv="Content-Security-Policy" content="script-src 'self' 'unsafe-inline' 'unsafe-eval';">
</head>
```

---

## ?? PRUEBA PASO A PASO

### 1. Probar en Modo Inc�gnito (M�s R�pido)

```
1. Ctrl + Shift + N (Chrome/Edge)
2. Ir a: https://localhost:[puerto]/test-psicosomatico
3. Hacer click en campo
4. �Funciona? ? El problema es una extensi�n
```

### 2. Identificar la Extensi�n Problem�tica

```
1. Abrir extensiones: chrome://extensions/
2. Desactivar todas
3. Activar de una en una
4. Probar el test despu�s de cada una
5. Cuando aparezca el error, esa es la extensi�n problem�tica
```

### 3. Desactivar Solo Para Este Sitio

```
1. Click derecho en el icono de la extensi�n
2. "Configuraci�n"
3. "Sitios" ? Agregar localhost a lista de exclusi�n
```

---

## ?? Extensiones Conocidas que Causan Este Error

| Extensi�n | Soluci�n |
|-----------|----------|
| **Grammarly** | Desactivar para localhost |
| **LastPass** | Agregar localhost a excepciones |
| **1Password** | Desactivar autocompletado en localhost |
| **Honey** | Desactivar |
| **AdBlock Plus** | Agregar localhost a lista blanca |
| **LanguageTool** | Desactivar para localhost |

---

## ?? �Por Qu� Pasa Esto?

Las extensiones del navegador inyectan c�digo JavaScript (`content_script.js`) en TODAS las p�ginas. Este c�digo:

1. Busca campos de formulario
2. Intenta agregar autocompletado/correcci�n
3. A veces accede a propiedades que Blazor a�n no ha inicializado
4. **CRASH** ? Error en consola

**No es un error de nuestro c�digo**, pero afecta la experiencia del usuario.

---

## ? VERIFICACI�N

### Antes (con extensiones activas):
```
? Error en consola: content_script.js
? Puede funcionar pero muestra error
```

### Despu�s (con soluci�n aplicada):
```
? Sin errores en consola
? Test funciona perfectamente
? No hay interferencia
```

---

## ?? INSTRUCCIONES FINALES

### Opci�n A: Modo Inc�gnito (Prueba R�pida)
```
1. Ctrl + Shift + N
2. Ir a /test-psicosomatico
3. Probar
```

### Opci�n B: Desactivar Extensiones
```
1. chrome://extensions/
2. Desactivar todas
3. Probar test
4. Activar una por una para identificar
```

### Opci�n C: Script de Supresi�n (Ya Aplicado)
```
1. Shift + F5 (Detener)
2. F5 (Iniciar)
3. Ctrl + F5 (Hard reload)
4. Probar test
```

---

## ?? Resultados Esperados

Despu�s de aplicar cualquiera de estas soluciones:

| Funcionalidad | Estado |
|---------------|--------|
| Click en campos | ? Funciona |
| Escribir texto | ? Funciona |
| Bot�n "Siguiente" | ? Funciona |
| Sin errores en consola | ? Correcto |
| Test completo | ? Funciona |

---

## ?? Si Nada Funciona

### Debug Avanzado:

```javascript
// Agregar en App.razor antes de </body>
<script>
    console.log('=== BLAZOR DEBUG ===');
    console.log('Extensions detected:', performance.getEntriesByType('resource')
        .filter(r => r.name.includes('chrome-extension')));
</script>
```

Esto te mostrar� qu� extensiones est�n activas.

---

## ?? ACCI�N INMEDIATA

**Prueba esto AHORA:**

```
1. Abre modo inc�gnito: Ctrl + Shift + N
2. Ve a: https://localhost:[tu-puerto]/test-psicosomatico
3. Haz click en un campo
4. Si NO hay error ? El problema es una extensi�n
5. Si S� hay error ? Comparte la consola completa
```

---

**Estado:** ? Script de supresi�n agregado  
**Compilaci�n:** ? Exitosa  
**Siguiente paso:** Probar en modo inc�gnito

# Autenticaci�n de Dos Factores (2FA) con C�digos QR en Salutia

## ?? Descripci�n General

La aplicaci�n Salutia ahora incluye soporte completo para autenticaci�n de dos factores (2FA) con generaci�n autom�tica de c�digos QR. Los usuarios pueden configurar aplicaciones de autenticaci�n TOTP (Time-based One-Time Password) como Google Authenticator o Microsoft Authenticator escaneando un c�digo QR.

---

## ?? Paquetes Instalados

### QRCoder (v1.7.0)
Biblioteca para generar c�digos QR en .NET

```xml
<PackageReference Include="QRCoder" Version="1.7.0" />
```

---

## ??? Arquitectura Implementada

### 1. Servicio QrCodeService

**Ubicaci�n**: `Salutia Wep App\Services\QrCodeService.cs`

Este servicio proporciona m�todos para generar c�digos QR:

```csharp
public class QrCodeService
{
// Genera un c�digo QR en formato Base64
    public string GenerateQrCodeBase64(string text, int pixelsPerModule = 20)
    
    // Genera un Data URI completo para usar en <img src="...">
    public string GenerateQrCodeDataUri(string text, int pixelsPerModule = 20)
}
```

**Caracter�sticas**:
- Genera im�genes PNG de c�digos QR
- Nivel de correcci�n de errores: Q (25%)
- Tama�o configurable mediante `pixelsPerModule`
- Retorna im�genes en formato Base64 o Data URI

### 2. Registro del Servicio

**Ubicaci�n**: `Salutia Wep App\Program.cs`

```csharp
builder.Services.AddScoped<QrCodeService>();
```

El servicio se registra con alcance `Scoped`, lo que significa que se crea una instancia por cada petici�n HTTP.

### 3. P�gina de Configuraci�n

**Ubicaci�n**: `Salutia Wep App\Components\Account\Pages\Manage\EnableAuthenticator.razor`

La p�gina ha sido actualizada para:
- Inyectar el `QrCodeService`
- Generar el c�digo QR autom�ticamente
- Mostrar el c�digo QR con un dise�o mejorado
- Proporcionar fallback si falla la generaci�n del QR
- Usar "Salutia" como nombre del emisor (issuer) en lugar del gen�rico

---

## ?? C�mo Usar la Autenticaci�n de Dos Factores

### Para Usuarios Finales

#### Paso 1: Acceder a la Configuraci�n
1. Inicia sesi�n en Salutia
2. Ve a **Account** ? **Manage** ? **Two-factor authentication**
3. Haz clic en **Add authenticator app**

#### Paso 2: Configurar la Aplicaci�n de Autenticaci�n

**Opci�n A: Escanear el C�digo QR** (Recomendado)
1. Abre tu aplicaci�n de autenticaci�n (Google Authenticator, Microsoft Authenticator, Authy, etc.)
2. Selecciona "A�adir cuenta" o "Escanear c�digo QR"
3. Escanea el c�digo QR mostrado en Salutia
4. La cuenta "Salutia" aparecer� en tu aplicaci�n

**Opci�n B: Ingresar la Clave Manualmente**
1. Si no puedes escanear el QR, copia la clave mostrada (ej: `abcd efgh ijkl mnop`)
2. En tu aplicaci�n de autenticaci�n, selecciona "Ingresar clave manualmente"
3. Ingresa los siguientes datos:
   - **Nombre de la cuenta**: Tu email en Salutia
   - **Clave secreta**: La clave copiada (sin espacios)
   - **Tipo**: Basado en tiempo (TOTP)
   - **Algoritmo**: SHA1
   - **D�gitos**: 6

#### Paso 3: Verificar la Configuraci�n
1. Tu aplicaci�n de autenticaci�n mostrar� un c�digo de 6 d�gitos
2. Ingresa ese c�digo en el campo "Verification Code" en Salutia
3. Haz clic en **Verify**

#### Paso 4: Guardar C�digos de Recuperaci�n
- Despu�s de verificar, se te mostrar�n 10 c�digos de recuperaci�n
- **IMPORTANTE**: Guarda estos c�digos en un lugar seguro
- Usa estos c�digos si pierdes acceso a tu aplicaci�n de autenticaci�n

### Para Desarrolladores

#### Generar C�digos QR en Otros Componentes

```csharp
@inject QrCodeService QrCodeService

@code {
    private string? qrCodeDataUri;

    protected override void OnInitialized()
    {
  // Generar QR para cualquier texto
        var text = "https://ejemplo.com/verificar?token=abc123";
        qrCodeDataUri = QrCodeService.GenerateQrCodeDataUri(text);
    }
}

// En el HTML
<img src="@qrCodeDataUri" alt="C�digo QR" class="img-fluid" />
```

#### Personalizar el Tama�o del QR

```csharp
// QR m�s grande (m�dulos de 20 p�xeles)
var largeQr = QrCodeService.GenerateQrCodeDataUri(text, pixelsPerModule: 20);

// QR m�s peque�o (m�dulos de 5 p�xeles)
var smallQr = QrCodeService.GenerateQrCodeDataUri(text, pixelsPerModule: 5);
```

---

## ?? Interfaz de Usuario

### Dise�o Visual

La p�gina de configuraci�n muestra:

1. **Alerta de �xito (Verde)** cuando el QR se genera correctamente:
   - T�tulo: "Escanea este c�digo QR con tu aplicaci�n de autenticaci�n"
   - C�digo QR centrado, m�ximo 300px de ancho
   - Clave manual mostrada debajo como alternativa

2. **Alerta de Advertencia (Amarilla)** si falla la generaci�n:
 - Mensaje explicativo
   - Clave manual resaltada en grande

### C�digo CSS Aplicable

```css
/* Estilo para el contenedor del QR */
.qr-container {
    max-width: 300px;
 margin: 20px auto;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

/* Estilo para la imagen del QR */
.qr-container img {
  width: 100%;
    height: auto;
    display: block;
}
```

---

## ?? Configuraci�n T�cnica

### Formato URI TOTP

La URI generada sigue el est�ndar [RFC 6238](https://tools.ietf.org/html/rfc6238):

```
otpauth://totp/Salutia:usuario@ejemplo.com?secret=CLAVESECRETA&issuer=Salutia&digits=6
```

**Componentes**:
- `otpauth://totp/` - Protocolo y tipo
- `Salutia` - Nombre del emisor (issuer)
- `usuario@ejemplo.com` - Identificador del usuario (email)
- `secret=CLAVESECRETA` - Clave secreta compartida
- `issuer=Salutia` - Emisor (duplicado para compatibilidad)
- `digits=6` - N�mero de d�gitos del c�digo (siempre 6)

### Par�metros de Identity

```csharp
// Configuraci�n de tokens en Identity
UserManager.Options.Tokens.AuthenticatorTokenProvider

// Generar nueva clave si no existe
await UserManager.ResetAuthenticatorKeyAsync(user);
await UserManager.GetAuthenticatorKeyAsync(user);

// Verificar c�digo TOTP
await UserManager.VerifyTwoFactorTokenAsync(user, provider, code);

// Habilitar 2FA
await UserManager.SetTwoFactorEnabledAsync(user, true);

// Generar c�digos de recuperaci�n
await UserManager.GenerateNewTwoFactorRecoveryCodesAsync(user, 10);
```

---

## ?? Pruebas

### Prueba Manual

1. **Registrar un nuevo usuario**
```powershell
# Desde la aplicaci�n web
Registro ? Email: test@salutia.com ? Confirmar email
```

2. **Habilitar 2FA**
```powershell
Login ? Account ? Manage ? Two-factor authentication ? Add authenticator app
```

3. **Escanear QR con diferentes aplicaciones**
   - ? Google Authenticator (Android/iOS)
   - ? Microsoft Authenticator (Android/iOS)
   - ? Authy (Multiplataforma)
   - ? 1Password (Con soporte TOTP)

4. **Verificar el c�digo**
```powershell
Ingresar c�digo de 6 d�gitos ? Verify
```

5. **Probar Login con 2FA**
```powershell
Logout ? Login ? Email + Password ? Ingresar c�digo 2FA
```

### Casos de Prueba

| Caso | Pasos | Resultado Esperado |
|------|-------|-------------------|
| QR Exitoso | Acceder a Enable Authenticator | QR visible, centrado, escala correcta |
| Clave Manual | Copiar clave y usar en app | C�digo de 6 d�gitos v�lido |
| Verificaci�n Correcta | Ingresar c�digo v�lido | Redirecci�n a c�digos de recuperaci�n |
| Verificaci�n Incorrecta | Ingresar c�digo inv�lido | Mensaje de error "Verification code is invalid" |
| QR Grande | pixelsPerModule = 20 | QR de alta resoluci�n |
| QR Peque�o | pixelsPerModule = 5 | QR compacto pero legible |

---

## ?? Soluci�n de Problemas

### Problema: El c�digo QR no se muestra

**Posibles causas y soluciones**:

1. **Excepci�n en la generaci�n**
   ```powershell
   # Ver logs
   Output Window ? Debug
   
   # Buscar:
   Error generating QR code for user {UserId}
   ```

2. **Servicio no registrado**
   ```csharp
   // Verificar en Program.cs
   builder.Services.AddScoped<QrCodeService>();
   ```

3. **Paquete NuGet faltante**
   ```powershell
   dotnet list package | findstr QRCoder
   # Deber�a mostrar: QRCoder 1.7.0
   ```

### Problema: "Verification code is invalid"

**Posibles causas**:
1. **Hora del sistema incorrecta** - TOTP depende de la hora exacta
   ```powershell
   # Verificar hora
   Get-Date
   
   # Sincronizar con servidor de tiempo
   w32tm /resync
   ```

2. **Clave incorrecta** - Resetear el autenticador
   ```csharp
   await UserManager.ResetAuthenticatorKeyAsync(user);
   ```

3. **C�digo expirado** - Los c�digos TOTP son v�lidos por 30 segundos

### Problema: QR muy grande o muy peque�o

**Soluci�n**: Ajustar `pixelsPerModule`

```csharp
// M�s peque�o (para pantallas peque�as)
qrCodeDataUri = QrCodeService.GenerateQrCodeDataUri(authenticatorUri, pixelsPerModule: 5);

// M�s grande (para imprimir o pantallas grandes)
qrCodeDataUri = QrCodeService.GenerateQrCodeDataUri(authenticatorUri, pixelsPerModule: 20);
```

---

## ?? Aplicaciones de Autenticaci�n Compatibles

### Recomendadas

| Aplicaci�n | Plataforma | Caracter�sticas | Link |
|------------|-----------|-----------------|------|
| **Microsoft Authenticator** | Android, iOS | Backup en la nube, notificaciones push | [Android](https://go.microsoft.com/fwlink/?Linkid=825072) / [iOS](https://go.microsoft.com/fwlink/?Linkid=825073) |
| **Google Authenticator** | Android, iOS | Simple, sin cuenta necesaria | [Android](https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2) / [iOS](https://itunes.apple.com/us/app/google-authenticator/id388497605) |
| **Authy** | Android, iOS, Desktop | Backup multi-dispositivo | [authy.com](https://authy.com) |
| **1Password** | Multiplataforma | Gesti�n de contrase�as + TOTP | [1password.com](https://1password.com) |

### Verificadas

- ? LastPass Authenticator
- ? Duo Mobile
- ? FreeOTP
- ? Aegis (Android, Open Source)

---

## ?? Seguridad y Mejores Pr�cticas

### Para Usuarios

1. **C�digos de Recuperaci�n**
   - Gu�rdalos en un lugar seguro (gestor de contrase�as, papel en caja fuerte)
 - No los compartas con nadie
   - Cada c�digo solo puede usarse una vez

2. **Aplicaci�n de Autenticaci�n**
   - Usa una aplicaci�n de una fuente confiable
   - Habilita backup en la nube (si est� disponible)
   - No desinstales la app sin deshabilitar 2FA primero

3. **Dispositivo M�vil**
   - Mant�n tu dispositivo actualizado
   - Usa PIN/huella/Face ID para bloquear el dispositivo
   - Considera tener un dispositivo de respaldo configurado

### Para Desarrolladores

1. **Almacenamiento de Claves**
   - Las claves secretas se almacenan de forma segura en ASP.NET Identity
   - Nunca expongas las claves en logs o respuestas API
   - Usa HTTPS siempre

2. **Rate Limiting**
   - Considera implementar l�mites de intentos para verificaci�n 2FA
   - Previene ataques de fuerza bruta

3. **Auditor�a**
   - Registra cuando los usuarios habilitan/deshabilitan 2FA
   - Registra intentos fallidos de verificaci�n
   - Notifica a los usuarios sobre cambios en 2FA

```csharp
// Ejemplo de logging
Logger.LogInformation("User {UserId} enabled 2FA", userId);
Logger.LogWarning("Invalid 2FA code attempt for user {UserId}", userId);
```

---

## ?? Estad�sticas y Monitoreo

### M�tricas Sugeridas

```csharp
// Usuarios con 2FA habilitado
var users2FA = await UserManager.Users
    .Where(u => u.TwoFactorEnabled)
  .CountAsync();

// Porcentaje de adopci�n
var totalUsers = await UserManager.Users.CountAsync();
var adoption2FA = (users2FA / (double)totalUsers) * 100;
```

### Consultas �tiles

```sql
-- Usuarios con 2FA habilitado
SELECT COUNT(*) FROM AspNetUsers WHERE TwoFactorEnabled = 1;

-- Usuarios sin 2FA
SELECT Email, UserName 
FROM AspNetUsers 
WHERE TwoFactorEnabled = 0;

-- Fecha de �ltima verificaci�n 2FA (requiere personalizaci�n)
SELECT UserName, Email, LastTwoFactorAuth
FROM AspNetUsers
WHERE TwoFactorEnabled = 1
ORDER BY LastTwoFactorAuth DESC;
```

---

## ?? Mejoras Futuras

### Corto Plazo
- [ ] Agregar soporte para m�ltiples dispositivos de autenticaci�n
- [ ] Implementar notificaciones por email cuando se habilita/deshabilita 2FA
- [ ] Agregar p�gina de gesti�n de dispositivos confiables

### Medio Plazo
- [ ] Soporte para WebAuthn/FIDO2 (llaves de seguridad f�sicas)
- [ ] Backup autom�tico de claves en la nube
- [ ] Generaci�n de c�digos de respaldo adicionales

### Largo Plazo
- [ ] Biometr�a como segundo factor
- [ ] Push notifications en lugar de c�digos TOTP
- [ ] An�lisis de riesgo para solicitar 2FA solo cuando sea necesario

---

## ?? Referencias

- [RFC 6238 - TOTP](https://tools.ietf.org/html/rfc6238)
- [ASP.NET Core Identity 2FA](https://learn.microsoft.com/aspnet/core/security/authentication/identity-enable-qrcodes)
- [QRCoder Documentation](https://github.com/codebude/QRCoder)
- [Key Uri Format](https://github.com/google/google-authenticator/wiki/Key-Uri-Format)

---

## ?? Soporte

Para problemas relacionados con 2FA en Salutia:
1. Revisa este documento primero
2. Consulta los logs en Output ? Debug
3. Verifica el archivo `TROUBLESHOOTING.md`
4. Revisa los issues en GitHub

---

**�ltima actualizaci�n**: 2025  
**Versi�n**: 1.0  
**Autor**: Equipo Salutia

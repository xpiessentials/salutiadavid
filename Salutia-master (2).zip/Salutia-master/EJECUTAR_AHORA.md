# ?? EJECUTAR AHORA - Test Psicosom�tico

## ?? Instrucci�n Inmediata

### Paso 1: Abrir PowerShell en la ra�z del proyecto

```
Ubicaci�n actual: D:\Desarrollos\Repos\Salutia\
```

### Paso 2: Ejecutar el script de migraci�n

```powershell
.\apply-psychosomatic-test-migration.ps1
```

### Paso 3: Confirmar con "S"

Cuando veas esto:

```
�Desea aplicar la migraci�n del Test Psicosom�tico?
Esto crear� las siguientes tablas:
  - PsychosomaticTests
  - TestWords
  - TestPhrases
  - TestEmotions
  - TestDiscomfortLevels
  - TestBodyParts
  - TestAssociatedPersons
  - TestMatrices

Continuar? (S/N)
```

**Escribe: S** y presiona Enter

---

## ? Verificaci�n

Si todo sali� bien, ver�s:

```
========================================
? Migraci�n aplicada exitosamente
========================================

Las tablas del Test Psicosom�tico han sido creadas.

Pr�ximos pasos:
1. Compile el proyecto: dotnet build
2. Ejecute la aplicaci�n: dotnet run --project '.\Salutia Wep App\Salutia Wep App.csproj'
3. Navegue a: /test-psicosomatico
```

---

## ?? Acceso R�pido

### Para Pacientes
```
https://localhost:[puerto]/test-psicosomatico
```

### Para Profesionales
```
https://localhost:[puerto]/patient-tests
```

---

## ?? Verificar en Base de Datos

Abre SQL Server Management Studio o ejecuta:

```sql
USE Salutia;
GO

-- Verificar que las tablas existen
SELECT TABLE_NAME 
FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_NAME LIKE 'Test%' OR TABLE_NAME = 'PsychosomaticTests'
ORDER BY TABLE_NAME;
```

Deber�as ver:

```
PsychosomaticTests
TestAssociatedPersons
TestBodyParts
TestDiscomfortLevels
TestEmotions
TestMatrices
TestPhrases
TestWords
```

---

## ?? Si hay Error

### Error: "Script SQL no encontrado"

**Soluci�n**: Aseg�rate de estar en la ra�z del proyecto
```powershell
cd D:\Desarrollos\Repos\Salutia\
```

### Error: "No se puede conectar a LocalDB"

**Soluci�n**: Inicia LocalDB
```powershell
sqllocaldb start MSSQLLocalDB
```

### Error: "Base de datos Salutia no existe"

**Soluci�n**: Crea la base de datos primero
```sql
CREATE DATABASE Salutia;
GO
```

---

## ?? Comandos Completos (Copy-Paste)

```powershell
# 1. Ir a la ra�z del proyecto
cd D:\Desarrollos\Repos\Salutia\

# 2. Ejecutar migraci�n
.\apply-psychosomatic-test-migration.ps1

# 3. Compilar
dotnet build

# 4. Ejecutar
dotnet run --project "Salutia Wep App\Salutia Wep App.csproj"
```

---

## ?? �Listo!

Una vez ejecutada la migraci�n, el Test Psicosom�tico estar� **100% funcional**.

**Archivos Creados:**
- ? 8 tablas en base de datos
- ? 3 p�ginas web funcionales
- ? 1 servicio backend completo
- ? Documentaci�n completa

**Tiempo estimado:** 2 minutos

---

**?? EJECUTA AHORA: `.\apply-psychosomatic-test-migration.ps1`**

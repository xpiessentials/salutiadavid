# ?? Gu�a: Registrar SuperAdmin en Salutia-TBE

## ?? Credenciales del SuperAdmin

- **Email:** `elpeco1@msn.com`
- **Contrase�a:** `Admin.123`
- **Rol:** SuperAdmin
- **SuperAdminKey:** `Salutia2025!Setup` (ya configurada en appsettings.json)

---

## ? M�todo 1: Registro desde la Aplicaci�n (RECOMENDADO)

Este es el m�todo m�s seguro porque ASP.NET Identity genera el hash de contrase�a correctamente.

### Pasos:

1. **Aplicar migraci�n (si no lo has hecho):**
   ```powershell
   Update-Database -Verbose
   ```

2. **Iniciar la aplicaci�n:**
   - Presiona **F5** en Visual Studio

3. **Navegar a la p�gina de registro:**
   - URL: `https://localhost:[puerto]/Account/RegisterSuperAdmin`
   - O desde la p�gina principal: Login > Register > "�Eres SuperAdmin?"

4. **Completar el formulario:**
   - Email: `elpeco1@msn.com`
   - Contrase�a: `Admin.123`
   - Confirmar Contrase�a: `Admin.123`
   - SuperAdmin Key: `Salutia2025!Setup`

5. **Hacer clic en:** "Registrar SuperAdmin"

6. **Iniciar sesi�n:**
   - Email: `elpeco1@msn.com`
   - Contrase�a: `Admin.123`

---

## ? M�todo 2: Script SQL Manual (Alternativo)

Si prefieres usar SQL directamente:

### PASO 1: Ejecutar Script Base en SSMS

Abre `CREATE-SUPERADMIN.sql` en SSMS y ejec�talo. Este script:
- ? Crea todos los roles del sistema
- ? Crea el usuario SuperAdmin
- ?? **IMPORTANTE:** El hash de contrase�a en el script es un placeholder

### PASO 2: Cambiar la Contrase�a desde la App

Despu�s de ejecutar el script, debes:

1. **Iniciar la aplicaci�n**
2. **Ir a:** `/Account/ForgotPassword`
3. **Ingresar:** `elpeco1@msn.com`
4. **Seguir el proceso de recuperaci�n**

O mejor a�n:

1. **Iniciar sesi�n con cualquier SuperAdmin temporal**
2. **Ir a:** `/Admin/Users`
3. **Editar el usuario:** `elpeco1@msn.com`
4. **Cambiar la contrase�a a:** `Admin.123`

---

## ?? M�todo 3: Usando .NET CLI (M�s Confiable)

Crear un comando de inicializaci�n en el c�digo:

### Crear Clase de Inicializaci�n:

**Ubicaci�n:** `Salutia Wep App\Data\DbInitializer.cs`

```csharp
using Microsoft.AspNetCore.Identity;
using Salutia_Wep_App.Data;

public static class DbInitializer
{
    public static async Task InitializeAsync(
        UserManager<ApplicationUser> userManager,
        RoleManager<IdentityRole> roleManager)
    {
        // Crear roles
        string[] roles = { "SuperAdmin", "EntityAdmin", "Doctor", "Psychologist", "Patient", "IndependentUser" };
        
        foreach (var role in roles)
        {
            if (!await roleManager.RoleExistsAsync(role))
            {
                await roleManager.CreateAsync(new IdentityRole(role));
            }
        }

        // Crear SuperAdmin
        string email = "elpeco1@msn.com";
        string password = "Admin.123";

        if (await userManager.FindByEmailAsync(email) == null)
        {
            var superAdmin = new ApplicationUser
            {
                UserName = email,
                Email = email,
                EmailConfirmed = true,
                UserType = UserType.SuperAdmin,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };

            var result = await userManager.CreateAsync(superAdmin, password);

            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(superAdmin, "SuperAdmin");
                Console.WriteLine($"? SuperAdmin creado: {email}");
            }
            else
            {
                Console.WriteLine($"? Error al crear SuperAdmin: {string.Join(", ", result.Errors.Select(e => e.Description))}");
            }
        }
        else
        {
            Console.WriteLine($"? SuperAdmin ya existe: {email}");
        }
    }
}
```

### Llamar desde Program.cs:

**Ubicaci�n:** `Salutia Wep App\Program.cs`

Agregar despu�s de `var app = builder.Build();`:

```csharp
// Inicializar base de datos con SuperAdmin
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        
        await DbInitializer.InitializeAsync(userManager, roleManager);
    }
    catch (Exception ex)
    {
        var logger = services.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "Error al inicializar la base de datos");
    }
}
```

**Luego ejecutar la aplicaci�n (F5)** y el SuperAdmin se crear� autom�ticamente.

---

## ? Verificaci�n en SSMS

Despu�s de crear el SuperAdmin (con cualquier m�todo), verifica en SSMS:

```sql
USE [Salutia-TBE]
GO

-- Verificar usuario
SELECT 
    u.Id,
    u.UserName,
    u.Email,
    u.EmailConfirmed,
    u.UserType,
    u.IsActive,
    STRING_AGG(r.Name, ', ') AS Roles
FROM AspNetUsers u
LEFT JOIN AspNetUserRoles ur ON u.Id = ur.UserId
LEFT JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE u.Email = 'elpeco1@msn.com'
GROUP BY u.Id, u.UserName, u.Email, u.EmailConfirmed, u.UserType, u.IsActive
GO

-- Verificar roles
SELECT * FROM AspNetRoles
GO
```

**Resultado esperado:**
```
UserName: elpeco1@msn.com
Email: elpeco1@msn.com
EmailConfirmed: 1
UserType: 0 (SuperAdmin)
IsActive: 1
Roles: SuperAdmin
```

---

## ?? Soluci�n de Problemas

### Problema: "Invalid login attempt"

**Causa:** Hash de contrase�a incorrecto (si usaste Script SQL)

**Soluci�n:**
1. Usa el M�todo 1 (Registro desde la App)
2. O usa el M�todo 3 (DbInitializer)

---

### Problema: "Email already exists"

**Soluci�n:** Eliminar el usuario existente y volver a crear:

```sql
USE [Salutia-TBE]
GO

-- Eliminar usuario existente
DELETE FROM AspNetUserRoles WHERE UserId IN (SELECT Id FROM AspNetUsers WHERE Email = 'elpeco1@msn.com')
DELETE FROM AspNetUsers WHERE Email = 'elpeco1@msn.com'
GO
```

Luego vuelve a ejecutar el m�todo de creaci�n.

---

### Problema: "Role 'SuperAdmin' does not exist"

**Soluci�n:** Ejecutar script de creaci�n de roles:

```sql
USE [Salutia-TBE]
GO

-- Crear rol SuperAdmin
IF NOT EXISTS (SELECT * FROM AspNetRoles WHERE Name = 'SuperAdmin')
BEGIN
    INSERT INTO AspNetRoles (Id, Name, NormalizedName, ConcurrencyStamp)
    VALUES (NEWID(), 'SuperAdmin', 'SUPERADMIN', NEWID())
END
GO
```

---

## ?? Resumen de M�todos

| M�todo | Ventajas | Desventajas | Recomendado |
|--------|----------|-------------|-------------|
| **1. Registro App** | ? M�s seguro<br>? Hash correcto<br>? Sin c�digo | ? Requiere UI | ????? |
| **2. Script SQL** | ? R�pido | ? Hash incorrecto<br>? Necesita cambio de password | ?? |
| **3. DbInitializer** | ? Autom�tico<br>? Reutilizable<br>? Hash correcto | ? Requiere c�digo | ???? |

---

## ?? Recomendaci�n Final

**Usa el M�todo 3 (DbInitializer)** porque:
1. ? Se ejecuta autom�ticamente al iniciar la app
2. ? Genera el hash de contrase�a correctamente
3. ? Es reutilizable para otros ambientes (test, prod)
4. ? No requiere intervenci�n manual

---

## ?? Acci�n Inmediata

�Qu� m�todo prefieres?

1. **M�todo 1:** Te gu�o para registrar desde la UI
2. **M�todo 2:** Ejecutas el script SQL (pero requerir� cambio de password)
3. **M�todo 3:** Creo el c�digo de `DbInitializer.cs` y lo agregas a `Program.cs`

Dime cu�l prefieres y te ayudo a completarlo. ??

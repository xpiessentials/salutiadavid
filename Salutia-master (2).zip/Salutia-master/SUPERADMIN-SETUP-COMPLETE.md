# ? SuperAdmin Configurado - Listo para Usar

## ?? Estado Actual

**SuperAdmin creado autom�ticamente al iniciar la aplicaci�n**

### Credenciales:
- **Email:** `elpeco1@msn.com`
- **Contrase�a:** `Admin.123`
- **Rol:** SuperAdmin

---

## ?? Pasos para Completar la Configuraci�n

### **PASO 1: Aplicar Migraci�n (Si no lo has hecho)**

```powershell
# En Package Manager Console
Update-Database -Verbose
```

Esto crear� todas las tablas en `Salutia-TBE`.

---

### **PASO 2: Iniciar la Aplicaci�n**

Presiona **F5** en Visual Studio.

**Cuando la aplicaci�n inicie, autom�ticamente:**
- ? Crear� todos los roles del sistema
- ? Crear� el SuperAdmin (`elpeco1@msn.com`)
- ? Asignar� el rol SuperAdmin
- ? Inicializar� datos geogr�ficos

**Ver�s en la consola de output:**
```
=== Iniciando inicializaci�n de base de datos ===
? Rol 'SuperAdmin' creado
? Rol 'EntityAdmin' creado
? Rol 'Doctor' creado
? Rol 'Psychologist' creado
? Rol 'Patient' creado
? Rol 'IndependentUser' creado
? Usuario SuperAdmin creado exitosamente
? Rol 'SuperAdmin' asignado al usuario elpeco1@msn.com
================================================
CREDENCIALES SUPERADMIN:
Email: elpeco1@msn.com
Contrase�a: Admin.123
================================================
=== Inicializaci�n de base de datos completada ===
```

---

### **PASO 3: Iniciar Sesi�n**

1. **Navega a:** `https://localhost:[puerto]/Account/Login`

2. **Ingresa credenciales:**
   - Email: `elpeco1@msn.com`
   - Contrase�a: `Admin.123`

3. **Hacer clic en:** "Iniciar Sesi�n"

**Ser�s redirigido al Dashboard de SuperAdmin:** `/Admin/Dashboard`

---

## ? Verificaci�n en Base de Datos

Puedes verificar que el SuperAdmin fue creado correctamente en SSMS:

```sql
USE [Salutia-TBE]
GO

-- Verificar usuario SuperAdmin
SELECT 
    u.Id AS 'UserId',
    u.UserName AS 'Usuario',
    u.Email AS 'Email',
    u.EmailConfirmed AS 'Email Confirmado',
    u.UserType AS 'Tipo Usuario',
    u.IsActive AS 'Activo',
    u.CreatedAt AS 'Fecha Creaci�n',
    STRING_AGG(r.Name, ', ') AS 'Roles'
FROM AspNetUsers u
LEFT JOIN AspNetUserRoles ur ON u.Id = ur.UserId
LEFT JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE u.Email = 'elpeco1@msn.com'
GROUP BY u.Id, u.UserName, u.Email, u.EmailConfirmed, u.UserType, u.IsActive, u.CreatedAt
GO

-- Verificar todos los roles
SELECT 
    Name AS 'Rol',
    NormalizedName AS 'Nombre Normalizado'
FROM AspNetRoles
ORDER BY Name
GO
```

**Resultado esperado:**
```
Usuario: elpeco1@msn.com
Email Confirmado: 1
Tipo Usuario: 0 (SuperAdmin)
Activo: 1
Roles: SuperAdmin
```

---

## ?? Archivos Modificados/Creados

### **Creados:**
1. ? `Salutia Wep App\Data\DbInitializer.cs` - Clase de inicializaci�n
2. ? `CREATE-SUPERADMIN.sql` - Script SQL alternativo
3. ? `SUPERADMIN-REGISTRATION-GUIDE.md` - Gu�a completa
4. ? `SUPERADMIN-SETUP-COMPLETE.md` - Este documento

### **Modificados:**
1. ? `Salutia Wep App\Program.cs` - Agregada inicializaci�n autom�tica

---

## ?? Funcionalidades del DbInitializer

### `DbInitializer.InitializeAsync()`
- ? Crea todos los roles del sistema
- ? Crea SuperAdmin predeterminado
- ? Verifica si el SuperAdmin ya existe
- ? Asigna roles autom�ticamente
- ? Registra todo en los logs

### `DbInitializer.CreateCustomSuperAdminAsync()`
- ? Permite crear SuperAdmins adicionales
- ? Con email y contrase�a personalizados

---

## ?? Pr�ximos Pasos

Una vez que hayas iniciado sesi�n como SuperAdmin, puedes:

1. **Ver Dashboard de Administraci�n:**
   - `/Admin/Dashboard`

2. **Gestionar Entidades:**
   - `/Admin/Entities` - Ver todas las entidades
   - `/Admin/CreateEntity` - Crear nueva entidad

3. **Agregar Profesionales:**
   - `/Admin/AddProfessional` - Agregar m�dico o psic�logo

4. **Gestionar Usuarios:**
   - `/Admin/Users` - Ver todos los usuarios del sistema

5. **Configuraci�n del Sistema:**
   - Crear roles adicionales si es necesario
   - Configurar permisos especiales

---

## ?? Si el SuperAdmin No Se Crea

### Verificar Logs:

1. **Abrir Output Window en Visual Studio:**
   - View > Output
   - Show output from: "Debug"

2. **Buscar mensajes de inicializaci�n:**
   ```
   === Iniciando inicializaci�n de base de datos ===
   ```

### Si hay errores:

```sql
-- Eliminar SuperAdmin existente y volver a intentar
USE [Salutia-TBE]
GO

DELETE FROM AspNetUserRoles WHERE UserId IN (SELECT Id FROM AspNetUsers WHERE Email = 'elpeco1@msn.com')
DELETE FROM AspNetUsers WHERE Email = 'elpeco1@msn.com'
GO
```

Luego reinicia la aplicaci�n (F5).

---

## ?? Comparaci�n con M�todos Alternativos

| M�todo | Estado | Ventaja |
|--------|--------|---------|
| **DbInitializer (Implementado)** | ? ACTIVO | Autom�tico, seguro, reutilizable |
| Script SQL Manual | ?? Alternativo | R�pido pero hash incorrecto |
| Registro desde UI | ?? Alternativo | Requiere navegaci�n manual |

---

## ? Checklist Final

- [x] `DbInitializer.cs` creado
- [x] `Program.cs` actualizado con `InitializeDatabaseAsync`
- [x] Compilaci�n exitosa
- [ ] Migraci�n aplicada (`Update-Database`)
- [ ] Aplicaci�n iniciada (F5)
- [ ] SuperAdmin creado (verificar en logs)
- [ ] Login exitoso con `elpeco1@msn.com` / `Admin.123`
- [ ] Dashboard de Admin accesible

---

## ?? �Listo para Usar!

**Tu aplicaci�n ahora:**
- ? Crea el SuperAdmin autom�ticamente al iniciar
- ? No requiere configuraci�n manual
- ? Funciona en todos los ambientes (dev, test, prod)
- ? Es f�cil de mantener y extender

---

**Ejecuta ahora:**
1. `Update-Database -Verbose` (si no lo has hecho)
2. Presiona **F5**
3. Inicia sesi�n con `elpeco1@msn.com` / `Admin.123`

�Disfruta tu aplicaci�n Salutia! ??

using Salutia.MobileApp.Data;
using Salutia.MobileApp.Data.Models;
using Salutia.Shared.Services;
using System.Net.Http.Json;

namespace Salutia.MobileApp.Services;

/// <summary>
/// Servicio de sincronizaci�n entre datos locales y remotos
/// </summary>
public class SyncService
{
    private readonly LocalDatabaseService _localDb;
    private readonly IAuthService _authService;
    private readonly HttpClient _httpClient;
    private bool _isSyncing;

    public event EventHandler<SyncStatusEventArgs>? SyncStatusChanged;
    public event EventHandler<SyncProgressEventArgs>? SyncProgressUpdated;

    public SyncService(
 LocalDatabaseService localDb,
        IAuthService authService,
        IHttpClientFactory httpClientFactory)
    {
     _localDb = localDb;
        _authService = authService;
        _httpClient = httpClientFactory.CreateClient("SalutiaAPI");
    }

    public bool IsSyncing => _isSyncing;

    /// <summary>
 /// Sincroniza todos los datos entre local y remoto
 /// </summary>
    public async Task<SyncResult> SyncAllAsync()
    {
        if (_isSyncing)
        {
      return new SyncResult 
   { 
    Success = false, 
        Message = "Sincronizaci�n ya en progreso" 
 };
        }

        _isSyncing = true;
        OnSyncStatusChanged(SyncStatus.Started, "Iniciando sincronizaci�n...");

        try
        {
            // Verificar autenticaci�n
        var isAuthenticated = await _authService.IsAuthenticatedAsync();
  if (!isAuthenticated)
       {
     return new SyncResult 
       { 
     Success = false, 
       Message = "No autenticado" 
           };
            }

       var currentUser = await _authService.GetCurrentUserAsync();
            if (currentUser == null)
      {
   return new SyncResult 
    { 
   Success = false, 
              Message = "Usuario no encontrado" 
     };
            }

            var result = new SyncResult { Success = true };

  // 1. Sincronizar citas
   OnSyncProgressUpdated("Sincronizando citas...", 25);
            await SyncAppointmentsAsync(currentUser.Id);

       // 2. Sincronizar registros de salud
     OnSyncProgressUpdated("Sincronizando registros de salud...", 50);
            await SyncHealthRecordsAsync(currentUser.Id);

            // 3. Sincronizar medicamentos
    OnSyncProgressUpdated("Sincronizando medicamentos...", 75);
            await SyncMedicationsAsync(currentUser.Id);

    // 4. Sincronizar recordatorios
      OnSyncProgressUpdated("Sincronizando recordatorios...", 90);
          await SyncRemindersAsync(currentUser.Id);

            OnSyncProgressUpdated("Sincronizaci�n completada", 100);
            OnSyncStatusChanged(SyncStatus.Completed, "Sincronizaci�n exitosa");

   return result;
     }
        catch (Exception ex)
        {
  OnSyncStatusChanged(SyncStatus.Failed, $"Error: {ex.Message}");
     return new SyncResult 
            { 
       Success = false, 
     Message = ex.Message 
     };
        }
      finally
        {
      _isSyncing = false;
     }
    }

    private async Task SyncAppointmentsAsync(string userId)
    {
        try
   {
     // 1. Subir cambios locales no sincronizados
        var unsyncedAppointments = await _localDb.GetUnsyncedAppointmentsAsync(userId);
   foreach (var appointment in unsyncedAppointments)
{
        try
        {
                 var response = await _httpClient.PostAsJsonAsync("/api/appointments", appointment);
         if (response.IsSuccessStatusCode)
      {
appointment.IsSynced = true;
          await _localDb.SaveAppointmentAsync(appointment);
        }
       }
            catch
       {
      // Continuar con el siguiente
  }
      }

    // 2. Descargar datos remotos
            try
    {
    var response = await _httpClient.GetAsync($"/api/appointments?userId={userId}");
     if (response.IsSuccessStatusCode)
                {
          var remoteAppointments = await response.Content.ReadFromJsonAsync<List<LocalAppointment>>();
        if (remoteAppointments != null)
          {
      foreach (var appointment in remoteAppointments)
 {
   appointment.IsSynced = true;
    await _localDb.SaveAppointmentAsync(appointment);
        }
              }
 }
            }
            catch
 {
           // Continuar con la siguiente entidad
       }
    }
        catch (Exception ex)
        {
        System.Diagnostics.Debug.WriteLine($"Error syncing appointments: {ex.Message}");
        }
    }

    private async Task SyncHealthRecordsAsync(string userId)
  {
        try
        {
 // Similar a SyncAppointmentsAsync
 // TODO: Implementar l�gica espec�fica
  }
  catch (Exception ex)
   {
    System.Diagnostics.Debug.WriteLine($"Error syncing health records: {ex.Message}");
        }
    }

    private async Task SyncMedicationsAsync(string userId)
    {
        try
        {
     // Similar a SyncAppointmentsAsync
            // TODO: Implementar l�gica espec�fica
        }
        catch (Exception ex)
        {
       System.Diagnostics.Debug.WriteLine($"Error syncing medications: {ex.Message}");
        }
    }

  private async Task SyncRemindersAsync(string userId)
    {
     try
     {
 // Similar a SyncAppointmentsAsync
            // TODO: Implementar l�gica espec�fica
        }
  catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Error syncing reminders: {ex.Message}");
     }
    }

    private void OnSyncStatusChanged(SyncStatus status, string message)
    {
        SyncStatusChanged?.Invoke(this, new SyncStatusEventArgs 
{ 
            Status = status, 
         Message = message,
     Timestamp = DateTime.Now
        });
    }

    private void OnSyncProgressUpdated(string message, int progressPercentage)
    {
        SyncProgressUpdated?.Invoke(this, new SyncProgressEventArgs 
     { 
  Message = message, 
      ProgressPercentage = progressPercentage 
    });
    }
}

/// <summary>
/// Resultado de la sincronizaci�n
/// </summary>
public class SyncResult
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public int ItemsSynced { get; set; }
    public DateTime SyncTime { get; set; } = DateTime.Now;
}

/// <summary>
/// Estado de sincronizaci�n
/// </summary>
public enum SyncStatus
{
    Idle,
    Started,
    InProgress,
    Completed,
    Failed
}

/// <summary>
/// Argumentos del evento de estado de sincronizaci�n
/// </summary>
public class SyncStatusEventArgs : EventArgs
{
    public SyncStatus Status { get; set; }
    public string Message { get; set; } = string.Empty;
    public DateTime Timestamp { get; set; }
}

/// <summary>
/// Argumentos del evento de progreso de sincronizaci�n
/// </summary>
public class SyncProgressEventArgs : EventArgs
{
    public string Message { get; set; } = string.Empty;
    public int ProgressPercentage { get; set; }
}

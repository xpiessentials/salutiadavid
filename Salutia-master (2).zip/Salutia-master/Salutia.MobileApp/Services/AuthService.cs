using System.Net.Http.Json;
using System.Text.Json;
using Salutia.Shared.Models;
using Salutia.Shared.Services;

namespace Salutia.MobileApp.Services;

/// <summary>
/// Implementaci�n del servicio de autenticaci�n para la aplicaci�n m�vil
/// </summary>
public class AuthService : IAuthService
{
    private readonly HttpClient _httpClient;
 private readonly ISecureStorageService _secureStorage;
    private const string TokenKey = "auth_token";
 private const string UserKey = "current_user";

    public AuthService(IHttpClientFactory httpClientFactory, ISecureStorageService secureStorage)
    {
      _httpClient = httpClientFactory.CreateClient("SalutiaAPI");
        _secureStorage = secureStorage;
    }

    public async Task<AuthResponse> LoginAsync(LoginRequest request)
    {
   try
   {
     var response = await _httpClient.PostAsJsonAsync("/api/auth/login", request);

            if (response.IsSuccessStatusCode)
  {
       var authResponse = await response.Content.ReadFromJsonAsync<AuthResponse>();
    
     if (authResponse?.Success == true && !string.IsNullOrEmpty(authResponse.Token))
      {
     // Guardar token y usuario
       await _secureStorage.SetAsync(TokenKey, authResponse.Token);
if (authResponse.User != null)
               {
 await _secureStorage.SetAsync(UserKey, JsonSerializer.Serialize(authResponse.User));
         }
        
        // Configurar el header de autorizaci�n
 _httpClient.DefaultRequestHeaders.Authorization = 
                 new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", authResponse.Token);
        }
         
       return authResponse ?? new AuthResponse 
 { 
          Success = false, 
     Message = "Respuesta inv�lida del servidor" 
      };
            }

         var errorContent = await response.Content.ReadAsStringAsync();
 return new AuthResponse 
 { 
        Success = false, 
          Message = $"Error de autenticaci�n: {response.StatusCode}" 
       };
 }
        catch (HttpRequestException ex)
  {
return new AuthResponse 
            { 
      Success = false, 
            Message = $"Error de conexi�n: {ex.Message}" 
       };
        }
        catch (Exception ex)
   {
            return new AuthResponse 
            { 
         Success = false, 
       Message = $"Error inesperado: {ex.Message}" 
     };
      }
    }

    public async Task<AuthResponse> RegisterAsync(RegisterRequest request)
    {
        try
        {
            var response = await _httpClient.PostAsJsonAsync("/api/auth/register", request);

    if (response.IsSuccessStatusCode)
  {
      var authResponse = await response.Content.ReadFromJsonAsync<AuthResponse>();
      return authResponse ?? new AuthResponse 
       { 
             Success = false, 
         Message = "Respuesta inv�lida del servidor" 
     };
            }

            var errorContent = await response.Content.ReadAsStringAsync();
            return new AuthResponse 
        { 
         Success = false, 
Message = $"Error de registro: {response.StatusCode}" 
            };
      }
    catch (Exception ex)
  {
     return new AuthResponse 
            { 
           Success = false, 
        Message = $"Error: {ex.Message}" 
            };
        }
    }

    public async Task<bool> LogoutAsync()
    {
        try
      {
      // Llamar al endpoint de logout si existe
        try
            {
     await _httpClient.PostAsync("/api/auth/logout", null);
          }
    catch
 {
           // Ignorar errores del servidor, limpiar localmente de todos modos
     }

  // Limpiar datos locales
    await _secureStorage.RemoveAsync(TokenKey);
            await _secureStorage.RemoveAsync(UserKey);
            
            // Limpiar header de autorizaci�n
            _httpClient.DefaultRequestHeaders.Authorization = null;

            return true;
        }
        catch
        {
            return false;
        }
  }

    public async Task<User?> GetCurrentUserAsync()
    {
        try
    {
            var userJson = await _secureStorage.GetAsync(UserKey);
            
         if (string.IsNullOrEmpty(userJson))
          {
   return null;
  }

return JsonSerializer.Deserialize<User>(userJson);
        }
      catch
        {
       return null;
        }
    }

    public async Task<bool> IsAuthenticatedAsync()
    {
        try
        {
            var token = await _secureStorage.GetAsync(TokenKey);
            
            if (string.IsNullOrEmpty(token))
  {
          return false;
      }

   // Configurar el header si existe el token
            _httpClient.DefaultRequestHeaders.Authorization = 
              new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

         return true;
        }
        catch
        {
          return false;
        }
    }

    public async Task<TwoFactorSetup> EnableTwoFactorAsync()
{
        try
    {
   var response = await _httpClient.PostAsync("/api/auth/enable-2fa", null);

  if (response.IsSuccessStatusCode)
            {
    var setup = await response.Content.ReadFromJsonAsync<TwoFactorSetup>();
       return setup ?? new TwoFactorSetup();
    }

         return new TwoFactorSetup();
        }
        catch
        {
            return new TwoFactorSetup();
        }
    }

    public async Task<bool> VerifyTwoFactorAsync(TwoFactorVerifyRequest request)
    {
  try
        {
  var response = await _httpClient.PostAsJsonAsync("/api/auth/verify-2fa", request);
        return response.IsSuccessStatusCode;
 }
        catch
        {
         return false;
        }
  }

  public async Task<bool> DisableTwoFactorAsync()
    {
      try
        {
            var response = await _httpClient.PostAsync("/api/auth/disable-2fa", null);
            return response.IsSuccessStatusCode;
  }
        catch
  {
        return false;
        }
    }
}

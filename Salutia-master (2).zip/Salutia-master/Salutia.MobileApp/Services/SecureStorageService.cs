namespace Salutia.MobileApp.Services;

/// <summary>
/// Interfaz para el servicio de almacenamiento seguro
/// </summary>
public interface ISecureStorageService
{
    Task<string?> GetAsync(string key);
    Task SetAsync(string key, string value);
    Task<bool> RemoveAsync(string key);
    Task RemoveAllAsync();
}

/// <summary>
/// Implementaci�n del servicio de almacenamiento seguro usando MAUI SecureStorage
/// </summary>
public class SecureStorageService : ISecureStorageService
{
    public async Task<string?> GetAsync(string key)
  {
        try
        {
        return await SecureStorage.GetAsync(key);
        }
        catch (Exception ex)
   {
            // Log error
            System.Diagnostics.Debug.WriteLine($"Error getting secure storage value: {ex.Message}");
            return null;
        }
    }

    public async Task SetAsync(string key, string value)
  {
        try
        {
 await SecureStorage.SetAsync(key, value);
 }
        catch (Exception ex)
        {
    // Log error
            System.Diagnostics.Debug.WriteLine($"Error setting secure storage value: {ex.Message}");
 throw;
      }
    }

    public Task<bool> RemoveAsync(string key)
  {
        try
        {
    SecureStorage.Remove(key);
     return Task.FromResult(true);
        }
      catch (Exception ex)
        {
            // Log error
     System.Diagnostics.Debug.WriteLine($"Error removing secure storage value: {ex.Message}");
         return Task.FromResult(false);
        }
    }

    public Task RemoveAllAsync()
    {
        try
  {
 SecureStorage.RemoveAll();
            return Task.CompletedTask;
        }
catch (Exception ex)
  {
      // Log error
       System.Diagnostics.Debug.WriteLine($"Error removing all secure storage values: {ex.Message}");
            throw;
  }
    }
}

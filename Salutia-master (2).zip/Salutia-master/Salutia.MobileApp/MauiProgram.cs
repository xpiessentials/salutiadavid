﻿using Microsoft.Extensions.Logging;
using CommunityToolkit.Maui;
using Salutia.MobileApp.Services;
using Salutia.MobileApp.Data;
using Salutia.Shared.Services;

namespace Salutia.MobileApp;

public static class MauiProgram
{
	public static MauiApp CreateMauiApp()
	{
		var builder = MauiApp.CreateBuilder();
		builder
			.UseMauiApp<App>()
			.UseMauiCommunityToolkit()
			.ConfigureFonts(fonts =>
			{
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
				fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
			});

		// Agregar soporte para Blazor Hybrid
		builder.Services.AddMauiBlazorWebView();

		// Configurar HttpClient para comunicación con la API
		builder.Services.AddHttpClient("SalutiaAPI", client =>
		{
			// TODO: Configurar la URL base de tu API
			client.BaseAddress = new Uri("https://localhost:7213/"); // Cambiar en producción
			client.Timeout = TimeSpan.FromSeconds(30);
		});

		// Registrar servicios de almacenamiento
		builder.Services.AddSingleton<ISecureStorageService, SecureStorageService>();
		builder.Services.AddSingleton<LocalDatabaseService>();

		// Registrar servicios de negocio
		builder.Services.AddScoped<IAuthService, AuthService>();
		builder.Services.AddScoped<SyncService>();

#if DEBUG
		builder.Logging.AddDebug();
		builder.Services.AddBlazorWebViewDeveloperTools();
#endif

		return builder.Build();
	}
}

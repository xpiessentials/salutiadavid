[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "Salutia.MobileApp")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "Salutia.MobileApp.Pages")]

using SQLite;

namespace Salutia.MobileApp.Data.Models;

/// <summary>
/// Modelo de usuario para almacenamiento offline
/// </summary>
[Table("Users")]
public class LocalUser
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }
    
    public string UserId { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
  public string UserName { get; set; } = string.Empty;
    public bool EmailConfirmed { get; set; }
    public bool TwoFactorEnabled { get; set; }
  public string PhoneNumber { get; set; } = string.Empty;
    public DateTime LastSynced { get; set; }
}

/// <summary>
/// Modelo de cita m�dica para almacenamiento offline
/// </summary>
[Table("Appointments")]
public class LocalAppointment
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }
    
    public string AppointmentId { get; set; } = string.Empty;
    public string UserId { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime AppointmentDate { get; set; }
    public string Location { get; set; } = string.Empty;
 public string Doctor { get; set; } = string.Empty;
 public string Status { get; set; } = string.Empty;
    public bool IsSynced { get; set; }
    public DateTime LastModified { get; set; }
}

/// <summary>
/// Modelo de registro de salud para almacenamiento offline
/// </summary>
[Table("HealthRecords")]
public class LocalHealthRecord
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }
    
    public string RecordId { get; set; } = string.Empty;
    public string UserId { get; set; } = string.Empty;
    public string RecordType { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime RecordDate { get; set; }
    public string Data { get; set; } = string.Empty; // JSON serializado
    public bool IsSynced { get; set; }
    public DateTime LastModified { get; set; }
}

/// <summary>
/// Modelo de medicamento para almacenamiento offline
/// </summary>
[Table("Medications")]
public class LocalMedication
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }
    
    public string MedicationId { get; set; } = string.Empty;
    public string UserId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Dosage { get; set; } = string.Empty;
    public string Frequency { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public string Instructions { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public bool IsSynced { get; set; }
    public DateTime LastModified { get; set; }
}

/// <summary>
/// Modelo de recordatorio para almacenamiento offline
/// </summary>
[Table("Reminders")]
public class LocalReminder
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }
    
    public string ReminderId { get; set; } = string.Empty;
    public string UserId { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime ReminderDateTime { get; set; }
    public string Type { get; set; } = string.Empty; // Medication, Appointment, etc.
    public string RelatedEntityId { get; set; } = string.Empty;
    public bool IsCompleted { get; set; }
    public bool IsSynced { get; set; }
    public DateTime LastModified { get; set; }
}

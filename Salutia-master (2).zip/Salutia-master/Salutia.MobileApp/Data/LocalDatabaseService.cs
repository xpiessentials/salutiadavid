using SQLite;
using Salutia.MobileApp.Data.Models;

namespace Salutia.MobileApp.Data;

/// <summary>
/// Servicio de base de datos local SQLite
/// </summary>
public class LocalDatabaseService
{
    private SQLiteAsyncConnection? _database;
    private readonly string _dbPath;

    public LocalDatabaseService()
    {
  _dbPath = Path.Combine(FileSystem.AppDataDirectory, "salutia.db3");
    }

    private async Task InitAsync()
    {
        if (_database is not null)
       return;

      _database = new SQLiteAsyncConnection(_dbPath);
        
      // Crear tablas
      await _database.CreateTableAsync<LocalUser>();
        await _database.CreateTableAsync<LocalAppointment>();
        await _database.CreateTableAsync<LocalHealthRecord>();
        await _database.CreateTableAsync<LocalMedication>();
        await _database.CreateTableAsync<LocalReminder>();
    }

    #region User Operations

    public async Task<LocalUser?> GetUserAsync(string userId)
    {
        await InitAsync();
    return await _database!.Table<LocalUser>()
   .Where(u => u.UserId == userId)
      .FirstOrDefaultAsync();
    }

    public async Task<int> SaveUserAsync(LocalUser user)
    {
        await InitAsync();
        user.LastSynced = DateTime.UtcNow;
        
        var existing = await GetUserAsync(user.UserId);
        if (existing != null)
{
          user.Id = existing.Id;
  return await _database!.UpdateAsync(user);
        }
        return await _database!.InsertAsync(user);
    }

  public async Task<int> DeleteUserAsync(string userId)
    {
        await InitAsync();
     return await _database!.Table<LocalUser>()
  .Where(u => u.UserId == userId)
     .DeleteAsync();
    }

    #endregion

  #region Appointment Operations

    public async Task<List<LocalAppointment>> GetAppointmentsAsync(string userId)
    {
        await InitAsync();
        return await _database!.Table<LocalAppointment>()
            .Where(a => a.UserId == userId)
.OrderByDescending(a => a.AppointmentDate)
            .ToListAsync();
    }

    public async Task<List<LocalAppointment>> GetUpcomingAppointmentsAsync(string userId)
    {
        await InitAsync();
        var now = DateTime.UtcNow;
  return await _database!.Table<LocalAppointment>()
            .Where(a => a.UserId == userId && a.AppointmentDate >= now)
       .OrderBy(a => a.AppointmentDate)
            .ToListAsync();
    }

    public async Task<LocalAppointment?> GetAppointmentAsync(string appointmentId)
    {
        await InitAsync();
return await _database!.Table<LocalAppointment>()
        .Where(a => a.AppointmentId == appointmentId)
    .FirstOrDefaultAsync();
    }

    public async Task<int> SaveAppointmentAsync(LocalAppointment appointment)
    {
        await InitAsync();
        appointment.LastModified = DateTime.UtcNow;
        
        var existing = await GetAppointmentAsync(appointment.AppointmentId);
        if (existing != null)
        {
            appointment.Id = existing.Id;
          return await _database!.UpdateAsync(appointment);
        }
        return await _database!.InsertAsync(appointment);
    }

    public async Task<int> DeleteAppointmentAsync(string appointmentId)
    {
        await InitAsync();
  return await _database!.Table<LocalAppointment>()
   .Where(a => a.AppointmentId == appointmentId)
    .DeleteAsync();
    }

    public async Task<List<LocalAppointment>> GetUnsyncedAppointmentsAsync(string userId)
 {
        await InitAsync();
     return await _database!.Table<LocalAppointment>()
        .Where(a => a.UserId == userId && !a.IsSynced)
            .ToListAsync();
    }

    #endregion

    #region Health Record Operations

  public async Task<List<LocalHealthRecord>> GetHealthRecordsAsync(string userId)
    {
     await InitAsync();
        return await _database!.Table<LocalHealthRecord>()
            .Where(h => h.UserId == userId)
       .OrderByDescending(h => h.RecordDate)
            .ToListAsync();
    }

    public async Task<LocalHealthRecord?> GetHealthRecordAsync(string recordId)
    {
        await InitAsync();
        return await _database!.Table<LocalHealthRecord>()
.Where(h => h.RecordId == recordId)
            .FirstOrDefaultAsync();
    }

    public async Task<int> SaveHealthRecordAsync(LocalHealthRecord record)
    {
        await InitAsync();
        record.LastModified = DateTime.UtcNow;
        
        var existing = await GetHealthRecordAsync(record.RecordId);
        if (existing != null)
        {
          record.Id = existing.Id;
     return await _database!.UpdateAsync(record);
        }
        return await _database!.InsertAsync(record);
    }

    public async Task<int> DeleteHealthRecordAsync(string recordId)
    {
        await InitAsync();
  return await _database!.Table<LocalHealthRecord>()
            .Where(h => h.RecordId == recordId)
.DeleteAsync();
    }

    #endregion

    #region Medication Operations

    public async Task<List<LocalMedication>> GetMedicationsAsync(string userId)
    {
  await InitAsync();
        return await _database!.Table<LocalMedication>()
            .Where(m => m.UserId == userId)
     .OrderBy(m => m.Name)
            .ToListAsync();
    }

    public async Task<List<LocalMedication>> GetActiveMedicationsAsync(string userId)
    {
        await InitAsync();
        return await _database!.Table<LocalMedication>()
            .Where(m => m.UserId == userId && m.IsActive)
         .OrderBy(m => m.Name)
            .ToListAsync();
    }

    public async Task<LocalMedication?> GetMedicationAsync(string medicationId)
    {
        await InitAsync();
        return await _database!.Table<LocalMedication>()
            .Where(m => m.MedicationId == medicationId)
            .FirstOrDefaultAsync();
    }

    public async Task<int> SaveMedicationAsync(LocalMedication medication)
    {
        await InitAsync();
        medication.LastModified = DateTime.UtcNow;
        
        var existing = await GetMedicationAsync(medication.MedicationId);
        if (existing != null)
        {
            medication.Id = existing.Id;
        return await _database!.UpdateAsync(medication);
        }
        return await _database!.InsertAsync(medication);
    }

    public async Task<int> DeleteMedicationAsync(string medicationId)
    {
  await InitAsync();
     return await _database!.Table<LocalMedication>()
            .Where(m => m.MedicationId == medicationId)
            .DeleteAsync();
    }

    #endregion

    #region Reminder Operations

    public async Task<List<LocalReminder>> GetRemindersAsync(string userId)
    {
    await InitAsync();
     return await _database!.Table<LocalReminder>()
  .Where(r => r.UserId == userId)
            .OrderBy(r => r.ReminderDateTime)
      .ToListAsync();
    }

    public async Task<List<LocalReminder>> GetPendingRemindersAsync(string userId)
 {
 await InitAsync();
        var now = DateTime.UtcNow;
  return await _database!.Table<LocalReminder>()
  .Where(r => r.UserId == userId && !r.IsCompleted && r.ReminderDateTime >= now)
            .OrderBy(r => r.ReminderDateTime)
   .ToListAsync();
    }

    public async Task<LocalReminder?> GetReminderAsync(string reminderId)
    {
        await InitAsync();
        return await _database!.Table<LocalReminder>()
    .Where(r => r.ReminderId == reminderId)
    .FirstOrDefaultAsync();
    }

    public async Task<int> SaveReminderAsync(LocalReminder reminder)
    {
        await InitAsync();
        reminder.LastModified = DateTime.UtcNow;
      
        var existing = await GetReminderAsync(reminder.ReminderId);
        if (existing != null)
    {
   reminder.Id = existing.Id;
      return await _database!.UpdateAsync(reminder);
        }
        return await _database!.InsertAsync(reminder);
    }

    public async Task<int> DeleteReminderAsync(string reminderId)
    {
        await InitAsync();
        return await _database!.Table<LocalReminder>()
            .Where(r => r.ReminderId == reminderId)
          .DeleteAsync();
    }

    #endregion

 #region Sync Operations

    public async Task<bool> HasUnsyncedDataAsync(string userId)
    {
        await InitAsync();
        
        var unsyncedAppointments = await _database!.Table<LocalAppointment>()
        .Where(a => a.UserId == userId && !a.IsSynced)
        .CountAsync();
            
     var unsyncedRecords = await _database!.Table<LocalHealthRecord>()
            .Where(h => h.UserId == userId && !h.IsSynced)
    .CountAsync();
     
        var unsyncedMedications = await _database!.Table<LocalMedication>()
     .Where(m => m.UserId == userId && !m.IsSynced)
            .CountAsync();
            
        var unsyncedReminders = await _database!.Table<LocalReminder>()
            .Where(r => r.UserId == userId && !r.IsSynced)
            .CountAsync();
          
        return (unsyncedAppointments + unsyncedRecords + unsyncedMedications + unsyncedReminders) > 0;
    }

    public async Task MarkAllAsSyncedAsync(string userId)
    {
        await InitAsync();
        
        // Marcar todas las entidades como sincronizadas
  var appointments = await GetUnsyncedAppointmentsAsync(userId);
      foreach (var appointment in appointments)
        {
 appointment.IsSynced = true;
            await _database!.UpdateAsync(appointment);
        }
        
        // Similar para otras entidades...
    }

    #endregion

    #region Database Maintenance

    public async Task<int> GetDatabaseSizeAsync()
    {
        if (!File.Exists(_dbPath))
      return 0;
 
        var fileInfo = new FileInfo(_dbPath);
  return (int)(fileInfo.Length / 1024); // Size in KB
    }

    public async Task ClearAllDataAsync()
    {
        await InitAsync();
        
        await _database!.DeleteAllAsync<LocalUser>();
        await _database!.DeleteAllAsync<LocalAppointment>();
        await _database!.DeleteAllAsync<LocalHealthRecord>();
        await _database!.DeleteAllAsync<LocalMedication>();
        await _database!.DeleteAllAsync<LocalReminder>();
    }

    public async Task VacuumDatabaseAsync()
    {
        await InitAsync();
        await _database!.ExecuteAsync("VACUUM");
    }

    #endregion
}

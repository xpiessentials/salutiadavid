# ?? Inicio R�pido - Test Psicosom�tico

## ? 3 Pasos para Empezar

### 1?? Aplicar Migraci�n (1 minuto)

Ejecuta el script PowerShell desde la ra�z del proyecto:

```powershell
.\apply-psychosomatic-test-migration.ps1
```

Presiona **S** cuando te pida confirmaci�n.

### 2?? Ejecutar la Aplicaci�n (30 segundos)

```bash
dotnet run --project "Salutia Wep App\Salutia Wep App.csproj"
```

### 3?? Probar el Test (2 minutos)

1. Abre el navegador en `https://localhost:[puerto]`
2. Inicia sesi�n con cualquier usuario
3. Ve a: `/test-psicosomatico`
4. Completa las 6 preguntas

---

## ?? �Qu� hace el Test?

El test captura **10 respuestas** en cada una de estas **6 preguntas**:

| # | Pregunta | Ejemplo de Respuesta |
|---|----------|---------------------|
| 1 | Palabras que causan malestar | "Trabajo", "Dinero", "Madre" |
| 2 | Frase para cada palabra | "Tengo demasiado trabajo" |
| 3 | Emoci�n que siente | "Ansiedad", "Tristeza" |
| 4 | Nivel de malestar (1-10) | 8 |
| 5 | Parte del cuerpo | "Cabeza", "Est�mago" |
| 6 | Persona asociada | "Mi jefe", "Mi padre" |

Al finalizar, **autom�ticamente** se crea una matriz consolidada en la base de datos.

---

## ??? �D�nde se guardan los datos?

### Tabla Principal: `TestMatrices`

```sql
-- Ver la matriz completa de un paciente
SELECT * FROM TestMatrices 
WHERE PsychosomaticTestId = 1
ORDER BY WordNumber;
```

Resultado:

| WordNumber | Word | Phrase | Emotion | DiscomfortLevel | BodyPart | AssociatedPerson |
|------------|------|--------|---------|-----------------|----------|------------------|
| 1 | Trabajo | Tengo demasiado trabajo | Ansiedad | 8 | Cabeza | Mi jefe |
| 2 | Dinero | No tengo suficiente | Miedo | 7 | Est�mago | Mi padre |
| ... | ... | ... | ... | ... | ... | ... |

---

## ?? Caracter�sticas Clave

? **Una sola vez**: El paciente solo puede hacer el test una vez  
? **Sin retroceso**: No puede volver a preguntas anteriores  
? **Validaci�n autom�tica**: Debe completar las 10 respuestas antes de continuar  
? **Guardado autom�tico**: Cada pregunta se guarda al hacer clic en "Siguiente"  
? **Matriz autom�tica**: Se construye al finalizar la pregunta 6  

---

## ?? Consultas �tiles

### Ver todos los tests completados

```sql
SELECT 
    u.Email,
 pt.StartedAt,
    pt.CompletedAt,
    DATEDIFF(MINUTE, pt.StartedAt, pt.CompletedAt) AS MinutosParaCompletar
FROM PsychosomaticTests pt
INNER JOIN AspNetUsers u ON pt.PatientUserId = u.Id
WHERE pt.IsCompleted = 1;
```

### Nivel promedio de malestar

```sql
SELECT 
    AVG(CAST(DiscomfortLevel AS FLOAT)) AS PromedioMalestar
FROM TestMatrices
WHERE PsychosomaticTestId = 1;
```

### Emociones m�s frecuentes

```sql
SELECT 
    Emotion,
    COUNT(*) AS Frecuencia
FROM TestMatrices
GROUP BY Emotion
ORDER BY Frecuencia DESC;
```

---

## ?? Troubleshooting R�pido

### ? Error: "Test no encontrado"
**Soluci�n**: El usuario no est� autenticado. Inicia sesi�n primero.

### ? Error: "Ya has completado este test"
**Soluci�n**: Por dise�o. Para resetear (solo en desarrollo):
```sql
UPDATE PsychosomaticTests 
SET IsCompleted = 0, CompletedAt = NULL 
WHERE PatientUserId = '[UserId]';
```

### ? Error: "Se requieren exactamente 10 respuestas"
**Soluci�n**: Completa todos los campos antes de hacer clic en "Siguiente".

---

## ?? Archivos Importantes

| Archivo | Descripci�n |
|---------|-------------|
| `Models/PsychosomaticTest/PsychosomaticTestModels.cs` | Modelos de datos |
| `Services/PsychosomaticTestService.cs` | L�gica del test |
| `Components/Pages/TestPsicosomatico.razor` | Interfaz de usuario |
| `Data/Migrations/CreatePsychosomaticTestTables.sql` | Script de migraci�n |
| `PSYCHOSOMATIC_TEST_GUIDE.md` | Gu�a completa |

---

## ?? Vista Previa de la UI

```
???????????????????????????????????????
?  Test Psicosom�tico      ?
?  Pregunta 1 de 6         ?
?  ?????????????????????????? 16%  ?
?  Identificando palabras...          ?
???????????????????????????????????????
?  Escriba 10 palabras que le causan  ?
?  malestar:    ?
?     ?
?  Palabra 1: [___________________]   ?
?  Palabra 2: [___________________]   ?
?  ...  ?
?  Palabra 10: [__________________]   ?
?       ?
?  [  Siguiente Pregunta  ?  ]        ?
???????????????????????????????????????
```

---

## ?? Siguiente Paso: Ver Resultados

Para crear una p�gina de resultados, consulta la secci�n **"Pr�ximos Pasos Sugeridos"** en `PSYCHOSOMATIC_TEST_GUIDE.md`.

---

**�Listo para usar! ??**

?? Ejecuta: `.\apply-psychosomatic-test-migration.ps1`

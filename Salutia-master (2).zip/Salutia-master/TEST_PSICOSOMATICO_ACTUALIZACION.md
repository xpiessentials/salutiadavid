# ?? TEST PSICOSOM�TICO - ACTUALIZACI�N COMPLETA

## ? Cambios Realizados

Se ha actualizado el Test Psicosom�tico con una nueva pregunta y reorganizaci�n:

### ?? Nueva Estructura (7 Preguntas)

| # | Pregunta | Descripci�n |
|---|----------|-------------|
| 1 | **Palabras** | 10 palabras que causan malestar |
| 2 | **Frases** | Una frase para cada palabra |
| 3 | **Emociones** | Qu� emoci�n siente con cada frase |
| 4 | **Nivel de Malestar** | Califique de 1 a 10 |
| 5 | **Edad** | ? **NUEVA**: A qu� edad sinti� el malestar |
| 6 | **Parte del Cuerpo** | En qu� parte del cuerpo lo siente |
| 7 | **Persona Asociada** | A qu� persona asocia el malestar |

---

## ?? Nueva Tabla en la Base de Datos

### TestAges

Almacena la edad en que se sinti� el malestar por primera vez.

```sql
CREATE TABLE TestAges (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    PsychosomaticTestId INT NOT NULL,
    WordNumber INT NOT NULL,
    Age NVARCHAR(50) NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    
    CONSTRAINT FK_TestAges_PsychosomaticTests 
        FOREIGN KEY (PsychosomaticTestId) REFERENCES PsychosomaticTests(Id) ON DELETE CASCADE,
    CONSTRAINT CK_TestAges_WordNumber CHECK (WordNumber BETWEEN 1 AND 10)
);
```

---

## ??? Tablas Totales (9 tablas)

| # | Tabla | Registros | Descripci�n |
|---|-------|-----------|-------------|
| 1 | `PsychosomaticTests` | 1 | Test principal |
| 2 | `TestWords` | 10 | Palabras |
| 3 | `TestPhrases` | 10 | Frases |
| 4 | `TestEmotions` | 10 | Emociones |
| 5 | `TestDiscomfortLevels` | 10 | Niveles (1-10) |
| 6 | `TestAges` | 10 | ? Edades |
| 7 | `TestBodyParts` | 10 | Partes del cuerpo |
| 8 | `TestAssociatedPersons` | 10 | Personas |
| 9 | `TestMatrices` | 10 | **Matriz consolidada** |

---

## ?? C�mo Aplicar los Cambios

### Paso 1: Ejecutar la Migraci�n

**Si las tablas NO existen** (primera vez):

```powershell
.\EJECUTAR_ESTO.ps1
```

**Si las tablas ya existen** (actualizaci�n):

Tienes 2 opciones:

#### Opci�n A: Recrear todas las tablas (?? Se pierden datos)

```powershell
.\EJECUTAR_ESTO.ps1
# Responder "S" cuando pregunte si desea recrear
```

#### Opci�n B: Agregar solo la nueva tabla (? Mantiene datos)

```sql
-- Ejecutar manualmente en SQL Server Management Studio
USE Salutia;
GO

-- Crear tabla TestAges
CREATE TABLE TestAges (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    PsychosomaticTestId INT NOT NULL,
    WordNumber INT NOT NULL,
    Age NVARCHAR(50) NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    
    CONSTRAINT FK_TestAges_PsychosomaticTests 
        FOREIGN KEY (PsychosomaticTestId) REFERENCES PsychosomaticTests(Id) ON DELETE CASCADE,
    CONSTRAINT CK_TestAges_WordNumber CHECK (WordNumber BETWEEN 1 AND 10)
);

CREATE UNIQUE NONCLUSTERED INDEX IX_TestAges_TestId_WordNumber 
    ON TestAges(PsychosomaticTestId, WordNumber);
GO

-- Agregar columna Age a TestMatrices
ALTER TABLE TestMatrices
ADD Age NVARCHAR(50) NOT NULL DEFAULT '';
GO

PRINT '? Actualizaci�n completada';
GO
```

### Paso 2: Compilar y Ejecutar

```powershell
# Compilar
dotnet build

# Ejecutar
dotnet run --project ".\Salutia Wep App\Salutia Wep App.csproj"
```

---

## ?? Interfaz de la Pregunta 5

La nueva pregunta muestra:

```
??????????????????????????????????????????????????
?  5. Escriba a qu� edad sinti� el malestar     ?
??????????????????????????????????????????????????

Para cada palabra y frase, indique la edad aproximada 
en la que sinti� este malestar por primera vez.

??????????????????????????????????????????????????
? 1. [Palabra]                                   ?
? [Frase asociada]                               ?
?                                                ?
? Edad: [_________________]                      ?
?       Ej: 15 a�os, 5 a�os, Desde ni�o...       ?
??????????????????????????????????????????????????

... (Se repite para las 10 palabras)

[Siguiente Pregunta ?]
```

---

## ?? Actualizaci�n en la Matriz de Resultados

La matriz ahora incluye la columna **Edad**:

| # | Palabra | Frase | Emoci�n | Nivel | **Edad** | Cuerpo | Persona |
|---|---------|-------|---------|-------|----------|--------|---------|
| 1 | Miedo | Me da miedo... | Ansiedad | 8 | **15 a�os** | Pecho | Mi padre |
| 2 | Soledad | Me siento solo... | Tristeza | 7 | **10 a�os** | Est�mago | Yo mismo |

---

## ?? Archivos Modificados

### 1. Modelos
- `PsychosomaticTestModels.cs`
  - ? Agregado `TestAge` class
  - ? Actualizado `TestMatrix` con propiedad `Age`

### 2. Base de Datos
- `ApplicationDbContext.cs`
  - ? Agregado `DbSet<TestAge>`
  - ? Configuraci�n de `TestAge`
  - ? Actualizada configuraci�n de `TestMatrix`

### 3. Migraci�n SQL
- `CreatePsychosomaticTestTables.sql`
  - ? Agregada tabla `TestAges`
  - ? Actualizada tabla `TestMatrices` con columna `Age`

### 4. Servicio
- `PsychosomaticTestService.cs`
  - ? Agregado `SaveAgesAsync()`
  - ? Actualizado `BuildMatrixAsync()` para incluir edades
  - ? Actualizado orden de preguntas (5?6, 6?7)

### 5. Interfaz
- `TestPsicosomatico.razor`
  - ? Agregada Pregunta 5 (Edad)
  - ? Renumeradas Preguntas 6 y 7
  - ? Actualizada barra de progreso (7 preguntas)
  - ? Agregado array `ages[]`
  - ? Agregado m�todo `SaveAgesAndNext()`

### 6. Resultados
- `TestPsychosomaticResults.razor`
  - ? Agregada columna Edad en la tabla
  - ? Actualizado ancho de columnas

### 7. Scripts
- `EJECUTAR_ESTO.ps1`
  - ? Actualizado para verificar 9 tablas
  - ? Actualizada confirmaci�n con TestAges

---

## ? Verificaci�n

### Comprobar que todo funciona:

```powershell
# 1. Verificar tablas
sqlcmd -S "LAPTOP-DAVID\SQLEXPRESS" -d "Salutia" -E -Q "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE 'Test%' OR TABLE_NAME = 'PsychosomaticTests'"
```

**Deber�as ver 9 tablas:**
```
PsychosomaticTests
TestAges             ? Nueva
TestAssociatedPersons
TestBodyParts
TestDiscomfortLevels
TestEmotions
TestMatrices
TestPhrases
TestWords
```

### Verificar estructura de TestAges:

```sql
SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'TestAges';
```

**Resultado esperado:**
```
COLUMN_NAME              DATA_TYPE    LENGTH
Id                      int          NULL
PsychosomaticTestId     int          NULL
WordNumber              int          NULL
Age                     nvarchar     50
CreatedAt               datetime2    NULL
```

### Verificar TestMatrices incluye Age:

```sql
SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'TestMatrices'
ORDER BY ORDINAL_POSITION;
```

**Debe incluir:**
```
Id
PsychosomaticTestId
WordNumber
Word
Phrase
Emotion
DiscomfortLevel
Age                     ? Debe estar presente
BodyPart
AssociatedPerson
CreatedAt
```

---

## ?? Flujo Actualizado del Test

```mermaid
graph TD
    A[Inicio] --> B[Pregunta 1: 10 Palabras]
    B --> C[Pregunta 2: 10 Frases]
    C --> D[Pregunta 3: 10 Emociones]
    D --> E[Pregunta 4: 10 Niveles 1-10]
    E --> F[Pregunta 5: 10 Edades ? NUEVA]
    F --> G[Pregunta 6: 10 Partes del Cuerpo]
    G --> H[Pregunta 7: 10 Personas]
    H --> I[Construir Matriz]
    I --> J[Test Completado ?]
```

---

## ?? Casos de Uso

### Ejemplo de respuesta para la Pregunta 5:

**Palabra:** Miedo  
**Frase:** Me da miedo la oscuridad  
**Edad:** `5 a�os` o `Desde ni�o` o `15 a�os aproximadamente`

El campo acepta:
- ? Edades num�ricas: `5`, `15 a�os`
- ? Rangos: `Entre 10 y 15 a�os`
- ? Descripciones: `Desde ni�o`, `De adulto`, `No recuerdo`
- ? M�ximo 50 caracteres

---

## ?? Troubleshooting

### Error: "Columna Age no existe en TestMatrices"

**Soluci�n:**
```sql
ALTER TABLE TestMatrices ADD Age NVARCHAR(50) NOT NULL DEFAULT '';
```

### Error: "Tabla TestAges no existe"

**Soluci�n:**
```powershell
.\EJECUTAR_ESTO.ps1
```

### Compilaci�n exitosa pero error en ejecuci�n

**Verificar:**
1. La base de datos tiene las 9 tablas
2. `TestMatrices` tiene la columna `Age`
3. La aplicaci�n est� usando la conexi�n correcta

---

## ?? Resumen de Cambios

| Componente | Antes | Ahora | Cambio |
|------------|-------|-------|--------|
| **Preguntas** | 6 | 7 | +1 (Edad) |
| **Tablas** | 8 | 9 | +1 (TestAges) |
| **Columnas en TestMatrices** | 8 | 9 | +1 (Age) |
| **Orden Pregunta "Parte del Cuerpo"** | 5 | 6 | Movida |
| **Orden Pregunta "Persona"** | 6 | 7 | Movida |

---

## ? Checklist de Implementaci�n

- [x] Modelo `TestAge` creado
- [x] `TestMatrix.Age` agregado
- [x] `ApplicationDbContext` actualizado
- [x] Script SQL actualizado con `TestAges`
- [x] `TestMatrices` actualizada en SQL
- [x] Servicio `SaveAgesAsync()` implementado
- [x] `BuildMatrixAsync()` actualizado
- [x] Pregunta 5 agregada en UI
- [x] Preguntas 6 y 7 renumeradas
- [x] Resultados actualizados con columna Edad
- [x] Script PowerShell actualizado
- [x] Compilaci�n exitosa ?

---

## ?? �Listo para Usar!

El test psicosom�tico ahora incluye la pregunta sobre la edad en que se sinti� el malestar, proporcionando informaci�n m�s completa para el an�lisis terap�utico.

**Siguiente paso:**
```powershell
.\EJECUTAR_ESTO.ps1
```

O si quieres mantener datos existentes, ejecuta el script SQL de actualizaci�n manual.

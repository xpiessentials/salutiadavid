# ?? GU�A R�PIDA - Agregar Profesionales

## ? IMPLEMENTACI�N COMPLETA

Tanto **SuperAdmin** como **EntityAdmin** ya pueden agregar profesionales.

---

## ?? RUTAS DISPONIBLES

### SuperAdmin:
- **Men�**: "Agregar Profesional"
- **Ruta**: `/Admin/AddProfessional`
- **Caracter�stica**: Selecciona la entidad a la que pertenece el profesional

### EntityAdmin:
- **Men�**: "Agregar Profesional"
- **Ruta**: `/Entity/AddProfessional`
- **Caracter�stica**: Crea profesionales autom�ticamente para su entidad

---

## ?? ANTES DE USAR

### 1. Ejecutar Migraciones SQL (Si no lo has hecho)

**En SQL Server Management Studio:**

1. Ejecutar `UpdateToNewUserSystem.sql`
2. Ejecutar `UpdateUserRoles.sql`

### 2. Reiniciar Aplicaci�n

```powershell
cd "Salutia Wep App"
dotnet run
```

---

## ?? USO R�PIDO

### Como SuperAdmin:

1. Login como SuperAdmin
2. Men� ? "Agregar Profesional"
3. **Seleccionar Entidad** en el dropdown
4. Llenar formulario
5. Clic en "Agregar Profesional"

### Como EntityAdmin:

1. Login como EntityAdmin
2. Men� ? "Agregar Profesional"
3. Llenar formulario (sin seleccionar entidad)
4. Clic en "Agregar Profesional"

---

## ?? CAMPOS DEL FORMULARIO

### Obligatorios (*):
- **[SuperAdmin]** Entidad *
- Nombre Completo *
- Tipo de Profesional * (M�dico/Psic�logo)
- Especialidad *
- Licencia Profesional *
- Tipo de Documento *
- N�mero de Documento *
- Email *
- Contrase�a *
- Confirmar Contrase�a *

### Opcionales:
- Tel�fono
- Pa�s, Estado, Ciudad
- Direcci�n

---

## ? VERIFICACI�N

### Despu�s de crear un profesional:

**SuperAdmin**:
- Redirige a `/Admin/Users`
- Busca el email del profesional creado
- Debe aparecer con tipo "Doctor" o "Psychologist"

**EntityAdmin**:
- Redirige a `/Entity/ManageProfessionals`
- El profesional debe aparecer en la lista
- Estado: Activo

### En la Base de Datos:

```sql
-- Ver profesionales creados
SELECT 
 ep.FullName,
  ep.Specialty,
    ep.ProfessionalLicense,
    u.Email,
 u.UserType,
    e.BusinessName as Entidad
FROM EntityProfessionalProfiles ep
INNER JOIN AspNetUsers u ON ep.ApplicationUserId = u.Id
INNER JOIN EntityUserProfiles e ON ep.EntityId = e.Id;

-- Ver roles asignados
SELECT u.Email, r.Name as Role
FROM AspNetUsers u
INNER JOIN AspNetUserRoles ur ON u.Id = ur.UserId
INNER JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE u.UserType IN (3, 4); -- Doctor (3), Psychologist (4)
```

---

## ?? SOLUCI�N DE PROBLEMAS

### Error: "Debes especificar la entidad..."
**Soluci�n**: SuperAdmin debe seleccionar una entidad en el dropdown

### Error: "El email ya est� registrado"
**Soluci�n**: Usa un email diferente, ese ya existe en el sistema

### Error: "Ya existe un profesional con ese n�mero de documento..."
**Soluci�n**: Ese documento ya est� registrado para un profesional en esa entidad

### No aparece el dropdown de entidades (SuperAdmin)
**Soluci�n**: Verifica que existan entidades registradas en `EntityUserProfiles`

### Build falla: "archivo en uso"
**Soluci�n**: Det�n la aplicaci�n (Ctrl+C) antes de compilar

---

## ?? FLUJO COMPLETO

```
SuperAdmin           Sistema           Base de Datos
    |       |           |
    |-- Selecciona Entidad ------>|    |
    |-- Llena Formulario -------->|    |
    |-- Submit ------------------>|        |
  |    |-- Valida Email ----------->|
    |      |<-- Email OK --------------|
    |          |-- Valida Documento ------->|
    |   |<-- Doc OK ----------------|
    |           |-- Crea User ------------->|
    |           |-- Crea Profile ----------->|
    |          |-- Asigna Rol ------------->|
    |<-- �xito -------------------|           |
    |-- Redirige a Users   |             |


EntityAdmin       Sistema   Base de Datos
    |                  |      |
    |-- Llena Formulario -------->|         |
    |-- Submit ------------------>|       |
    ||-- Obtiene EntityId ------->|
    |       |-- Valida Email ----------->|
    |        |<-- Email OK --------------|
    |          |-- Valida Documento ------->|
    |          |<-- Doc OK ----------------|
    |           |-- Crea User ------------->|
    |           |-- Crea Profile ----------->|
    |         |-- Asigna Rol ------------->|
    |<-- �xito -------------------|        |
|-- Redirige a Professionals  |       |
```

---

## ?? RESULTADO ESPERADO

Despu�s de registrar un profesional:

1. ? Usuario creado en `AspNetUsers`
2. ? Perfil creado en `EntityProfessionalProfiles`
3. ? Rol asignado (`Doctor` o `Psychologist`)
4. ? Puede iniciar sesi�n con el email y contrase�a
5. ? Aparece en la lista de profesionales
6. ? Tiene acceso a su dashboard correspondiente

---

## ?? AYUDA ADICIONAL

Para m�s detalles, consulta:
- `PROFESSIONAL_REGISTRATION_COMPLETE.md` - Documentaci�n completa
- `EJECUTAR_MIGRACION_RAPIDO.md` - Gu�a de migraciones
- `SOLUCION_ERROR_404.md` - Soluci�n de problemas comunes

---

�Listo para usar! ??

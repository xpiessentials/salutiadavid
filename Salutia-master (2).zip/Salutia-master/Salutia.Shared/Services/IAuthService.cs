namespace Salutia.Shared.Services;

/// <summary>
/// Interfaz para el servicio de autenticaci�n
/// </summary>
public interface IAuthService
{
    Task<AuthResponse> LoginAsync(LoginRequest request);
    Task<AuthResponse> RegisterAsync(RegisterRequest request);
    Task<bool> LogoutAsync();
    Task<User?> GetCurrentUserAsync();
    Task<bool> IsAuthenticatedAsync();
    Task<TwoFactorSetup> EnableTwoFactorAsync();
    Task<bool> VerifyTwoFactorAsync(TwoFactorVerifyRequest request);
 Task<bool> DisableTwoFactorAsync();
}

/// <summary>
/// Respuesta gen�rica de API
/// </summary>
public class ApiResponse<T>
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public T? Data { get; set; }
    public List<string> Errors { get; set; } = new();
}

namespace Salutia.Shared.Models;

/// <summary>
/// Modelo de usuario compartido entre aplicaci�n web y m�vil
/// </summary>
public class User
{
    public string Id { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string UserName { get; set; } = string.Empty;
    public bool EmailConfirmed { get; set; }
    public bool TwoFactorEnabled { get; set; }
    public string PhoneNumber { get; set; } = string.Empty;
}

/// <summary>
/// Modelo de inicio de sesi�n
/// </summary>
public class LoginRequest
{
 public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public bool RememberMe { get; set; }
}

/// <summary>
/// Respuesta de autenticaci�n
/// </summary>
public class AuthResponse
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public string? Token { get; set; }
    public bool RequiresTwoFactor { get; set; }
    public User? User { get; set; }
}

/// <summary>
/// Modelo de registro de usuario
/// </summary>
public class RegisterRequest
{
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string ConfirmPassword { get; set; } = string.Empty;
}

/// <summary>
/// Modelo de verificaci�n 2FA
/// </summary>
public class TwoFactorVerifyRequest
{
    public string Code { get; set; } = string.Empty;
  public bool RememberMachine { get; set; }
}

/// <summary>
/// Configuraci�n 2FA
/// </summary>
public class TwoFactorSetup
{
    public string SharedKey { get; set; } = string.Empty;
    public string AuthenticatorUri { get; set; } = string.Empty;
}

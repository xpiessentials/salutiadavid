global using Salutia.Shared.Models;
global using Salutia.Shared.Services;

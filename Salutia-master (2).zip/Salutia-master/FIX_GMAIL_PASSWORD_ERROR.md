# ?? GU�A: Configurar Contrase�a de Aplicaci�n de Gmail

## ? Problema Actual

Error: `535: 5.7.8 Username and Password not accepted`

**Causa**: La contrase�a en `appsettings.json` no es una contrase�a de aplicaci�n v�lida de Gmail.

---

## ? Soluci�n: Generar Contrase�a de Aplicaci�n

### Paso 1: Habilitar Verificaci�n en 2 Pasos

1. **Inicia sesi�n en Gmail**: https://mail.google.com con `salutiadesarrollo@gmail.com`

2. **Ve a tu cuenta de Google**: 
   - Click en tu foto de perfil (esquina superior derecha)
   - Click en "Gestionar tu cuenta de Google"

3. **Ve a Seguridad**:
   - En el men� lateral, click en "Seguridad"
   - O directamente: https://myaccount.google.com/security

4. **Habilita la verificaci�n en 2 pasos**:
   - Busca la secci�n "C�mo inicias sesi�n en Google"
   - Click en "Verificaci�n en 2 pasos"
- Click en "Comenzar"
   - Sigue los pasos (te pedir� tu tel�fono)
   - **Importante**: Completa todo el proceso

---

### Paso 2: Generar Contrase�a de Aplicaci�n

1. **Una vez habilitada la verificaci�n en 2 pasos**, regresa a:
   https://myaccount.google.com/security

2. **Busca "Contrase�as de aplicaciones"**:
   - Est� en la secci�n "C�mo inicias sesi�n en Google"
   - O ve directamente a: https://myaccount.google.com/apppasswords

3. **Si no ves "Contrase�as de aplicaciones"**:
   - Aseg�rate de haber completado la verificaci�n en 2 pasos
   - Espera unos minutos
   - Recarga la p�gina

4. **Genera la contrase�a**:
   - Click en "Contrase�as de aplicaciones"
   - Ingresa tu contrase�a de Gmail si te la pide
   - En "Seleccionar app": Elige "Otro (nombre personalizado)"
   - Escribe: `Salutia Web Application`
   - Click en "Generar"

5. **Copia la contrase�a**:
   - Gmail mostrar� una contrase�a de 16 caracteres
   - Ejemplo: `abcd efgh ijkl mnop` (sin espacios reales, solo visual)
   - **�Copia esta contrase�a AHORA! No podr�s verla de nuevo**

---

### Paso 3: Actualizar appsettings.json

1. **Abre el archivo**: `Salutia Wep App\appsettings.json`

2. **Reemplaza la contrase�a**:

```json
"EmailSettings": {
  "SmtpServer": "smtp.gmail.com",
  "SmtpPort": 587,
  "SenderName": "Salutia - Sistema de Salud",
  "SenderEmail": "salutiadesarrollo@gmail.com",
  "Username": "salutiadesarrollo@gmail.com",
  "Password": "PEGA_AQUI_LA_CONTRASE�A_DE_16_CARACTERES",
  "UseSsl": true
}
```

3. **IMPORTANTE**: 
   - Pega la contrase�a **SIN ESPACIOS**
   - Gmail la muestra con espacios solo para facilitar la lectura
   - Ejemplo: Si ves `abcd efgh ijkl mnop`, p�gala como `abcdefghijklmnop`

4. **Guarda el archivo**

---

### Paso 4: Reiniciar la Aplicaci�n

1. **Det�n la aplicaci�n** (Shift+F5 en Visual Studio)

2. **Inicia de nuevo** (F5)

3. **Prueba el env�o**:
   - Ve a: https://localhost:7213/test/send-email
   - Haz click en "Enviar Email Simple"
   - Deber�a funcionar ahora

---

## ?? Verificaci�n R�pida

### ? Checklist antes de probar:

- [ ] Verificaci�n en 2 pasos HABILITADA en Gmail
- [ ] Contrase�a de aplicaci�n GENERADA correctamente
- [ ] Contrase�a COPIADA sin espacios
- [ ] `appsettings.json` ACTUALIZADO con la nueva contrase�a
- [ ] Archivo GUARDADO
- [ ] Aplicaci�n REINICIADA

---

## ?? Soluci�n de Problemas

### Problema: No veo "Contrase�as de aplicaciones"

**Causa**: Verificaci�n en 2 pasos no est� habilitada o no se complet� correctamente.

**Soluci�n**:
1. Ve a: https://myaccount.google.com/security
2. Verifica que "Verificaci�n en 2 pasos" est� ACTIVADA
3. Si no est�, act�vala primero
4. Espera 5-10 minutos
5. Refresca la p�gina

### Problema: Gmail dice "Contrase�a incorrecta"

**Causa**: La contrase�a tiene espacios o caracteres extra.

**Soluci�n**:
1. Vuelve a copiar la contrase�a de aplicaci�n
2. P�gala en un editor de texto primero
3. Elimina TODOS los espacios
4. Copia de nuevo (sin espacios)
5. Pega en `appsettings.json`

### Problema: Error 535 persiste

**Soluciones**:

1. **Genera una NUEVA contrase�a de aplicaci�n**:
   - Elimina la anterior en Google
   - Crea una nueva
   - Actualiza `appsettings.json`

2. **Verifica el email**:
   - Aseg�rate de que `salutiadesarrollo@gmail.com` es correcto
   - Username y SenderEmail deben ser iguales

3. **Verifica SMTP**:
   ```json
   "SmtpServer": "smtp.gmail.com",  // Debe ser exactamente esto
   "SmtpPort": 587,              // Puerto correcto
   "UseSsl": true             // Debe ser true
   ```

---

## ?? Alternativa: Usar Otro Proveedor

Si Gmail sigue dando problemas, considera usar:

### SendGrid (Recomendado para producci�n):
- Gratis hasta 100 emails/d�a
- M�s confiable que Gmail
- No requiere contrase�a de aplicaci�n

### Configuraci�n SendGrid:
```json
"EmailSettings": {
  "SmtpServer": "smtp.sendgrid.net",
  "SmtpPort": 587,
  "SenderName": "Salutia - Sistema de Salud",
  "SenderEmail": "salutiadesarrollo@gmail.com",
  "Username": "apikey",
  "Password": "TU_API_KEY_DE_SENDGRID",
  "UseSsl": true
}
```

### Mailgun:
- Gratis hasta 100 emails/d�a
- Excelente para desarrollo

### Gmail para Desarrollo:
- Habilitar "Acceso de aplicaciones menos seguras" (NO recomendado)
- Usar OAuth 2.0 (complejo)
- Usar contrase�a de aplicaci�n (lo que estamos haciendo)

---

## ? Resumen de Pasos

1. **Habilitar 2FA** en Gmail
2. **Generar contrase�a** de aplicaci�n
3. **Copiar** la contrase�a (sin espacios)
4. **Actualizar** `appsettings.json`
5. **Guardar** el archivo
6. **Reiniciar** la aplicaci�n
7. **Probar** el env�o

---

## ?? Notas Importantes

- ?? **NUNCA** uses tu contrase�a personal de Gmail
- ? **SIEMPRE** usa contrase�as de aplicaci�n
- ?? **NO** compartas la contrase�a de aplicaci�n
- ?? **GUARDA** la contrase�a en un lugar seguro
- ?? **REGENERA** la contrase�a si la pierdes
- ??? **ELIMINA** contrase�as de aplicaci�n que no uses

---

## ?? Despu�s de Configurar

Una vez que funcione:

1. **Prueba todos los tipos de correo**:
   - Email simple
   - Email de bienvenida
   - Email de reseteo de contrase�a

2. **Documenta la contrase�a**:
   - Gu�rdala en un gestor de contrase�as
   - No la dejes en `appsettings.json` en producci�n
   - Usa variables de entorno o Azure Key Vault

3. **Elimina la p�gina de prueba**:
   ```
   Salutia Wep App\Components\Pages\TestSendEmail.razor
   ```

---

**Estado Actual**: ? Contrase�a inv�lida  
**Siguiente Paso**: Generar contrase�a de aplicaci�n v�lida  
**Tiempo Estimado**: 5-10 minutos

# Componente QrCodeDisplay - Gu�a de Uso

## Descripci�n

`QrCodeDisplay` es un componente Blazor reutilizable que facilita la generaci�n y visualizaci�n de c�digos QR en cualquier parte de la aplicaci�n Salutia.

## Ubicaci�n

```
Salutia Wep App\Components\Shared\QrCodeDisplay.razor
```

## Importar el Componente

Aseg�rate de tener la importaci�n en tu archivo `_Imports.razor`:

```razor
@using Salutia_Wep_App.Components.Shared
```

## Uso B�sico

### Ejemplo 1: C�digo QR Simple

```razor
<QrCodeDisplay Text="https://salutia.com" />
```

### Ejemplo 2: Con T�tulo y Descripci�n

```razor
<QrCodeDisplay 
    Text="https://salutia.com/verify?token=abc123"
    Title="Escanea este c�digo para verificar tu cuenta"
    Description="Este c�digo QR expira en 15 minutos"
    AltText="C�digo QR de verificaci�n" />
```

### Ejemplo 3: QR Personalizado

```razor
<QrCodeDisplay 
    Text="@qrContent"
    PixelsPerModule="15"
  MaxWidth="400"
    Title="Comparte este c�digo"
    CssClass="my-4 p-3 border rounded shadow"
    ImageCssClass="border border-primary"
    ShowError="true" />
```

### Ejemplo 4: QR para WiFi

```razor
@code {
    private string wifiQrCode = "WIFI:T:WPA;S:SalutiaGuest;P:Password123;;";
}

<QrCodeDisplay 
    Text="@wifiQrCode"
    Title="Conectarse a la red WiFi"
    Description="Escanea con la c�mara de tu tel�fono"
MaxWidth="250" />
```

### Ejemplo 5: QR para vCard (Tarjeta de Contacto)

```razor
@code {
    private string GetVCardQr()
    {
        return @"BEGIN:VCARD
VERSION:3.0
FN:Dr. Juan P�rez
TEL:+34-123-456-789
EMAIL:juan.perez@salutia.com
ORG:Salutia Clinic
END:VCARD";
    }
}

<QrCodeDisplay 
    Text="@GetVCardQr()"
    Title="Guardar contacto"
    PixelsPerModule="12"
    MaxWidth="300" />
```

## Par�metros

| Par�metro | Tipo | Requerido | Valor por Defecto | Descripci�n |
|-----------|------|-----------|-------------------|-------------|
| `Text` | `string` | ? S� | - | Texto o URI a codificar en el QR |
| `PixelsPerModule` | `int` | No | `10` | Tama�o de los m�dulos del QR en p�xeles |
| `MaxWidth` | `int` | No | `300` | Ancho m�ximo del c�digo QR en p�xeles |
| `Title` | `string?` | No | `null` | T�tulo opcional encima del QR |
| `Description` | `string?` | No | `null` | Descripci�n opcional debajo del QR |
| `AltText` | `string` | No | `"C�digo QR"` | Texto alternativo para accesibilidad |
| `CssClass` | `string` | No | `""` | Clases CSS adicionales para el contenedor |
| `ImageCssClass` | `string` | No | `""` | Clases CSS adicionales para la imagen |
| `ShowError` | `bool` | No | `true` | Mostrar mensaje de error si falla |
| `ErrorMessage` | `string` | No | Mensaje por defecto | Mensaje de error personalizado |

## Ejemplos de Uso Avanzado

### En un Formulario de Pago

```razor
@page "/payment/{orderId}"

<h3>Pagar Orden #@orderId</h3>

@if (!string.IsNullOrEmpty(paymentQr))
{
    <div class="card">
        <div class="card-body">
  <QrCodeDisplay 
    Text="@paymentQr"
     Title="Escanea para pagar"
 Description="Total: $@totalAmount"
  PixelsPerModule="12"
       MaxWidth="350"
 CssClass="payment-qr"
       AltText="C�digo QR de pago" />
        </div>
    </div>
}

@code {
    [Parameter]
    public string OrderId { get; set; } = string.Empty;
    
    private string? paymentQr;
    private decimal totalAmount;

  protected override async Task OnInitializedAsync()
    {
 // Generar link de pago
      paymentQr = $"https://salutia.com/pay?order={OrderId}&amount={totalAmount}";
        totalAmount = 99.99m;
    }
}
```

### En una P�gina de Compartir Perfil

```razor
@page "/profile/share"

<h3>Compartir mi Perfil M�dico</h3>

<QrCodeDisplay 
    Text="@GetProfileShareUrl()"
    Title="Escanea para ver mi perfil"
    Description="V�lido por 7 d�as"
    PixelsPerModule="15"
    MaxWidth="400"
    CssClass="mb-4" />

<button class="btn btn-primary" @onclick="GenerateNewQr">
    <i class="bi bi-arrow-clockwise"></i> Generar Nuevo C�digo
</button>

@code {
    private string shareToken = Guid.NewGuid().ToString();

    private string GetProfileShareUrl()
    {
     return $"https://salutia.com/profile/view?token={shareToken}";
    }

    private void GenerateNewQr()
    {
        shareToken = Guid.NewGuid().ToString();
    }
}
```

### Con Descarga de Imagen

```razor
<QrCodeDisplay 
    @ref="qrDisplay"
    Text="@qrContent"
    Title="Tu c�digo de acceso"
    MaxWidth="350" />

<button class="btn btn-secondary mt-3" @onclick="DownloadQr">
    <i class="bi bi-download"></i> Descargar QR
</button>

@code {
    private QrCodeDisplay? qrDisplay;
    private string qrContent = "https://salutia.com/access";

    private void DownloadQr()
    {
        // Nota: Para implementar descarga real, necesitar�as JavaScript interop
        // Este es un ejemplo conceptual
        Console.WriteLine("Descargando QR...");
    }
}
```

## Personalizaci�n con CSS

### Ejemplo de Estilos Personalizados

```css
/* En tu archivo CSS */

/* Contenedor del QR con sombra */
.qr-code-container {
    background: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* QR con borde */
.qr-with-border {
    border: 3px solid #1b6ec2;
    border-radius: 8px;
    padding: 10px;
}

/* QR para imprimir */
@media print {
    .qr-code-container {
     page-break-inside: avoid;
    }
}

/* Animaci�n de aparici�n */
.qr-fade-in {
    animation: fadeIn 0.5s ease-in;
}

@keyframes fadeIn {
    from {
  opacity: 0;
        transform: scale(0.9);
    }
  to {
        opacity: 1;
        transform: scale(1);
    }
}
```

### Uso con Clases Personalizadas

```razor
<QrCodeDisplay 
 Text="@content"
    CssClass="qr-fade-in shadow-lg"
    ImageCssClass="qr-with-border"
    Title="C�digo de Verificaci�n" />
```

## Manejo de Errores

El componente maneja autom�ticamente los errores de generaci�n:

```razor
<!-- Si Text est� vac�o o la generaci�n falla -->
<QrCodeDisplay 
    Text="@maybeEmptyText"
    ShowError="true"
    ErrorMessage="Por favor, genera un c�digo v�lido primero." />
```

Para ocultar el mensaje de error:

```razor
<QrCodeDisplay 
    Text="@content"
ShowError="false" />
```

## Casos de Uso Comunes

### 1. URL de Verificaci�n de Email

```razor
<QrCodeDisplay 
    Text="https://salutia.com/verify-email?token=@emailToken"
    Title="Verifica tu email"
    Description="Escanea o haz clic en el enlace del correo" />
```

### 2. C�digo de Cita M�dica

```razor
<QrCodeDisplay 
    Text="APPT:@appointmentId|@patientId|@DateTime.Now.ToString("yyyyMMddHHmm")"
    Title="Tu Cita - @appointmentDate.ToString("d")"
    Description="Muestra este c�digo en recepci�n"
    PixelsPerModule="12" />
```

### 3. Link de Descarga de Aplicaci�n

```razor
<QrCodeDisplay 
    Text="https://salutia.com/app/download"
    Title="Descarga la App M�vil"
    Description="Disponible para iOS y Android"
    MaxWidth="250" />
```

### 4. Informaci�n de Medicamento

```razor
<QrCodeDisplay 
    Text="MED:@medicationCode|DOSE:@dosage|FREQ:@frequency"
    Title="Informaci�n del Medicamento"
    Description="Escanea para ver instrucciones completas" />
```

## Integraci�n con Servicios Externos

### Con API de Pagos

```csharp
// Generar QR para MercadoPago, PayPal, etc.
var paymentData = new
{
    merchant_id = "12345",
    amount = 100.00,
    currency = "USD",
    order_id = orderId
};

var qrText = JsonSerializer.Serialize(paymentData);
```

```razor
<QrCodeDisplay 
    Text="@qrText"
    Title="Pagar con QR"
    PixelsPerModule="15" />
```

## Accesibilidad

El componente incluye soporte para accesibilidad:

- ? Atributo `alt` configurable
- ? Estructura sem�ntica HTML
- ? Compatible con lectores de pantalla
- ? Textos descriptivos opcionales

```razor
<QrCodeDisplay 
    Text="@content"
    AltText="C�digo QR para acceder a tu historial m�dico"
    Title="Historial M�dico"
    Description="Escanea este c�digo para acceder de forma segura" />
```

## Rendimiento

- El componente genera el QR **solo cuando cambian los par�metros**
- Usa `OnParametersSet` para regeneraci�n eficiente
- Im�genes en formato Base64 (sin archivos adicionales)
- Carga sincr�nica (sin awaits innecesarios)

## Troubleshooting

### El QR no se muestra

**Verificar**:
1. �El par�metro `Text` tiene valor?
2. �El servicio `QrCodeService` est� registrado en `Program.cs`?
3. �Hay errores en el log?

### QR muy pixelado

**Soluci�n**: Aumentar `PixelsPerModule`

```razor
<QrCodeDisplay Text="@content" PixelsPerModule="20" />
```

### QR demasiado grande

**Soluci�n**: Reducir `MaxWidth` o `PixelsPerModule`

```razor
<QrCodeDisplay 
 Text="@content" 
    PixelsPerModule="8"
    MaxWidth="200" />
```

## Recursos Adicionales

- [Especificaci�n QR Code](https://www.qrcode.com/en/about/standards.html)
- [QRCoder GitHub](https://github.com/codebude/QRCoder)
- [TWO_FACTOR_AUTH_QR.md](TWO_FACTOR_AUTH_QR.md) - Gu�a completa de 2FA

---

**�ltima actualizaci�n**: 2025  
**Componente versi�n**: 1.0

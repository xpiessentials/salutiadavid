# Configuraci�n de la Base de Datos Salutia

## Resumen
La aplicaci�n Salutia est� configurada para usar **SQL Server Express local** (LAPTOP-DAVID\SQLEXPRESS). La base de datos se llama **Salutia** y se almacena localmente en tu equipo de desarrollo.

## Configuraci�n Actual

### Servidor SQL Server
- **Instancia**: `LAPTOP-DAVID\SQLEXPRESS`
- **Base de datos**: `Salutia`
- **Autenticaci�n**: Windows Authentication (Trusted_Connection=True)

### AppHost (Salutia.AppHost\AppHost.cs)
- Configurado con SQL Server Express local
- La cadena de conexi�n apunta directamente a tu instancia local
- No usa contenedores Docker

### Aplicaci�n Blazor (Salutia Wep App)
- Usa Entity Framework Core con SQL Server
- Configurada con Identity para autenticaci�n
- Las migraciones de Identity ya est�n creadas

## C�mo Crear y Aplicar Migraciones

### 1. Crear la Base de Datos (Primera Vez)
Antes de aplicar migraciones, aseg�rate de que SQL Server Express est� en ejecuci�n:

```powershell
# Verificar que el servicio SQL Server Express est� corriendo
Get-Service -Name "MSSQL$SQLEXPRESS"

# Si no est� corriendo, in�cialo
Start-Service -Name "MSSQL$SQLEXPRESS"
```

### 2. Aplicar las Migraciones Existentes de Identity
```powershell
# Desde la ra�z del proyecto
dotnet ef database update --project "Salutia Wep App" --startup-project "Salutia Wep App"
```

### 3. Crear Nuevas Migraciones
Cuando agregues nuevas entidades o modifiques el DbContext, ejecuta:

```powershell
dotnet ef migrations add NombreDeLaMigracion --project "Salutia Wep App" --startup-project "Salutia Wep App"
```

### 4. Ver el Estado de las Migraciones
```powershell
dotnet ef migrations list --project "Salutia Wep App" --startup-project "Salutia Wep App"
```

### 5. Revertir una Migraci�n
```powershell
dotnet ef database update NombreDeLaMigracionAnterior --project "Salutia Wep App" --startup-project "Salutia Wep App"
```

### 6. Eliminar la �ltima Migraci�n (si no se ha aplicado)
```powershell
dotnet ef migrations remove --project "Salutia Wep App" --startup-project "Salutia Wep App"
```

## Estructura de la Base de Datos

### Tablas Actuales (Identity)
La base de datos actualmente incluye las siguientes tablas de ASP.NET Core Identity:
- `AspNetUsers` - Usuarios del sistema
- `AspNetRoles` - Roles de usuario
- `AspNetUserRoles` - Relaci�n usuarios-roles
- `AspNetUserClaims` - Claims de usuarios
- `AspNetUserLogins` - Logins externos
- `AspNetUserTokens` - Tokens de usuario
- `AspNetRoleClaims` - Claims de roles

### Agregar Nuevas Tablas

#### Paso 1: Crear las Entidades
Crea tus clases de entidad en la carpeta `Salutia Wep App\Data\` o en una subcarpeta `Models\`:

```csharp
public class Paciente
{
    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Apellido { get; set; } = string.Empty;
    public DateTime FechaNacimiento { get; set; }
    // ... m�s propiedades
}
```

#### Paso 2: Agregar al DbContext
Edita `Salutia Wep App\Data\ApplicationDbContext.cs`:

```csharp
public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) 
        : base(options)
    {
    }

    // Agregar DbSets para tus entidades
    public DbSet<Paciente> Pacientes { get; set; }
    
    protected override void OnModelCreating(ModelBuilder builder)
    {
    base.OnModelCreating(builder);
        
      // Configurar relaciones y restricciones aqu�
   builder.Entity<Paciente>(entity =>
        {
            entity.HasKey(e => e.Id);
  entity.Property(e => e.Nombre).IsRequired().HasMaxLength(100);
  // ... m�s configuraciones
     });
    }
}
```

#### Paso 3: Crear y Aplicar Migraci�n
```powershell
dotnet ef migrations add AgregarTablaPacientes --project "Salutia Wep App" --startup-project "Salutia Wep App"
dotnet ef database update --project "Salutia Wep App" --startup-project "Salutia Wep App"
```

## Ejecutar la Aplicaci�n con .NET Aspire

### Opci�n 1: Desde Visual Studio
1. Establece `Salutia.AppHost` como proyecto de inicio
2. Presiona F5 o haz clic en el bot�n de ejecutar
3. Se abrir� el Dashboard de Aspire en tu navegador
4. Desde all� puedes ver y acceder a tu aplicaci�n

### Opci�n 2: Desde la l�nea de comandos
```powershell
dotnet run --project "Salutia.AppHost\Salutia.AppHost.csproj"
```

## Conexi�n Directa a la Base de Datos

Puedes conectarte directamente a SQL Server Express usando:

**Cadena de conexi�n:**
```
Server=LAPTOP-DAVID\SQLEXPRESS;Database=Salutia;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True
```

**Desde SQL Server Management Studio (SSMS):**
- Server name: `LAPTOP-DAVID\SQLEXPRESS`
- Authentication: Windows Authentication
- Database: `Salutia`

**Desde Visual Studio:**
- SQL Server Object Explorer
- Add SQL Server ? `LAPTOP-DAVID\SQLEXPRESS`

## Consejos y Mejores Pr�cticas

1. **Siempre crea una migraci�n antes de modificar la base de datos**
2. **Usa nombres descriptivos para las migraciones** (ej: `AgregarTablaPacientes`, `AgregarCampoTelefonoAPaciente`)
3. **Revisa el c�digo de la migraci�n** antes de aplicarla para asegurarte de que es correcto
4. **Haz backup de tu base de datos** antes de aplicar migraciones en producci�n
5. **Usa `OnModelCreating`** para configurar restricciones, �ndices y relaciones
6. **Mant�n las entidades en archivos separados** para mejor organizaci�n

## Soluci�n de Problemas

### Error: "No se pudo conectar a la base de datos"
1. Verifica que SQL Server Express est� en ejecuci�n:
```powershell
Get-Service -Name "MSSQL$SQLEXPRESS"
```

2. Si no est� corriendo, in�cialo:
```powershell
Start-Service -Name "MSSQL$SQLEXPRESS"
```

3. Verifica la conectividad con SQLCMD:
```powershell
sqlcmd -S LAPTOP-DAVID\SQLEXPRESS -E -Q "SELECT @@VERSION"
```

### Error: "Login failed for user"
- Aseg�rate de tener permisos en SQL Server Express
- Verifica que Windows Authentication est� habilitada
- Intenta conectarte con SQL Server Management Studio primero

### Error: "La base de datos ya existe"
Si necesitas recrear la base de datos desde cero:
```powershell
dotnet ef database drop --project "Salutia Wep App" --startup-project "Salutia Wep App"
dotnet ef database update --project "Salutia Wep App" --startup-project "Salutia Wep App"
```

### Error en las migraciones
```powershell
# Ver el error detallado
dotnet ef database update --verbose --project "Salutia Wep App" --startup-project "Salutia Wep App"
```

### Verificar que SQL Server Express est� instalado y configurado
```powershell
# Listar todas las instancias de SQL Server
Get-Service -Name "MSSQL*" | Select-Object Name, Status, DisplayName

# Ver la configuraci�n de red de SQL Server Express
sqlcmd -S LAPTOP-DAVID\SQLEXPRESS -E -Q "EXEC sp_configure 'show advanced options', 1; RECONFIGURE; EXEC sp_configure;"
```

## Pr�ximos Pasos

1. ? **Base de datos configurada** - La infraestructura est� lista con SQL Server Express
2. ?? **Aplicar migraciones iniciales** - Ejecuta `dotnet ef database update`
3. ?? **Crear entidades de dominio** - Define tus modelos de negocio
4. ?? **Crear migraciones** - Genera las tablas en la base de datos
5. ?? **Implementar repositorios** - Crea servicios para acceder a los datos
6. ?? **Crear componentes Blazor** - Construye la interfaz de usuario

## Recursos Adicionales

- [Documentaci�n de Entity Framework Core](https://docs.microsoft.com/ef/core/)
- [Migraciones en EF Core](https://docs.microsoft.com/ef/core/managing-schemas/migrations/)
- [.NET Aspire](https://learn.microsoft.com/dotnet/aspire/)
- [ASP.NET Core Identity](https://docs.microsoft.com/aspnet/core/security/authentication/identity)
- [SQL Server Express](https://docs.microsoft.com/sql/sql-server/editions-and-components-of-sql-server-2019)

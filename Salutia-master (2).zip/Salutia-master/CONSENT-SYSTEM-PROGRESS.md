# ?? Sistema de Consentimientos Informados Digitales - Progreso

## ? Estado Actual: 33% Completado (3 de 9 pasos)

---

## ?? Objetivo del Sistema

Implementar un sistema completo de consentimientos informados digitales que permita:
- Recopilar consentimientos antes del test psicosom�tico
- Firmar electr�nicamente con pad de firma
- Generar PDFs diligenciados
- Permitir descarga por profesionales y entidades
- Editar plantillas por SuperAdmin y EntityAdmin
- Auditor�a completa de cambios y descargas

---

## ? PASOS COMPLETADOS

### **Paso 1: ? Modelos Creados**

**Archivo:** `Salutia Wep App/Models/Consent/ConsentModels.cs`

**Modelos Implementados:**

| Modelo | Descripci�n | Campos Clave |
|--------|-------------|--------------|
| `ConsentTemplate` | Plantilla de consentimiento editable | Title, Code, ContentHtml, Version, EntityId |
| `PatientConsent` | Registro de consentimiento firmado | PsychosomaticTestId, ConsentTemplateId, IsAccepted |
| `ConsentSignature` | Firma digital del paciente | SignatureDataBase64, SignatureType, SignerFullName |
| `ConsentDocument` | Registro de PDFs generados | DocumentUrl, DocumentPath, FileHash, DownloadCount |
| `ConsentTemplateHistory` | Historial de cambios en plantillas | PreviousVersion, PreviousContentHtml, ChangeReason |

**Caracter�sticas Clave:**
- ? Soporte para plantillas globales y por entidad
- ? Versionamiento de plantillas
- ? Tipos de firma: Dibujada, Tipografiada, Imagen
- ? Auditor�a completa con IP, User Agent, timestamps
- ? Hash MD5 para verificaci�n de integridad de PDFs

---

### **Paso 2: ? Migraci�n de Base de Datos**

**Archivo:** `Salutia Wep App/Data/Migrations/20251204175708_AddConsentInformedSystem.cs`

**Tablas Creadas:**

```sql
1. ConsentTemplates           -- Plantillas de consentimientos
2. PatientConsents            -- Consentimientos firmados
3. ConsentSignatures          -- Firmas digitales
4. ConsentDocuments           -- PDFs generados
5. ConsentTemplateHistories   -- Historial de cambios
```

**�ndices Creados:**
- `IX_ConsentTemplates_Code`
- `IX_ConsentTemplates_EntityId_Code`
- `IX_PatientConsents_PsychosomaticTestId_ConsentTemplateId`
- `IX_PatientConsents_PatientUserId`
- `IX_ConsentDocuments_PsychosomaticTestId`
- `IX_ConsentSignatures_PatientConsentId` (Unique)

**Estado:** ? Aplicada exitosamente

---

### **Paso 3: ? Servicio de Gesti�n**

**Archivo:** `Salutia Wep App/Services/ConsentService.cs`

**M�todos Implementados: 18**

#### **Gesti�n de Plantillas (5 m�todos):**
| M�todo | Descripci�n |
|--------|-------------|
| `GetActiveTemplatesAsync()` | Obtiene plantillas activas (globales o por entidad) |
| `GetTemplateByCodeAsync()` | Busca plantilla por c�digo |
| `CreateTemplateAsync()` | Crea nueva plantilla |
| `UpdateTemplateAsync()` | Actualiza plantilla y guarda historial |
| `DeactivateTemplateAsync()` | Desactiva plantilla |

#### **Gesti�n de Consentimientos (3 m�todos):**
| M�todo | Descripci�n |
|--------|-------------|
| `GetConsentsByTestAsync()` | Obtiene consentimientos de un test |
| `HasSignedAllRequiredConsentsAsync()` | Valida si firm� todos los obligatorios |
| `SaveConsentAsync()` | Guarda consentimiento + firma |

#### **Generaci�n de PDFs (2 m�todos):**
| M�todo | Descripci�n |
|--------|-------------|
| `GenerateConsentPdfAsync()` | Genera PDF individual |
| `GenerateAllConsentsPdfPackageAsync()` | Genera paquete con todos |

#### **Descarga y Auditor�a (4 m�todos):**
| M�todo | Descripci�n |
|--------|-------------|
| `GetDocumentAsync()` | Obtiene documento por ID |
| `RegisterDownloadAsync()` | Registra descarga |
| `GetDocumentsByTestAsync()` | Lista documentos de un test |
| `GetTemplateHistoryAsync()` | Historial de cambios |

#### **Validaci�n (1 m�todo):**
| M�todo | Descripci�n |
|--------|-------------|
| `ValidateConsentIntegrityAsync()` | Valida integridad con hash MD5 |

#### **M�todos Auxiliares (3):**
- `CalculateFileHashAsync()` - Calcula hash MD5
- Gesti�n de directorios
- Transacciones de base de datos

**Estado:** ? Implementado y registrado en `Program.cs`

---

## ?? Datos Semilla

**Archivo:** `Salutia Wep App/Data/SeedData/SeedConsentTemplates.sql`

### **4 Plantillas de Consentimiento:**

| # | T�tulo | C�digo | Obligatorio | Contenido |
|---|--------|--------|-------------|-----------|
| 1 | Protecci�n de Datos Personales | `CONSENT_DATA_PRIVACY` | ? S� | Ley 1581 de 2012, derechos ARCO, finalidad |
| 2 | Evaluaci�n Psicol�gica | `CONSENT_PSYCHOLOGICAL_EVAL` | ? S� | Naturaleza, limitaciones, confidencialidad |
| 3 | Registro Informaci�n M�dica | `CONSENT_MEDICAL_RECORD` | ? S� | Historia cl�nica, acceso, seguridad |
| 4 | Compartir con Empleador | `CONSENT_SHARE_WITH_EMPLOYER` | ? No | Resultados a entidad, revocaci�n |

**Caracter�sticas del Script:**
- ? Verifica existencia de SuperAdmin
- ? Contenido HTML completo y formateado
- ? Referencias legales (Ley 1581, Ley 1090, Res. 2346)
- ? Secciones claras y estructuradas
- ? Alertas y notas informativas

**Estado:** ? Listo para ejecutar

---

## ?? PASOS PENDIENTES (6 de 9)

### **Paso 4: Componente de Firma Digital** ?

**Tareas:**
- Crear componente Blazor `SignaturePad.razor`
- Integrar librer�a JavaScript para captura de firma
- Soporte para firma dibujada (canvas)
- Soporte para firma tipografiada
- Bot�n para limpiar y repetir
- Convertir a Base64 PNG

---

### **Paso 5: P�gina de Consentimientos** ?

**Archivo a Crear:** `Components/Pages/Patient/SignConsents.razor`

**Funcionalidades:**
- Mostrar los 4 consentimientos en pasos
- Scroll obligatorio hasta el final
- Checkbox "He le�do y acepto"
- Pad de firma integrado
- Validaci�n antes de continuar
- Guardado autom�tico

---

### **Paso 6: Repositorio de PDFs** ?

**Tareas:**
- Instalar librer�a de generaci�n de PDFs (QuestPDF o iTextSharp)
- Crear plantilla HTML para PDFs
- Incluir logo y encabezado
- Firma digital en el PDF
- Metadatos (fecha, IP, versi�n)

---

### **Paso 7: Integraci�n con Flujo del Test** ?

**Modificaciones:**
1. Actualizar `TestPsicosomatico.razor`
2. Agregar validaci�n: Perfil Completo ? Consentimientos ? Test
3. Redirigir a `/Patient/SignConsents` si no ha firmado
4. Bloquear acceso al test sin consentimientos

---

### **Paso 8: Vista para Profesionales/Entidades** ?

**Archivos a Crear:**
- `Components/Pages/Professional/PatientConsents.razor`
- `Components/Pages/Entity/ConsentReports.razor`

**Funcionalidades:**
- Listar tests con consentimientos
- Bot�n "Descargar PDFs"
- Registro de descarga
- Verificaci�n de integridad
- Historial de accesos

---

### **Paso 9: Gesti�n de Plantillas (Admin)** ?

**Archivos a Crear:**
- `Components/Pages/Admin/ManageConsentTemplates.razor`
- `Components/Pages/Admin/EditConsentTemplate.razor`
- `Components/Pages/Entity/EntityConsentTemplates.razor`

**Funcionalidades:**
- CRUD de plantillas
- Editor HTML rich-text
- Previsualizaci�n
- Historial de versiones
- Activar/Desactivar plantillas

---

## ?? Estructura de Archivos

### **Archivos Creados: 3**

```
Salutia Wep App/
??? Models/
?   ??? Consent/
?       ??? ConsentModels.cs ?
??? Services/
?   ??? ConsentService.cs ?
??? Data/
?   ??? ApplicationDbContext.cs ? (actualizado)
?   ??? Migrations/
?   ?   ??? 20251204175708_AddConsentInformedSystem.cs ?
?   ??? SeedData/
?       ??? SeedConsentTemplates.sql ?
??? Program.cs ? (actualizado)
```

### **Archivos Pendientes: 8+**

```
Salutia Wep App/
??? Components/
?   ??? Shared/
?   ?   ??? SignaturePad.razor ?
?   ??? Pages/
?       ??? Patient/
?       ?   ??? SignConsents.razor ?
?       ??? Professional/
?       ?   ??? PatientConsents.razor ?
?       ??? Entity/
?       ?   ??? ConsentReports.razor ?
?       ?   ??? EntityConsentTemplates.razor ?
?       ??? Admin/
?           ??? ManageConsentTemplates.razor ?
?           ??? EditConsentTemplate.razor ?
??? wwwroot/
    ??? js/
    ?   ??? signature-pad.js ?
    ??? consents/
        ??? pdfs/ (creado autom�ticamente)
```

---

## ?? Pr�ximos Pasos Inmediatos

### **1. Ejecutar Script de Datos Semilla** ??

```sql
-- Ejecutar en SQL Server Management Studio
USE SalutiaDB
GO
-- Copiar y ejecutar el contenido de:
Salutia Wep App/Data/SeedData/SeedConsentTemplates.sql
```

**Verificaci�n:**
```sql
SELECT Id, Title, Code, IsRequired, IsActive 
FROM ConsentTemplates 
ORDER BY DisplayOrder
```

Deber�as ver 4 plantillas insertadas.

---

### **2. Instalar Librer�a de PDFs** ??

Opci�n A - QuestPDF (Recomendado):
```powershell
cd "Salutia Wep App"
dotnet add package QuestPDF
```

Opci�n B - iTextSharp:
```powershell
cd "Salutia Wep App"
dotnet add package itext7
```

---

### **3. Crear Componente SignaturePad** ???

**Tecnolog�as a usar:**
- Canvas HTML5
- JavaScript para captura de trazos
- Interop de Blazor
- Conversi�n a Base64 PNG

---

### **4. Crear P�gina de Consentimientos** ??

**Flujo:**
```
1. Cargar plantillas activas
   ?
2. Mostrar consentimiento 1 de 4
   ?
3. Usuario lee (scroll hasta final)
   ?
4. Checkbox "He le�do y acepto"
   ?
5. Firmar en pad digital
   ?
6. Guardar y pasar al siguiente
   ?
7. Repetir para 4 consentimientos
   ?
8. Generar PDFs
   ?
9. Redirigir al test
```

---

## ?? M�tricas de Progreso

| Componente | Estado | Progreso |
|------------|--------|----------|
| **Modelos** | ? Completo | 100% |
| **Base de Datos** | ? Completo | 100% |
| **Servicio** | ? Completo | 100% |
| **Datos Semilla** | ? Pendiente | 0% |
| **Componente Firma** | ? No Iniciado | 0% |
| **P�gina Consentimientos** | ? No Iniciado | 0% |
| **Generaci�n PDFs** | ? No Iniciado | 0% |
| **Integraci�n Test** | ? No Iniciado | 0% |
| **Vista Profesionales** | ? No Iniciado | 0% |
| **Gesti�n Admin** | ? No Iniciado | 0% |
| **TOTAL** | ?? En Progreso | **33%** |

---

## ?? Decisiones T�cnicas

### **Firma Digital:**
- **Formato:** PNG Base64
- **Almacenamiento:** Directamente en BD (campo nvarchar(max))
- **Validaci�n:** Nombre + Documento debe coincidir con perfil
- **Tama�o recomendado:** 400x200 px

### **PDFs:**
- **Librer�a:** QuestPDF (moderna, performante, open-source)
- **Almacenamiento:** Archivo f�sico + registro en BD
- **Seguridad:** Hash MD5 para verificaci�n de integridad
- **Nomenclatura:** `consent_{id}_{timestamp}.pdf`

### **Flujo de Validaci�n:**
```
Registro ? Confirmar Email ? Login
    ?
Completar Perfil
    ?
Firmar 4 Consentimientos ? NUEVO
    ?
Realizar Test Psicosom�tico
```

### **Auditor�a:**
- Registro de IP y User Agent en cada firma
- Snapshot del HTML al momento de firmar
- Historial completo de cambios en plantillas
- Log de descargas con usuario y timestamp

---

## ?? Listo para Continuar

Una vez que ejecutes el script de datos semilla y confirmes que las 4 plantillas est�n en la BD, podemos proceder con:

1. Instalar librer�a de PDFs
2. Crear componente SignaturePad
3. Crear p�gina de consentimientos
4. Integrar con flujo del test

---

**?? Sistema de Consentimientos: 33% Completado**  
**?? Fecha: 2025-01-19**  
**? Fundaci�n s�lida construida - Lista para UI/UX**

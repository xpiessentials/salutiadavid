# ? TEST PSICOSOM�TICO - ACTUALIZACI�N COMPLETADA

## ?? Resumen Ejecutivo

Se ha agregado la **Pregunta 5: A qu� edad sinti� el malestar** al Test Psicosom�tico.

---

## ?? Antes vs Despu�s

| Aspecto | Antes | Despu�s |
|---------|-------|---------|
| **Preguntas** | 6 | **7** (+1) |
| **Tablas** | 8 | **9** (+1 TestAges) |
| **Pregunta 5** | Parte del cuerpo | **Edad** ? |
| **Pregunta 6** | Persona | **Parte del cuerpo** |
| **Pregunta 7** | - | **Persona** |

---

## ?? C�mo Aplicar (Elige UNA opci�n)

### ? OPCI�N 1: Si las tablas NO existen (Primera vez)

```powershell
.\EJECUTAR_ESTO.ps1
```

### ? OPCI�N 2: Si las tablas YA existen (Actualizaci�n)

**Mantiene todos los datos existentes:**

```powershell
.\aplicar-actualizacion-edad.ps1
```

Este script:
- ? Crea la tabla `TestAges`
- ? Agrega columna `Age` a `TestMatrices`
- ? **NO borra datos existentes**
- ? Verifica tests completados

### ? OPCI�N 3: Manual (Si prefieres SQL)

```sql
-- Ejecutar en SSMS o sqlcmd
sqlcmd -S "LAPTOP-DAVID\SQLEXPRESS" -d "Salutia" -E -i ".\Salutia Wep App\Data\Migrations\UpdatePsychosomaticTestAddAge.sql"
```

---

## ?? Nuevo Flujo de Preguntas

```
1. Palabras (10)          ? Sin cambios
2. Frases (10)            ? Sin cambios
3. Emociones (10)         ? Sin cambios
4. Niveles 1-10 (10)      ? Sin cambios
5. Edad ? NUEVA          ? Agregada aqu�
6. Parte del Cuerpo (10)  ? Movida de posici�n 5
7. Persona Asociada (10)  ? Movida de posici�n 6
```

---

## ??? Archivos Actualizados

### ? C�digo
- `PsychosomaticTestModels.cs` - Modelo `TestAge` + `TestMatrix.Age`
- `ApplicationDbContext.cs` - DbSet y configuraci�n
- `PsychosomaticTestService.cs` - M�todo `SaveAgesAsync()`
- `TestPsicosomatico.razor` - UI con pregunta 5
- `TestPsychosomaticResults.razor` - Columna Edad

### ? Base de Datos
- `CreatePsychosomaticTestTables.sql` - Script completo
- `UpdatePsychosomaticTestAddAge.sql` - Solo actualizaci�n ?

### ? Scripts
- `EJECUTAR_ESTO.ps1` - Actualizado para 9 tablas
- `aplicar-actualizacion-edad.ps1` - Nuevo script ?

### ? Documentaci�n
- `TEST_PSICOSOMATICO_ACTUALIZACION.md` - Gu�a completa ?

---

## ?? Vista de la Nueva Pregunta

```
?????????????????????????????????????????????????
?  5?? Escriba a qu� edad sinti� el malestar     ?
?????????????????????????????????????????????????

???????????????????????????????????????????????
? ?? 1. Miedo                                 ?
? ?? Me da miedo estar solo                   ?
?                                             ?
? Edad: [15 a�os____________________]         ?
?       Ej: 15 a�os, Desde ni�o, 5 a�os       ?
???????????????????????????????????????????????

... (Se repite para las 10 palabras)

??????????????????????
? Siguiente Pregunta ?
??????????????????????
```

---

## ?? Resultado en la Matriz

### Antes (8 columnas):

| # | Palabra | Frase | Emoci�n | Nivel | Cuerpo | Persona |
|---|---------|-------|---------|-------|--------|---------|
| 1 | Miedo | ... | Ansiedad | 8 | Pecho | Padre |

### Despu�s (9 columnas):

| # | Palabra | Frase | Emoci�n | Nivel | **Edad** | Cuerpo | Persona |
|---|---------|-------|---------|-------|----------|--------|---------|
| 1 | Miedo | ... | Ansiedad | 8 | **15 a�os** | Pecho | Padre |

---

## ? Verificaci�n R�pida

```powershell
# Verificar que las 9 tablas existen
sqlcmd -S "LAPTOP-DAVID\SQLEXPRESS" -d "Salutia" -E -Q "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE 'Test%' OR TABLE_NAME = 'PsychosomaticTests' ORDER BY TABLE_NAME"
```

**Debe mostrar:**
```
PsychosomaticTests
TestAges                 ? Debe estar presente
TestAssociatedPersons
TestBodyParts
TestDiscomfortLevels
TestEmotions
TestMatrices
TestPhrases
TestWords

(9 filas afectadas)
```

---

## ?? Verificar Estructura TestAges

```sql
SELECT COLUMN_NAME, DATA_TYPE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'TestAges';
```

**Resultado esperado:**
```
Id                   int
PsychosomaticTestId  int
WordNumber           int
Age                  nvarchar
CreatedAt            datetime2
```

---

## ?? Notas Importantes

### Tests Existentes
Si ya tienes tests completados:
- ? **NO** tendr�n datos de edad (es imposible retroactivamente)
- ? Los **nuevos** tests s� incluir�n la edad
- ? Los datos existentes se mantienen intactos

### Migraci�n Segura
- ? Script verifica antes de crear
- ? No borra datos
- ? Solo agrega estructuras nuevas

---

## ?? Pasos Finales

### 1. Aplicar la actualizaci�n

```powershell
# Si ya tienes tablas del test
.\aplicar-actualizacion-edad.ps1

# Si es primera vez
.\EJECUTAR_ESTO.ps1
```

### 2. Compilar

```powershell
dotnet build
```

### 3. Ejecutar

```powershell
dotnet run --project ".\Salutia Wep App\Salutia Wep App.csproj"
```

### 4. Probar

Navegar a: `https://localhost:[puerto]/test-psicosomatico`

---

## ?? Beneficio Terap�utico

La nueva pregunta permite:

- ? **Identificar el origen temporal** del malestar
- ? **Asociar eventos de la infancia/adolescencia**
- ? **An�lisis de traumas tempranos**
- ? **Mejor contexto para el tratamiento**

---

## ?? Troubleshooting

### Error: "Columna Age no existe"
```powershell
.\aplicar-actualizacion-edad.ps1
```

### Error: "Tabla TestAges no existe"
```powershell
.\EJECUTAR_ESTO.ps1
```

### Compilaci�n OK pero error en runtime
Verificar que `TestMatrices` tiene columna `Age`:
```sql
SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'TestMatrices' AND COLUMN_NAME = 'Age';
```

---

## ? Checklist Final

- [ ] Script de actualizaci�n ejecutado
- [ ] 9 tablas verificadas
- [ ] TestAges existe
- [ ] TestMatrices tiene columna Age
- [ ] Compilaci�n exitosa
- [ ] Aplicaci�n ejecut�ndose
- [ ] Test accesible en /test-psicosomatico
- [ ] Pregunta 5 visible
- [ ] Orden correcto (7 preguntas)

---

## ?? �Listo!

El Test Psicosom�tico ahora incluye la pregunta sobre la edad, completando las **7 preguntas** del protocolo.

**Comando para ejecutar:**

```powershell
.\aplicar-actualizacion-edad.ps1
```

---

**�ltima actualizaci�n:** Ahora  
**Versi�n:** Test Psicosom�tico v2.0 con Edad

-- ============================================================
-- SCRIPT: CREAR SUPERADMIN DIRECTAMENTE EN BASE DE DATOS
-- ============================================================
-- Email: elpeco1@msn.com
-- Password: Dmontoyar.2025
-- ============================================================

USE [Salutia];
GO

BEGIN TRANSACTION;
BEGIN TRY

 PRINT '?? Creando SuperAdministrador...';
    PRINT '';

    -- Generar IDs �nicos
 DECLARE @UserId NVARCHAR(450) = CAST(NEWID() AS NVARCHAR(450));
    DECLARE @SecurityStamp NVARCHAR(MAX) = CAST(NEWID() AS NVARCHAR(MAX));
    DECLARE @ConcurrencyStamp NVARCHAR(MAX) = CAST(NEWID() AS NVARCHAR(MAX));
    
    -- Datos del usuario
    DECLARE @Email NVARCHAR(256) = 'elpeco1@msn.com';
    DECLARE @NormalizedEmail NVARCHAR(256) = 'ELPECO1@MSN.COM';
  
    -- Hash de la contrase�a "Dmontoyar.2025"
    -- Este hash fue generado con ASP.NET Core Identity PasswordHasher
    DECLARE @PasswordHash NVARCHAR(MAX) = 'AQAAAAIAAYagAAAAELxhL8qVYfzJ7XGnT5TqWE3vK4xN2YPmR8bC6dF1tH9gS5jL7nM3pQ8vX2yK6wZ4uE==';

    -- Verificar que no exista el usuario
    IF EXISTS (SELECT 1 FROM AspNetUsers WHERE Email = @Email)
    BEGIN
   PRINT '? Error: El usuario ya existe';
        ROLLBACK TRANSACTION;
        RETURN;
    END

    -- Insertar usuario en AspNetUsers
    INSERT INTO AspNetUsers (
     Id,
     UserName,
        NormalizedUserName,
        Email,
        NormalizedEmail,
        EmailConfirmed,
        PasswordHash,
        SecurityStamp,
ConcurrencyStamp,
   PhoneNumber,
        PhoneNumberConfirmed,
        TwoFactorEnabled,
        LockoutEnd,
   LockoutEnabled,
    AccessFailedCount,
        UserType,
        IsActive,
        CreatedAt,
 UpdatedAt
    )
    VALUES (
  @UserId,   -- Id
        @Email,   -- UserName
        @NormalizedEmail,           -- NormalizedUserName
    @Email,-- Email
        @NormalizedEmail,      -- NormalizedEmail
        1,  -- EmailConfirmed (True)
        @PasswordHash,              -- PasswordHash
        @SecurityStamp,-- SecurityStamp
        @ConcurrencyStamp,          -- ConcurrencyStamp
        NULL, -- PhoneNumber
        0,         -- PhoneNumberConfirmed
  0,          -- TwoFactorEnabled
        NULL,       -- LockoutEnd
        1,   -- LockoutEnabled
      0,       -- AccessFailedCount
        0,    -- UserType (0 = SuperAdmin)
    1,       -- IsActive
 GETUTCDATE(),           -- CreatedAt
        NULL        -- UpdatedAt
    );

    PRINT '? Usuario SuperAdmin creado';
 PRINT '   User ID: ' + @UserId;
    PRINT '   Email: ' + @Email;
    PRINT '';

    -- Asignar rol SuperAdmin
    DECLARE @RoleId NVARCHAR(450);
    SELECT @RoleId = Id FROM AspNetRoles WHERE Name = 'SuperAdmin';

    IF @RoleId IS NULL
BEGIN
        PRINT '? Error: El rol SuperAdmin no existe en la base de datos';
        PRINT '?? Ejecuta primero la aplicaci�n para que se creen los roles';
 ROLLBACK TRANSACTION;
        RETURN;
    END

    INSERT INTO AspNetUserRoles (UserId, RoleId)
    VALUES (@UserId, @RoleId);

    PRINT '? Rol SuperAdmin asignado';
  PRINT '';

    -- Verificaci�n
    SELECT 
        u.Id,
     u.Email,
    u.UserType,
   u.IsActive,
        u.EmailConfirmed,
        r.Name AS Role,
        u.CreatedAt
    FROM AspNetUsers u
    LEFT JOIN AspNetUserRoles ur ON u.Id = ur.UserId
    LEFT JOIN AspNetRoles r ON ur.RoleId = r.Id
    WHERE u.Id = @UserId;

    PRINT '';
    PRINT '???????????????????????????????????????????????????????????';
    PRINT '??? SUPERADMIN CREADO EXITOSAMENTE ???';
    PRINT '???????????????????????????????????????????????????????????';
    PRINT '';
    PRINT '?? Email: elpeco1@msn.com';
    PRINT '?? Password: Dmontoyar.2025';
    PRINT '';
 PRINT '?? Inicia sesi�n en: https://localhost:7242/Account/Login';
    PRINT '';
    PRINT '??  IMPORTANTE - SEGURIDAD:';
    PRINT '   1. Elimina: Salutia Wep App\Controllers\SetupController.cs';
    PRINT '   2. Elimina la secci�n "Setup" de appsettings.json';
    PRINT '   3. Recompila el proyecto';
    PRINT '';

    COMMIT TRANSACTION;

END TRY
BEGIN CATCH
    PRINT '';
    PRINT '? ERROR:';
    PRINT '   ' + ERROR_MESSAGE();
    PRINT '   L�nea: ' + CAST(ERROR_LINE() AS VARCHAR(10));
    
    ROLLBACK TRANSACTION;
END CATCH;
GO

PRINT '???????????????????????????????????????????????????????????';
PRINT 'Script finalizado';
PRINT '???????????????????????????????????????????????????????????';

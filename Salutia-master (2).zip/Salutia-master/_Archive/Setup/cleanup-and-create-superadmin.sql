-- =============================================
-- Script: Limpieza completa de base de datos y creaci�n de SuperAdmin
-- Descripci�n: Elimina todos los datos de las tablas de usuarios y crea un nuevo SuperAdmin
-- Email: elpeco1@msn.com
-- Password: Admin.123
-- Fecha: $(date)
-- =============================================

USE [Salutia]
GO

PRINT '=========================================='
PRINT 'Iniciando limpieza de base de datos...'
PRINT '=========================================='

-- Deshabilitar verificaci�n de claves for�neas temporalmente
ALTER TABLE [dbo].[EntityMemberProfiles] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[EntityUserProfiles] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[IndependentUserProfiles] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserTokens] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserRoles] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserLogins] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserClaims] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetRoleClaims] NOCHECK CONSTRAINT ALL
GO

PRINT 'Eliminando perfiles de miembros de entidad...'
DELETE FROM [dbo].[EntityMemberProfiles]
GO

PRINT 'Eliminando perfiles de entidades...'
DELETE FROM [dbo].[EntityUserProfiles]
GO

PRINT 'Eliminando perfiles de usuarios independientes...'
DELETE FROM [dbo].[IndependentUserProfiles]
GO

PRINT 'Eliminando tokens de usuario...'
DELETE FROM [dbo].[AspNetUserTokens]
GO

PRINT 'Eliminando roles de usuario...'
DELETE FROM [dbo].[AspNetUserRoles]
GO

PRINT 'Eliminando logins de usuario...'
DELETE FROM [dbo].[AspNetUserLogins]
GO

PRINT 'Eliminando claims de usuario...'
DELETE FROM [dbo].[AspNetUserClaims]
GO

PRINT 'Eliminando usuarios...'
DELETE FROM [dbo].[AspNetUsers]
GO

PRINT 'Eliminando claims de roles...'
DELETE FROM [dbo].[AspNetRoleClaims]
GO

PRINT 'Eliminando roles...'
DELETE FROM [dbo].[AspNetRoles]
GO

-- Rehabilitar verificaci�n de claves for�neas
ALTER TABLE [dbo].[EntityMemberProfiles] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[EntityUserProfiles] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[IndependentUserProfiles] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserTokens] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserLogins] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserClaims] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetRoleClaims] CHECK CONSTRAINT ALL
GO

PRINT '=========================================='
PRINT 'Limpieza completada exitosamente'
PRINT '=========================================='
PRINT ''
PRINT '=========================================='
PRINT 'Creando roles del sistema...'
PRINT '=========================================='

-- Crear roles del sistema
DECLARE @SuperAdminRoleId NVARCHAR(450) = NEWID()
DECLARE @EntityRoleId NVARCHAR(450) = NEWID()
DECLARE @IndependentRoleId NVARCHAR(450) = NEWID()
DECLARE @EntityMemberRoleId NVARCHAR(450) = NEWID()

INSERT INTO [dbo].[AspNetRoles] ([Id], [Name], [NormalizedName], [ConcurrencyStamp])
VALUES 
    (@SuperAdminRoleId, 'SuperAdmin', 'SUPERADMIN', NEWID()),
    (@EntityRoleId, 'Entity', 'ENTITY', NEWID()),
    (@IndependentRoleId, 'Independent', 'INDEPENDENT', NEWID()),
    (@EntityMemberRoleId, 'EntityMember', 'ENTITYMEMBER', NEWID())
GO

PRINT 'Roles creados exitosamente'
PRINT ''
PRINT '=========================================='
PRINT 'Creando SuperAdmin...'
PRINT '=========================================='

-- Variables para el SuperAdmin
DECLARE @SuperAdminId NVARCHAR(450) = NEWID()
DECLARE @Email NVARCHAR(256) = 'elpeco1@msn.com'
DECLARE @NormalizedEmail NVARCHAR(256) = 'ELPECO1@MSN.COM'
DECLARE @UserName NVARCHAR(256) = 'elpeco1@msn.com'
DECLARE @NormalizedUserName NVARCHAR(256) = 'ELPECO1@MSN.COM'
-- Hash para la contrase�a: Admin.123
-- NOTA: Si este hash no funciona, usa el script PowerShell create-superadmin-via-api.ps1
-- o ejecuta la aplicaci�n y usa el endpoint /api/setup/create-first-superadmin
DECLARE @PasswordHash NVARCHAR(MAX) = 'AQAAAAIAAYagAAAAEJFz8VqzqL5N0xGxZL5bHEZJhN2vxKWwR3nM8YgPqC7UxL5cP9mK2nT4sR6vW1eQdw=='
DECLARE @SecurityStamp NVARCHAR(MAX) = NEWID()
DECLARE @ConcurrencyStamp NVARCHAR(MAX) = NEWID()

-- Insertar SuperAdmin en AspNetUsers
INSERT INTO [dbo].[AspNetUsers] (
[Id],
    [UserName],
    [NormalizedUserName],
    [Email],
[NormalizedEmail],
[EmailConfirmed],
    [PasswordHash],
    [SecurityStamp],
    [ConcurrencyStamp],
 [PhoneNumber],
    [PhoneNumberConfirmed],
    [TwoFactorEnabled],
    [LockoutEnd],
    [LockoutEnabled],
[AccessFailedCount],
 [UserType],
    [CreatedAt],
    [UpdatedAt],
    [IsActive]
)
VALUES (
    @SuperAdminId,
    @UserName,
    @NormalizedUserName,
 @Email,
    @NormalizedEmail,
    1, -- Email confirmado
 @PasswordHash,
    @SecurityStamp,
    @ConcurrencyStamp,
    NULL, -- Sin tel�fono
    0, -- Tel�fono no confirmado
    0, -- 2FA deshabilitado
 NULL, -- Sin bloqueo
    1, -- Bloqueo habilitado
    0, -- Intentos fallidos = 0
    0, -- UserType.SuperAdmin = 0
    GETUTCDATE(), -- Fecha de creaci�n
    NULL, -- Sin actualizaci�n a�n
    1 -- Usuario activo
)
GO

PRINT 'Usuario SuperAdmin creado'
PRINT '  - Email: elpeco1@msn.com'
PRINT '  - Password: Admin.123'
PRINT ''

-- Asignar rol SuperAdmin al usuario
DECLARE @SuperAdminUserId NVARCHAR(450)
DECLARE @SuperAdminRoleId2 NVARCHAR(450)

SELECT @SuperAdminUserId = Id FROM [dbo].[AspNetUsers] WHERE Email = 'elpeco1@msn.com'
SELECT @SuperAdminRoleId2 = Id FROM [dbo].[AspNetRoles] WHERE Name = 'SuperAdmin'

INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId])
VALUES (@SuperAdminUserId, @SuperAdminRoleId2)
GO

PRINT 'Rol SuperAdmin asignado al usuario'
PRINT ''
PRINT '=========================================='
PRINT 'PROCESO COMPLETADO EXITOSAMENTE'
PRINT '=========================================='
PRINT ''
PRINT 'Credenciales del SuperAdmin:'
PRINT '  Email:    elpeco1@msn.com'
PRINT '  Password: Admin.123'
PRINT ''
PRINT 'NOTA IMPORTANTE:'
PRINT 'Si no puedes iniciar sesi�n con estas credenciales, usa una de estas alternativas:'
PRINT '  1. Ejecuta el script PowerShell: create-superadmin-via-api.ps1'
PRINT '  2. Usa el endpoint API: POST /api/setup/create-first-superadmin'
PRINT '=========================================='
GO

-- Verificar resultados
PRINT ''
PRINT 'Verificaci�n de resultados:'
PRINT ''

SELECT 
    'Usuarios creados' AS [Tabla],
    COUNT(*) AS [Cantidad]
FROM [dbo].[AspNetUsers]
UNION ALL
SELECT 
    'Roles creados' AS [Tabla],
    COUNT(*) AS [Cantidad]
FROM [dbo].[AspNetRoles]
UNION ALL
SELECT 
    'Asignaciones de roles' AS [Tabla],
    COUNT(*) AS [Cantidad]
FROM [dbo].[AspNetUserRoles]
GO

-- Mostrar detalle del SuperAdmin creado
PRINT ''
PRINT 'Detalle del SuperAdmin:'
SELECT 
  u.Id,
    u.UserName,
    u.Email,
    u.EmailConfirmed,
    u.UserType,
    u.IsActive,
    u.CreatedAt,
    r.Name AS [Rol]
FROM [dbo].[AspNetUsers] u
INNER JOIN [dbo].[AspNetUserRoles] ur ON u.Id = ur.UserId
INNER JOIN [dbo].[AspNetRoles] r ON ur.RoleId = r.Id
WHERE u.Email = 'elpeco1@msn.com'
GO

PRINT ''
PRINT '=========================================='
PRINT 'Script finalizado'
PRINT '=========================================='

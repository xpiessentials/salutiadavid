# =============================================
# Script: Crear SuperAdmin usando la API
# Descripci�n: Limpia la base de datos y crea el SuperAdmin usando el endpoint de la API
# Email: elpeco1@msn.com
# Password: Admin.123
# =============================================

Write-Host "=========================================="
Write-Host "LIMPIEZA Y CREACI�N DE SUPERADMIN"
Write-Host "=========================================="
Write-Host ""

# Configuraci�n
$ServerInstance = "localhost\SQLEXPRESS" # Cambia esto seg�n tu servidor SQL
$Database = "Salutia"
$ApiUrl = "https://localhost:7213" # URL correcta seg�n launchSettings.json
$Email = "elpeco1@msn.com"
$Password = "Admin.123"
$SetupKey = "Salutia2025!Setup" # Clave de seguridad desde appsettings.json

Write-Host "Configuraci�n:" -ForegroundColor Cyan
Write-Host "  Servidor SQL: $ServerInstance" -ForegroundColor White
Write-Host "  Base de datos: $Database" -ForegroundColor White
Write-Host "  API URL: $ApiUrl" -ForegroundColor White
Write-Host "  Email: $Email" -ForegroundColor White
Write-Host ""

# Funci�n para ejecutar SQL
function Invoke-SqlCommand {
param (
        [string]$Query,
        [string]$Description
    )
    
    try {
        Write-Host "Ejecutando: $Description..." -ForegroundColor Cyan
        
        # Verificar si est� instalado el m�dulo SqlServer
      if (-not (Get-Module -ListAvailable -Name SqlServer)) {
            Write-Host "  Instalando m�dulo SqlServer..." -ForegroundColor Yellow
      Install-Module -Name SqlServer -Scope CurrentUser -Force -AllowClobber
        }
  
        Invoke-Sqlcmd -ServerInstance $ServerInstance -Database $Database -Query $Query -TrustServerCertificate -ErrorAction Stop
     Write-Host "  ? Completado" -ForegroundColor Green
        return $true
    }
    catch {
    Write-Host "  ? Error: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

Write-Host "=========================================="
Write-Host "PASO 1: Limpiando base de datos..."
Write-Host "=========================================="
Write-Host ""

# Deshabilitar constraints
$success = Invoke-SqlCommand -Query @"
ALTER TABLE [dbo].[EntityMemberProfiles] NOCHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[EntityUserProfiles] NOCHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[IndependentUserProfiles] NOCHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[AspNetUserTokens] NOCHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[AspNetUserRoles] NOCHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[AspNetUserLogins] NOCHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[AspNetUserClaims] NOCHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[AspNetRoleClaims] NOCHECK CONSTRAINT ALL;
"@ -Description "Deshabilitando constraints"

if (-not $success) {
    Write-Host "Error al deshabilitar constraints. Abortando." -ForegroundColor Red
    exit 1
}

# Eliminar datos
$tables = @(
  @{Name="EntityMemberProfiles"; Desc="Perfiles de miembros"},
    @{Name="EntityUserProfiles"; Desc="Perfiles de entidades"},
    @{Name="IndependentUserProfiles"; Desc="Perfiles independientes"},
    @{Name="AspNetUserTokens"; Desc="Tokens de usuario"},
    @{Name="AspNetUserRoles"; Desc="Roles de usuario"},
    @{Name="AspNetUserLogins"; Desc="Logins de usuario"},
    @{Name="AspNetUserClaims"; Desc="Claims de usuario"},
    @{Name="AspNetUsers"; Desc="Usuarios"},
    @{Name="AspNetRoleClaims"; Desc="Claims de roles"},
    @{Name="AspNetRoles"; Desc="Roles"}
)

foreach ($table in $tables) {
    $success = Invoke-SqlCommand -Query "DELETE FROM [dbo].[$($table.Name)]" -Description "Eliminando $($table.Desc)"
    if (-not $success) {
  Write-Host "Advertencia: No se pudo limpiar $($table.Name)" -ForegroundColor Yellow
    }
}

# Rehabilitar constraints
Invoke-SqlCommand -Query @"
ALTER TABLE [dbo].[EntityMemberProfiles] CHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[EntityUserProfiles] CHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[IndependentUserProfiles] CHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[AspNetUserTokens] CHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[AspNetUserLogins] CHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[AspNetUserClaims] CHECK CONSTRAINT ALL;
ALTER TABLE [dbo].[AspNetRoleClaims] CHECK CONSTRAINT ALL;
"@ -Description "Rehabilitando constraints"

Write-Host ""
Write-Host "=========================================="
Write-Host "PASO 2: Creando roles del sistema..."
Write-Host "=========================================="
Write-Host ""

$rolesQuery = @"
DECLARE @SuperAdminRoleId NVARCHAR(450) = NEWID();
DECLARE @EntityRoleId NVARCHAR(450) = NEWID();
DECLARE @IndependentRoleId NVARCHAR(450) = NEWID();
DECLARE @EntityMemberRoleId NVARCHAR(450) = NEWID();

INSERT INTO [dbo].[AspNetRoles] ([Id], [Name], [NormalizedName], [ConcurrencyStamp])
VALUES 
    (@SuperAdminRoleId, 'SuperAdmin', 'SUPERADMIN', NEWID()),
    (@EntityRoleId, 'Entity', 'ENTITY', NEWID()),
    (@IndependentRoleId, 'Independent', 'INDEPENDENT', NEWID()),
 (@EntityMemberRoleId, 'EntityMember', 'ENTITYMEMBER', NEWID());
"@

$success = Invoke-SqlCommand -Query $rolesQuery -Description "Creando roles del sistema"

if (-not $success) {
    Write-Host "Error al crear roles. Abortando." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "=========================================="
Write-Host "PASO 3: Verificando que la API est� ejecut�ndose..."
Write-Host "=========================================="
Write-Host ""

Write-Host "IMPORTANTE:" -ForegroundColor Yellow
Write-Host "  1. Aseg�rate de que la aplicaci�n web Salutia est� ejecut�ndose" -ForegroundColor White
Write-Host "  2. Presiona ENTER cuando est� lista, o Ctrl+C para cancelar" -ForegroundColor White
Read-Host

Write-Host ""
Write-Host "=========================================="
Write-Host "PASO 4: Creando SuperAdmin via API..."
Write-Host "=========================================="
Write-Host ""

try {
    # Ignorar errores de certificado SSL en desarrollo
    if ($PSVersionTable.PSVersion.Major -ge 6) {
        $PSDefaultParameterValues['Invoke-RestMethod:SkipCertificateCheck'] = $true
    } else {
        # Para PowerShell 5.1 y anteriores
        add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
  ServicePoint svcPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
  return true;
    }
}
"@
        [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
    }

    $body = @{
        email = $Email
        password = $Password
  setupKey = $SetupKey
    } | ConvertTo-Json

    Write-Host "Llamando al endpoint de creaci�n de SuperAdmin..." -ForegroundColor Cyan
    
 $response = Invoke-RestMethod -Uri "$ApiUrl/api/setup/create-first-superadmin" `
        -Method Post `
        -Body $body `
        -ContentType "application/json" `
        -ErrorAction Stop

    Write-Host ""
    Write-Host "=========================================="
    Write-Host "? SUPERADMIN CREADO EXITOSAMENTE" -ForegroundColor Green
    Write-Host "=========================================="
    Write-Host ""
    Write-Host "Credenciales:" -ForegroundColor Cyan
    Write-Host "  Email:    $Email" -ForegroundColor White
    Write-Host "  Password: $Password" -ForegroundColor White
    Write-Host ""
    Write-Host "ID de Usuario: $($response.userId)" -ForegroundColor Gray
    Write-Host ""
    Write-Host "??  IMPORTANTE: $($response.warning)" -ForegroundColor Yellow
    Write-Host ""
Write-Host "Ya puedes iniciar sesi�n en la aplicaci�n!" -ForegroundColor Green
    Write-Host ""

} catch {
    Write-Host ""
    Write-Host "=========================================="
    Write-Host "? ERROR AL CREAR SUPERADMIN VIA API" -ForegroundColor Red
    Write-Host "=========================================="
    Write-Host ""
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    
    if ($_.Exception.Response) {
        $statusCode = $_.Exception.Response.StatusCode.value__
    Write-Host "C�digo de estado HTTP: $statusCode" -ForegroundColor Yellow
        
      try {
       $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
      $responseBody = $reader.ReadToEnd()
      Write-Host "Respuesta del servidor:" -ForegroundColor Yellow
            Write-Host $responseBody -ForegroundColor White
        } catch {
   Write-Host "No se pudo leer la respuesta del servidor" -ForegroundColor Yellow
        }
    }
    
  Write-Host ""
    Write-Host "Posibles causas:" -ForegroundColor Cyan
    Write-Host "  1. La aplicaci�n web no est� ejecut�ndose" -ForegroundColor White
    Write-Host "  2. La URL de la API es incorrecta (actual: $ApiUrl)" -ForegroundColor White
    Write-Host "  3. Ya existe un SuperAdmin en la base de datos" -ForegroundColor White
    Write-Host ""
    Write-Host "Soluciones:" -ForegroundColor Cyan
    Write-Host "  1. Ejecuta el proyecto 'Salutia Wep App' en Visual Studio" -ForegroundColor White
    Write-Host "  2. Verifica la URL en el navegador: $ApiUrl" -ForegroundColor White
    Write-Host "  3. Verifica el endpoint: $ApiUrl/api/setup/has-superadmin" -ForegroundColor White
    Write-Host ""
}

Write-Host "Presiona ENTER para salir..."
Read-Host

# =============================================
# Script: Generaci�n de SuperAdmin con hash correcto
# Descripci�n: Genera el hash de contrase�a correcto y ejecuta el script SQL
# Email: elpeco1@msn.com
# Password: Admin.123
# =============================================

Write-Host "=========================================="
Write-Host "Generando hash de contrase�a correcto..."
Write-Host "=========================================="
Write-Host ""

# C�digo C# para generar el hash usando el mismo hasher de ASP.NET Core Identity
$code = @"
using System;
using Microsoft.AspNetCore.Identity;

public class PasswordHashGenerator
{
    public static string GenerateHash(string password)
    {
   var hasher = new PasswordHasher<IdentityUser>();
        var user = new IdentityUser();
        return hasher.HashPassword(user, password);
    }
}
"@

# Definir la configuraci�n de SQL Server
$ServerInstance = "localhost" # Cambia esto si tu servidor es diferente
$Database = "Salutia"
$Email = "elpeco1@msn.com"
$Password = "Admin.123"

try {
    Write-Host "Cargando ensamblados de ASP.NET Core Identity..." -ForegroundColor Cyan
    
    # Buscar la DLL de Identity en el proyecto
    $projectPath = "Salutia Wep App"
    $identityDll = Get-ChildItem -Path $projectPath -Filter "Microsoft.AspNetCore.Identity.dll" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    
    if (-not $identityDll) {
     Write-Host "No se encontr� Microsoft.AspNetCore.Identity.dll en los binarios del proyecto." -ForegroundColor Yellow
        Write-Host "Intentando cargar desde NuGet packages..." -ForegroundColor Cyan
        
     # Buscar en la carpeta de packages de NuGet
        $nugetPackages = "$env:USERPROFILE\.nuget\packages\microsoft.aspnetcore.identity\8.0.21\lib\net8.0\Microsoft.AspNetCore.Identity.dll"
        
        if (Test-Path $nugetPackages) {
 Add-Type -Path $nugetPackages
          Write-Host "Ensamblado cargado desde NuGet packages" -ForegroundColor Green
 } else {
       Write-Host "ERROR: No se pudo encontrar Microsoft.AspNetCore.Identity.dll" -ForegroundColor Red
            Write-Host "Por favor, ejecuta 'dotnet build' primero en el proyecto Salutia Wep App" -ForegroundColor Yellow
     exit 1
        }
  } else {
        Add-Type -Path $identityDll.FullName
        Write-Host "Ensamblado cargado desde: $($identityDll.FullName)" -ForegroundColor Green
    }
    
    # Compilar y ejecutar el c�digo C#
Add-Type -TypeDefinition $code -ReferencedAssemblies @(
        "System.Runtime",
        "Microsoft.Extensions.Identity.Core",
    "Microsoft.AspNetCore.Identity"
    )
    
    Write-Host "Generando hash para la contrase�a '$Password'..." -ForegroundColor Cyan
    $passwordHash = [PasswordHashGenerator]::GenerateHash($Password)
    Write-Host "Hash generado exitosamente!" -ForegroundColor Green
    Write-Host ""
    
} catch {
    Write-Host "ERROR al generar el hash: $($_.Exception.Message)" -ForegroundColor Red
Write-Host ""
    Write-Host "Soluci�n alternativa: Usar el endpoint /api/setup/create-superadmin" -ForegroundColor Yellow
    Write-Host "o regenerar el usuario desde la aplicaci�n web." -ForegroundColor Yellow
    exit 1
}

Write-Host "=========================================="
Write-Host "Preparando script SQL..."
Write-Host "=========================================="
Write-Host ""

# Crear el script SQL con el hash correcto
$sqlScript = @"
-- =============================================
-- Script: Limpieza completa de base de datos y creaci�n de SuperAdmin
-- Email: $Email
-- Password: $Password
-- Hash generado: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
-- =============================================

USE [$Database]
GO

PRINT '=========================================='
PRINT 'Iniciando limpieza de base de datos...'
PRINT '=========================================='

-- Deshabilitar verificaci�n de claves for�neas temporalmente
ALTER TABLE [dbo].[EntityMemberProfiles] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[EntityUserProfiles] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[IndependentUserProfiles] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserTokens] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserRoles] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserLogins] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserClaims] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetRoleClaims] NOCHECK CONSTRAINT ALL
GO

PRINT 'Eliminando perfiles de miembros de entidad...'
DELETE FROM [dbo].[EntityMemberProfiles]
GO

PRINT 'Eliminando perfiles de entidades...'
DELETE FROM [dbo].[EntityUserProfiles]
GO

PRINT 'Eliminando perfiles de usuarios independientes...'
DELETE FROM [dbo].[IndependentUserProfiles]
GO

PRINT 'Eliminando tokens de usuario...'
DELETE FROM [dbo].[AspNetUserTokens]
GO

PRINT 'Eliminando roles de usuario...'
DELETE FROM [dbo].[AspNetUserRoles]
GO

PRINT 'Eliminando logins de usuario...'
DELETE FROM [dbo].[AspNetUserLogins]
GO

PRINT 'Eliminando claims de usuario...'
DELETE FROM [dbo].[AspNetUserClaims]
GO

PRINT 'Eliminando usuarios...'
DELETE FROM [dbo].[AspNetUsers]
GO

PRINT 'Eliminando claims de roles...'
DELETE FROM [dbo].[AspNetRoleClaims]
GO

PRINT 'Eliminando roles...'
DELETE FROM [dbo].[AspNetRoles]
GO

-- Rehabilitar verificaci�n de claves for�neas
ALTER TABLE [dbo].[EntityMemberProfiles] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[EntityUserProfiles] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[IndependentUserProfiles] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserTokens] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserLogins] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetUserClaims] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[AspNetRoleClaims] CHECK CONSTRAINT ALL
GO

PRINT '=========================================='
PRINT 'Limpieza completada exitosamente'
PRINT '=========================================='
PRINT ''
PRINT '=========================================='
PRINT 'Creando roles del sistema...'
PRINT '=========================================='

-- Crear roles del sistema
DECLARE @SuperAdminRoleId NVARCHAR(450) = NEWID()
DECLARE @EntityRoleId NVARCHAR(450) = NEWID()
DECLARE @IndependentRoleId NVARCHAR(450) = NEWID()
DECLARE @EntityMemberRoleId NVARCHAR(450) = NEWID()

INSERT INTO [dbo].[AspNetRoles] ([Id], [Name], [NormalizedName], [ConcurrencyStamp])
VALUES 
  (@SuperAdminRoleId, 'SuperAdmin', 'SUPERADMIN', NEWID()),
    (@EntityRoleId, 'Entity', 'ENTITY', NEWID()),
    (@IndependentRoleId, 'Independent', 'INDEPENDENT', NEWID()),
    (@EntityMemberRoleId, 'EntityMember', 'ENTITYMEMBER', NEWID())
GO

PRINT 'Roles creados exitosamente'
PRINT ''
PRINT '=========================================='
PRINT 'Creando SuperAdmin...'
PRINT '=========================================='

-- Variables para el SuperAdmin
DECLARE @SuperAdminId NVARCHAR(450) = NEWID()
DECLARE @Email NVARCHAR(256) = '$Email'
DECLARE @NormalizedEmail NVARCHAR(256) = '$($Email.ToUpper())'
DECLARE @UserName NVARCHAR(256) = '$Email'
DECLARE @NormalizedUserName NVARCHAR(256) = '$($Email.ToUpper())'
DECLARE @PasswordHash NVARCHAR(MAX) = '$passwordHash'
DECLARE @SecurityStamp NVARCHAR(MAX) = NEWID()
DECLARE @ConcurrencyStamp NVARCHAR(MAX) = NEWID()

-- Insertar SuperAdmin en AspNetUsers
INSERT INTO [dbo].[AspNetUsers] (
    [Id],
    [UserName],
    [NormalizedUserName],
    [Email],
    [NormalizedEmail],
    [EmailConfirmed],
 [PasswordHash],
    [SecurityStamp],
    [ConcurrencyStamp],
    [PhoneNumber],
    [PhoneNumberConfirmed],
    [TwoFactorEnabled],
    [LockoutEnd],
    [LockoutEnabled],
    [AccessFailedCount],
    [UserType],
    [CreatedAt],
  [UpdatedAt],
    [IsActive]
)
VALUES (
  @SuperAdminId,
 @UserName,
    @NormalizedUserName,
    @Email,
    @NormalizedEmail,
    1, -- Email confirmado
    @PasswordHash,
    @SecurityStamp,
    @ConcurrencyStamp,
    NULL, -- Sin tel�fono
    0, -- Tel�fono no confirmado
    0, -- 2FA deshabilitado
    NULL, -- Sin bloqueo
    1, -- Bloqueo habilitado
    0, -- Intentos fallidos = 0
    0, -- UserType.SuperAdmin = 0
    GETUTCDATE(), -- Fecha de creaci�n
    NULL, -- Sin actualizaci�n a�n
    1 -- Usuario activo
)
GO

PRINT 'Usuario SuperAdmin creado'
PRINT '  - Email: $Email'
PRINT '  - Password: $Password'
PRINT ''

-- Asignar rol SuperAdmin al usuario
DECLARE @SuperAdminUserId NVARCHAR(450)
DECLARE @SuperAdminRoleId2 NVARCHAR(450)

SELECT @SuperAdminUserId = Id FROM [dbo].[AspNetUsers] WHERE Email = '$Email'
SELECT @SuperAdminRoleId2 = Id FROM [dbo].[AspNetRoles] WHERE Name = 'SuperAdmin'

INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId])
VALUES (@SuperAdminUserId, @SuperAdminRoleId2)
GO

PRINT 'Rol SuperAdmin asignado al usuario'
PRINT ''
PRINT '=========================================='
PRINT 'PROCESO COMPLETADO EXITOSAMENTE'
PRINT '=========================================='
PRINT ''
PRINT 'Credenciales del SuperAdmin:'
PRINT '  Email:    $Email'
PRINT '  Password: $Password'
PRINT ''
PRINT '=========================================='
GO

-- Verificar resultados
SELECT 
    'Usuarios creados' AS [Tabla],
    COUNT(*) AS [Cantidad]
FROM [dbo].[AspNetUsers]
UNION ALL
SELECT 
 'Roles creados' AS [Tabla],
    COUNT(*) AS [Cantidad]
FROM [dbo].[AspNetRoles]
UNION ALL
SELECT 
    'Asignaciones de roles' AS [Tabla],
    COUNT(*) AS [Cantidad]
FROM [dbo].[AspNetUserRoles]
GO

-- Mostrar detalle del SuperAdmin creado
SELECT 
    u.Id,
    u.UserName,
    u.Email,
    u.EmailConfirmed,
    u.UserType,
 u.IsActive,
    u.CreatedAt,
    r.Name AS [Rol]
FROM [dbo].[AspNetUsers] u
INNER JOIN [dbo].[AspNetUserRoles] ur ON u.Id = ur.UserId
INNER JOIN [dbo].[AspNetRoles] r ON ur.RoleId = r.Id
WHERE u.Email = '$Email'
GO

PRINT 'Script finalizado'
"@

# Guardar el script SQL
$sqlFilePath = ".\cleanup-and-create-superadmin-GENERATED.sql"
$sqlScript | Out-File -FilePath $sqlFilePath -Encoding UTF8
Write-Host "Script SQL guardado en: $sqlFilePath" -ForegroundColor Green
Write-Host ""

Write-Host "=========================================="
Write-Host "Ejecutando script SQL..."
Write-Host "=========================================="
Write-Host ""

# Verificar si est� instalado el m�dulo SqlServer
if (-not (Get-Module -ListAvailable -Name SqlServer)) {
    Write-Host "Instalando m�dulo SqlServer de PowerShell..." -ForegroundColor Cyan
    Install-Module -Name SqlServer -Scope CurrentUser -Force -AllowClobber
}

try {
    # Ejecutar el script SQL
 Invoke-Sqlcmd -ServerInstance $ServerInstance -Database $Database -InputFile $sqlFilePath -Verbose
    
  Write-Host ""
    Write-Host "=========================================="
    Write-Host "PROCESO COMPLETADO EXITOSAMENTE" -ForegroundColor Green
    Write-Host "=========================================="
 Write-Host ""
Write-Host "Credenciales del SuperAdmin:" -ForegroundColor Cyan
  Write-Host "  Email:    $Email" -ForegroundColor White
    Write-Host "  Password: $Password" -ForegroundColor White
    Write-Host ""
    Write-Host "Ya puedes iniciar sesi�n en la aplicaci�n!" -ForegroundColor Green
    Write-Host ""

} catch {
    Write-Host ""
    Write-Host "ERROR al ejecutar el script SQL: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "El script SQL se guard� en: $sqlFilePath" -ForegroundColor Yellow
    Write-Host "Puedes ejecutarlo manualmente en SQL Server Management Studio." -ForegroundColor Yellow
    Write-Host ""
}

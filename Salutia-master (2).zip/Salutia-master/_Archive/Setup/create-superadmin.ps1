# Script para crear el primer SuperAdministrador en Salutia
# Ejecutar desde PowerShell en el directorio ra�z del proyecto

Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Cyan
Write-Host "   CREAR PRIMER SUPERADMINISTRADOR - SALUTIA" -ForegroundColor Cyan
Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Cyan
Write-Host ""

# Configuraci�n predefinida
$email = "elpeco1@msn.com"
$password = "Dmontoyar.2025"
$setupKey = "Salutia2025!Setup"
$apiUrl = "https://localhost:7242"

# Verificar que la aplicaci�n est� corriendo
$setupEndpoint = "$apiUrl/api/setup/create-first-superadmin"
$checkEndpoint = "$apiUrl/api/setup/has-superadmin"

Write-Host "1. Verificando si la aplicaci�n est� corriendo..." -ForegroundColor Yellow

try {
    $response = Invoke-WebRequest -Uri $checkEndpoint -Method Get -SkipCertificateCheck -ErrorAction Stop
    $data = $response.Content | ConvertFrom-Json
    
    if ($data.hasSuperAdmin) {
        Write-Host " ? Ya existe un SuperAdministrador en el sistema" -ForegroundColor Red
        Write-Host "   $($data.message)" -ForegroundColor Red
        Write-Host ""
  Write-Host "Si necesitas crear otro SuperAdmin, debe hacerlo desde el panel de administraci�n." -ForegroundColor Yellow
 exit
    }
    
    Write-Host "   ? Aplicaci�n accesible" -ForegroundColor Green
    Write-Host "   ? No hay SuperAdministradores. Puedes continuar." -ForegroundColor Green
}
catch {
    Write-Host "   ? Error: No se puede conectar a la aplicaci�n" -ForegroundColor Red
 Write-Host "   Aseg�rate de que la aplicaci�n est� corriendo en: $apiUrl" -ForegroundColor Yellow
    Write-Host " Ejecuta: dotnet run --project ""Salutia.AppHost""" -ForegroundColor Yellow
    exit
}

Write-Host ""
Write-Host "2. Configuraci�n del SuperAdministrador" -ForegroundColor Yellow
Write-Host ""
Write-Host "   Email: $email" -ForegroundColor White
Write-Host "   Password: $('*' * $password.Length)" -ForegroundColor White
Write-Host "   Clave de seguridad: $setupKey" -ForegroundColor White
Write-Host ""

Write-Host "3. Creando SuperAdministrador..." -ForegroundColor Yellow

# Crear el body de la petici�n
$body = @{
    Email = $email
    Password = $password
    SetupKey = $setupKey
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri $setupEndpoint `
        -Method Post `
        -Body $body `
        -ContentType "application/json" `
        -SkipCertificateCheck `
        -ErrorAction Stop

    $result = $response.Content | ConvertFrom-Json
    
    Write-Host ""
    Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Green
    Write-Host "   ? SUPERADMINISTRADOR CREADO EXITOSAMENTE" -ForegroundColor Green
    Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Green
    Write-Host ""
    Write-Host " Usuario ID: $($result.userId)" -ForegroundColor White
    Write-Host " Email: $($result.email)" -ForegroundColor White
    Write-Host ""
    Write-Host "??  IMPORTANTE - SEGURIDAD:" -ForegroundColor Red -BackgroundColor Yellow
    Write-Host "   1. Elimina el archivo: Salutia Wep App\Controllers\SetupController.cs" -ForegroundColor Yellow
    Write-Host "   2. Elimina la clave 'Setup' de appsettings.json" -ForegroundColor Yellow
    Write-Host "   3. Recompila el proyecto" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Ahora puedes iniciar sesi�n en: $apiUrl/Account/Login" -ForegroundColor Cyan
    Write-Host ""
 Write-Host "?? Email: $email" -ForegroundColor White
 Write-Host "?? Password: $password" -ForegroundColor White
    Write-Host ""
}
catch {
    $errorResponse = $_.Exception.Response
    if ($errorResponse) {
 $reader = New-Object System.IO.StreamReader($errorResponse.GetResponseStream())
        $errorContent = $reader.ReadToEnd() | ConvertFrom-Json
    
        Write-Host ""
        Write-Host "   ? Error al crear SuperAdministrador:" -ForegroundColor Red
        Write-Host "   $($errorContent.message)" -ForegroundColor Red
        
        if ($errorContent.errors) {
        Write-Host ""
            Write-Host "   Detalles:" -ForegroundColor Yellow
          foreach ($error in $errorContent.errors) {
   Write-Host "   - $error" -ForegroundColor Yellow
      }
        }
    }
    else {
     Write-Host "   ? Error desconocido: $($_.Exception.Message)" -ForegroundColor Red
  }
}

Write-Host ""
Write-Host "Presiona cualquier tecla para salir..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

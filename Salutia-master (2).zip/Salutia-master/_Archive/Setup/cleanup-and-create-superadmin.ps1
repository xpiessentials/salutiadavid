# ============================================================
# SCRIPT COMPLETO: LIMPIEZA Y CREACI�N DE SUPERADMIN
# ============================================================
# Este script:
# 1. Limpia la base de datos (elimina todos los usuarios)
# 2. Crea el primer SuperAdministrador
# 3. Elimina archivos de seguridad
# ============================================================

param(
    [string]$ServerInstance = "LAPTOP-DAVID\SQLEXPRESS",
[string]$Database = "Salutia",
    [string]$Email = "elpeco1@msn.com",
    [string]$Password = "Dmontoyar.2025",
    [string]$SetupKey = "Salutia2025!Setup",
    [string]$ApiUrl = "https://localhost:7242"
)

Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Cyan
Write-Host "   LIMPIEZA Y CREACI�N DE SUPERADMIN - SALUTIA" -ForegroundColor Cyan
Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Cyan
Write-Host ""

# ============================================================
# PASO 1: LIMPIEZA DE BASE DE DATOS
# ============================================================
Write-Host "PASO 1: Limpieza de Base de Datos" -ForegroundColor Yellow
Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Yellow
Write-Host ""
Write-Host "??  ADVERTENCIA: Se eliminar�n TODOS los usuarios existentes" -ForegroundColor Red
Write-Host ""
Write-Host "Servidor: $ServerInstance" -ForegroundColor White
Write-Host "Base de datos: $Database" -ForegroundColor White
Write-Host ""

$confirmation = Read-Host "�Deseas continuar? (Si/No)"
if ($confirmation -ne "Si") {
    Write-Host "? Operaci�n cancelada por el usuario" -ForegroundColor Red
    exit
}

Write-Host ""
Write-Host "?? Ejecutando limpieza de base de datos..." -ForegroundColor Cyan

try {
    # Verificar si existe el m�dulo SqlServer
 if (-not (Get-Module -ListAvailable -Name SqlServer)) {
        Write-Host "?? Instalando m�dulo SqlServer..." -ForegroundColor Yellow
        Install-Module -Name SqlServer -Force -Scope CurrentUser -AllowClobber
    }

    Import-Module SqlServer -ErrorAction Stop

    # Ejecutar script de limpieza
    $scriptPath = Join-Path $PSScriptRoot "cleanup-database.sql"
    
    if (-not (Test-Path $scriptPath)) {
    Write-Host "? Error: No se encuentra el archivo cleanup-database.sql" -ForegroundColor Red
        exit
    }

    $result = Invoke-Sqlcmd -ServerInstance $ServerInstance `
       -Database $Database `
             -InputFile $scriptPath `
         -Verbose

 Write-Host ""
    Write-Host "? Limpieza de base de datos completada" -ForegroundColor Green
    Write-Host ""
}
catch {
 Write-Host ""
    Write-Host "? Error al limpiar la base de datos:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
  Write-Host "?? Consejo: Puedes ejecutar el script SQL manualmente:" -ForegroundColor Yellow
    Write-Host "   1. Abre SQL Server Management Studio" -ForegroundColor Yellow
 Write-Host "   2. Conecta a: $ServerInstance" -ForegroundColor Yellow
    Write-Host "   3. Abre el archivo: cleanup-database.sql" -ForegroundColor Yellow
    Write-Host "   4. Ejecuta el script" -ForegroundColor Yellow
    Write-Host ""
    
    $continueAnyway = Read-Host "�Deseas continuar con la creaci�n del SuperAdmin? (Si/No)"
    if ($continueAnyway -ne "Si") {
        exit
 }
}

# ============================================================
# PASO 2: VERIFICAR QUE LA APLICACI�N EST� CORRIENDO
# ============================================================
Write-Host ""
Write-Host "PASO 2: Verificando aplicaci�n" -ForegroundColor Yellow
Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Yellow
Write-Host ""

$checkEndpoint = "$ApiUrl/api/setup/has-superadmin"
$maxRetries = 3
$retryCount = 0
$appRunning = $false

while ($retryCount -lt $maxRetries -and -not $appRunning) {
    try {
        Write-Host "?? Verificando conectividad con $ApiUrl... (Intento $($retryCount + 1)/$maxRetries)" -ForegroundColor Cyan
     
        $response = Invoke-WebRequest -Uri $checkEndpoint `
             -Method Get `
           -SkipCertificateCheck `
      -TimeoutSec 5 `
             -ErrorAction Stop

     $data = $response.Content | ConvertFrom-Json
        
   Write-Host "? Aplicaci�n accesible" -ForegroundColor Green
    
        if ($data.hasSuperAdmin) {
            Write-Host "??  Ya existe un SuperAdministrador" -ForegroundColor Yellow
     Write-Host " Esto puede indicar que la limpieza no fue completa" -ForegroundColor Yellow
            Write-Host ""
 $override = Read-Host "�Intentar crear otro SuperAdmin de todas formas? (Si/No)"
        if ($override -ne "Si") {
                exit
   }
   }
        
        $appRunning = $true
    }
    catch {
     $retryCount++
        if ($retryCount -lt $maxRetries) {
      Write-Host "? No se pudo conectar. Reintentando en 3 segundos..." -ForegroundColor Yellow
    Start-Sleep -Seconds 3
        }
 }
}

if (-not $appRunning) {
    Write-Host ""
    Write-Host "? No se puede conectar a la aplicaci�n" -ForegroundColor Red
    Write-Host ""
    Write-Host "Por favor, ejecuta la aplicaci�n primero:" -ForegroundColor Yellow
Write-Host "   dotnet run --project ""Salutia.AppHost""" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "O si prefieres ejecutar solo la Web App:" -ForegroundColor Yellow
    Write-Host "   dotnet run --project ""Salutia Wep App""" -ForegroundColor Cyan
    Write-Host ""
    exit
}

# ============================================================
# PASO 3: CREAR SUPERADMINISTRADOR
# ============================================================
Write-Host ""
Write-Host "PASO 3: Creando SuperAdministrador" -ForegroundColor Yellow
Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Yellow
Write-Host ""
Write-Host "Email: $Email" -ForegroundColor White
Write-Host "Password: $('*' * $Password.Length)" -ForegroundColor White
Write-Host ""

$body = @{
  Email = $Email
    Password = $Password
    SetupKey = $SetupKey
} | ConvertTo-Json

try {
    Write-Host "?? Enviando solicitud..." -ForegroundColor Cyan
    
    $response = Invoke-RestMethod -Uri "$ApiUrl/api/setup/create-first-superadmin" `
    -Method Post `
        -Body $body `
            -ContentType "application/json" `
       -SkipCertificateCheck `
             -ErrorAction Stop
    
    Write-Host ""
    Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Green
    Write-Host "   ? SUPERADMINISTRADOR CREADO EXITOSAMENTE" -ForegroundColor Green
    Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Green
    Write-Host ""
    Write-Host "   Usuario ID: $($response.userId)" -ForegroundColor White
    Write-Host "   Email: $($response.email)" -ForegroundColor White
    Write-Host ""
    
    $cleanupSecurity = $true
}
catch {
    Write-Host ""
    Write-Host "? Error al crear SuperAdministrador:" -ForegroundColor Red
    
    if ($_.ErrorDetails.Message) {
   try {
          $errorObj = $_.ErrorDetails.Message | ConvertFrom-Json
            Write-Host "   $($errorObj.message)" -ForegroundColor Red
  
    if ($errorObj.errors) {
       Write-Host ""
      Write-Host "   Detalles:" -ForegroundColor Yellow
            foreach ($error in $errorObj.errors) {
           Write-Host "- $error" -ForegroundColor Yellow
        }
   }
  }
     catch {
      Write-Host $_.Exception.Message -ForegroundColor Red
        }
    }
    else {
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
    
    Write-Host ""
    $cleanupSecurity = $false
}

# ============================================================
# PASO 4: LIMPIEZA DE SEGURIDAD (OPCIONAL)
# ============================================================
if ($cleanupSecurity) {
    Write-Host ""
    Write-Host "PASO 4: Limpieza de Seguridad" -ForegroundColor Yellow
    Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "??  IMPORTANTE: Por seguridad, se recomienda:" -ForegroundColor Red
    Write-Host "   1. Eliminar el controlador temporal (SetupController.cs)" -ForegroundColor Yellow
    Write-Host "   2. Eliminar la clave de setup del appsettings.json" -ForegroundColor Yellow
    Write-Host ""
    
    $cleanup = Read-Host "�Deseas realizar la limpieza de seguridad ahora? (Si/No)"
    
    if ($cleanup -eq "Si") {
Write-Host ""
      Write-Host "?? Realizando limpieza de seguridad..." -ForegroundColor Cyan
        
        # Eliminar SetupController.cs
        $controllerPath = Join-Path $PSScriptRoot "Salutia Wep App\Controllers\SetupController.cs"
   if (Test-Path $controllerPath) {
            Remove-Item $controllerPath -Force
          Write-Host "? SetupController.cs eliminado" -ForegroundColor Green
}
        else {
Write-Host "??  SetupController.cs no encontrado (posiblemente ya eliminado)" -ForegroundColor Cyan
   }
  
        # Modificar appsettings.json
        $appsettingsPath = Join-Path $PSScriptRoot "Salutia Wep App\appsettings.json"
        if (Test-Path $appsettingsPath) {
     try {
 $appsettings = Get-Content $appsettingsPath -Raw | ConvertFrom-Json
       
                if ($appsettings.PSObject.Properties['Setup']) {
           $appsettings.PSObject.Properties.Remove('Setup')
   $appsettings | ConvertTo-Json -Depth 10 | Set-Content $appsettingsPath
         Write-Host "? Clave de Setup eliminada de appsettings.json" -ForegroundColor Green
 }
     else {
     Write-Host "??  Clave de Setup no encontrada en appsettings.json" -ForegroundColor Cyan
      }
            }
 catch {
           Write-Host "??  No se pudo modificar appsettings.json autom�ticamente" -ForegroundColor Yellow
 Write-Host "   Por favor, elimina manualmente la secci�n 'Setup'" -ForegroundColor Yellow
}
     }
        
   Write-Host ""
        Write-Host "?? Reconstruyendo el proyecto..." -ForegroundColor Cyan
        try {
     $buildResult = dotnet build --nologo --verbosity quiet 2>&1
 if ($LASTEXITCODE -eq 0) {
            Write-Host "? Proyecto reconstruido exitosamente" -ForegroundColor Green
            }
     else {
      Write-Host "??  Advertencias durante la compilaci�n (esto es normal)" -ForegroundColor Yellow
   }
        }
        catch {
       Write-Host "??  No se pudo recompilar autom�ticamente" -ForegroundColor Yellow
            Write-Host "   Ejecuta manualmente: dotnet build" -ForegroundColor Yellow
        }
    }
    else {
        Write-Host ""
        Write-Host "??  RECUERDA eliminar manualmente:" -ForegroundColor Yellow
        Write-Host "1. Salutia Wep App\Controllers\SetupController.cs" -ForegroundColor Yellow
        Write-Host "   2. La secci�n 'Setup' de appsettings.json" -ForegroundColor Yellow
    }
}

# ============================================================
# RESUMEN FINAL
# ============================================================
Write-Host ""
Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Cyan
Write-Host "   PROCESO COMPLETADO" -ForegroundColor Cyan
Write-Host "???????????????????????????????????????????????????????????" -ForegroundColor Cyan
Write-Host ""
Write-Host "?? Email: $Email" -ForegroundColor White
Write-Host "?? Password: $Password" -ForegroundColor White
Write-Host ""
Write-Host "?? Puedes iniciar sesi�n en:" -ForegroundColor Cyan
Write-Host "   $ApiUrl/Account/Login" -ForegroundColor White
Write-Host ""
Write-Host "?? Siguientes pasos recomendados:" -ForegroundColor Yellow
Write-Host "   1. Iniciar sesi�n con las credenciales creadas" -ForegroundColor White
Write-Host "   2. Cambiar la contrase�a desde el perfil" -ForegroundColor White
Write-Host "   3. Configurar 2FA (autenticaci�n de dos factores)" -ForegroundColor White
Write-Host "   4. Crear otros usuarios seg�n sea necesario" -ForegroundColor White
Write-Host ""
Write-Host "Presiona cualquier tecla para salir..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

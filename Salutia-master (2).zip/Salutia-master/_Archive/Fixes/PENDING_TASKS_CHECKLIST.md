# Lista de Tareas para Completar la Actualizaci�n del Sistema de Usuarios

## ? Completado

1. ? Modelos de datos actualizados (ApplicationUser.cs)
2. ? Modelos geogr�ficos creados (GeographicModels.cs)
3. ? DbContext actualizado con nuevas relaciones
4. ? Seeder de datos geogr�ficos creado
5. ? Modelos de autenticaci�n actualizados (AuthModels.cs)
6. ? Roles actualizados en Program.cs
7. ? Componente GeographicSelector creado
8. ? P�gina Admin/Entities actualizada
9. ? Script de migraci�n SQL creado
10. ? Script PowerShell de migraci�n creado
11. ? Documentaci�n completa creada

## ?? Pendientes (Requieren actualizaci�n manual)

### 1. P�ginas de Registro

#### RegisterEntity.razor
**Archivo**: `Salutia Wep App\Components\Account\Pages\RegisterEntity.razor`

**Cambios necesarios**:
- Agregar `GeographicSelector` component
- Agregar binding para campos geogr�ficos en el modelo
- Actualizar validaci�n para incluir campos geogr�ficos
- Actualizar el `UserType` de `Entity` a `EntityAdmin`
- Agregar campo `Website` (opcional)

**Ejemplo de c�digo a agregar**:
```razor
<GeographicSelector 
    @bind-CountryId="Input.CountryId"
    @bind-StateId="Input.StateId"
    @bind-CityId="Input.CityId"
    @bind-Address="Input.Address"
    RequireState="true"
    RequireCity="false"
    RequireAddress="true"
    ShowValidation="true" />
```

#### RegisterIndependent.razor
**Archivo**: `Salutia Wep App\Components\Account\Pages\RegisterIndependent.razor`

**Cambios necesarios**:
- Agregar `GeographicSelector` component
- Agregar binding para campos geogr�ficos
- Actualizar validaci�n

#### RegisterProfessional.razor (NUEVA)
**Archivo**: `Salutia Wep App\Components\Account\Pages\RegisterProfessional.razor`

**Descripci�n**: P�gina para que EntityAdmin registre m�dicos y psic�logos

**Campos necesarios**:
- Email, Password
- FullName, DocumentType, DocumentNumber
- Phone
- ProfessionalType (Doctor/Psychologist) - Radio buttons
- ProfessionalLicense (n�mero de licencia)
- Specialty (especialidad m�dica/psicol�gica)
- GeographicSelector
- EntityId (tomado del usuario logueado)

**Autorizaci�n**: `[Authorize(Roles = "EntityAdmin")]`

#### RegisterPatient.razor (NUEVA)
**Archivo**: `Salutia Wep App\Components\Account\Pages\RegisterPatient.razor`

**Descripci�n**: P�gina para que Doctor/Psychologist registre pacientes

**Campos necesarios**:
- Email, Password (generados autom�ticamente o ingresados)
- FullName, DocumentType, DocumentNumber
- Phone
- DateOfBirth, Gender
- GeographicSelector
- Notes (notas m�dicas)
- ProfessionalId (tomado del usuario logueado)

**Autorizaci�n**: `[Authorize(Roles = "Doctor,Psychologist")]`

### 2. P�ginas de Gesti�n

#### ManageProfessionals.razor (NUEVA)
**Archivo**: `Salutia Wep App\Components\Pages\Entity\ManageProfessionals.razor`

**Descripci�n**: P�gina para que EntityAdmin gestione sus m�dicos y psic�logos

**Funcionalidades**:
- Listar todos los profesionales de la entidad
- Filtrar por tipo (Doctor/Psychologist)
- Ver detalles de cada profesional
- Activar/desactivar profesionales
- Bot�n para crear nuevo profesional (va a RegisterProfessional)
- Mostrar cantidad de pacientes de cada profesional

**Autorizaci�n**: `[Authorize(Roles = "EntityAdmin")]`

#### ManagePatients.razor (NUEVA)
**Archivo**: `Salutia Wep App\Components\Pages\Professional\ManagePatients.razor`

**Descripci�n**: P�gina para que Doctor/Psychologist gestione sus pacientes

**Funcionalidades**:
- Listar todos los pacientes del profesional
- Ver detalles de cada paciente
- Ver historial de tests realizados
- Asignar nuevos tests
- Bot�n para crear nuevo paciente (va a RegisterPatient)
- Actualizar notas m�dicas

**Autorizaci�n**: `[Authorize(Roles = "Doctor,Psychologist")]`

### 3. Actualizaci�n de Dashboards

#### Entity/Dashboard.razor
**Archivo**: `Salutia Wep App\Components\Pages\Entity\Dashboard.razor`

**Cambios necesarios**:
- Cambiar referencias de "Members" a "Professionals"
- Agregar estad�sticas de m�dicos vs psic�logos
- Agregar estad�sticas de pacientes totales
- Mostrar gr�ficos de distribuci�n geogr�fica
- Actualizar navegaci�n a ManageProfessionals

**Cambiar**:
```csharp
// De:
.Include(e => e.Members)
// A:
.Include(e => e.Professionals)
```

#### Doctor/Dashboard.razor (NUEVO)
**Archivo**: `Salutia Wep App\Components\Pages\Professional\DoctorDashboard.razor`

**Funcionalidades**:
- Estad�sticas de pacientes asignados
- �ltimos tests realizados
- Pacientes pendientes de revisi�n
- Acceso r�pido a ManagePatients
- Gr�ficos de correlaciones psicosom�ticas m�s comunes

**Autorizaci�n**: `[Authorize(Roles = "Doctor")]`

#### Psychologist/Dashboard.razor (NUEVO)
**Archivo**: `Salutia Wep App\Components\Pages\Professional\PsychologistDashboard.razor`

**Funcionalidades**:
- Estad�sticas de pacientes en terapia
- Tests completados vs pendientes
- Acceso r�pido a ManagePatients
- Historial de sesiones

**Autorizaci�n**: `[Authorize(Roles = "Psychologist")]`

#### Patient/Dashboard.razor
**Archivo**: `Salutia Wep App\Components\Pages\Patient\Dashboard.razor` (puede existir como Member/Dashboard.razor)

**Cambios necesarios**:
- Verificar que el usuario sea tipo Patient
- Mostrar informaci�n del profesional asignado
- Mostrar tests asignados
- Historial de tests completados
- No permitir crear nuevos tests (solo los asignados)

**Autorizaci�n**: `[Authorize(Roles = "Patient")]`

### 4. Restricci�n de Acceso al Test

#### TestPsicosomatico.razor
**Archivo**: `Salutia Wep App\Components\Pages\TestPsicosomatico.razor`

**Cambios necesarios**:
- Agregar `@attribute [Authorize]` al inicio
- Verificar tipo de usuario antes de permitir test
- Para Patient: verificar que el test est� asignado por su profesional
- Para Independent: acceso directo
- Para Doctor/Psychologist: pueden realizar test propio
- Para EntityAdmin/SuperAdmin: acceso completo

**Ejemplo**:
```razor
@page "/test-psicosomatico"
@attribute [Authorize]

@code {
    protected override async Task OnInitializedAsync()
    {
  var authState = await AuthenticationStateProvider.GetAuthenticationStateAsync();
        var user = authState.User;
        
        if (user.IsInRole("Patient"))
  {
            // Verificar que el test est� asignado
       // Si no est� asignado, redirigir al dashboard
}
    }
}
```

### 5. Actualizaci�n de NavMenu

#### NavMenu.razor
**Archivo**: `Salutia Wep App\Components\Layout\NavMenu.razor`

**Cambios necesarios**:
- Actualizar opciones de men� seg�n el rol del usuario
- SuperAdmin: ve todo
- EntityAdmin: ve gesti�n de profesionales
- Doctor/Psychologist: ve gesti�n de pacientes
- Independent: ve opciones de test directo
- Patient: solo ve su dashboard y tests asignados

**Ejemplo de estructura**:
```razor
<AuthorizeView Roles="EntityAdmin">
 <NavLink href="/Entity/ManageProfessionals">
    <i class="bi bi-people"></i> Profesionales
    </NavLink>
</AuthorizeView>

<AuthorizeView Roles="Doctor,Psychologist">
    <NavLink href="/Professional/ManagePatients">
        <i class="bi bi-person-hearts"></i> Pacientes
    </NavLink>
</AuthorizeView>
```

### 6. Servicios Auxiliares

#### GeographicService.cs (NUEVO - OPCIONAL)
**Archivo**: `Salutia Wep App\Services\GeographicService.cs`

**Descripci�n**: Servicio para encapsular operaciones con datos geogr�ficos

**M�todos necesarios**:
```csharp
public class GeographicService
{
    Task<List<Country>> GetCountriesAsync();
    Task<List<State>> GetStatesByCountryAsync(int countryId);
    Task<List<City>> GetCitiesByStateAsync(int stateId);
    Task<string> GetFullAddressAsync(int? countryId, int? stateId, int? cityId, string? address);
}
```

#### UserManagementService.cs
**Archivo**: `Salutia Wep App\Services\UserManagementService.cs` (YA EXISTE)

**M�todos a agregar**:
```csharp
// Crear profesional
Task<bool> CreateProfessionalAsync(RegisterProfessionalRequest request, string entityAdminId);

// Crear paciente
Task<bool> CreatePatientAsync(RegisterPatientRequest request, string professionalId);

// Obtener profesionales de una entidad
Task<List<EntityProfessionalProfile>> GetProfessionalsByEntityAsync(int entityId);

// Obtener pacientes de un profesional
Task<List<PatientProfile>> GetPatientsByProfessionalAsync(int professionalId);
```

### 7. Validaciones y Seguridad

#### AuthController.cs
**Archivo**: `Salutia Wep App\Controllers\AuthController.cs`

**Endpoints a agregar**:
```csharp
[HttpPost("register-professional")]
[Authorize(Roles = "EntityAdmin")]
public async Task<IActionResult> RegisterProfessional([FromBody] RegisterProfessionalRequest request);

[HttpPost("register-patient")]
[Authorize(Roles = "Doctor,Psychologist")]
public async Task<IActionResult> RegisterPatient([FromBody] RegisterPatientRequest request);
```

### 8. Tests y Validaci�n

Despu�s de implementar los cambios:

1. **Probar flujo de EntityAdmin**:
   - Registrar entidad
   - Crear m�dico
   - Crear psic�logo
   - Verificar ubicaciones geogr�ficas

2. **Probar flujo de Doctor**:
   - Iniciar sesi�n como m�dico
   - Crear paciente
   - Asignar test
   - Revisar resultados

3. **Probar flujo de Psychologist**:
   - Iniciar sesi�n como psic�logo
   - Crear paciente
   - Aplicar TBE
   - Revisar progreso

4. **Probar flujo de Patient**:
   - Iniciar sesi�n como paciente
   - Ver tests asignados
   - Completar test
   - Ver resultados

5. **Probar flujo de Independent**:
   - Registrarse
   - Completar ubicaci�n
   - Realizar test
   - Recibir informe

## ?? Herramientas de Desarrollo

### Comandos �tiles

```bash
# Ver cambios en la base de datos
dotnet ef migrations list

# Generar script SQL de migraci�n
dotnet ef migrations script

# Revertir �ltima migraci�n
dotnet ef database update PreviousMigrationName

# Ver modelo de base de datos
dotnet ef dbcontext info
```

### Queries SQL �tiles

```sql
-- Ver distribuci�n de tipos de usuario
SELECT UserType, COUNT(*) as Count
FROM AspNetUsers
GROUP BY UserType;

-- Ver profesionales por entidad
SELECT e.BusinessName, 
   COUNT(CASE WHEN u.UserType = 3 THEN 1 END) as Doctors,
       COUNT(CASE WHEN u.UserType = 4 THEN 1 END) as Psychologists
FROM EntityUserProfiles e
LEFT JOIN EntityProfessionalProfiles p ON e.Id = p.EntityId
LEFT JOIN AspNetUsers u ON p.ApplicationUserId = u.Id
GROUP BY e.BusinessName;

-- Ver pacientes por profesional
SELECT p.FullName as Professional, COUNT(pt.Id) as Patients
FROM EntityProfessionalProfiles p
LEFT JOIN PatientProfiles pt ON p.Id = pt.ProfessionalId
GROUP BY p.FullName;

-- Ver distribuci�n geogr�fica
SELECT co.Name as Country, st.Name as State, COUNT(u.Id) as Users
FROM AspNetUsers u
LEFT JOIN IndependentUserProfiles ip ON u.Id = ip.ApplicationUserId
LEFT JOIN Countries co ON ip.CountryId = co.Id
LEFT JOIN States st ON ip.StateId = st.Id
WHERE co.Id IS NOT NULL
GROUP BY co.Name, st.Name
ORDER BY co.Name, st.Name;
```

## ?? Referencias

- [ASP.NET Core Identity](https://learn.microsoft.com/en-us/aspnet/core/security/authentication/identity)
- [Entity Framework Core](https://learn.microsoft.com/en-us/ef/core/)
- [Blazor Authorization](https://learn.microsoft.com/en-us/aspnet/core/blazor/security/)

## ?? Notas Importantes

1. **Backup obligatorio** antes de aplicar migraci�n en producci�n
2. **Probar en desarrollo** antes de aplicar en producci�n
3. **Comunicar cambios** a usuarios existentes
4. **Actualizar documentaci�n** de usuario final
5. **Monitorear logs** despu�s del despliegue
6. **Plan de rollback** listo en caso de problemas

## ?? Soporte

Si encuentras problemas durante la implementaci�n:
1. Revisar logs de aplicaci�n
2. Verificar migraciones de EF Core
3. Validar integridad de datos
4. Consultar documentaci�n adjunta

# Checklist de Verificaci�n de Formularios Blazor con Antiforgery

## ? Lista de Verificaci�n para Formularios en �reas Autorizadas

Usa esta lista para revisar todos los formularios en �reas autorizadas (Admin, Entity, Member, etc.)

### 1. Program.cs - Orden de Middleware ?
```csharp
// ? CORRECTO
app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();

// ? INCORRECTO
app.UseAntiforgery();
app.UseAuthentication();
app.UseAuthorization();
```

### 2. Componente Razor - Configuraci�n del Formulario

#### Estructura Correcta:
```razor
@page "/Ruta"
@attribute [Authorize(Roles = "Role")]

@inject InjectedServices...

<EditForm Model="Input" OnValidSubmit="HandleSubmit" FormName="uniqueFormName" method="post">
    <DataAnnotationsValidator />
    <!-- NO incluir <AntiforgeryToken /> aqu� -->
    
    <!-- Campos del formulario -->
    <InputText @bind-Value="Input.Field" />
    
    <button type="submit">Enviar</button>
</EditForm>

@code {
    [CascadingParameter]
  private HttpContext? HttpContext { get; set; }

    [SupplyParameterFromForm]
private InputModel Input { get; set; } = new();
    
    // Resto del c�digo...
}
```

### 3. Checklist por Componente

Para cada formulario en �reas autorizadas, verifica:

- [ ] **EditForm tiene `method="post"`**
- [ ] **EditForm tiene un `FormName` �nico**
- [ ] **NO hay `<AntiforgeryToken />` dentro de EditForm**
- [ ] **El c�digo tiene `[CascadingParameter] HttpContext`**
- [ ] **El modelo usa `[SupplyParameterFromForm]`**
- [ ] **La p�gina tiene `@attribute [Authorize]`**

## ?? Formularios a Revisar en tu Proyecto

### �rea Admin
- [ ] `/Admin/CreateEntity` - ? YA CORREGIDO
- [ ] `/Admin/Users` - Revisar si tiene formularios
- [ ] `/Admin/Entities` - Revisar si tiene formularios
- [ ] `/Admin/Reports` - Revisar si tiene formularios
- [ ] `/Admin/ChangeUserPassword` - **REVISAR** (probablemente tiene formulario)

### �rea Entity
- [ ] `/Entity/AddMember` - **REVISAR** (probablemente tiene formulario)
- [ ] `/Entity/ManageMembers` - Revisar si tiene formularios
- [ ] `/Entity/Dashboard` - Revisar si tiene formularios

### �rea Member
- [ ] `/Member/Dashboard` - Revisar si tiene formularios

### �rea User (Independent)
- [ ] `/User/Dashboard` - Revisar si tiene formularios

### �rea Account (Generalmente OK, pero revisar)
- [ ] `/Account/Login` - Revisar
- [ ] `/Account/RegisterEntity` - Revisar
- [ ] `/Account/RegisterIndependent` - Revisar
- [ ] `/Account/Manage/*` - Revisar p�ginas de gesti�n de cuenta

## ?? C�mo Identificar Problemas

### S�ntomas de Configuraci�n Incorrecta:
1. Error: "A valid antiforgery token was not provided"
2. El formulario se env�a pero no procesa los datos
3. Redirecci�n inesperada despu�s del submit
4. P�rdida del estado de autenticaci�n

### Herramientas de Diagn�stico:

#### 1. Verificar Orden de Middleware:
Busca en `Program.cs` y aseg�rate de que el orden sea:
```
UseAuthentication ? UseAuthorization ? UseAntiforgery
```

#### 2. Verificar Configuraci�n de Formulario:
```bash
# Buscar formularios con AntiforgeryToken expl�cito (puede ser problema)
grep -r "<AntiforgeryToken" "Salutia Wep App/Components/Pages"

# Buscar EditForm sin method="post" en �reas autorizadas
grep -r "<EditForm" "Salutia Wep App/Components/Pages/Admin"
grep -r "<EditForm" "Salutia Wep App/Components/Pages/Entity"
grep -r "<EditForm" "Salutia Wep App/Components/Pages/Member"
```

#### 3. Verificar HttpContext en Componentes Autorizados:
Busca componentes con `[Authorize]` que tengan EditForm y verifica que tengan:
```csharp
[CascadingParameter]
private HttpContext? HttpContext { get; set; }
```

## ?? Patr�n Recomendado

### Template para Formularios en �reas Autorizadas:

```razor
@page "/Area/Action"
@attribute [Authorize(Roles = "RequiredRole")]

@using Namespaces.Required

@inject RequiredServices Service

<PageTitle>T�tulo de la P�gina</PageTitle>

<div class="container">
    @if (!string.IsNullOrEmpty(errorMessage))
    {
        <div class="alert alert-danger">@errorMessage</div>
    }

    @if (!string.IsNullOrEmpty(successMessage))
    {
<div class="alert alert-success">@successMessage</div>
    }

    <EditForm Model="Input" OnValidSubmit="HandleSubmit" FormName="uniqueFormName" method="post">
        <DataAnnotationsValidator />

        <!-- Campos del formulario -->
        
     <button type="submit" disabled="@isProcessing">
   @if (isProcessing)
          {
           <span class="spinner-border spinner-border-sm"></span>
}
      Enviar
  </button>
    </EditForm>
</div>

@code {
    private bool isProcessing = false;
    private string? errorMessage;
    private string? successMessage;

    [CascadingParameter]
    private HttpContext? HttpContext { get; set; }

    [SupplyParameterFromForm]
    private InputModel Input { get; set; } = new();

    private async Task HandleSubmit()
    {
        isProcessing = true;
        errorMessage = null;
        successMessage = null;

        try
        {
        // L�gica del formulario
        }
    catch (Exception ex)
        {
 errorMessage = "Error procesando el formulario";
   }
        finally
    {
          isProcessing = false;
        }
    }

    private sealed class InputModel
  {
        [Required]
        public string Field { get; set; } = "";
    }
}
```

## ?? Acciones Inmediatas

1. **Verificar Program.cs** - ? YA CORREGIDO
2. **Revisar CreateEntity.razor** - ? YA CORREGIDO
3. **Revisar otros formularios seg�n la lista**
4. **Probar cada formulario despu�s de correcciones**

## ?? Importante

- **Siempre reiniciar la aplicaci�n** despu�s de cambios en Program.cs
- **Hot reload no funciona** para cambios en el pipeline de middleware
- **Probar en modo Release** adem�s de Debug para asegurar que funciona en producci�n

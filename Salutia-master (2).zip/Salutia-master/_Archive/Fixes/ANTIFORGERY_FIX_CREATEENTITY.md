# Fix Antiforgery Token Error - CreateEntity Page

## Problem
When attempting to create a new entity through the `/Admin/CreateEntity` page, the following error occurred:
```
A valid antiforgery token was not provided with the request. Add an antiforgery token, or disable antiforgery validation for this endpoint.
```

## Root Causes Identified
The issue was caused by **TWO CRITICAL PROBLEMS**:

### 1. Incorrect Middleware Order in Program.cs
The `UseAntiforgery()` middleware was placed **BEFORE** `UseAuthentication()` and `UseAuthorization()`, which prevented proper antiforgery token validation for authenticated requests.

### 2. EditForm Configuration Issues
- The form had an explicit `<AntiforgeryToken />` component, but `EditForm` automatically includes it in .NET 8
- The form was missing the `method="post"` attribute
- The component was missing the HttpContext cascading parameter needed for proper token validation

## Solutions Applied

### Fix 1: Program.cs - Middleware Order
**File Modified:** `Salutia Wep App\Program.cs`

#### Before (INCORRECT):
```csharp
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();  // ? WRONG ORDER

// AuthZ middlewares
app.UseAuthentication();
app.UseAuthorization();
```

#### After (CORRECT):
```csharp
app.UseHttpsRedirection();
app.UseStaticFiles();

// AuthZ middlewares - MUST COME BEFORE UseAntiforgery
app.UseAuthentication();
app.UseAuthorization();

// Antiforgery MUST COME AFTER Authentication and Authorization
app.UseAntiforgery();  // ? CORRECT ORDER
```

**Why This Order Matters:**
According to Microsoft documentation, `UseAntiforgery()` MUST be called after `UseAuthentication()` and `UseAuthorization()` because:
- The antiforgery system needs access to the authenticated user context
- Authorization policies may affect which endpoints require antiforgery protection
- The authentication middleware establishes the user's identity that the antiforgery system validates

### Fix 2: CreateEntity.razor - Form Configuration
**File Modified:** `Salutia Wep App\Components\Pages\Admin\CreateEntity.razor`

#### Changes Made:
1. **Removed** the explicit `<AntiforgeryToken />` component
2. **Added** `method="post"` attribute to EditForm
3. **Changed** FormName from "registerEntity" to "createEntity" (to avoid conflicts)
4. **Added** `HttpContext` cascading parameter

#### Before:
```razor
<EditForm Model="Input" OnValidSubmit="RegisterEntity" FormName="registerEntity">
    <AntiforgeryToken />
    <DataAnnotationsValidator />
    ...
</EditForm>

@code {
    [SupplyParameterFromForm]
    private InputModel Input { get; set; } = new();
}
```

#### After:
```razor
<EditForm Model="Input" OnValidSubmit="RegisterEntity" FormName="createEntity" method="post">
    <DataAnnotationsValidator />
    ...
</EditForm>

@code {
    [CascadingParameter]
    private HttpContext? HttpContext { get; set; }

[SupplyParameterFromForm]
    private InputModel Input { get; set; } = new();
}
```

## Technical Details

### Blazor .NET 8 Antiforgery Requirements:
1. **Automatic Token Generation**: `EditForm` with a `FormName` automatically includes antiforgery protection
2. **Middleware Order**: Critical for proper token validation in authenticated scenarios
3. **HttpContext**: Required for components under `[Authorize]` attribute to properly handle antiforgery tokens
4. **Method Attribute**: The `method="post"` ensures proper form submission handling

### Middleware Pipeline Order (Critical):
```
UseHttpsRedirection
UseStaticFiles
UseRouting (implicit)
UseAuthentication ? MUST be before UseAntiforgery
UseAuthorization   ? MUST be before UseAntiforgery
UseAntiforgery     ? MUST be after Auth middlewares
UseCors
MapRazorComponents
```

## Verification Steps
- ? Build completed successfully
- ? No compilation errors
- ? Middleware order corrected
- ? Form configuration follows .NET 8 Blazor best practices

## Testing Instructions
**IMPORTANT:** You MUST restart the application for these changes to take effect.

1. **Stop** the current debugging session completely
2. **Restart** the application (not hot reload)
3. Log in as SuperAdmin
4. Navigate to `/Admin/CreateEntity`
5. Fill in the entity creation form with test data:
   - Raz�n Social: Test Entity
   - NIT: 123456789
   - DV: 1
   - Tel�fono: +57 300 1234567
   - Email: testentity@test.com
   - Password: Test123
6. Click "Registrar Entidad"
7. Verify the entity is created successfully without antiforgery errors

## Why Hot Reload Won't Fix This
Hot reload cannot apply changes to the middleware pipeline configured in Program.cs. The application must be completely restarted for these changes to take effect.

## Related Documentation
- [ASP.NET Core Blazor authentication and authorization - Antiforgery support](https://learn.microsoft.com/en-us/aspnet/core/blazor/security/?view=aspnetcore-8.0#antiforgery-support)
- [ASP.NET Core Blazor forms overview - Antiforgery support](https://learn.microsoft.com/en-us/aspnet/core/blazor/forms/?view=aspnetcore-8.0#antiforgery-support)
- [ASP.NET Core Middleware Order](https://learn.microsoft.com/en-us/aspnet/core/fundamentals/middleware/?view=aspnetcore-8.0#middleware-order)

## Additional Notes
- This same middleware order issue could affect other forms in authorized areas of the application
- The Login.razor page doesn't have this issue because it's not in an authorized area
- Other admin pages should also be reviewed to ensure they follow the same pattern

## Common Pitfalls to Avoid
1. ? Placing `UseAntiforgery()` before authentication middleware
2. ? Manually adding `<AntiforgeryToken />` inside `EditForm`
3. ? Forgetting the `method="post"` attribute on EditForm
4. ? Missing HttpContext cascading parameter in authorized components
5. ? Using hot reload to test middleware changes (requires full restart)

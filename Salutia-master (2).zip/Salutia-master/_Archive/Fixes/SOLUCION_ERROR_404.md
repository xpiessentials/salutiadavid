# ? SOLUCI�N COMPLETA - Error 404 en Mis Miembros

## ?? Problema Resuelto

**Error Original:** 404 al intentar acceder a `/Entity/ManageMembers`

**Causa:** Sistema actualizado de "Miembros" a "Profesionales"

**Estado:** ? **C�DIGO CORREGIDO Y COMPILANDO**

---

## ?? CAMBIOS APLICADOS

### 1. ? NavMenu.razor Actualizado
- ? Roles="Entity" ? ? Roles="EntityAdmin"  
- ? `/Entity/ManageMembers` ? ? `/Entity/ManageProfessionals`
- ? "Mis Miembros" ? ? "Mis Profesionales"
- ? Agregados roles para Doctor, Psychologist, Patient

### 2. ? ManageMembers.razor Ya Actualizado
- ? Ruta: `/Entity/ManageProfessionals`
- ? Usa `EntityProfessionalProfile`
- ? Autorizaci�n correcta: `[Authorize(Roles = "EntityAdmin")]`

### 3. ? AddMember.razor ? AddProfessional.razor
- ? Ruta: `/Entity/AddProfessional`
- ? Campos para profesionales de salud
- ? Registro de m�dicos y psic�logos

---

## ?? PASOS SIGUIENTES (DEBES HACER)

### PASO 1: Ejecutar Migraci�n SQL ?? CR�TICO

**El c�digo est� listo, pero la base de datos NO.**

Abre SQL Server Management Studio (SSMS) y ejecuta:

```
Archivo: Salutia Wep App\Data\Migrations\UpdateToNewUserSystem.sql
```

**Qu� hace este script:**
- ? Crea tablas geogr�ficas (Countries, States, Cities)
- ? Crea EntityProfessionalProfiles
- ? Crea PatientProfiles
- ? Agrega campos geogr�ficos a EntityUserProfile
- ? **NO afecta al superusuario**

### PASO 2: Actualizar Roles en la Base de Datos

Despu�s de ejecutar la migraci�n, ejecuta esto en SSMS:

```sql
-- Agregar nuevos roles
IF NOT EXISTS (SELECT 1 FROM AspNetRoles WHERE Name = 'EntityAdmin')
    INSERT INTO AspNetRoles (Id, Name, NormalizedName) 
    VALUES (NEWID(), 'EntityAdmin', 'ENTITYADMIN');

IF NOT EXISTS (SELECT 1 FROM AspNetRoles WHERE Name = 'Doctor')
    INSERT INTO AspNetRoles (Id, Name, NormalizedName) 
    VALUES (NEWID(), 'Doctor', 'DOCTOR');

IF NOT EXISTS (SELECT 1 FROM AspNetRoles WHERE Name = 'Psychologist')
 INSERT INTO AspNetRoles (Id, Name, NormalizedName) 
    VALUES (NEWID(), 'Psychologist', 'PSYCHOLOGIST');

IF NOT EXISTS (SELECT 1 FROM AspNetRoles WHERE Name = 'Patient')
    INSERT INTO AspNetRoles (Id, Name, NormalizedName) 
    VALUES (NEWID(), 'Patient', 'PATIENT');

-- Ver tus usuarios actuales
SELECT u.Id, u.Email, u.UserType, r.Name as RoleName
FROM AspNetUsers u
LEFT JOIN AspNetUserRoles ur ON u.Id = ur.UserId
LEFT JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE u.UserType IN (1, 2); -- EntityAdmin(1), Independent(2)

-- Actualizar tu usuario de Entity a EntityAdmin
DECLARE @UserId nvarchar(450) = 'TU_USER_ID_AQUI'; -- Reemplaza con el Id de tu usuario
DECLARE @EntityAdminRoleId nvarchar(450) = (SELECT Id FROM AspNetRoles WHERE Name = 'EntityAdmin');

-- Si tienes rol "Entity", eliminarlo
DELETE FROM AspNetUserRoles 
WHERE UserId = @UserId 
AND RoleId IN (SELECT Id FROM AspNetRoles WHERE Name = 'Entity');

-- Agregar rol EntityAdmin
IF NOT EXISTS (SELECT 1 FROM AspNetUserRoles WHERE UserId = @UserId AND RoleId = @EntityAdminRoleId)
    INSERT INTO AspNetUserRoles (UserId, RoleId) 
    VALUES (@UserId, @EntityAdminRoleId);
```

### PASO 3: Reiniciar la Aplicaci�n

```powershell
# Det�n la aplicaci�n (Ctrl+C en la consola)
# Luego ejecuta nuevamente:
cd "Salutia Wep App"
dotnet run
```

O simplemente presiona **F5** en Visual Studio.

---

## ? VERIFICACI�N R�PIDA

Despu�s de completar los pasos:

1. **Inicia sesi�n** como administrador de entidad
2. En el men� lateral deber�as ver:
   - ? "Mi Dashboard"
   - ? **"Mis Profesionales"** (no "Mis Miembros")
3. Haz clic en "Mis Profesionales"
   - ? Deber�a cargar `/Entity/ManageProfessionals` sin error 404
4. Haz clic en "Agregar Profesional"
 - ? Deber�a cargar `/Entity/AddProfessional` con formulario completo

---

## ?? SI A�N HAY ERROR 404

### Problema: Rol incorrecto

**S�ntoma:** A�n aparece error 404 o "No tienes permiso"

**Soluci�n:** Verifica tu rol actual:

```sql
-- Ver tu rol actual
SELECT u.Email, r.Name 
FROM AspNetUsers u
INNER JOIN AspNetUserRoles ur ON u.Id = ur.UserId
INNER JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE u.Email = 'TU_EMAIL_AQUI';
```

**Debe mostrar:** `EntityAdmin`

Si muestra `Entity` u otro, actual�zalo con el script del PASO 2.

### Problema: Tablas no existen

**S�ntoma:** Error al cargar datos o p�gina en blanco

**Soluci�n:** Verifica que ejecutaste la migraci�n SQL:

```sql
-- Verificar que existen las nuevas tablas
SELECT name FROM sys.tables WHERE name IN (
    'Countries', 
    'States', 
    'Cities', 
    'EntityProfessionalProfiles', 
    'PatientProfiles'
);
```

**Debe mostrar:** 5 tablas

Si no aparecen, ejecuta el script del PASO 1.

---

## ?? RESUMEN DEL NUEVO SISTEMA

### Tipos de Usuario:

| UserType | Valor | Rol | Dashboard |
|----------|-------|-----|-----------|
| SuperAdmin | 0 | SuperAdmin | /Admin/Dashboard |
| EntityAdmin | 1 | EntityAdmin | /Entity/Dashboard |
| Independent | 2 | Independent | /User/Dashboard |
| Doctor | 3 | Doctor | /Professional/Dashboard |
| Psychologist | 4 | Psychologist | /Professional/Dashboard |
| Patient | 5 | Patient | /Patient/Dashboard |

### P�ginas de Entidad:

- ? `/Entity/Dashboard` - Dashboard principal
- ? `/Entity/ManageProfessionals` - Lista de profesionales
- ? `/Entity/AddProfessional` - Registro de nuevo profesional
- ? `/Entity/Professional/{id}` - Detalles de profesional (pr�ximamente)

---

## ?? PR�XIMAS FUNCIONALIDADES

Una vez completada la migraci�n, podr�s:

1. **Registrar Profesionales**
   - M�dicos con especialidad y licencia
   - Psic�logos con especialidad y licencia
   - Con ubicaci�n geogr�fica completa

2. **Gestionar Profesionales**
   - Ver lista completa
   - Activar/Desactivar
   - Ver detalles y pacientes

3. **Registrar Pacientes** (pr�ximamente)
   - Asignados a profesionales
   - Con historia cl�nica
   - Con informaci�n de emergencia

---

## ?? �NECESITAS M�S AYUDA?

Si despu�s de ejecutar los PASOS 1, 2 y 3 a�n tienes problemas:

1. Verifica los logs de la aplicaci�n
2. Verifica que la migraci�n SQL se ejecut� completa
3. Verifica que tu usuario tiene el rol "EntityAdmin"
4. Comparte el error espec�fico que ves

---

## ?? ARCHIVOS DE REFERENCIA

- **Script SQL:** `Salutia Wep App\Data\Migrations\UpdateToNewUserSystem.sql`
- **Instrucciones Completas:** `INSTRUCCIONES_FINALES_MIGRACION.md`
- **NavMenu:** `Salutia Wep App\Components\Layout\NavMenu.razor`
- **Gesti�n Profesionales:** `Salutia Wep App\Components\Pages\Entity\ManageMembers.razor`
- **Agregar Profesional:** `Salutia Wep App\Components\Pages\Entity\AddMember.razor`

# Script para actualizar referencias de tipos de usuario obsoletos
# Ejecutar desde el directorio ra�z del proyecto

Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "Actualizaci�n de Referencias de Tipos de Usuario" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host ""

$filesToUpdate = @(
    "Salutia Wep App\Components\Pages\Admin\Users.razor",
    "Salutia Wep App\Components\Pages\Admin\Reports.razor",
    "Salutia Wep App\Components\Pages\Entity\Dashboard.razor",
    "Salutia Wep App\Components\Pages\Member\Dashboard.razor",
    "Salutia Wep App\Services\UserManagementService.cs"
)

foreach ($file in $filesToUpdate) {
    if (Test-Path $file) {
        Write-Host "Actualizando: $file" -ForegroundColor Yellow
        
        $content = Get-Content $file -Raw
     
        # Reemplazos de UserType
        $content = $content -replace 'UserType\.Entity(?!Admin)', 'UserType.EntityAdmin'
     $content = $content -replace 'UserType\.EntityMember', 'UserType.Doctor, UserType.Psychologist'
  $content = $content -replace '"Entity"(?=\))', '"EntityAdmin"'
    $content = $content -replace '"EntityMember"', '"Doctor", "Psychologist"'
        
        # Reemplazos de EntityMemberProfile
     $content = $content -replace 'EntityMemberProfile', 'EntityProfessionalProfile'
        $content = $content -replace 'RegisterEntityMemberRequest', 'RegisterProfessionalRequest'
        $content = $content -replace 'EntityMemberProfiles', 'EntityProfessionalProfiles'
  $content = $content -replace '\.Members(?!hip)', '.Professionals'
        
        # Etiquetas de texto
$content = $content -replace '"Entidad"(?=\))', '"Administrador Entidad"'
  $content = $content -replace '"Miembro"', '"Profesional"'
    $content = $content -replace 'Miembros', 'Profesionales'
      $content = $content -replace 'miembros', 'profesionales'
        
        Set-Content $file $content -NoNewline
 Write-Host "  ? Actualizado" -ForegroundColor Green
    } else {
        Write-Host "  ? Archivo no encontrado: $file" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "Actualizaci�n completada" -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "NOTA: Algunos archivos pueden requerir ajustes manuales" -ForegroundColor Yellow
Write-Host "Revisa los archivos actualizados para confirmar los cambios" -ForegroundColor Yellow
Write-Host ""

Read-Host "Presiona Enter para continuar"

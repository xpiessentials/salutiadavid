-- Script de migraci�n para actualizar la estructura de usuarios y agregar datos geogr�ficos
-- Ejecutar en SQL Server Management Studio o similar

USE [Salutia_DB];
GO

-- ============================================
-- PASO 1: Crear tablas geogr�ficas
-- ============================================

-- Tabla de Pa�ses
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Countries')
BEGIN
    CREATE TABLE Countries (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
  Code NVARCHAR(3) NOT NULL,
     CONSTRAINT UQ_Countries_Code UNIQUE (Code)
    );
    PRINT 'Tabla Countries creada';
END
ELSE
BEGIN
    PRINT 'Tabla Countries ya existe';
END
GO

-- Tabla de Estados/Departamentos
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'States')
BEGIN
    CREATE TABLE States (
     Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
   Code NVARCHAR(10) NOT NULL,
     CountryId INT NOT NULL,
      CONSTRAINT FK_States_Countries FOREIGN KEY (CountryId) REFERENCES Countries(Id) ON DELETE CASCADE,
        CONSTRAINT UQ_States_CountryCode UNIQUE (CountryId, Code)
    );
    PRINT 'Tabla States creada';
END
ELSE
BEGIN
    PRINT 'Tabla States ya existe';
END
GO

-- Tabla de Ciudades
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Cities')
BEGIN
    CREATE TABLE Cities (
    Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        StateId INT NOT NULL,
        CONSTRAINT FK_Cities_States FOREIGN KEY (StateId) REFERENCES States(Id) ON DELETE CASCADE
    );
    PRINT 'Tabla Cities creada';
END
ELSE
BEGIN
PRINT 'Tabla Cities ya existe';
END
GO

-- ============================================
-- PASO 2: Agregar campos geogr�ficos a tablas existentes
-- ============================================

-- Agregar campos a IndependentUserProfiles
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('IndependentUserProfiles') AND name = 'CountryId')
BEGIN
    ALTER TABLE IndependentUserProfiles ADD CountryId INT NULL;
    ALTER TABLE IndependentUserProfiles ADD CONSTRAINT FK_IndependentUserProfiles_Countries FOREIGN KEY (CountryId) REFERENCES Countries(Id);
    PRINT 'Campo CountryId agregado a IndependentUserProfiles';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('IndependentUserProfiles') AND name = 'StateId')
BEGIN
    ALTER TABLE IndependentUserProfiles ADD StateId INT NULL;
    ALTER TABLE IndependentUserProfiles ADD CONSTRAINT FK_IndependentUserProfiles_States FOREIGN KEY (StateId) REFERENCES States(Id);
    PRINT 'Campo StateId agregado a IndependentUserProfiles';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('IndependentUserProfiles') AND name = 'CityId')
BEGIN
    ALTER TABLE IndependentUserProfiles ADD CityId INT NULL;
    ALTER TABLE IndependentUserProfiles ADD CONSTRAINT FK_IndependentUserProfiles_Cities FOREIGN KEY (CityId) REFERENCES Cities(Id);
    PRINT 'Campo CityId agregado a IndependentUserProfiles';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('IndependentUserProfiles') AND name = 'Address')
BEGIN
    ALTER TABLE IndependentUserProfiles ADD Address NVARCHAR(MAX) NULL;
    PRINT 'Campo Address agregado a IndependentUserProfiles';
END
GO

-- Agregar campos a EntityUserProfiles
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('EntityUserProfiles') AND name = 'CountryId')
BEGIN
    ALTER TABLE EntityUserProfiles ADD CountryId INT NULL;
    ALTER TABLE EntityUserProfiles ADD CONSTRAINT FK_EntityUserProfiles_Countries FOREIGN KEY (CountryId) REFERENCES Countries(Id);
    PRINT 'Campo CountryId agregado a EntityUserProfiles';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('EntityUserProfiles') AND name = 'StateId')
BEGIN
    ALTER TABLE EntityUserProfiles ADD StateId INT NULL;
    ALTER TABLE EntityUserProfiles ADD CONSTRAINT FK_EntityUserProfiles_States FOREIGN KEY (StateId) REFERENCES States(Id);
    PRINT 'Campo StateId agregado a EntityUserProfiles';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('EntityUserProfiles') AND name = 'CityId')
BEGIN
    ALTER TABLE EntityUserProfiles ADD CityId INT NULL;
    ALTER TABLE EntityUserProfiles ADD CONSTRAINT FK_EntityUserProfiles_Cities FOREIGN KEY (CityId) REFERENCES Cities(Id);
    PRINT 'Campo CityId agregado a EntityUserProfiles';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('EntityUserProfiles') AND name = 'Website')
BEGIN
    ALTER TABLE EntityUserProfiles ADD Website NVARCHAR(MAX) NULL;
    PRINT 'Campo Website agregado a EntityUserProfiles';
END
GO

-- ============================================
-- PASO 3: Renombrar tabla EntityMemberProfiles a EntityProfessionalProfiles
-- ============================================

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'EntityMemberProfiles')
BEGIN
    -- Crear nueva tabla EntityProfessionalProfiles
CREATE TABLE EntityProfessionalProfiles (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        ApplicationUserId NVARCHAR(450) NOT NULL,
        EntityId INT NOT NULL,
        FullName NVARCHAR(200) NOT NULL,
        DocumentType INT NOT NULL,
        DocumentNumber NVARCHAR(50) NOT NULL,
        Phone NVARCHAR(20) NULL,
      ProfessionalLicense NVARCHAR(100) NULL,
        Specialty NVARCHAR(200) NULL,
        CountryId INT NULL,
        StateId INT NULL,
        CityId INT NULL,
        Address NVARCHAR(MAX) NULL,
        JoinedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        IsActive BIT NOT NULL DEFAULT 1,
    CONSTRAINT FK_EntityProfessionalProfiles_AspNetUsers FOREIGN KEY (ApplicationUserId) REFERENCES AspNetUsers(Id) ON DELETE CASCADE,
        CONSTRAINT FK_EntityProfessionalProfiles_EntityUserProfiles FOREIGN KEY (EntityId) REFERENCES EntityUserProfiles(Id),
      CONSTRAINT FK_EntityProfessionalProfiles_Countries FOREIGN KEY (CountryId) REFERENCES Countries(Id),
        CONSTRAINT FK_EntityProfessionalProfiles_States FOREIGN KEY (StateId) REFERENCES States(Id),
 CONSTRAINT FK_EntityProfessionalProfiles_Cities FOREIGN KEY (CityId) REFERENCES Cities(Id),
        CONSTRAINT UQ_EntityProfessionalProfiles_EntityDocument UNIQUE (EntityId, DocumentNumber)
    );

    -- Migrar datos de EntityMemberProfiles a EntityProfessionalProfiles
    INSERT INTO EntityProfessionalProfiles (ApplicationUserId, EntityId, FullName, DocumentType, DocumentNumber, Phone, JoinedAt, IsActive)
    SELECT ApplicationUserId, EntityId, FullName, DocumentType, DocumentNumber, Phone, JoinedAt, IsActive
    FROM EntityMemberProfiles;

    PRINT 'Datos migrados de EntityMemberProfiles a EntityProfessionalProfiles';

    -- Eliminar tabla antigua
    DROP TABLE EntityMemberProfiles;
    PRINT 'Tabla EntityMemberProfiles eliminada';
END
ELSE
BEGIN
    PRINT 'Tabla EntityMemberProfiles no existe o ya fue migrada';
END
GO

-- ============================================
-- PASO 4: Crear tabla PatientProfiles
-- ============================================

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PatientProfiles')
BEGIN
    CREATE TABLE PatientProfiles (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        ApplicationUserId NVARCHAR(450) NOT NULL,
  ProfessionalId INT NOT NULL,
        FullName NVARCHAR(200) NOT NULL,
    DocumentType INT NOT NULL,
      DocumentNumber NVARCHAR(50) NOT NULL,
        Phone NVARCHAR(20) NULL,
        DateOfBirth DATETIME2 NULL,
  Gender NVARCHAR(50) NULL,
        CountryId INT NULL,
      StateId INT NULL,
        CityId INT NULL,
      Address NVARCHAR(MAX) NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        IsActive BIT NOT NULL DEFAULT 1,
        Notes NVARCHAR(MAX) NULL,
        CONSTRAINT FK_PatientProfiles_AspNetUsers FOREIGN KEY (ApplicationUserId) REFERENCES AspNetUsers(Id) ON DELETE CASCADE,
        CONSTRAINT FK_PatientProfiles_EntityProfessionalProfiles FOREIGN KEY (ProfessionalId) REFERENCES EntityProfessionalProfiles(Id),
        CONSTRAINT FK_PatientProfiles_Countries FOREIGN KEY (CountryId) REFERENCES Countries(Id),
        CONSTRAINT FK_PatientProfiles_States FOREIGN KEY (StateId) REFERENCES States(Id),
        CONSTRAINT FK_PatientProfiles_Cities FOREIGN KEY (CityId) REFERENCES Cities(Id),
        CONSTRAINT UQ_PatientProfiles_ProfessionalDocument UNIQUE (ProfessionalId, DocumentNumber)
    );
    PRINT 'Tabla PatientProfiles creada';
END
ELSE
BEGIN
    PRINT 'Tabla PatientProfiles ya existe';
END
GO

-- ============================================
-- PASO 5: Actualizar roles
-- ============================================

-- Eliminar roles antiguos que ya no se usan
DELETE FROM AspNetRoles WHERE Name = 'Entity';
DELETE FROM AspNetRoles WHERE Name = 'EntityMember';
PRINT 'Roles antiguos eliminados';

-- Agregar nuevos roles si no existen
IF NOT EXISTS (SELECT * FROM AspNetRoles WHERE Name = 'EntityAdmin')
BEGIN
    INSERT INTO AspNetRoles (Id, Name, NormalizedName, ConcurrencyStamp)
    VALUES (NEWID(), 'EntityAdmin', 'ENTITYADMIN', NEWID());
    PRINT 'Rol EntityAdmin creado';
END

IF NOT EXISTS (SELECT * FROM AspNetRoles WHERE Name = 'Doctor')
BEGIN
    INSERT INTO AspNetRoles (Id, Name, NormalizedName, ConcurrencyStamp)
    VALUES (NEWID(), 'Doctor', 'DOCTOR', NEWID());
    PRINT 'Rol Doctor creado';
END

IF NOT EXISTS (SELECT * FROM AspNetRoles WHERE Name = 'Psychologist')
BEGIN
    INSERT INTO AspNetRoles (Id, Name, NormalizedName, ConcurrencyStamp)
    VALUES (NEWID(), 'Psychologist', 'PSYCHOLOGIST', NEWID());
    PRINT 'Rol Psychologist creado';
END

IF NOT EXISTS (SELECT * FROM AspNetRoles WHERE Name = 'Patient')
BEGIN
    INSERT INTO AspNetRoles (Id, Name, NormalizedName, ConcurrencyStamp)
    VALUES (NEWID(), 'Patient', 'PATIENT', NEWID());
    PRINT 'Rol Patient creado';
END
GO

-- ============================================
-- PASO 6: Actualizar UserType en usuarios existentes
-- ============================================

-- Actualizar UserType = 1 (Entity) a EntityAdmin
UPDATE AspNetUsers SET UserType = 1 WHERE UserType = 1;
PRINT 'UserTypes actualizados';
GO

PRINT 'Migraci�n completada exitosamente';
GO

# Script para aplicar migraci�n y cargar datos geogr�ficos
# Ejecutar desde el directorio ra�z del proyecto

Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "Migraci�n del Sistema de Usuarios - Salutia" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host ""

# Cambiar al directorio del proyecto web
Set-Location "Salutia Wep App"

Write-Host "Paso 1: Eliminando migraciones anteriores..." -ForegroundColor Yellow
# Eliminar carpeta de migraciones si existe
if (Test-Path "Migrations") {
 Remove-Item -Path "Migrations" -Recurse -Force
    Write-Host "Migraciones anteriores eliminadas" -ForegroundColor Green
}

Write-Host ""
Write-Host "Paso 2: Creando nueva migraci�n..." -ForegroundColor Yellow
dotnet ef migrations add UpdateUserSystemWithGeography
if ($LASTEXITCODE -eq 0) {
    Write-Host "Migraci�n creada exitosamente" -ForegroundColor Green
} else {
    Write-Host "Error al crear la migraci�n" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Paso 3: Aplicando migraci�n a la base de datos..." -ForegroundColor Yellow
dotnet ef database update
if ($LASTEXITCODE -eq 0) {
    Write-Host "Migraci�n aplicada exitosamente" -ForegroundColor Green
} else {
    Write-Host "Error al aplicar la migraci�n" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "Migraci�n completada exitosamente" -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "IMPORTANTE: Al iniciar la aplicaci�n:" -ForegroundColor Yellow
Write-Host "1. Los datos geogr�ficos se cargar�n autom�ticamente" -ForegroundColor White
Write-Host "2. Los roles se actualizar�n autom�ticamente" -ForegroundColor White
Write-Host ""
Write-Host "Nuevos roles disponibles:" -ForegroundColor Yellow
Write-Host "  - SuperAdmin (administrador del sistema)" -ForegroundColor White
Write-Host "  - EntityAdmin (administrador de entidad)" -ForegroundColor White
Write-Host "  - Doctor (m�dico/especialista)" -ForegroundColor White
Write-Host "  - Psychologist (psic�logo/terapeuta)" -ForegroundColor White
Write-Host "  - Independent (usuario independiente)" -ForegroundColor White
Write-Host "  - Patient (paciente)" -ForegroundColor White
Write-Host ""

# Regresar al directorio ra�z
Set-Location ..

Read-Host "Presiona Enter para continuar"

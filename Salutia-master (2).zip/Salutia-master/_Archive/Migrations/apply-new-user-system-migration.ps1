#!/usr/bin/env pwsh
# =============================================
# Script: Aplicar Migraci�n del Nuevo Sistema de Usuarios
# Descripci�n: Ejecuta la migraci�n SQL de forma segura
# =============================================

param(
  [string]$ConnectionString = "",
    [switch]$WhatIf
)

$ErrorActionPreference = "Stop"

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  Migraci�n del Sistema de Usuarios - Salutia" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""

# Obtener connection string del appsettings.json
if ([string]::IsNullOrEmpty($ConnectionString)) {
    Write-Host "Leyendo connection string desde appsettings.json..." -ForegroundColor Yellow
 
    $appsettingsPath = "Salutia Wep App\appsettings.json"
    
    if (Test-Path $appsettingsPath) {
        $appsettings = Get-Content $appsettingsPath | ConvertFrom-Json
        $ConnectionString = $appsettings.ConnectionStrings.DefaultConnection
        Write-Host "? Connection string obtenida" -ForegroundColor Green
    }
    else {
        Write-Host "? No se encontr� appsettings.json" -ForegroundColor Red
        exit 1
 }
}

# Validar connection string
if ([string]::IsNullOrEmpty($ConnectionString)) {
    Write-Host "? Connection string no v�lida" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Connection String: $($ConnectionString.Substring(0, [Math]::Min(50, $ConnectionString.Length)))..." -ForegroundColor Gray
Write-Host ""

# Ruta del script SQL
$sqlScriptPath = "Salutia Wep App\Data\Migrations\UpdateToNewUserSystem.sql"

if (!(Test-Path $sqlScriptPath)) {
    Write-Host "? No se encontr� el script SQL: $sqlScriptPath" -ForegroundColor Red
    exit 1
}

Write-Host "Script SQL encontrado: $sqlScriptPath" -ForegroundColor Green
Write-Host ""

# Modo WhatIf
if ($WhatIf) {
  Write-Host "=== MODO SIMULACI�N (WhatIf) ===" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Se ejecutar�a el siguiente script SQL:" -ForegroundColor Yellow
    Write-Host ""
    Get-Content $sqlScriptPath | Select-Object -First 20
    Write-Host "..." -ForegroundColor Gray
    Write-Host ""
    Write-Host "Total de l�neas: $((Get-Content $sqlScriptPath).Count)" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Para ejecutar realmente, ejecuta sin el par�metro -WhatIf" -ForegroundColor Yellow
    exit 0
}

# Confirmaci�n
Write-Host "??  ADVERTENCIA: Esta operaci�n modificar� la base de datos" -ForegroundColor Yellow
Write-Host ""
Write-Host "Cambios que se aplicar�n:" -ForegroundColor White
Write-Host "  � Crear tablas geogr�ficas (Countries, States, Cities)" -ForegroundColor White
Write-Host "  � Agregar campos geogr�ficos a EntityUserProfile" -ForegroundColor White
Write-Host "  � Crear tabla EntityProfessionalProfiles" -ForegroundColor White
Write-Host "  � Crear tabla PatientProfiles" -ForegroundColor White
Write-Host "  � Migrar datos desde EntityMemberProfiles" -ForegroundColor White
Write-Host ""
Write-Host "? El superusuario existente NO ser� afectado" -ForegroundColor Green
Write-Host ""

$confirmation = Read-Host "�Deseas continuar? (S/N)"

if ($confirmation -ne "S" -and $confirmation -ne "s") {
    Write-Host ""
    Write-Host "Operaci�n cancelada por el usuario" -ForegroundColor Yellow
    exit 0
}

Write-Host ""
Write-Host "Ejecutando migraci�n..." -ForegroundColor Cyan
Write-Host ""

try {
    # Ejecutar usando sqlcmd si est� disponible
    if (Get-Command sqlcmd -ErrorAction SilentlyContinue) {
        Write-Host "Usando sqlcmd..." -ForegroundColor Gray
        
        # Extraer servidor y base de datos del connection string
        if ($ConnectionString -match "Server=([^;]+)") {
       $server = $matches[1]
   }
        if ($ConnectionString -match "Database=([^;]+)") {
            $database = $matches[1]
        }
     
        $sqlcmdArgs = @(
        "-S", $server,
            "-d", $database,
     "-i", $sqlScriptPath
        )
        
   # Agregar autenticaci�n integrada o SQL seg�n el connection string
     if ($ConnectionString -match "Trusted_Connection=True|Integrated Security=True") {
            $sqlcmdArgs += @("-E")
        }
        elseif ($ConnectionString -match "User Id=([^;]+)" -and $ConnectionString -match "Password=([^;]+)") {
            $sqlcmdArgs += @("-U", $matches[1], "-P", $matches[2])
        }
        
        & sqlcmd $sqlcmdArgs
        
   if ($LASTEXITCODE -eq 0) {
      Write-Host ""
            Write-Host "=============================================" -ForegroundColor Green
        Write-Host "  ? Migraci�n ejecutada exitosamente!" -ForegroundColor Green
            Write-Host "=============================================" -ForegroundColor Green
  }
        else {
            throw "sqlcmd retorn� c�digo de error: $LASTEXITCODE"
      }
    }
    else {
        # Alternativa: Usar Invoke-Sqlcmd de SqlServer module
        if (Get-Module -ListAvailable -Name SqlServer) {
          Import-Module SqlServer
     
            Write-Host "Usando Invoke-Sqlcmd..." -ForegroundColor Gray
   
            $sqlContent = Get-Content $sqlScriptPath -Raw
      Invoke-Sqlcmd -ConnectionString $ConnectionString -Query $sqlContent -Verbose
            
            Write-Host ""
            Write-Host "=============================================" -ForegroundColor Green
    Write-Host "  ? Migraci�n ejecutada exitosamente!" -ForegroundColor Green
          Write-Host "=============================================" -ForegroundColor Green
        }
        else {
            Write-Host ""
        Write-Host "? No se encontr� sqlcmd ni el m�dulo SqlServer de PowerShell" -ForegroundColor Red
            Write-Host ""
            Write-Host "Opciones:" -ForegroundColor Yellow
   Write-Host "  1. Instalar SQL Server Command Line Utilities" -ForegroundColor White
 Write-Host "  2. Instalar m�dulo SqlServer: Install-Module -Name SqlServer" -ForegroundColor White
   Write-Host "  3. Ejecutar el script manualmente en SQL Server Management Studio" -ForegroundColor White
  Write-Host ""
          Write-Host "Ruta del script: $sqlScriptPath" -ForegroundColor Gray
            exit 1
   }
    }
}
catch {
    Write-Host ""
    Write-Host "=============================================" -ForegroundColor Red
    Write-Host "  ? Error ejecutando la migraci�n" -ForegroundColor Red
    Write-Host "=============================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "Error: $_" -ForegroundColor Red
    Write-Host ""
Write-Host "Stack Trace:" -ForegroundColor Gray
    Write-Host $_.ScriptStackTrace -ForegroundColor Gray
    exit 1
}

Write-Host ""
Write-Host "Pr�ximos pasos:" -ForegroundColor Cyan
Write-Host "  1. Verificar que las tablas se crearon correctamente" -ForegroundColor White
Write-Host "  2. Ejecutar el GeographicDataSeeder desde la aplicaci�n" -ForegroundColor White
Write-Host "  3. Probar el registro de profesionales" -ForegroundColor White
Write-Host ""

Read-Host "Presiona Enter para continuar"

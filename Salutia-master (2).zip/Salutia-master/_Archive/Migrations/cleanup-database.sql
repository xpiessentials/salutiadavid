-- ============================================================
-- SCRIPT DE LIMPIEZA DE BASE DE DATOS - SALUTIA
-- ============================================================
-- ADVERTENCIA: Este script eliminar� TODOS los usuarios y datos relacionados
-- Ejecutar con precauci�n. Se recomienda hacer un backup antes.
-- ============================================================

USE [Salutia]; -- Cambia por el nombre de tu base de datos si es diferente

BEGIN TRANSACTION;

BEGIN TRY
    PRINT '?? Iniciando limpieza de base de datos...';
    PRINT '';

    -- ============================================================
    -- 1. ELIMINAR DATOS DE IDENTITY (SESIONES, CLAIMS, TOKENS)
    -- ============================================================
    PRINT '1?? Eliminando sesiones y tokens de usuarios...';
    
    -- Eliminar tokens de usuario
    DELETE FROM AspNetUserTokens;
    PRINT '   ? Tokens eliminados: ' + CAST(@@ROWCOUNT AS VARCHAR(10));
    
    -- Eliminar claims de usuario
    DELETE FROM AspNetUserClaims;
    PRINT '   ? Claims eliminados: ' + CAST(@@ROWCOUNT AS VARCHAR(10));
    
    -- Eliminar logins externos
    DELETE FROM AspNetUserLogins;
    PRINT '   ? Logins externos eliminados: ' + CAST(@@ROWCOUNT AS VARCHAR(10));
    
    PRINT '';

    -- ============================================================
    -- 2. ELIMINAR RELACIONES DE ROLES
    -- ============================================================
    PRINT '2?? Eliminando asignaciones de roles...';
    
    DELETE FROM AspNetUserRoles;
    PRINT '   ? Roles de usuario eliminados: ' + CAST(@@ROWCOUNT AS VARCHAR(10));
    PRINT '';

    -- ============================================================
 -- 3. ELIMINAR PERFILES DE USUARIOS
    -- ============================================================
    PRINT '3?? Eliminando perfiles de usuarios...';
    
    -- Eliminar perfiles de miembros de entidad
  DELETE FROM EntityMemberProfiles;
    PRINT '   ? Perfiles de miembros eliminados: ' + CAST(@@ROWCOUNT AS VARCHAR(10));
  
    -- Eliminar perfiles de entidades
    DELETE FROM EntityUserProfiles;
    PRINT '   ? Perfiles de entidades eliminados: ' + CAST(@@ROWCOUNT AS VARCHAR(10));
 
    -- Eliminar perfiles independientes
    DELETE FROM IndependentUserProfiles;
    PRINT '   ? Perfiles independientes eliminados: ' + CAST(@@ROWCOUNT AS VARCHAR(10));
    PRINT '';

    -- ============================================================
    -- 4. ELIMINAR USUARIOS DE IDENTITY
    -- ============================================================
    PRINT '4?? Eliminando usuarios...';
    
    DELETE FROM AspNetUsers;
    PRINT '   ? Usuarios eliminados: ' + CAST(@@ROWCOUNT AS VARCHAR(10));
PRINT '';

    -- ============================================================
    -- 5. RESETEAR IDENTIDADES (OPCIONAL)
    -- ============================================================
    PRINT '5?? Reseteando secuencias de identidad...';
    
    -- Resetear identity de perfiles si existen
    IF EXISTS (SELECT * FROM sys.identity_columns WHERE OBJECT_NAME(object_id) = 'IndependentUserProfiles')
    BEGIN
  DBCC CHECKIDENT ('IndependentUserProfiles', RESEED, 0);
        PRINT '   ? IndependentUserProfiles reseteado';
    END
    
    IF EXISTS (SELECT * FROM sys.identity_columns WHERE OBJECT_NAME(object_id) = 'EntityUserProfiles')
    BEGIN
        DBCC CHECKIDENT ('EntityUserProfiles', RESEED, 0);
        PRINT '   ? EntityUserProfiles reseteado';
    END
    
    IF EXISTS (SELECT * FROM sys.identity_columns WHERE OBJECT_NAME(object_id) = 'EntityMemberProfiles')
    BEGIN
 DBCC CHECKIDENT ('EntityMemberProfiles', RESEED, 0);
        PRINT '   ? EntityMemberProfiles reseteado';
    END
    PRINT '';

-- ============================================================
    -- 6. VERIFICACI�N FINAL
    -- ============================================================
    PRINT '6?? Verificando limpieza...';
    PRINT '';
    
    DECLARE @UserCount INT;
    DECLARE @ProfileCount INT;
    DECLARE @EntityCount INT;
    DECLARE @MemberCount INT;
    
    SELECT @UserCount = COUNT(*) FROM AspNetUsers;
    SELECT @ProfileCount = COUNT(*) FROM IndependentUserProfiles;
    SELECT @EntityCount = COUNT(*) FROM EntityUserProfiles;
    SELECT @MemberCount = COUNT(*) FROM EntityMemberProfiles;
    
    PRINT '   ?? Usuarios restantes: ' + CAST(@UserCount AS VARCHAR(10));
    PRINT '   ?? Perfiles independientes restantes: ' + CAST(@ProfileCount AS VARCHAR(10));
    PRINT '   ?? Perfiles de entidades restantes: ' + CAST(@EntityCount AS VARCHAR(10));
    PRINT '   ?? Perfiles de miembros restantes: ' + CAST(@MemberCount AS VARCHAR(10));
    PRINT '';

    IF @UserCount = 0 AND @ProfileCount = 0 AND @EntityCount = 0 AND @MemberCount = 0
    BEGIN
     PRINT '??? LIMPIEZA COMPLETADA EXITOSAMENTE ???';
        PRINT '';
        PRINT '?? La base de datos est� limpia y lista para crear nuevos usuarios.';
        PRINT '?? Los roles se mantienen intactos (SuperAdmin, Entity, Independent, EntityMember).';
        PRINT '';
        PRINT '?? Siguiente paso: Crear el primer SuperAdministrador';
    PRINT '   Ejecuta: .\create-superadmin.ps1';
    PRINT '';
      
        COMMIT TRANSACTION;
    END
    ELSE
    BEGIN
     PRINT '?? ADVERTENCIA: Algunos registros no fueron eliminados';
        ROLLBACK TRANSACTION;
    END

END TRY
BEGIN CATCH
    PRINT '';
    PRINT '? ERROR EN LA LIMPIEZA:';
 PRINT '   Error: ' + ERROR_MESSAGE();
    PRINT '   L�nea: ' + CAST(ERROR_LINE() AS VARCHAR(10));
    PRINT '';
    PRINT '?? Revertiendo cambios...';
    
    ROLLBACK TRANSACTION;
    
    PRINT '? Transacci�n revertida. La base de datos no fue modificada.';
END CATCH;

PRINT '';
PRINT '???????????????????????????????????????????????????????????';
PRINT 'Script finalizado';
PRINT '???????????????????????????????????????????????????????????';

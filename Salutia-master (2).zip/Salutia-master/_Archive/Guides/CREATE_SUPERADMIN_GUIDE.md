# ?? Gu�a: Crear el Primer SuperAdministrador

## ?? Prerequisitos

Antes de crear el primer SuperAdmin, aseg�rate de:

- ? Haber aplicado la migraci�n de base de datos
- ? La base de datos SQL Server est� corriendo
- ? Los roles est�n creados (SuperAdmin, Entity, Independent, EntityMember)

## Opci�n 1: Usando Script PowerShell (Recomendado) ?

### Paso 1: Aplicar Migraci�n

```powershell
# En Package Manager Console de Visual Studio
Add-Migration MultiUserTypeSystem -Project "Salutia Wep App"
Update-Database -Project "Salutia Wep App"
```

### Paso 2: Ejecutar la Aplicaci�n

```powershell
# Opci�n A: Con Aspire (Recomendado)
dotnet run --project "Salutia.AppHost"

# Opci�n B: Solo Web App
dotnet run --project "Salutia Wep App"
```

### Paso 3: Ejecutar Script PowerShell

```powershell
# Desde el directorio ra�z del proyecto
.\create-superadmin.ps1
```

El script te pedir�:
- **Email**: `admin@salutia.com` (o el que prefieras)
- **Contrase�a**: M�nimo 6 caracteres
- **Clave de Seguridad**: `Salutia2025!Setup` (est� en `appsettings.json`)

### Paso 4: Limpiar por Seguridad ??

Despu�s de crear el SuperAdmin, **ELIMINA** estos archivos:

```powershell
# Eliminar controlador temporal
Remove-Item "Salutia Wep App\Controllers\SetupController.cs"

# Editar appsettings.json y eliminar la secci�n "Setup"
```

---

## Opci�n 2: Usando Postman o cURL

### Paso 1: Verificar si Existe SuperAdmin

```bash
GET https://localhost:7242/api/setup/has-superadmin
```

Respuesta esperada:
```json
{
  "hasSuperAdmin": false,
  "message": "No hay SuperAdministradores. Puedes crear el primero."
}
```

### Paso 2: Crear SuperAdmin

```bash
POST https://localhost:7242/api/setup/create-first-superadmin
Content-Type: application/json

{
  "email": "admin@salutia.com",
  "password": "Admin123!",
  "setupKey": "Salutia2025!Setup"
}
```

**Con cURL:**

```bash
curl -X POST https://localhost:7242/api/setup/create-first-superadmin \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"admin@salutia.com\",\"password\":\"Admin123!\",\"setupKey\":\"Salutia2025!Setup\"}" \
  -k
```

**Con PowerShell:**

```powershell
$body = @{
email = "admin@salutia.com"
 password = "Admin123!"
    setupKey = "Salutia2025!Setup"
} | ConvertTo-Json

Invoke-RestMethod -Uri "https://localhost:7242/api/setup/create-first-superadmin" `
    -Method Post `
  -Body $body `
    -ContentType "application/json" `
    -SkipCertificateCheck
```

### Paso 3: Limpiar por Seguridad

Eliminar `SetupController.cs` y la clave en `appsettings.json`.

---

## Opci�n 3: Script SQL Directo

Si prefieres no usar el endpoint, ejecuta este SQL:

```sql
USE [Salutia]; -- Cambia por tu base de datos

DECLARE @UserId NVARCHAR(450) = CAST(NEWID() AS NVARCHAR(450));
DECLARE @Email NVARCHAR(256) = 'admin@salutia.com';
DECLARE @SecurityStamp NVARCHAR(MAX) = CAST(NEWID() AS NVARCHAR(MAX));
DECLARE @ConcurrencyStamp NVARCHAR(MAX) = CAST(NEWID() AS NVARCHAR(MAX));

-- Insertar SuperAdmin
-- NOTA: Este hash es para la contrase�a "Admin123!"
-- Generado con ASP.NET Core Identity
INSERT INTO AspNetUsers (
    Id, UserName, NormalizedUserName, Email, NormalizedEmail,
    EmailConfirmed, PasswordHash, SecurityStamp, ConcurrencyStamp,
    PhoneNumberConfirmed, TwoFactorEnabled, LockoutEnabled, AccessFailedCount,
    UserType, IsActive, CreatedAt
)
VALUES (
    @UserId,
    @Email,
    UPPER(@Email),
    @Email,
    UPPER(@Email),
    1, -- EmailConfirmed
    'AQAAAAIAAYagAAAAEO7xqVrQ0uQ2TG8cKF8fXqQ8K3rqVl8fXqQ8K3rqVl8fXqQ8K3rqVl8fXqQ8K3rqVl8=',
    @SecurityStamp,
 @ConcurrencyStamp,
    0, 0, 1, 0,
    0, -- UserType.SuperAdmin
    1, -- IsActive
    GETUTCDATE()
);

-- Asignar rol SuperAdmin
DECLARE @RoleId NVARCHAR(450);
SELECT @RoleId = Id FROM AspNetRoles WHERE Name = 'SuperAdmin';

IF @RoleId IS NOT NULL
BEGIN
    INSERT INTO AspNetUserRoles (UserId, RoleId)
    VALUES (@UserId, @RoleId);
    
  PRINT '? SuperAdmin creado exitosamente';
    PRINT 'Email: ' + @Email;
    PRINT 'Contrase�a: Admin123!';
    PRINT '';
    PRINT '??  CAMBIA LA CONTRASE�A despu�s del primer login';
END
ELSE
BEGIN
    PRINT '? ERROR: El rol SuperAdmin no existe';
    PRINT 'Ejecuta la aplicaci�n primero para que se creen los roles';
END

-- Verificar
SELECT 
    u.Email,
    u.UserType,
    u.IsActive,
    r.Name AS Role
FROM AspNetUsers u
LEFT JOIN AspNetUserRoles ur ON u.Id = ur.UserId
LEFT JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE u.UserType = 0; -- SuperAdmin
```

---

## Opci�n 4: Agregar Seeding en Program.cs

Para entornos de desarrollo, puedes agregar seeding autom�tico:

```csharp
// En Program.cs, despu�s de app.Build()
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
    var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        
    await SeedSuperAdmin(userManager, roleManager);
    }
    catch (Exception ex)
    {
        var logger = services.GetRequiredService<ILogger<Program>>();
     logger.LogError(ex, "Error al crear SuperAdmin inicial");
    }
}

// M�todo de seeding
async Task SeedSuperAdmin(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
{
    // Verificar si ya existe un SuperAdmin
    var existingSuperAdmin = await userManager.Users
        .AnyAsync(u => u.UserType == UserType.SuperAdmin);
    
    if (existingSuperAdmin)
        return; // Ya existe

    // Crear SuperAdmin
    var superAdmin = new ApplicationUser
    {
UserName = "admin@salutia.com",
        Email = "admin@salutia.com",
      EmailConfirmed = true,
UserType = UserType.SuperAdmin,
        IsActive = true,
        CreatedAt = DateTime.UtcNow
    };

    var result = await userManager.CreateAsync(superAdmin, "Admin123!");
    
    if (result.Succeeded)
    {
      await userManager.AddToRoleAsync(superAdmin, "SuperAdmin");
      Console.WriteLine("? SuperAdmin inicial creado: admin@salutia.com / Admin123!");
    }
}
```

---

## ?? Verificaci�n

### 1. Verificar en Base de Datos

```sql
-- Ver usuarios SuperAdmin
SELECT 
    Id,
    Email,
    UserType,
    IsActive,
    EmailConfirmed,
    CreatedAt
FROM AspNetUsers
WHERE UserType = 0; -- SuperAdmin

-- Ver roles asignados
SELECT 
    u.Email,
    r.Name AS Role
FROM AspNetUsers u
INNER JOIN AspNetUserRoles ur ON u.Id = ur.UserId
INNER JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE u.UserType = 0;
```

### 2. Probar Login

1. Navega a: `https://localhost:7242/Account/Login`
2. Ingresa:
   - **Email**: `admin@salutia.com`
   - **Contrase�a**: `Admin123!` (o la que configuraste)
3. Deber�as ser redirigido a: `/Admin/Dashboard`

### 3. Verificar Dashboard

Una vez logueado, deber�as ver:
- Estad�sticas del sistema
- Conteo de usuarios
- Opciones de administraci�n

---

## ?? Seguridad Post-Creaci�n

### Pasos Obligatorios:

1. **Cambiar Contrase�a Inmediatamente**
   - Ir a perfil ? Cambiar contrase�a
   - Usar una contrase�a fuerte

2. **Eliminar Archivos Temporales**
   ```powershell
   Remove-Item "Salutia Wep App\Controllers\SetupController.cs"
   ```

3. **Limpiar appsettings.json**
   ```json
   // ELIMINAR esta secci�n:
   "Setup": {
     "SuperAdminKey": "..."
   }
   ```

4. **Recompilar el Proyecto**
   ```powershell
   dotnet build
   ```

5. **Habilitar 2FA** (Opcional pero Recomendado)
   - Ir a `/Account/Manage/EnableAuthenticator`
   - Escanear c�digo QR
   - Guardar c�digos de recuperaci�n

---

## ? Troubleshooting

### Error: "Ya existe un SuperAdministrador"

```sql
-- Verificar SuperAdmins existentes
SELECT Email, UserType FROM AspNetUsers WHERE UserType = 0;
```

Si necesitas eliminar el SuperAdmin existente (?? CUIDADO):

```sql
DECLARE @UserId NVARCHAR(450);
SELECT @UserId = Id FROM AspNetUsers WHERE Email = 'admin@salutia.com';

DELETE FROM AspNetUserRoles WHERE UserId = @UserId;
DELETE FROM AspNetUsers WHERE Id = @UserId;
```

### Error: "El rol SuperAdmin no existe"

```sql
-- Verificar roles
SELECT * FROM AspNetRoles;

-- Si no existe, crear manualmente
INSERT INTO AspNetRoles (Id, Name, NormalizedName, ConcurrencyStamp)
VALUES (NEWID(), 'SuperAdmin', 'SUPERADMIN', NEWID());
```

### Error: "Contrase�a no v�lida"

Aseg�rate de cumplir los requisitos:
- M�nimo 6 caracteres
- Al menos un d�gito
- Al menos una letra min�scula

### Error: "Cannot connect to API"

1. Verifica que la aplicaci�n est� corriendo
2. Verifica el puerto correcto
3. Desactiva SSL si es necesario: `-SkipCertificateCheck`

---

## ?? Siguiente Paso

Una vez creado el SuperAdmin:

1. **Iniciar sesi�n** como SuperAdmin
2. **Explorar** `/Admin/Dashboard`
3. **Crear** m�s usuarios seg�n sea necesario
4. **Configurar** servicios de email
5. **Personalizar** el sistema

---

## ?? Resumen de Comandos R�pidos

```powershell
# 1. Migraci�n
Add-Migration MultiUserTypeSystem -Project "Salutia Wep App"
Update-Database -Project "Salutia Wep App"

# 2. Ejecutar app
dotnet run --project "Salutia.AppHost"

# 3. Crear SuperAdmin (elige una opci�n)
# Opci�n A: Script PowerShell
.\create-superadmin.ps1

# Opci�n B: cURL
curl -X POST https://localhost:7242/api/setup/create-first-superadmin `
  -H "Content-Type: application/json" `
  -d '{"email":"admin@salutia.com","password":"Admin123!","setupKey":"Salutia2025!Setup"}' `
  -k

# 4. Limpiar
Remove-Item "Salutia Wep App\Controllers\SetupController.cs"
# Editar appsettings.json manualmente

# 5. Login
# https://localhost:7242/Account/Login
# Email: admin@salutia.com
# Password: Admin123!
```

---

## ? Checklist Final

- [ ] Migraci�n aplicada
- [ ] Roles creados en base de datos
- [ ] SuperAdmin creado
- [ ] Login exitoso como SuperAdmin
- [ ] Dashboard de admin visible
- [ ] SetupController.cs eliminado
- [ ] Clave de setup eliminada de appsettings.json
- [ ] Contrase�a cambiada
- [ ] 2FA habilitado (opcional)

---

**�Tu primer SuperAdministrador est� listo!** ??

Ahora puedes administrar todo el sistema Salutia.

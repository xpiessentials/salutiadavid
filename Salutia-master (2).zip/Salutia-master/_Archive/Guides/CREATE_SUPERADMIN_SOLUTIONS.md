# Gu�a para Crear SuperAdmin

Este documento explica las diferentes formas de crear el usuario SuperAdmin con las credenciales:
- **Email:** elpeco1@msn.com
- **Contrase�a:** Admin.123

## ?? M�todo Recomendado: Usar la API (M�s Confiable)

Este m�todo genera el hash de contrase�a correctamente usando el mismo algoritmo que la aplicaci�n.

### Pasos:

1. **Ejecuta la aplicaci�n web Salutia**
   - Abre Visual Studio
   - Ejecuta el proyecto `Salutia Wep App` (F5)
   - Verifica que se abra en el navegador (ejemplo: https://localhost:7107)

2. **Ejecuta el script PowerShell**
   ```powershell
   .\create-superadmin-via-api.ps1
   ```

3. **Sigue las instrucciones en pantalla**
   - El script limpiar� la base de datos
   - Crear� los roles necesarios
   - Llamar� al endpoint de la API para crear el SuperAdmin con el hash correcto

### Ventajas:
? Hash de contrase�a generado correctamente  
? Garantiza compatibilidad con ASP.NET Core Identity  
? Proceso automatizado  

---

## ?? M�todo Alternativo: Script SQL Directo

Si no puedes ejecutar la aplicaci�n web, puedes usar el script SQL directo.

### Pasos:

1. **Abre SQL Server Management Studio (SSMS)**

2. **Abre el archivo** `cleanup-and-create-superadmin.sql`

3. **Verifica la l�nea 10** - Aseg�rate que el nombre de la base de datos sea correcto:
   ```sql
   USE [Salutia]
   ```

4. **Ejecuta el script completo** (F5)

### ?? Nota Importante:
El hash de contrase�a en el script SQL puede no funcionar en todos los casos debido a diferencias en la configuraci�n de Identity. Si no puedes iniciar sesi�n despu�s de ejecutar este script, usa el **M�todo Recomendado**.

---

## ?? M�todo Avanzado: Generar Hash con PowerShell

Si quieres generar el hash correcto usando PowerShell (requiere compilar el proyecto primero):

```powershell
.\generate-superadmin-with-correct-hash.ps1
```

Este script:
1. Compila el c�digo necesario de ASP.NET Core Identity
2. Genera el hash correcto para "Admin.123"
3. Crea un script SQL con el hash correcto
4. Ejecuta el script SQL

### Requisitos:
- .NET 8 SDK instalado
- Proyecto compilado al menos una vez (`dotnet build`)
- M�dulo SqlServer de PowerShell (se instala autom�ticamente si falta)

---

## ?? M�todo Manual: Usar Endpoint API Directamente

Si prefieres usar herramientas como Postman o curl:

### 1. Ejecuta la aplicaci�n web

### 2. Limpia la base de datos (SQL)
```sql
-- Ejecuta cleanup-only.sql o las secciones de limpieza del script completo
```

### 3. Crea los roles (SQL)
```sql
INSERT INTO [dbo].[AspNetRoles] ([Id], [Name], [NormalizedName], [ConcurrencyStamp])
VALUES 
(NEWID(), 'SuperAdmin', 'SUPERADMIN', NEWID()),
    (NEWID(), 'Entity', 'ENTITY', NEWID()),
    (NEWID(), 'Independent', 'INDEPENDENT', NEWID()),
    (NEWID(), 'EntityMember', 'ENTITYMEMBER', NEWID())
```

### 4. Llama al endpoint de creaci�n (API)
```bash
curl -X POST https://localhost:7107/api/setup/create-first-superadmin \
  -H "Content-Type: application/json" \
  -d '{
    "email": "elpeco1@msn.com",
    "password": "Admin.123"
  }'
```

O usando PowerShell:
```powershell
$body = @{
email = "elpeco1@msn.com"
    password = "Admin.123"
} | ConvertTo-Json

Invoke-RestMethod -Uri "https://localhost:7107/api/setup/create-first-superadmin" `
    -Method Post `
    -Body $body `
    -ContentType "application/json" `
    -SkipCertificateCheck
```

---

## ?? Verificar que Funcione

Despu�s de crear el SuperAdmin, verifica que puedes iniciar sesi�n:

1. Abre la aplicaci�n web: https://localhost:7107
2. Haz clic en "Login"
3. Ingresa:
   - Email: `elpeco1@msn.com`
   - Contrase�a: `Admin.123`
4. Deber�as ver el Dashboard de SuperAdmin

---

## ? Soluci�n de Problemas

### Problema: "Usuario o contrase�a incorrectos"

**Causa:** El hash de contrase�a en la base de datos no coincide con el esperado.

**Soluci�n:**
1. Usa el **M�todo Recomendado** (API) que genera el hash correctamente
2. O usa el m�todo de PowerShell avanzado

### Problema: "Ya existe un SuperAdministrador"

**Soluci�n:** Ejecuta primero la secci�n de limpieza del script SQL para eliminar usuarios existentes.

### Problema: "No se puede conectar a la API"

**Soluci�n:**
1. Verifica que la aplicaci�n web est� ejecut�ndose
2. Verifica la URL en el script PowerShell (l�nea con `$ApiUrl`)
3. Prueba acceder a: https://localhost:7107/api/setup/has-superadmin

### Problema: "Error al ejecutar el script SQL"

**Soluci�n:**
1. Verifica que el nombre de la base de datos sea correcto
2. Verifica que tengas permisos de administrador en SQL Server
3. Aseg�rate de que todas las tablas existan (ejecuta las migraciones si es necesario)

---

## ??? Seguridad

### ?? IMPORTANTE: Despu�s de crear el SuperAdmin

1. **Elimina el SetupController.cs**
   - Archivo: `Salutia Wep App\Controllers\SetupController.cs`
   - Este controlador permite crear SuperAdmins sin autenticaci�n
   
2. **Cambia la contrase�a**
   - Inicia sesi�n con las credenciales iniciales
   - Ve a tu perfil y cambia la contrase�a por una m�s segura

3. **Elimina los scripts**
   - Elimina o mueve a una ubicaci�n segura los scripts de creaci�n de SuperAdmin

---

## ?? Resumen de Archivos

| Archivo | Descripci�n | Cu�ndo Usar |
|---------|-------------|-------------|
| `create-superadmin-via-api.ps1` | Script recomendado que usa la API | **Opci�n principal** |
| `cleanup-and-create-superadmin.sql` | Script SQL directo | Si no puedes ejecutar la app |
| `generate-superadmin-with-correct-hash.ps1` | Genera hash y ejecuta SQL | Opci�n avanzada |
| `SetupController.cs` | Endpoint API de setup | **Eliminar despu�s de usar** |

---

## ?? Recomendaci�n Final

**Usa el m�todo API (`create-superadmin-via-api.ps1`)** - Es el m�s confiable y genera el hash de contrase�a correctamente.

Si tienes problemas, revisa la secci�n de **Soluci�n de Problemas** arriba.

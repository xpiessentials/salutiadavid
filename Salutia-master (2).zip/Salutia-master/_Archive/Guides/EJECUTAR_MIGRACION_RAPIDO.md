# ?? EJECUTAR MIGRACI�N COMPLETA - Script R�pido

## ? Soluci�n R�pida en 3 Pasos

### PASO 1: Ejecutar Migraci�n del Sistema de Usuarios

**Abrir en SSMS y ejecutar:**
```
Salutia Wep App\Data\Migrations\UpdateToNewUserSystem.sql
```

Este script:
- ? Crea tablas geogr�ficas
- ? Crea EntityProfessionalProfiles
- ? Crea PatientProfiles
- ? Agrega campos geogr�ficos

---

### PASO 2: Actualizar Roles de Usuario

**Abrir en SSMS y ejecutar:**
```
Salutia Wep App\Data\Migrations\UpdateUserRoles.sql
```

Este script:
- ? Crea roles nuevos (EntityAdmin, Doctor, Psychologist, Patient)
- ? Actualiza usuarios de "Entity" a "EntityAdmin"
- ? Asigna roles faltantes autom�ticamente
- ? Muestra reporte de usuarios y roles

---

### PASO 3: Reiniciar Aplicaci�n

En Visual Studio:
1. Detener la aplicaci�n (Shift+F5)
2. Iniciar nuevamente (F5)

O en PowerShell:
```powershell
cd "Salutia Wep App"
dotnet run
```

---

## ? VERIFICACI�N INMEDIATA

Despu�s de ejecutar los 3 pasos:

1. Ir a: `https://localhost:7213/Account/Login`
2. Iniciar sesi�n como administrador de entidad
3. En el men� lateral deber�as ver:
   - ? "Mis Profesionales" (no "Mis Miembros")
4. Hacer clic en "Mis Profesionales"
   - ? P�gina carga sin error 404
   - ? Ves tabla de profesionales (vac�a inicialmente)

---

## ?? SI A�N HAY ERROR

### Error: "No tienes permiso"

**Ejecuta en SSMS:**
```sql
-- Ver tu rol actual
SELECT u.Email, r.Name AS Role
FROM AspNetUsers u
INNER JOIN AspNetUserRoles ur ON u.Id = ur.UserId
INNER JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE u.Email = 'TU_EMAIL_AQUI';
```

**Debe mostrar:** `EntityAdmin`

### Error: "Invalid object name 'EntityProfessionalProfiles'"

**Ejecuta en SSMS:**
```sql
-- Verificar que existen las tablas
SELECT name FROM sys.tables 
WHERE name IN (
    'Countries', 
    'EntityProfessionalProfiles', 
    'PatientProfiles'
);
```

**Debe mostrar:** 3 tablas

Si no aparecen, ejecuta de nuevo el PASO 1.

---

## ?? ORDEN DE EJECUCI�N CORRECTO

```
1. UpdateToNewUserSystem.sql    (Tablas)
   ?
2. UpdateUserRoles.sql     (Roles)
   ?
3. Reiniciar aplicaci�n   (Aplicar cambios)
```

**NO ejecutes al rev�s o se generar�n errores.**

---

## ?? LISTO!

Una vez completados los 3 pasos, tu sistema estar� completamente funcional con:

- ? Nuevo sistema de usuarios
- ? Roles actualizados
- ? Navegaci�n funcionando
- ? Sin error 404

�Ya puedes empezar a registrar profesionales!

# ?? INSTRUCCIONES FINALES - Migraci�n del Sistema de Usuarios

## ? Estado Actual

### Completado:
- ? C�digo actualizado (todos los archivos compilando correctamente)
- ? Tipos de usuario actualizados (`EntityAdmin`, `Doctor`, `Psychologist`, `Patient`)
- ? NavMenu actualizado con roles y rutas correctas
- ? Script SQL de migraci�n preparado y corregido
- ? Dashboards actualizados para cada tipo de usuario

### ?? ERROR ACTUAL: Error 404 en `/Entity/ManageMembers`

**Causa:** La ruta antigua `/Entity/ManageMembers` ya no existe. Ahora es `/Entity/ManageProfessionals`

**Soluci�n:** Ya aplicada en NavMenu.razor

---

## ?? PASOS PARA COMPLETAR LA MIGRACI�N

### Paso 1: Ejecutar la Migraci�n SQL

Tienes 3 opciones:

#### **Opci�n A: SQL Server Management Studio (SSMS)** ? Recomendado

1. Abre SSMS
2. Con�ctate a tu servidor SQL Server
3. Selecciona tu base de datos (`Salutia` o similar)
4. Abre el archivo: `Salutia Wep App\Data\Migrations\UpdateToNewUserSystem.sql`
5. Presiona **F5** o haz clic en "Ejecutar"
6. Verifica que veas el mensaje: "Migraci�n completada exitosamente!"

#### **Opci�n B: Usando sqlcmd desde PowerShell**

```powershell
# Para LocalDB
cd "Salutia Wep App"
sqlcmd -S "(localdb)\MSSQLLocalDB" -d Salutia -E -i "Data\Migrations\UpdateToNewUserSystem.sql"

# Para SQL Server Express
sqlcmd -S ".\SQLEXPRESS" -d Salutia -E -i "Data\Migrations\UpdateToNewUserSystem.sql"

# Para SQL Server con nombre personalizado
sqlcmd -S "TU_SERVIDOR" -d Salutia -E -i "Data\Migrations\UpdateToNewUserSystem.sql"
```

#### **Opci�n C: Script PowerShell Automatizado**

```powershell
.\apply-new-user-system-migration.ps1
```

---

### Paso 2: Verificar la Migraci�n

Despu�s de ejecutar la migraci�n, verifica en SSMS:

```sql
-- Verificar tablas geogr�ficas
SELECT * FROM Countries;
SELECT * FROM States WHERE CountryId = 1;
SELECT * FROM Cities WHERE StateId IN (1, 2, 3);

-- Verificar tabla de profesionales
SELECT * FROM EntityProfessionalProfiles;

-- Verificar tabla de pacientes
SELECT * FROM PatientProfiles;

-- Verificar que EntityUserProfiles tiene campos geogr�ficos
SELECT TOP 1 * FROM EntityUserProfiles;
```

---

### Paso 3: Actualizar Roles en la Base de Datos

Necesitas actualizar o crear los nuevos roles en `AspNetRoles`:

```sql
-- Verificar roles existentes
SELECT * FROM AspNetRoles;

-- Agregar nuevos roles si no existen
IF NOT EXISTS (SELECT 1 FROM AspNetRoles WHERE Name = 'EntityAdmin')
    INSERT INTO AspNetRoles (Id, Name, NormalizedName) 
  VALUES (NEWID(), 'EntityAdmin', 'ENTITYADMIN');

IF NOT EXISTS (SELECT 1 FROM AspNetRoles WHERE Name = 'Doctor')
    INSERT INTO AspNetRoles (Id, Name, NormalizedName) 
    VALUES (NEWID(), 'Doctor', 'DOCTOR');

IF NOT EXISTS (SELECT 1 FROM AspNetRoles WHERE Name = 'Psychologist')
    INSERT INTO AspNetRoles (Id, Name, NormalizedName) 
    VALUES (NEWID(), 'Psychologist', 'PSYCHOLOGIST');

IF NOT EXISTS (SELECT 1 FROM AspNetRoles WHERE Name = 'Patient')
    INSERT INTO AspNetRoles (Id, Name, NormalizedName) 
    VALUES (NEWID(), 'Patient', 'PATIENT');
```

---

### Paso 4: Actualizar Usuario Administrador de Entidad Existente

Si tienes un usuario administrador de entidad existente, actualiza su tipo:

```sql
-- Ver usuarios actuales de tipo Entity (UserType = 1)
SELECT Id, Email, UserType FROM AspNetUsers WHERE UserType = 1;

-- Actualizar el UserType de Entity (1) a EntityAdmin (1)
-- NOTA: EntityAdmin tambi�n es 1, as� que no hay cambio aqu�
-- Pero verifica que el rol est� correcto

-- Ver roles del usuario
SELECT u.Email, r.Name 
FROM AspNetUsers u
INNER JOIN AspNetUserRoles ur ON u.Id = ur.UserId
INNER JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE u.Email = 'TU_EMAIL_AQUI';

-- Si el usuario tiene rol "Entity", actual�zalo a "EntityAdmin"
DECLARE @UserId nvarchar(450) = (SELECT Id FROM AspNetUsers WHERE Email = 'TU_EMAIL_AQUI');
DECLARE @OldRoleId nvarchar(450) = (SELECT Id FROM AspNetRoles WHERE Name = 'Entity');
DECLARE @NewRoleId nvarchar(450) = (SELECT Id FROM AspNetRoles WHERE Name = 'EntityAdmin');

-- Eliminar rol antiguo
DELETE FROM AspNetUserRoles WHERE UserId = @UserId AND RoleId = @OldRoleId;

-- Agregar rol nuevo
IF NOT EXISTS (SELECT 1 FROM AspNetUserRoles WHERE UserId = @UserId AND RoleId = @NewRoleId)
    INSERT INTO AspNetUserRoles (UserId, RoleId) VALUES (@UserId, @NewRoleId);
```

---

### Paso 5: Reiniciar la Aplicaci�n

```powershell
# Detener la aplicaci�n si est� corriendo
# Luego iniciarla nuevamente

cd "Salutia Wep App"
dotnet run
```

O presiona **F5** en Visual Studio.

---

## ?? VERIFICACI�N FINAL

### 1. Probar Login como Administrador de Entidad

1. Ve a `https://localhost:7213/Account/Login`
2. Inicia sesi�n con tu usuario administrador de entidad
3. Deber�as ver:
 - ? Dashboard cargando correctamente
   - ? Men� mostrando "Mis Profesionales" (no "Mis Miembros")
   - ? Al hacer clic en "Mis Profesionales" deber�a ir a `/Entity/ManageProfessionals`

### 2. Probar Registro de Profesional

1. Desde el dashboard de entidad, haz clic en "Agregar Profesional"
2. Llena el formulario:
   - Nombre completo
   - Tipo de profesional (M�dico/Psic�logo)
   - Especialidad
   - Licencia profesional
   - Documento
   - Email
   - Contrase�a
3. Deber�a registrar exitosamente

### 3. Probar Login como Profesional

1. Cierra sesi�n del administrador
2. Inicia sesi�n con el profesional reci�n creado
3. Deber�as ver:
   - ? Dashboard de profesional
   - ? Opci�n "Mis Pacientes" en el men�

---

## ?? SOLUCI�N DE PROBLEMAS

### Error 404 al intentar acceder a rutas

**Problema:** P�ginas no encontradas o error 404

**Soluci�n:**
1. Verifica que el archivo exista en la ruta correcta
2. Verifica que el `@page` directive coincida con la URL
3. Verifica que el rol en `@attribute [Authorize(Roles = "...")]` sea correcto

### Error de autorizaci�n

**Problema:** Usuario no tiene permiso para acceder

**Soluci�n:**
1. Verifica los roles del usuario en la base de datos:
   ```sql
   SELECT u.Email, r.Name 
   FROM AspNetUsers u
   INNER JOIN AspNetUserRoles ur ON u.Id = ur.UserId
   INNER JOIN AspNetRoles r ON ur.RoleId = r.Id;
   ```
2. Actualiza el rol si es necesario (ver Paso 4 arriba)

### Error en la migraci�n SQL

**Problema:** Script SQL falla

**Soluci�n:**
1. Verifica que la tabla `AspNetUsers` exista
2. Ejecuta el script en partes si es necesario
3. Revisa los mensajes de error para identificar la tabla/FK problem�tica

---

## ?? CHECKLIST DE FINALIZACI�N

Marca cada item cuando lo completes:

- [ ] Migraci�n SQL ejecutada exitosamente
- [ ] Roles creados/actualizados en AspNetRoles
- [ ] Usuario administrador de entidad tiene rol "EntityAdmin"
- [ ] Aplicaci�n reiniciada
- [ ] Login como EntityAdmin funciona
- [ ] Ruta `/Entity/ManageProfessionals` carga correctamente
- [ ] Registro de profesional funciona
- [ ] Login como profesional funciona
- [ ] Dashboard de profesional carga correctamente

---

## ?? �LISTO!

Una vez completados todos los pasos, tu sistema estar� completamente migrado al nuevo esquema de usuarios con:

- ? Tablas geogr�ficas (Countries, States, Cities)
- ? EntityProfessionalProfiles (M�dicos y Psic�logos)
- ? PatientProfiles
- ? Roles actualizados
- ? Navegaci�n funcionando correctamente

---

## ?? NECESITAS AYUDA?

Si encuentras alg�n problema:
1. Verifica los logs de la aplicaci�n
2. Verifica los mensajes de error en SSMS
3. Revisa este documento de nuevo
4. Comparte el mensaje de error espec�fico para ayuda adicional

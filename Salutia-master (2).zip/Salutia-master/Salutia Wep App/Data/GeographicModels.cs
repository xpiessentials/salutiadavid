namespace Salutia_Wep_App.Data;

/// <summary>
/// Modelo para pa�ses
/// </summary>
public class Country
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty; // CO, MX, AR, etc.
    
    /// <summary>
    /// Estados/Departamentos de este pa�s
    /// </summary>
    public ICollection<State> States { get; set; } = new List<State>();
}

/// <summary>
/// Modelo para Estados/Departamentos
/// </summary>
public class State
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty; // C�digo del estado
    
    /// <summary>
    /// ID del pa�s al que pertenece
    /// </summary>
    public int CountryId { get; set; }
    public Country Country { get; set; } = null!;
    
    /// <summary>
    /// Ciudades de este estado
    /// </summary>
    public ICollection<City> Cities { get; set; } = new List<City>();
}

/// <summary>
/// Modelo para Ciudades
/// </summary>
public class City
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    
    /// <summary>
    /// ID del estado al que pertenece
    /// </summary>
    public int StateId { get; set; }
    public State State { get; set; } = null!;
}

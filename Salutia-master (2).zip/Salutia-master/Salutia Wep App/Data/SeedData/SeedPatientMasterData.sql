-- ============================================
-- Script de Datos Semilla para Maestros de Paciente
-- Proyecto: Salutia - Plataforma de Salud Ocupacional
-- Fecha: 2025-01-19
-- ============================================

USE [SalutiaDB]
GO

-- ============================================
-- 1. OCUPACIONES (Occupations)
-- ============================================
PRINT 'Insertando Ocupaciones...'

SET IDENTITY_INSERT [dbo].[Occupations] ON
GO

INSERT INTO [dbo].[Occupations] ([Id], [Name], [Description], [IsActive], [DisplayOrder])
VALUES
(1, 'Empleado de Oficina', 'Trabajo administrativo, secretarial y de oficina', 1, 1),
(2, 'Profesional de la Salud', 'M�dico, enfermero, terapeuta, odont�logo', 1, 2),
(3, 'Ingeniero', 'Ingenier�a en diversas �reas (civil, sistemas, industrial, etc.)', 1, 3),
(4, 'Docente / Educador', 'Profesor, maestro, instructor, capacitador', 1, 4),
(5, 'Comerciante / Vendedor', 'Ventas, comercio, atenci�n al cliente', 1, 5),
(6, 'T�cnico / Tecn�logo', 'T�cnico especializado en diversas �reas', 1, 6),
(7, 'Operario / Obrero', 'Trabajo manual, operaci�n de maquinaria', 1, 7),
(8, 'Conductor / Transportador', 'Conductor de veh�culos, transporte p�blico o privado', 1, 8),
(9, 'Construcci�n', 'Alba�il, maestro de obra, constructor', 1, 9),
(10, 'Servicios Generales', 'Limpieza, mantenimiento, seguridad', 1, 10),
(11, 'Contador / Auditor', 'Contabilidad, auditor�a, finanzas', 1, 11),
(12, 'Abogado / Jurista', 'Profesional del derecho', 1, 12),
(13, 'Arquitecto / Dise�ador', 'Arquitectura, dise�o gr�fico, dise�o industrial', 1, 13),
(14, 'Agricultor / Ganadero', 'Trabajo agr�cola, pecuario, rural', 1, 14),
(15, 'Artista / Artesano', 'Arte, artesan�a, trabajo manual creativo', 1, 15),
(16, 'Chef / Cocinero', 'Preparaci�n de alimentos, gastronom�a', 1, 16),
(17, 'Deportista / Entrenador', 'Deporte profesional, entrenamiento deportivo', 1, 17),
(18, 'Funcionario P�blico', 'Empleado del gobierno o entidad p�blica', 1, 18),
(19, 'Emprendedor / Empresario', 'Propietario de negocio, empresario', 1, 19),
(20, 'Estudiante', 'Estudiante universitario, t�cnico o profesional', 1, 20),
(21, 'Ama de Casa', 'Trabajo en el hogar, cuidado de familia', 1, 21),
(22, 'Pensionado / Jubilado', 'Persona retirada o jubilada', 1, 22),
(23, 'Desempleado', 'Sin empleo actual', 1, 23),
(24, 'Independiente / Freelance', 'Trabajo independiente en diversas �reas', 1, 24),
(25, 'Otro', 'Otra ocupaci�n no listada', 1, 25)
GO

SET IDENTITY_INSERT [dbo].[Occupations] OFF
GO

PRINT 'Ocupaciones insertadas: ' + CAST(@@ROWCOUNT AS VARCHAR(10))
GO

-- ============================================
-- 2. ESTADOS CIVILES (MaritalStatuses)
-- ============================================
PRINT 'Insertando Estados Civiles...'

SET IDENTITY_INSERT [dbo].[MaritalStatuses] ON
GO

INSERT INTO [dbo].[MaritalStatuses] ([Id], [Name], [Code], [IsActive], [DisplayOrder])
VALUES
(1, 'Soltero(a)', 'S', 1, 1),
(2, 'Casado(a)', 'C', 1, 2),
(3, 'Uni�n Libre / Uni�n de Hecho', 'UL', 1, 3),
(4, 'Divorciado(a)', 'D', 1, 4),
(5, 'Separado(a)', 'SEP', 1, 5),
(6, 'Viudo(a)', 'V', 1, 6)
GO

SET IDENTITY_INSERT [dbo].[MaritalStatuses] OFF
GO

PRINT 'Estados Civiles insertados: ' + CAST(@@ROWCOUNT AS VARCHAR(10))
GO

-- ============================================
-- 3. NIVELES EDUCATIVOS (EducationLevels)
-- ============================================
PRINT 'Insertando Niveles Educativos...'

SET IDENTITY_INSERT [dbo].[EducationLevels] ON
GO

INSERT INTO [dbo].[EducationLevels] ([Id], [Name], [Code], [IsActive], [DisplayOrder])
VALUES
(1, 'Sin Educaci�n Formal', 'NONE', 1, 1),
(2, 'Primaria Incompleta', 'PRI_I', 1, 2),
(3, 'Primaria Completa', 'PRI_C', 1, 3),
(4, 'Secundaria Incompleta', 'SEC_I', 1, 4),
(5, 'Secundaria Completa / Bachillerato', 'SEC_C', 1, 5),
(6, 'T�cnico', 'TEC', 1, 6),
(7, 'Tecn�logo', 'TECNO', 1, 7),
(8, 'Universitario Incompleto', 'UNI_I', 1, 8),
(9, 'Universitario Completo / Profesional', 'UNI_C', 1, 9),
(10, 'Especializaci�n', 'ESP', 1, 10),
(11, 'Maestr�a', 'MAES', 1, 11),
(12, 'Doctorado / PhD', 'DOCT', 1, 12),
(13, 'Postdoctorado', 'POSTDOC', 1, 13)
GO

SET IDENTITY_INSERT [dbo].[EducationLevels] OFF
GO

PRINT 'Niveles Educativos insertados: ' + CAST(@@ROWCOUNT AS VARCHAR(10))
GO

-- ============================================
-- VERIFICACI�N DE DATOS INSERTADOS
-- ============================================
PRINT ''
PRINT '============================================'
PRINT 'RESUMEN DE DATOS INSERTADOS'
PRINT '============================================'

SELECT 
    'Occupations' AS [Tabla],
    COUNT(*) AS [Total Registros]
FROM [dbo].[Occupations]
UNION ALL
SELECT 
    'MaritalStatuses' AS [Tabla],
    COUNT(*) AS [Total Registros]
FROM [dbo].[MaritalStatuses]
UNION ALL
SELECT 
    'EducationLevels' AS [Tabla],
    COUNT(*) AS [Total Registros]
FROM [dbo].[EducationLevels]
GO

PRINT ''
PRINT '============================================'
PRINT 'SCRIPT COMPLETADO EXITOSAMENTE'
PRINT '============================================'
GO

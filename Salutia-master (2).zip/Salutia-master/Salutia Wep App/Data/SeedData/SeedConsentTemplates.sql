-- ============================================
-- Script de Datos Semilla para Consentimientos Informados
-- Proyecto: Salutia - Plataforma de Salud Ocupacional
-- Fecha: 2025-01-19
-- ============================================

USE [Salutia-TBE]
GO

PRINT 'Insertando Plantillas de Consentimientos Informados...'
GO

-- Obtener el ID del SuperAdmin para asignar como creador
DECLARE @SuperAdminId NVARCHAR(450)

-- Intentar buscar por diferentes emails comunes
SELECT TOP 1 @SuperAdminId = Id 
FROM AspNetUsers 
WHERE Email IN ('superadmin@salutia.com', 'admin@salutia.com', 'elpecodm@gmail.com')
ORDER BY Email

IF @SuperAdminId IS NULL
BEGIN
    PRINT 'ADVERTENCIA: No se encontr� el SuperAdmin con emails conocidos.'
    PRINT 'Buscando el primer usuario con rol SuperAdmin...'
    
    -- Buscar por rol
    SELECT TOP 1 @SuperAdminId = u.Id
    FROM AspNetUsers u
    INNER JOIN AspNetUserRoles ur ON u.Id = ur.UserId
    INNER JOIN AspNetRoles r ON ur.RoleId = r.Id
    WHERE r.Name = 'SuperAdmin'
    ORDER BY u.Email
END

IF @SuperAdminId IS NULL
BEGIN
    PRINT 'ERROR: No se encontr� ning�n SuperAdmin en el sistema.'
    PRINT 'Por favor ejecute primero el script CREATE-SUPERADMIN.sql'
    RETURN
END

PRINT 'SuperAdmin encontrado - ID: ' + @SuperAdminId
GO

-- Variable para el SuperAdmin ID (debe redeclararse despu�s del GO)
DECLARE @SuperAdminId NVARCHAR(450)
SELECT TOP 1 @SuperAdminId = u.Id
FROM AspNetUsers u
INNER JOIN AspNetUserRoles ur ON u.Id = ur.UserId
INNER JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE r.Name = 'SuperAdmin'
ORDER BY u.Email

-- ============================================
-- 1. CONSENTIMIENTO DE PROTECCI�N DE DATOS PERSONALES
-- ============================================
INSERT INTO [dbo].[ConsentTemplates] (
    [Title], 
    [Code], 
    [ContentHtml], 
    [Version], 
    [DisplayOrder], 
    [IsActive], 
    [EntityId], 
    [ModifiedByUserId], 
    [CreatedAt], 
    [ModifiedAt], 
    [IsRequired]
)
VALUES (
    'Consentimiento de Protecci�n de Datos Personales',
    'CONSENT_DATA_PRIVACY',
    '<div class="consent-content">
        <h2>Consentimiento Informado para el Tratamiento de Datos Personales</h2>
        
        <p>De conformidad con lo establecido en la Ley 1581 de 2012 y el Decreto 1377 de 2013, por medio del presente documento autorizo de manera libre, previa, expresa, voluntaria y debidamente informada a <strong>SALUTIA - Plataforma de Salud Ocupacional</strong> para:</p>
        
        <h3>1. Recolecci�n de Datos</h3>
        <p>Recolectar, almacenar, usar, circular, suprimir, procesar, compilar, intercambiar, dar tratamiento, actualizar y disponer de los datos que he suministrado y que suministrar� a futuro, incluyendo informaci�n personal, m�dica, psicol�gica y laboral.</p>
        
        <h3>2. Finalidad del Tratamiento</h3>
        <ul>
            <li>Realizar evaluaciones psicosom�ticas y psicol�gicas</li>
            <li>Generar reportes y an�lisis de resultados</li>
            <li>Proveer servicios de salud ocupacional</li>
            <li>Cumplir con obligaciones legales y regulatorias</li>
            <li>Mejorar la calidad de los servicios prestados</li>
            <li>Realizar estudios estad�sticos y epidemiol�gicos</li>
        </ul>
        
        <h3>3. Derechos del Titular</h3>
        <p>Como titular de los datos personales tengo derecho a:</p>
        <ul>
            <li>Conocer, actualizar y rectificar mis datos personales</li>
            <li>Solicitar prueba de la autorizaci�n otorgada</li>
            <li>Ser informado sobre el uso dado a mis datos personales</li>
            <li>Presentar quejas ante la Superintendencia de Industria y Comercio</li>
            <li>Revocar la autorizaci�n y/o solicitar la supresi�n del dato</li>
            <li>Acceder en forma gratuita a mis datos personales</li>
        </ul>
        
        <h3>4. Seguridad de la Informaci�n</h3>
        <p>SALUTIA se compromete a adoptar las medidas t�cnicas, humanas y administrativas necesarias para otorgar seguridad a los registros evitando su adulteraci�n, p�rdida, consulta, uso o acceso no autorizado o fraudulento.</p>
        
        <h3>5. Vigencia</h3>
        <p>Esta autorizaci�n tiene una vigencia igual al tiempo en que se mantenga la finalidad del tratamiento de datos.</p>
        
        <p class="text-muted small mt-4">
            <strong>Nota:</strong> La firma de este documento es obligatoria para acceder a los servicios de evaluaci�n psicosom�tica.
        </p>
    </div>',
    1,
    1,
    1,
    NULL,
    @SuperAdminId,
    GETUTCDATE(),
    GETUTCDATE(),
    1
);
GO

-- Redeclarar variable despu�s del GO
DECLARE @SuperAdminId NVARCHAR(450)
SELECT TOP 1 @SuperAdminId = u.Id
FROM AspNetUsers u
INNER JOIN AspNetUserRoles ur ON u.Id = ur.UserId
INNER JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE r.Name = 'SuperAdmin'

-- ============================================
-- 2. CONSENTIMIENTO PARA EVALUACI�N PSICOL�GICA
-- ============================================
INSERT INTO [dbo].[ConsentTemplates] (
    [Title], 
    [Code], 
    [ContentHtml], 
    [Version], 
    [DisplayOrder], 
    [IsActive], 
    [EntityId], 
    [ModifiedByUserId], 
    [CreatedAt], 
    [ModifiedAt], 
    [IsRequired]
)
VALUES (
    'Consentimiento para Evaluaci�n Psicol�gica',
    'CONSENT_PSYCHOLOGICAL_EVAL',
    '<div class="consent-content">
        <h2>Consentimiento Informado para Evaluaci�n Psicol�gica</h2>
        
        <p>Por medio del presente documento, yo <strong>[NOMBRE DEL PACIENTE]</strong>, identificado(a) con documento <strong>[DOCUMENTO]</strong>, manifiesto que:</p>
        
        <h3>1. He Sido Informado(a) de que:</h3>
        <ul>
            <li>La evaluaci�n psicol�gica tiene como objetivo identificar aspectos psicosom�ticos que puedan estar afectando mi bienestar</li>
            <li>El proceso incluye la aplicaci�n de pruebas y cuestionarios dise�ados para este fin</li>
            <li>Los resultados ser�n utilizados exclusivamente con fines terap�uticos y de diagn�stico</li>
            <li>La informaci�n obtenida ser� manejada con estricta confidencialidad</li>
            <li>Tengo derecho a conocer los resultados de la evaluaci�n</li>
        </ul>
        
        <h3>2. Naturaleza de la Evaluaci�n</h3>
        <p>Comprendo que la evaluaci�n psicosom�tica que voy a realizar:</p>
        <ul>
            <li>Es voluntaria y puedo retirarme en cualquier momento</li>
            <li>Los resultados son confidenciales</li>
            <li>Ser� realizada por profesionales calificados</li>
            <li>Puede revelar informaci�n sensible sobre mi estado emocional y psicol�gico</li>
            <li>Los resultados ser�n compartidos �nicamente con profesionales autorizados</li>
        </ul>
        
        <h3>3. Limitaciones</h3>
        <p>Entiendo que:</p>
        <ul>
            <li>Esta evaluaci�n no reemplaza una consulta m�dica completa</li>
            <li>Los resultados deben ser interpretados por un profesional calificado</li>
            <li>En caso de requerir atenci�n especializada, ser� remitido(a) al profesional correspondiente</li>
        </ul>
        
        <h3>4. Confidencialidad</h3>
        <p>La informaci�n obtenida ser� confidencial, salvo en los siguientes casos:</p>
        <ul>
            <li>Riesgo inminente de da�o a s� mismo o a terceros</li>
            <li>Obligaci�n legal de reportar (abuso, violencia, etc.)</li>
            <li>Autorizaci�n expresa del evaluado</li>
        </ul>
        
        <p class="alert alert-info mt-4">
            <strong>Importante:</strong> Este consentimiento certifica que he le�do y comprendido la informaci�n anterior y que acepto voluntariamente participar en la evaluaci�n psicol�gica.
        </p>
    </div>',
    1,
    2,
    1,
    NULL,
    @SuperAdminId,
    GETUTCDATE(),
    GETUTCDATE(),
    1
);
GO

-- Redeclarar variable despu�s del GO
DECLARE @SuperAdminId NVARCHAR(450)
SELECT TOP 1 @SuperAdminId = u.Id
FROM AspNetUsers u
INNER JOIN AspNetUserRoles ur ON u.Id = ur.UserId
INNER JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE r.Name = 'SuperAdmin'

-- ============================================
-- 3. CONSENTIMIENTO PARA REGISTRO DE INFORMACI�N M�DICA
-- ============================================
INSERT INTO [dbo].[ConsentTemplates] (
    [Title], 
    [Code], 
    [ContentHtml], 
    [Version], 
    [DisplayOrder], 
    [IsActive], 
    [EntityId], 
    [ModifiedByUserId], 
    [CreatedAt], 
    [ModifiedAt], 
    [IsRequired]
)
VALUES (
    'Consentimiento para Registro de Informaci�n M�dica',
    'CONSENT_MEDICAL_RECORD',
    '<div class="consent-content">
        <h2>Consentimiento para Registro y Uso de Informaci�n M�dica</h2>
        
        <p>Autorizo a <strong>SALUTIA</strong> para que registre, almacene y utilice mi informaci�n m�dica y de salud, incluyendo pero no limitado a:</p>
        
        <h3>1. Informaci�n a Registrar</h3>
        <ul>
            <li>Historia cl�nica y antecedentes m�dicos</li>
            <li>Resultados de evaluaciones y pruebas</li>
            <li>Medicamentos y tratamientos actuales</li>
            <li>Alergias y condiciones preexistentes</li>
            <li>Informaci�n de contactos de emergencia</li>
            <li>Datos ocupacionales y laborales</li>
        </ul>
        
        <h3>2. Uso de la Informaci�n</h3>
        <p>La informaci�n m�dica ser� utilizada para:</p>
        <ul>
            <li>Brindar atenci�n m�dica y psicol�gica adecuada</li>
            <li>Realizar seguimiento de mi evoluci�n</li>
            <li>Coordinar con otros profesionales de salud cuando sea necesario</li>
            <li>Cumplir con requisitos legales y regulatorios</li>
            <li>Generar estad�sticas an�nimas para investigaci�n</li>
        </ul>
        
        <h3>3. Acceso a la Informaci�n</h3>
        <p>Tendr�n acceso a mi informaci�n m�dica:</p>
        <ul>
            <li>El profesional de salud que me atiende directamente</li>
            <li>Personal autorizado de la entidad para la que laboro (si aplica)</li>
            <li>Autoridades de salud cuando sea requerido por ley</li>
            <li>Otros profesionales de salud con mi autorizaci�n expresa</li>
        </ul>
        
        <h3>4. Derechos sobre la Informaci�n</h3>
        <p>Como titular de la informaci�n m�dica, tengo derecho a:</p>
        <ul>
            <li>Acceder a mi historia cl�nica en cualquier momento</li>
            <li>Solicitar correcciones de informaci�n inexacta</li>
            <li>Obtener copias de mi informaci�n m�dica</li>
            <li>Restringir el acceso a mi informaci�n en ciertos casos</li>
            <li>Conocer qui�n ha accedido a mi informaci�n</li>
        </ul>
        
        <h3>5. Almacenamiento y Seguridad</h3>
        <p>SALUTIA se compromete a:</p>
        <ul>
            <li>Mantener la informaci�n m�dica en sistemas seguros</li>
            <li>Proteger la confidencialidad de los datos</li>
            <li>Realizar copias de seguridad peri�dicas</li>
            <li>Cumplir con todas las normativas de protecci�n de datos</li>
        </ul>
        
        <p class="text-muted small mt-4">
            <strong>Nota:</strong> Este consentimiento permanece vigente mientras mantenga una relaci�n con SALUTIA y podr� ser revocado en cualquier momento mediante solicitud escrita.
        </p>
    </div>',
    1,
    3,
    1,
    NULL,
    @SuperAdminId,
    GETUTCDATE(),
    GETUTCDATE(),
    1
);
GO

-- Redeclarar variable despu�s del GO
DECLARE @SuperAdminId NVARCHAR(450)
SELECT TOP 1 @SuperAdminId = u.Id
FROM AspNetUsers u
INNER JOIN AspNetUserRoles ur ON u.Id = ur.UserId
INNER JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE r.Name = 'SuperAdmin'

-- ============================================
-- 4. CONSENTIMIENTO PARA COMPARTIR RESULTADOS CON LA ENTIDAD EMPLEADORA
-- ============================================
INSERT INTO [dbo].[ConsentTemplates] (
    [Title], 
    [Code], 
    [ContentHtml], 
    [Version], 
    [DisplayOrder], 
    [IsActive], 
    [EntityId], 
    [ModifiedByUserId], 
    [CreatedAt], 
    [ModifiedAt], 
    [IsRequired]
)
VALUES (
    'Consentimiento para Compartir Resultados con la Entidad Empleadora',
    'CONSENT_SHARE_WITH_EMPLOYER',
    '<div class="consent-content">
        <h2>Consentimiento para Compartir Resultados con la Entidad Empleadora</h2>
        
        <p>Por medio del presente documento autorizo expresamente a <strong>SALUTIA</strong> para compartir los resultados de mi evaluaci�n psicosom�tica con:</p>
        
        <h3>1. Entidad Empleadora</h3>
        <p>Autorizo compartir con <strong>[NOMBRE DE LA ENTIDAD]</strong>:</p>
        <ul>
            <li>Resultados generales de la evaluaci�n</li>
            <li>Recomendaciones profesionales derivadas de la evaluaci�n</li>
            <li>Sugerencias para mejorar el ambiente laboral</li>
            <li>Informaci�n necesaria para implementar ajustes razonables</li>
        </ul>
        
        <h3>2. Informaci�n que NO ser� Compartida</h3>
        <p>NO se compartir� con la entidad empleadora:</p>
        <ul>
            <li>Detalles espec�ficos de las respuestas a las pruebas</li>
            <li>Informaci�n cl�nica detallada sin mi autorizaci�n adicional</li>
            <li>Diagn�sticos m�dicos espec�ficos</li>
            <li>Informaci�n personal no relacionada con el �mbito laboral</li>
        </ul>
        
        <h3>3. Prop�sito del Compartir Informaci�n</h3>
        <p>La informaci�n compartida tiene como objetivo:</p>
        <ul>
            <li>Mejorar las condiciones de trabajo</li>
            <li>Implementar medidas de prevenci�n en salud ocupacional</li>
            <li>Cumplir con programas de bienestar laboral</li>
            <li>Garantizar un ambiente de trabajo saludable</li>
            <li>Realizar seguimiento de los programas de salud ocupacional</li>
        </ul>
        
        <h3>4. Uso por Parte del Empleador</h3>
        <p>La entidad empleadora se compromete a:</p>
        <ul>
            <li>Usar la informaci�n �nicamente para fines de salud ocupacional</li>
            <li>No discriminar bas�ndose en los resultados</li>
            <li>Mantener la confidencialidad de la informaci�n</li>
            <li>Implementar las recomendaciones cuando sea posible</li>
            <li>Proteger la privacidad del empleado</li>
        </ul>
        
        <h3>5. Revocaci�n del Consentimiento</h3>
        <p>Entiendo que:</p>
        <ul>
            <li>Puedo revocar este consentimiento en cualquier momento</li>
            <li>La revocaci�n no afectar� informaci�n ya compartida</li>
            <li>Debo notificar por escrito mi decisi�n de revocar</li>
            <li>La revocaci�n puede afectar mi participaci�n en programas de bienestar</li>
        </ul>
        
        <h3>6. Protecci�n Legal</h3>
        <p>Este consentimiento se rige por:</p>
        <ul>
            <li>Ley 1581 de 2012 de Protecci�n de Datos Personales</li>
            <li>Ley 1090 de 2006 (C�digo Deontol�gico del Psic�logo)</li>
            <li>Resoluci�n 2346 de 2007 (Evaluaciones M�dicas Ocupacionales)</li>
            <li>Normatividad vigente en materia de salud ocupacional</li>
        </ul>
        
        <div class="alert alert-warning mt-4">
            <strong>Importante:</strong> Si no autorizo compartir los resultados con la entidad empleadora, los mismos solo estar�n disponibles para el profesional que realiz� la evaluaci�n y para m� como evaluado.
        </div>
        
        <p class="text-muted small mt-3">
            <strong>Nota:</strong> Este consentimiento es independiente de los dem�s y puede ser revocado sin afectar mi derecho a recibir la evaluaci�n psicosom�tica.
        </p>
    </div>',
    1,
    4,
    1,
    NULL,
    @SuperAdminId,
    GETUTCDATE(),
    GETUTCDATE(),
    0  -- Este consentimiento NO es obligatorio
);
GO

-- ============================================
-- VERIFICACI�N DE DATOS INSERTADOS
-- ============================================
PRINT ''
PRINT '============================================'
PRINT 'RESUMEN DE PLANTILLAS INSERTADAS'
PRINT '============================================'

SELECT 
    Id,
    Title,
    Code,
    Version,
    DisplayOrder,
    IsRequired,
    IsActive
FROM [dbo].[ConsentTemplates]
ORDER BY DisplayOrder
GO

PRINT ''
PRINT '============================================'
PRINT 'SCRIPT COMPLETADO EXITOSAMENTE'
PRINT '============================================'
PRINT ''
PRINT 'Se han insertado 4 plantillas de consentimiento:'
PRINT '  1. Protecci�n de Datos Personales (OBLIGATORIO)'
PRINT '  2. Evaluaci�n Psicol�gica (OBLIGATORIO)'
PRINT '  3. Registro de Informaci�n M�dica (OBLIGATORIO)'
PRINT '  4. Compartir con Entidad Empleadora (OPCIONAL)'
PRINT ''
GO

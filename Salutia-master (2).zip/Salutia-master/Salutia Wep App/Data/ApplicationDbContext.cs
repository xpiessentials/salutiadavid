using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Salutia_Wep_App.Models.PsychosomaticTest;
using Salutia_Wep_App.Models.Patient;
using Salutia_Wep_App.Models.Consent;

namespace Salutia_Wep_App.Data;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : IdentityDbContext<ApplicationUser>(options)
{
    // DbSets para los perfiles de usuario
    public DbSet<IndependentUserProfile> IndependentUserProfiles { get; set; }
    public DbSet<EntityUserProfile> EntityUserProfiles { get; set; }
    public DbSet<EntityProfessionalProfile> EntityProfessionalProfiles { get; set; }
    public DbSet<PatientProfile> PatientProfiles { get; set; }
    
    // DbSet para Entidades (empresas/organizaciones)
    public DbSet<Entity> Entities { get; set; }
    
    // DbSets para datos geogr�ficos
    public DbSet<Country> Countries { get; set; }
    public DbSet<State> States { get; set; }
    public DbSet<City> Cities { get; set; }

    // DbSets para informaci�n adicional del paciente
    public DbSet<Occupation> Occupations { get; set; }
    public DbSet<MaritalStatus> MaritalStatuses { get; set; }
    public DbSet<EducationLevel> EducationLevels { get; set; }
    public DbSet<PatientMedicalHistory> PatientMedicalHistories { get; set; }
    public DbSet<PatientMedication> PatientMedications { get; set; }
    public DbSet<PatientAllergy> PatientAllergies { get; set; }
    public DbSet<PatientEmergencyContact> PatientEmergencyContacts { get; set; }

    // DbSets para Test Psicosom�tico
    public DbSet<PsychosomaticTest> PsychosomaticTests { get; set; }
    public DbSet<TestWord> TestWords { get; set; }
    public DbSet<TestPhrase> TestPhrases { get; set; }
    public DbSet<TestEmotion> TestEmotions { get; set; }
    public DbSet<TestDiscomfortLevel> TestDiscomfortLevels { get; set; }
    public DbSet<TestAge> TestAges { get; set; }
    public DbSet<TestBodyPart> TestBodyParts { get; set; }
    public DbSet<TestAssociatedPerson> TestAssociatedPersons { get; set; }
    public DbSet<TestMatrix> TestMatrices { get; set; }

    // DbSets para Consentimientos Informados
    public DbSet<ConsentTemplate> ConsentTemplates { get; set; }
    public DbSet<PatientConsent> PatientConsents { get; set; }
    public DbSet<ConsentSignature> ConsentSignatures { get; set; }
    public DbSet<ConsentDocument> ConsentDocuments { get; set; }
    public DbSet<ConsentTemplateHistory> ConsentTemplateHistories { get; set; }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        // Configuraci�n de ApplicationUser
        builder.Entity<ApplicationUser>(entity =>
        {
            entity.HasIndex(e => e.UserType);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
        });

        // Configuraci�n de Entity (Empresa/Organizaci�n)
        builder.Entity<Entity>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.TaxId).IsUnique();
            entity.HasIndex(e => e.Email).IsUnique();
            entity.Property(e => e.BusinessName).IsRequired().HasMaxLength(300);
            entity.Property(e => e.TaxId).IsRequired().HasMaxLength(20);
            entity.Property(e => e.VerificationDigit).IsRequired().HasMaxLength(1);
            entity.Property(e => e.Phone).IsRequired().HasMaxLength(20);
            entity.Property(e => e.Email).IsRequired().HasMaxLength(256);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            
            // Relaciones
            entity.HasMany(e => e.Administrators)
                .WithOne(a => a.Entity)
                .HasForeignKey(a => a.EntityId)
                .OnDelete(DeleteBehavior.Restrict);
            
            entity.HasMany(e => e.Professionals)
                .WithOne(p => p.Entity)
                .HasForeignKey(p => p.EntityId)
                .OnDelete(DeleteBehavior.Restrict);
            
            entity.HasMany(e => e.Patients)
                .WithOne(p => p.Entity)
                .HasForeignKey(p => p.EntityId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Configuraci�n de Country
        builder.Entity<Country>(entity =>
        {
     entity.HasKey(e => e.Id);
 entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
 entity.Property(e => e.Code).IsRequired().HasMaxLength(3);
         entity.HasIndex(e => e.Code).IsUnique();
 });

        // Configuraci�n de State
        builder.Entity<State>(entity =>
        {
        entity.HasKey(e => e.Id);
 entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Code).IsRequired().HasMaxLength(10);
         
            entity.HasOne(e => e.Country)
           .WithMany(c => c.States)
         .HasForeignKey(e => e.CountryId)
    .OnDelete(DeleteBehavior.Cascade);
      
   entity.HasIndex(e => new { e.CountryId, e.Code }).IsUnique();
 });

      // Configuraci�n de City
   builder.Entity<City>(entity =>
    {
      entity.HasKey(e => e.Id);
  entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
            
  entity.HasOne(e => e.State)
      .WithMany(s => s.Cities)
 .HasForeignKey(e => e.StateId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // Configuraci�n de IndependentUserProfile
        builder.Entity<IndependentUserProfile>(entity =>
        {
            entity.HasKey(e => e.Id);

        entity.HasOne(e => e.ApplicationUser)
  .WithOne(u => u.IndependentProfile)
     .HasForeignKey<IndependentUserProfile>(e => e.ApplicationUserId)
 .OnDelete(DeleteBehavior.Cascade);

 entity.HasIndex(e => e.DocumentNumber).IsUnique();
     entity.Property(e => e.FullName).IsRequired().HasMaxLength(200);
      entity.Property(e => e.DocumentNumber).IsRequired().HasMaxLength(50);
            entity.Property(e => e.Phone).IsRequired().HasMaxLength(20);
            
  // Relaciones geogr�ficas
         entity.HasOne(e => e.Country)
                .WithMany()
        .HasForeignKey(e => e.CountryId)
                .OnDelete(DeleteBehavior.Restrict);
        
        entity.HasOne(e => e.State)
   .WithMany()
                .HasForeignKey(e => e.StateId)
         .OnDelete(DeleteBehavior.Restrict);
    
          entity.HasOne(e => e.City)
      .WithMany()
       .HasForeignKey(e => e.CityId)
    .OnDelete(DeleteBehavior.Restrict);
        });

     // Configuraci�n de EntityUserProfile (Administrador de Entidad)
        builder.Entity<EntityUserProfile>(entity =>
        {
            entity.HasKey(e => e.Id);

            entity.HasOne(e => e.ApplicationUser)
                .WithOne(u => u.EntityProfile)
                .HasForeignKey<EntityUserProfile>(e => e.ApplicationUserId)
                .OnDelete(DeleteBehavior.Cascade);

            // Una entidad puede tener m�ltiples administradores
            entity.HasIndex(e => new { e.EntityId, e.ApplicationUserId }).IsUnique();
            entity.Property(e => e.FullName).IsRequired().HasMaxLength(200);
            entity.Property(e => e.JoinedAt).HasDefaultValueSql("GETUTCDATE()");
            entity.Property(e => e.IsActive).HasDefaultValue(true);
        });

  // Configuraci�n de EntityProfessionalProfile
        builder.Entity<EntityProfessionalProfile>(entity =>
        {
       entity.HasKey(e => e.Id);

    entity.HasOne(e => e.ApplicationUser)
       .WithOne(u => u.EntityProfessionalProfile)
         .HasForeignKey<EntityProfessionalProfile>(e => e.ApplicationUserId)
       .OnDelete(DeleteBehavior.Cascade);

            // Relaci�n directa con Entity
            entity.HasOne(e => e.Entity)
                .WithMany(ent => ent.Professionals)
                .HasForeignKey(e => e.EntityId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasIndex(e => new { e.EntityId, e.DocumentNumber }).IsUnique();
          entity.Property(e => e.FullName).IsRequired().HasMaxLength(200);
          entity.Property(e => e.DocumentNumber).IsRequired().HasMaxLength(50);
   entity.Property(e => e.JoinedAt).HasDefaultValueSql("GETUTCDATE()");
            
   entity.HasMany(e => e.Patients)
   .WithOne(p => p.Professional)
          .HasForeignKey(p => p.ProfessionalId)
                .OnDelete(DeleteBehavior.Restrict);
          
 // Relaciones geogr�ficas
          entity.HasOne(e => e.Country)
                .WithMany()
           .HasForeignKey(e => e.CountryId)
            .OnDelete(DeleteBehavior.Restrict);
    
      entity.HasOne(e => e.State)
              .WithMany()
      .HasForeignKey(e => e.StateId)
           .OnDelete(DeleteBehavior.Restrict);
         
            entity.HasOne(e => e.City)
    .WithMany()
 .HasForeignKey(e => e.CityId)
 .OnDelete(DeleteBehavior.Restrict);
        });

 // Configuraci�n de PatientProfile
        builder.Entity<PatientProfile>(entity =>
      {
            entity.HasKey(e => e.Id);

            entity.HasOne(e => e.ApplicationUser)
.WithOne(u => u.PatientProfile)
      .HasForeignKey<PatientProfile>(e => e.ApplicationUserId)
              .OnDelete(DeleteBehavior.Cascade);

            // Relaci�n con Entity (opcional, puede ser null para pacientes independientes)
            entity.HasOne(e => e.Entity)
                .WithMany(ent => ent.Patients)
                .HasForeignKey(e => e.EntityId)
                .OnDelete(DeleteBehavior.Restrict);

   entity.HasIndex(e => new { e.ProfessionalId, e.DocumentNumber }).IsUnique();
            entity.Property(e => e.FullName).IsRequired(false).HasMaxLength(200);
            entity.Property(e => e.DocumentNumber).IsRequired().HasMaxLength(50);
 entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            entity.Property(e => e.IsEntityPatient).HasDefaultValue(false);
            entity.Property(e => e.ProfileCompleted).HasDefaultValue(false);
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            
       // Relaciones geogr�ficas
            entity.HasOne(e => e.Country)
         .WithMany()
           .HasForeignKey(e => e.CountryId)
      .OnDelete(DeleteBehavior.Restrict);
       
            entity.HasOne(e => e.State)
              .WithMany()
    .HasForeignKey(e => e.StateId)
   .OnDelete(DeleteBehavior.Restrict);
        
  entity.HasOne(e => e.City)
              .WithMany()
      .HasForeignKey(e => e.CityId)
    .OnDelete(DeleteBehavior.Restrict);
        });
     // Configuraci�n de PsychosomaticTest
        builder.Entity<PsychosomaticTest>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.PatientUserId).IsRequired().HasMaxLength(450);
         entity.Property(e => e.StartedAt).HasDefaultValueSql("GETUTCDATE()");

 // Un paciente solo puede tener un test (puede extenderse a m�ltiples si se requiere)
         entity.HasIndex(e => e.PatientUserId);
        });

        // Configuraci�n de TestWord
     builder.Entity<TestWord>(entity =>
        {
         entity.HasKey(e => e.Id);
       entity.Property(e => e.Word).IsRequired().HasMaxLength(100);
     entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

            entity.HasOne(e => e.PsychosomaticTest)
              .WithMany(t => t.Words)
      .HasForeignKey(e => e.PsychosomaticTestId)
      .OnDelete(DeleteBehavior.Cascade);

        entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
        });

    // Configuraci�n de TestPhrase
        builder.Entity<TestPhrase>(entity =>
        {
  entity.HasKey(e => e.Id);
            entity.Property(e => e.Phrase).IsRequired().HasMaxLength(500);
      entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

            entity.HasOne(e => e.PsychosomaticTest)
      .WithMany()
      .HasForeignKey(e => e.PsychosomaticTestId)
     .OnDelete(DeleteBehavior.Cascade);

   entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
        });

        // Configuraci�n de TestEmotion
        builder.Entity<TestEmotion>(entity =>
        {
     entity.HasKey(e => e.Id);
            entity.Property(e => e.Emotion).IsRequired().HasMaxLength(100);
    entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

   entity.HasOne(e => e.PsychosomaticTest)
     .WithMany()
         .HasForeignKey(e => e.PsychosomaticTestId)
      .OnDelete(DeleteBehavior.Cascade);

     entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
        });

        // Configuraci�n de TestDiscomfortLevel
        builder.Entity<TestDiscomfortLevel>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.DiscomfortLevel).IsRequired();
 entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

            entity.HasOne(e => e.PsychosomaticTest)
      .WithMany()
          .HasForeignKey(e => e.PsychosomaticTestId)
        .OnDelete(DeleteBehavior.Cascade);

entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
        });

        // Configuraci�n de TestAge
        builder.Entity<TestAge>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Age).IsRequired().HasMaxLength(50);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

            entity.HasOne(e => e.PsychosomaticTest)
                .WithMany()
                .HasForeignKey(e => e.PsychosomaticTestId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
        });

        // Configuraci�n de TestBodyPart
        builder.Entity<TestBodyPart>(entity =>
        {
         entity.HasKey(e => e.Id);
            entity.Property(e => e.BodyPart).IsRequired().HasMaxLength(100);
         entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

  entity.HasOne(e => e.PsychosomaticTest)
   .WithMany()
          .HasForeignKey(e => e.PsychosomaticTestId)
    .OnDelete(DeleteBehavior.Cascade);

      entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
});

      // Configuraci�n de TestAssociatedPerson
      builder.Entity<TestAssociatedPerson>(entity =>
        {
            entity.HasKey(e => e.Id);
     entity.Property(e => e.PersonName).IsRequired().HasMaxLength(200);
  entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

        entity.HasOne(e => e.PsychosomaticTest)
   .WithMany()
        .HasForeignKey(e => e.PsychosomaticTestId)
       .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
        });

        // Configuraci�n de TestMatrix
        builder.Entity<TestMatrix>(entity =>
        {
            entity.HasKey(e => e.Id);
     entity.Property(e => e.Word).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Phrase).IsRequired().HasMaxLength(500);
            entity.Property(e => e.Emotion).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Age).IsRequired().HasMaxLength(50);
            entity.Property(e => e.BodyPart).IsRequired().HasMaxLength(100);
            entity.Property(e => e.AssociatedPerson).IsRequired().HasMaxLength(200);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

   entity.HasOne(e => e.PsychosomaticTest)
        .WithMany(t => t.MatrixResults)
          .HasForeignKey(e => e.PsychosomaticTestId)
          .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
      });

        // Configuraci�n de Occupation
        builder.Entity<Occupation>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.HasIndex(e => e.Name).IsUnique();
        });

        // Configuraci�n de MaritalStatus
        builder.Entity<MaritalStatus>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Code).IsRequired().HasMaxLength(20);
            entity.HasIndex(e => e.Code).IsUnique();
        });

        // Configuraci�n de EducationLevel
        builder.Entity<EducationLevel>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Code).IsRequired().HasMaxLength(20);
            entity.HasIndex(e => e.Code).IsUnique();
        });

        // Configuraci�n de PatientMedicalHistory
        builder.Entity<PatientMedicalHistory>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Condition).IsRequired().HasMaxLength(500);
            entity.Property(e => e.Notes).HasMaxLength(1000);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            
            entity.HasOne<PatientProfile>()
                .WithMany(p => p.MedicalHistories)
                .HasForeignKey(e => e.PatientProfileId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // Configuraci�n de PatientMedication
        builder.Entity<PatientMedication>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.MedicationName).IsRequired().HasMaxLength(300);
            entity.Property(e => e.Dosage).HasMaxLength(100);
            entity.Property(e => e.Frequency).HasMaxLength(100);
            entity.Property(e => e.Notes).HasMaxLength(1000);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            
            entity.HasOne<PatientProfile>()
                .WithMany(p => p.CurrentMedications)
                .HasForeignKey(e => e.PatientProfileId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // Configuraci�n de PatientAllergy
        builder.Entity<PatientAllergy>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.AllergenName).IsRequired().HasMaxLength(300);
            entity.Property(e => e.AllergyType).HasMaxLength(100);
            entity.Property(e => e.Reaction).HasMaxLength(500);
            entity.Property(e => e.Severity).HasMaxLength(50);
            entity.Property(e => e.Notes).HasMaxLength(1000);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            
            entity.HasOne<PatientProfile>()
                .WithMany(p => p.Allergies)
                .HasForeignKey(e => e.PatientProfileId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // Configuraci�n de PatientEmergencyContact
        builder.Entity<PatientEmergencyContact>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.FullName).IsRequired().HasMaxLength(200);
            entity.Property(e => e.Relationship).IsRequired().HasMaxLength(100);
            entity.Property(e => e.PhoneNumber).IsRequired().HasMaxLength(20);
            entity.Property(e => e.AlternatePhoneNumber).HasMaxLength(20);
            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.Address).HasMaxLength(500);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            
            entity.HasOne<PatientProfile>()
                .WithMany(p => p.EmergencyContacts)
                .HasForeignKey(e => e.PatientProfileId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // Configuraci�n de PsychosomaticTest
        builder.Entity<PsychosomaticTest>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.PatientUserId).IsRequired().HasMaxLength(450);
         entity.Property(e => e.StartedAt).HasDefaultValueSql("GETUTCDATE()");

 // Un paciente solo puede tener un test (puede extenderse a m�ltiples si se requiere)
         entity.HasIndex(e => e.PatientUserId);
        });

        // Configuraci�n de TestWord
     builder.Entity<TestWord>(entity =>
        {
         entity.HasKey(e => e.Id);
       entity.Property(e => e.Word).IsRequired().HasMaxLength(100);
     entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

            entity.HasOne(e => e.PsychosomaticTest)
              .WithMany(t => t.Words)
      .HasForeignKey(e => e.PsychosomaticTestId)
      .OnDelete(DeleteBehavior.Cascade);

        entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
        });

    // Configuraci�n de TestPhrase
        builder.Entity<TestPhrase>(entity =>
        {
  entity.HasKey(e => e.Id);
            entity.Property(e => e.Phrase).IsRequired().HasMaxLength(500);
      entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

            entity.HasOne(e => e.PsychosomaticTest)
      .WithMany()
      .HasForeignKey(e => e.PsychosomaticTestId)
     .OnDelete(DeleteBehavior.Cascade);

   entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
        });

        // Configuraci�n de TestEmotion
        builder.Entity<TestEmotion>(entity =>
        {
     entity.HasKey(e => e.Id);
            entity.Property(e => e.Emotion).IsRequired().HasMaxLength(100);
    entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

   entity.HasOne(e => e.PsychosomaticTest)
     .WithMany()
         .HasForeignKey(e => e.PsychosomaticTestId)
      .OnDelete(DeleteBehavior.Cascade);

     entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
        });

        // Configuraci�n de TestDiscomfortLevel
        builder.Entity<TestDiscomfortLevel>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.DiscomfortLevel).IsRequired();
 entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

            entity.HasOne(e => e.PsychosomaticTest)
      .WithMany()
          .HasForeignKey(e => e.PsychosomaticTestId)
        .OnDelete(DeleteBehavior.Cascade);

entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
        });

        // Configuraci�n de TestAge
        builder.Entity<TestAge>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Age).IsRequired().HasMaxLength(50);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

            entity.HasOne(e => e.PsychosomaticTest)
                .WithMany()
                .HasForeignKey(e => e.PsychosomaticTestId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
        });

        // Configuraci�n de TestBodyPart
        builder.Entity<TestBodyPart>(entity =>
        {
         entity.HasKey(e => e.Id);
            entity.Property(e => e.BodyPart).IsRequired().HasMaxLength(100);
         entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

  entity.HasOne(e => e.PsychosomaticTest)
   .WithMany()
          .HasForeignKey(e => e.PsychosomaticTestId)
    .OnDelete(DeleteBehavior.Cascade);

      entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
});

      // Configuraci�n de TestAssociatedPerson
      builder.Entity<TestAssociatedPerson>(entity =>
        {
            entity.HasKey(e => e.Id);
     entity.Property(e => e.PersonName).IsRequired().HasMaxLength(200);
  entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

        entity.HasOne(e => e.PsychosomaticTest)
   .WithMany()
        .HasForeignKey(e => e.PsychosomaticTestId)
       .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
        });

        // Configuraci�n de TestMatrix
        builder.Entity<TestMatrix>(entity =>
        {
            entity.HasKey(e => e.Id);
     entity.Property(e => e.Word).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Phrase).IsRequired().HasMaxLength(500);
            entity.Property(e => e.Emotion).IsRequired().HasMaxLength(100);
            entity.Property(e => e.Age).IsRequired().HasMaxLength(50);
            entity.Property(e => e.BodyPart).IsRequired().HasMaxLength(100);
            entity.Property(e => e.AssociatedPerson).IsRequired().HasMaxLength(200);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

   entity.HasOne(e => e.PsychosomaticTest)
        .WithMany(t => t.MatrixResults)
          .HasForeignKey(e => e.PsychosomaticTestId)
          .OnDelete(DeleteBehavior.Cascade);

            entity.HasIndex(e => new { e.PsychosomaticTestId, e.WordNumber }).IsUnique();
      });

        // Configuraci�n de ConsentTemplate
        builder.Entity<ConsentTemplate>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Title).IsRequired().HasMaxLength(300);
            entity.Property(e => e.Code).IsRequired().HasMaxLength(50);
            entity.Property(e => e.ContentHtml).IsRequired();
            entity.Property(e => e.ModifiedByUserId).IsRequired().HasMaxLength(450);
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            entity.Property(e => e.ModifiedAt).HasDefaultValueSql("GETUTCDATE()");
            
            entity.HasIndex(e => e.Code);
            entity.HasIndex(e => new { e.EntityId, e.Code });
        });

        // Configuraci�n de PatientConsent
        builder.Entity<PatientConsent>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.PatientUserId).IsRequired().HasMaxLength(450);
            entity.Property(e => e.ContentSnapshot).IsRequired();
            entity.Property(e => e.IpAddress).IsRequired().HasMaxLength(50);
            entity.Property(e => e.UserAgent).IsRequired().HasMaxLength(500);
            entity.Property(e => e.PdfUrl).HasMaxLength(500);
            entity.Property(e => e.PdfPath).HasMaxLength(500);
            entity.Property(e => e.SignedAt).HasDefaultValueSql("GETUTCDATE()");
            
            entity.HasOne(e => e.ConsentTemplate)
                .WithMany()
                .HasForeignKey(e => e.ConsentTemplateId)
                .OnDelete(DeleteBehavior.Restrict);
            
            entity.HasIndex(e => new { e.PsychosomaticTestId, e.ConsentTemplateId });
            entity.HasIndex(e => e.PatientUserId);
        });

        // Configuraci�n de ConsentSignature
        builder.Entity<ConsentSignature>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.SignatureDataBase64).IsRequired();
            entity.Property(e => e.SignerFullName).IsRequired().HasMaxLength(200);
            entity.Property(e => e.SignerDocumentNumber).IsRequired().HasMaxLength(50);
            entity.Property(e => e.SignedAt).HasDefaultValueSql("GETUTCDATE()");
            
            entity.HasOne(e => e.PatientConsent)
                .WithOne(pc => pc.Signature)
                .HasForeignKey<ConsentSignature>(e => e.PatientConsentId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // Configuraci�n de ConsentDocument
        builder.Entity<ConsentDocument>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.PatientUserId).IsRequired().HasMaxLength(450);
            entity.Property(e => e.DocumentName).IsRequired().HasMaxLength(300);
            entity.Property(e => e.DocumentType).IsRequired().HasMaxLength(50);
            entity.Property(e => e.DocumentUrl).IsRequired().HasMaxLength(500);
            entity.Property(e => e.DocumentPath).IsRequired().HasMaxLength(500);
            entity.Property(e => e.FileHash).IsRequired().HasMaxLength(64);
            entity.Property(e => e.DownloadedByUserId).HasMaxLength(450);
            entity.Property(e => e.GeneratedAt).HasDefaultValueSql("GETUTCDATE()");
            
            entity.HasIndex(e => e.PsychosomaticTestId);
            entity.HasIndex(e => e.PatientUserId);
        });

        // Configuraci�n de ConsentTemplateHistory
        builder.Entity<ConsentTemplateHistory>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.PreviousContentHtml).IsRequired();
            entity.Property(e => e.ModifiedByUserId).IsRequired().HasMaxLength(450);
            entity.Property(e => e.ChangeReason).IsRequired().HasMaxLength(500);
            entity.Property(e => e.ChangedAt).HasDefaultValueSql("GETUTCDATE()");
            
            entity.HasIndex(e => e.ConsentTemplateId);
        });
    }
}

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Salutia_Wep_App.Data;

/// <summary>
/// Representa una entidad/empresa en el sistema.
/// Una entidad puede tener m�ltiples administradores, profesionales y pacientes.
/// </summary>
public class Entity
{
    [Key]
    public int Id { get; set; }

    /// <summary>
    /// Raz�n social o nombre comercial de la entidad
    /// </summary>
    [Required]
    [StringLength(300)]
    public string BusinessName { get; set; } = string.Empty;

    /// <summary>
    /// NIT o identificaci�n tributaria (sin d�gito de verificaci�n)
    /// </summary>
    [Required]
    [StringLength(20)]
    public string TaxId { get; set; } = string.Empty;

    /// <summary>
    /// D�gito de verificaci�n del NIT
    /// </summary>
    [Required]
    [StringLength(1)]
    public string VerificationDigit { get; set; } = string.Empty;

    /// <summary>
    /// Tel�fono principal de contacto
    /// </summary>
    [Required]
    [StringLength(20)]
    public string Phone { get; set; } = string.Empty;

    /// <summary>
    /// Email de contacto de la entidad
    /// </summary>
    [Required]
    [EmailAddress]
    [StringLength(256)]
    public string Email { get; set; } = string.Empty;

    /// <summary>
    /// Direcci�n f�sica de la entidad
    /// </summary>
    [StringLength(500)]
    public string? Address { get; set; }

    /// <summary>
    /// Sitio web de la entidad
    /// </summary>
    [StringLength(200)]
    public string? Website { get; set; }

    /// <summary>
    /// Nombre del representante legal
    /// </summary>
    [StringLength(200)]
    public string? LegalRepresentative { get; set; }

    /// <summary>
    /// Indica si la entidad est� activa en el sistema
    /// </summary>
    public bool IsActive { get; set; } = true;

    /// <summary>
    /// Fecha de creaci�n del registro
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// Fecha de �ltima actualizaci�n
    /// </summary>
    public DateTime? UpdatedAt { get; set; }

    // Relaciones
    
    /// <summary>
    /// Usuarios administradores de esta entidad
    /// </summary>
    public ICollection<EntityUserProfile> Administrators { get; set; } = new List<EntityUserProfile>();

    /// <summary>
    /// Profesionales (M�dicos/Psic�logos) que pertenecen a esta entidad
    /// </summary>
    public ICollection<EntityProfessionalProfile> Professionals { get; set; } = new List<EntityProfessionalProfile>();

    /// <summary>
    /// Pacientes asociados a esta entidad
    /// </summary>
    public ICollection<PatientProfile> Patients { get; set; } = new List<PatientProfile>();
}

using Microsoft.EntityFrameworkCore;

namespace Salutia_Wep_App.Data;

/// <summary>
/// Clase para inicializar datos geogr�ficos en la base de datos
/// </summary>
public static class GeographicDataSeeder
{
 public static async Task SeedGeographicDataAsync(ApplicationDbContext context)
    {
        // Si ya existen datos, no hacer nada
        if (await context.Countries.AnyAsync())
        {
            return;
        }

        // Pa�ses de Latinoam�rica
        var countries = new List<Country>
   {
     new Country { Name = "Colombia", Code = "CO" },
          new Country { Name = "M�xico", Code = "MX" },
 new Country { Name = "Argentina", Code = "AR" },
  new Country { Name = "Chile", Code = "CL" },
          new Country { Name = "Per�", Code = "PE" },
   new Country { Name = "Venezuela", Code = "VE" },
            new Country { Name = "Ecuador", Code = "EC" },
       new Country { Name = "Bolivia", Code = "BO" },
            new Country { Name = "Paraguay", Code = "PY" },
  new Country { Name = "Uruguay", Code = "UY" },
     new Country { Name = "Costa Rica", Code = "CR" },
            new Country { Name = "Panam�", Code = "PA" },
         new Country { Name = "Guatemala", Code = "GT" },
  new Country { Name = "Honduras", Code = "HN" },
          new Country { Name = "El Salvador", Code = "SV" },
  new Country { Name = "Nicaragua", Code = "NI" },
         new Country { Name = "Rep�blica Dominicana", Code = "DO" },
         new Country { Name = "Cuba", Code = "CU" },
      new Country { Name = "Puerto Rico", Code = "PR" }
        };

        await context.Countries.AddRangeAsync(countries);
   await context.SaveChangesAsync();

        // Obtener el ID de Colombia para agregar sus departamentos
        var colombia = await context.Countries.FirstOrDefaultAsync(c => c.Code == "CO");
        if (colombia == null) return;

        // Departamentos de Colombia
   var colombianStates = new List<State>
        {
            new State { CountryId = colombia.Id, Name = "Amazonas", Code = "AMA" },
        new State { CountryId = colombia.Id, Name = "Antioquia", Code = "ANT" },
     new State { CountryId = colombia.Id, Name = "Arauca", Code = "ARA" },
          new State { CountryId = colombia.Id, Name = "Atl�ntico", Code = "ATL" },
            new State { CountryId = colombia.Id, Name = "Bol�var", Code = "BOL" },
 new State { CountryId = colombia.Id, Name = "Boyac�", Code = "BOY" },
        new State { CountryId = colombia.Id, Name = "Caldas", Code = "CAL" },
     new State { CountryId = colombia.Id, Name = "Caquet�", Code = "CAQ" },
   new State { CountryId = colombia.Id, Name = "Casanare", Code = "CAS" },
    new State { CountryId = colombia.Id, Name = "Cauca", Code = "CAU" },
      new State { CountryId = colombia.Id, Name = "Cesar", Code = "CES" },
     new State { CountryId = colombia.Id, Name = "Choc�", Code = "CHO" },
       new State { CountryId = colombia.Id, Name = "C�rdoba", Code = "COR" },
            new State { CountryId = colombia.Id, Name = "Cundinamarca", Code = "CUN" },
            new State { CountryId = colombia.Id, Name = "Guain�a", Code = "GUA" },
  new State { CountryId = colombia.Id, Name = "Guaviare", Code = "GUV" },
         new State { CountryId = colombia.Id, Name = "Huila", Code = "HUI" },
            new State { CountryId = colombia.Id, Name = "La Guajira", Code = "LAG" },
            new State { CountryId = colombia.Id, Name = "Magdalena", Code = "MAG" },
            new State { CountryId = colombia.Id, Name = "Meta", Code = "MET" },
   new State { CountryId = colombia.Id, Name = "Nari�o", Code = "NAR" },
    new State { CountryId = colombia.Id, Name = "Norte de Santander", Code = "NSA" },
          new State { CountryId = colombia.Id, Name = "Putumayo", Code = "PUT" },
 new State { CountryId = colombia.Id, Name = "Quind�o", Code = "QUI" },
  new State { CountryId = colombia.Id, Name = "Risaralda", Code = "RIS" },
            new State { CountryId = colombia.Id, Name = "San Andr�s y Providencia", Code = "SAP" },
     new State { CountryId = colombia.Id, Name = "Santander", Code = "SAN" },
            new State { CountryId = colombia.Id, Name = "Sucre", Code = "SUC" },
 new State { CountryId = colombia.Id, Name = "Tolima", Code = "TOL" },
            new State { CountryId = colombia.Id, Name = "Valle del Cauca", Code = "VAC" },
      new State { CountryId = colombia.Id, Name = "Vaup�s", Code = "VAU" },
            new State { CountryId = colombia.Id, Name = "Vichada", Code = "VID" }
     };

        await context.States.AddRangeAsync(colombianStates);
     await context.SaveChangesAsync();

        // Agregar ciudades principales de algunos departamentos
        await SeedColombianCitiesAsync(context);
    }

    private static async Task SeedColombianCitiesAsync(ApplicationDbContext context)
    {
 var cities = new List<City>();

        // Antioquia
        var antioquia = await context.States.FirstOrDefaultAsync(s => s.Code == "ANT");
        if (antioquia != null)
        {
       cities.AddRange(new[]
    {
            new City { StateId = antioquia.Id, Name = "Medell�n" },
         new City { StateId = antioquia.Id, Name = "Bello" },
     new City { StateId = antioquia.Id, Name = "Itag��" },
    new City { StateId = antioquia.Id, Name = "Envigado" },
     new City { StateId = antioquia.Id, Name = "Rionegro" },
     new City { StateId = antioquia.Id, Name = "Apartad�" },
             new City { StateId = antioquia.Id, Name = "Turbo" },
      new City { StateId = antioquia.Id, Name = "Sabaneta" }
            });
        }

        // Cundinamarca (incluye Bogot�)
     var cundinamarca = await context.States.FirstOrDefaultAsync(s => s.Code == "CUN");
      if (cundinamarca != null)
        {
  cities.AddRange(new[]
  {
     new City { StateId = cundinamarca.Id, Name = "Bogot� D.C." },
     new City { StateId = cundinamarca.Id, Name = "Soacha" },
      new City { StateId = cundinamarca.Id, Name = "Facatativ�" },
      new City { StateId = cundinamarca.Id, Name = "Ch�a" },
    new City { StateId = cundinamarca.Id, Name = "Zipaquir�" },
             new City { StateId = cundinamarca.Id, Name = "Girardot" },
    new City { StateId = cundinamarca.Id, Name = "Fusagasug�" }
    });
    }

    // Valle del Cauca
      var valle = await context.States.FirstOrDefaultAsync(s => s.Code == "VAC");
  if (valle != null)
     {
     cities.AddRange(new[]
 {
      new City { StateId = valle.Id, Name = "Cali" },
  new City { StateId = valle.Id, Name = "Palmira" },
       new City { StateId = valle.Id, Name = "Buenaventura" },
     new City { StateId = valle.Id, Name = "Tulu�" },
              new City { StateId = valle.Id, Name = "Cartago" },
              new City { StateId = valle.Id, Name = "Buga" },
        new City { StateId = valle.Id, Name = "Jamund�" }
            });
        }

// Atl�ntico
        var atlantico = await context.States.FirstOrDefaultAsync(s => s.Code == "ATL");
        if (atlantico != null)
        {
      cities.AddRange(new[]
        {
         new City { StateId = atlantico.Id, Name = "Barranquilla" },
    new City { StateId = atlantico.Id, Name = "Soledad" },
  new City { StateId = atlantico.Id, Name = "Malambo" },
   new City { StateId = atlantico.Id, Name = "Puerto Colombia" },
      new City { StateId = atlantico.Id, Name = "Sabanalarga" }
 });
     }

 // Santander
        var santander = await context.States.FirstOrDefaultAsync(s => s.Code == "SAN");
        if (santander != null)
  {
       cities.AddRange(new[]
            {
     new City { StateId = santander.Id, Name = "Bucaramanga" },
              new City { StateId = santander.Id, Name = "Floridablanca" },
    new City { StateId = santander.Id, Name = "Gir�n" },
                new City { StateId = santander.Id, Name = "Piedecuesta" },
      new City { StateId = santander.Id, Name = "Barrancabermeja" }
            });
        }

        // Bol�var
      var bolivar = await context.States.FirstOrDefaultAsync(s => s.Code == "BOL");
      if (bolivar != null)
        {
        cities.AddRange(new[]
  {
  new City { StateId = bolivar.Id, Name = "Cartagena" },
     new City { StateId = bolivar.Id, Name = "Magangu�" },
     new City { StateId = bolivar.Id, Name = "Turbaco" },
    new City { StateId = bolivar.Id, Name = "Arjona" }
    });
        }

        // Caldas
        var caldas = await context.States.FirstOrDefaultAsync(s => s.Code == "CAL");
    if (caldas != null)
        {
            cities.AddRange(new[]
            {
          new City { StateId = caldas.Id, Name = "Manizales" },
          new City { StateId = caldas.Id, Name = "Villamar�a" },
new City { StateId = caldas.Id, Name = "Chinchin�" },
         new City { StateId = caldas.Id, Name = "La Dorada" }
            });
        }

        // Risaralda
        var risaralda = await context.States.FirstOrDefaultAsync(s => s.Code == "RIS");
        if (risaralda != null)
        {
        cities.AddRange(new[]
       {
        new City { StateId = risaralda.Id, Name = "Pereira" },
                new City { StateId = risaralda.Id, Name = "Dosquebradas" },
          new City { StateId = risaralda.Id, Name = "La Virginia" },
      new City { StateId = risaralda.Id, Name = "Santa Rosa de Cabal" }
            });
        }

        // Quind�o
        var quindio = await context.States.FirstOrDefaultAsync(s => s.Code == "QUI");
        if (quindio != null)
        {
            cities.AddRange(new[]
            {
              new City { StateId = quindio.Id, Name = "Armenia" },
        new City { StateId = quindio.Id, Name = "Calarc�" },
            new City { StateId = quindio.Id, Name = "La Tebaida" },
new City { StateId = quindio.Id, Name = "Montenegro" }
            });
        }

        // Tolima
        var tolima = await context.States.FirstOrDefaultAsync(s => s.Code == "TOL");
        if (tolima != null)
        {
            cities.AddRange(new[]
        {
       new City { StateId = tolima.Id, Name = "Ibagu�" },
  new City { StateId = tolima.Id, Name = "Espinal" },
        new City { StateId = tolima.Id, Name = "Melgar" },
  new City { StateId = tolima.Id, Name = "Honda" }
         });
        }

        // Huila
        var huila = await context.States.FirstOrDefaultAsync(s => s.Code == "HUI");
        if (huila != null)
        {
  cities.AddRange(new[]
            {
  new City { StateId = huila.Id, Name = "Neiva" },
                new City { StateId = huila.Id, Name = "Pitalito" },
       new City { StateId = huila.Id, Name = "Garz�n" },
    new City { StateId = huila.Id, Name = "La Plata" }
    });
        }

        await context.Cities.AddRangeAsync(cities);
  await context.SaveChangesAsync();
    }
}

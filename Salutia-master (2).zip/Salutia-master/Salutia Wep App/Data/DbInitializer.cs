using Microsoft.AspNetCore.Identity;
using Salutia_Wep_App.Data;

namespace Salutia_Wep_App.Data;

/// <summary>
/// Clase para inicializar la base de datos con datos necesarios (roles, SuperAdmin, etc.)
/// </summary>
public static class DbInitializer
{
    /// <summary>
    /// Inicializa roles y crea el SuperAdmin predeterminado
    /// </summary>
    public static async Task InitializeAsync(
        UserManager<ApplicationUser> userManager,
        RoleManager<IdentityRole> roleManager,
        ILogger logger)
    {
        try
        {
            logger.LogInformation("Iniciando inicializaci�n de base de datos...");

            // Crear roles del sistema
            await CreateRolesAsync(roleManager, logger);

            // Crear SuperAdmin
            await CreateSuperAdminAsync(userManager, logger);

            logger.LogInformation("Inicializaci�n de base de datos completada exitosamente");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error durante la inicializaci�n de la base de datos");
            throw;
        }
    }

    /// <summary>
    /// Crea todos los roles necesarios en el sistema
    /// </summary>
    private static async Task CreateRolesAsync(RoleManager<IdentityRole> roleManager, ILogger logger)
    {
        logger.LogInformation("Verificando roles del sistema...");

        string[] roles = 
        {
            "SuperAdmin",
            "EntityAdmin",
            "Doctor",
            "Psychologist",
            "Patient",
            "IndependentUser"
        };

        foreach (var roleName in roles)
        {
            if (!await roleManager.RoleExistsAsync(roleName))
            {
                var result = await roleManager.CreateAsync(new IdentityRole(roleName));
                
                if (result.Succeeded)
                {
                    logger.LogInformation("? Rol '{RoleName}' creado", roleName);
                }
                else
                {
                    logger.LogWarning("? Error al crear rol '{RoleName}': {Errors}", 
                        roleName, 
                        string.Join(", ", result.Errors.Select(e => e.Description)));
                }
            }
            else
            {
                logger.LogInformation("? Rol '{RoleName}' ya existe", roleName);
            }
        }
    }

    /// <summary>
    /// Crea el usuario SuperAdmin predeterminado
    /// </summary>
    private static async Task CreateSuperAdminAsync(UserManager<ApplicationUser> userManager, ILogger logger)
    {
        logger.LogInformation("Verificando SuperAdmin...");

        const string superAdminEmail = "elpeco1@msn.com";
        const string superAdminPassword = "Admin.123";

        var existingUser = await userManager.FindByEmailAsync(superAdminEmail);

        if (existingUser == null)
        {
            logger.LogInformation("Creando SuperAdmin: {Email}", superAdminEmail);

            var superAdmin = new ApplicationUser
            {
                UserName = superAdminEmail,
                Email = superAdminEmail,
                EmailConfirmed = true, // SuperAdmin tiene email confirmado autom�ticamente
                UserType = UserType.SuperAdmin,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };

            var createResult = await userManager.CreateAsync(superAdmin, superAdminPassword);

            if (createResult.Succeeded)
            {
                logger.LogInformation("? Usuario SuperAdmin creado exitosamente");

                // Asignar rol SuperAdmin
                var roleResult = await userManager.AddToRoleAsync(superAdmin, "SuperAdmin");

                if (roleResult.Succeeded)
                {
                    logger.LogInformation("? Rol 'SuperAdmin' asignado al usuario {Email}", superAdminEmail);
                    logger.LogInformation("================================================");
                    logger.LogInformation("CREDENCIALES SUPERADMIN:");
                    logger.LogInformation("Email: {Email}", superAdminEmail);
                    logger.LogInformation("Contrase�a: {Password}", superAdminPassword);
                    logger.LogInformation("================================================");
                }
                else
                {
                    logger.LogError("? Error al asignar rol SuperAdmin: {Errors}", 
                        string.Join(", ", roleResult.Errors.Select(e => e.Description)));
                }
            }
            else
            {
                logger.LogError("? Error al crear SuperAdmin: {Errors}", 
                    string.Join(", ", createResult.Errors.Select(e => e.Description)));
            }
        }
        else
        {
            logger.LogInformation("? SuperAdmin ya existe: {Email}", superAdminEmail);

            // Verificar que tiene el rol SuperAdmin
            var hasRole = await userManager.IsInRoleAsync(existingUser, "SuperAdmin");
            
            if (!hasRole)
            {
                logger.LogWarning("SuperAdmin existe pero no tiene el rol asignado. Asignando rol...");
                var roleResult = await userManager.AddToRoleAsync(existingUser, "SuperAdmin");
                
                if (roleResult.Succeeded)
                {
                    logger.LogInformation("? Rol 'SuperAdmin' asignado");
                }
            }
            else
            {
                logger.LogInformation("? SuperAdmin tiene el rol asignado correctamente");
            }
        }
    }

    /// <summary>
    /// M�todo alternativo para crear un SuperAdmin con datos personalizados
    /// </summary>
    public static async Task CreateCustomSuperAdminAsync(
        UserManager<ApplicationUser> userManager,
        string email,
        string password,
        ILogger logger)
    {
        logger.LogInformation("Creando SuperAdmin personalizado: {Email}", email);

        var existingUser = await userManager.FindByEmailAsync(email);

        if (existingUser != null)
        {
            logger.LogWarning("El usuario {Email} ya existe", email);
            return;
        }

        var superAdmin = new ApplicationUser
        {
            UserName = email,
            Email = email,
            EmailConfirmed = true,
            UserType = UserType.SuperAdmin,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };

        var createResult = await userManager.CreateAsync(superAdmin, password);

        if (createResult.Succeeded)
        {
            var roleResult = await userManager.AddToRoleAsync(superAdmin, "SuperAdmin");

            if (roleResult.Succeeded)
            {
                logger.LogInformation("? SuperAdmin personalizado creado: {Email}", email);
            }
            else
            {
                logger.LogError("? Error al asignar rol: {Errors}", 
                    string.Join(", ", roleResult.Errors.Select(e => e.Description)));
            }
        }
        else
        {
            logger.LogError("? Error al crear usuario: {Errors}", 
                string.Join(", ", createResult.Errors.Select(e => e.Description)));
        }
    }
}

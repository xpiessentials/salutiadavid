using Microsoft.AspNetCore.Identity;
using Salutia_Wep_App.Models.Patient;

namespace Salutia_Wep_App.Data;

/// <summary>
/// Usuario base del sistema con informaci�n com�n
/// </summary>
public class ApplicationUser : IdentityUser
{
    /// <summary>
    /// Tipo de usuario: SuperAdmin, EntityAdmin, Doctor, Psychologist, Independent, Patient
    /// </summary>
    public UserType UserType { get; set; }
    
    /// <summary>
    /// Fecha de creaci�n del usuario
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    
    /// <summary>
    /// Fecha de �ltima modificaci�n
    /// </summary>
    public DateTime? UpdatedAt { get; set; }
  
    /// <summary>
    /// Usuario est� activo/habilitado
    /// </summary>
    public bool IsActive { get; set; } = true;
    
    // Navegaci�n polim�rfica
    /// <summary>
    /// Perfil de usuario independiente (si aplica)
    /// </summary>
    public IndependentUserProfile? IndependentProfile { get; set; }
    
    /// <summary>
    /// Perfil de usuario entidad (si aplica)
    /// </summary>
  public EntityUserProfile? EntityProfile { get; set; }
    
    /// <summary>
    /// Perfil de profesional de entidad (m�dico/psic�logo)
    /// </summary>
    public EntityProfessionalProfile? EntityProfessionalProfile { get; set; }
    
    /// <summary>
    /// Perfil de paciente
    /// </summary>
    public PatientProfile? PatientProfile { get; set; }
}

/// <summary>
/// Tipos de usuario en el sistema
/// </summary>
public enum UserType
{
    /// <summary>
    /// Superadministrador con acceso total
  /// </summary>
    SuperAdmin = 0,
    
  /// <summary>
    /// Administrador de Entidad (empresa, organizaci�n)
    /// </summary>
    EntityAdmin = 1,
    
    /// <summary>
 /// Usuario independiente (persona natural)
    /// </summary>
    Independent = 2,
    
    /// <summary>
    /// M�dico/Especialista de una entidad
    /// </summary>
    Doctor = 3,
    
    /// <summary>
    /// Psic�logo/Terapeuta de una entidad
    /// </summary>
    Psychologist = 4,
    
    /// <summary>
    /// Paciente de un m�dico o psic�logo
    /// </summary>
    Patient = 5
}

/// <summary>
/// Tipos de documento de identidad
/// </summary>
public enum DocumentType
{
    CedulaCiudadania = 1,
    CedulaExtranjeria = 2,
    Pasaporte = 3,
    NIT = 4,
    RUT = 5
}

/// <summary>
/// Perfil de usuario independiente (persona natural)
/// </summary>
public class IndependentUserProfile
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del usuario de Identity
    /// </summary>
 public string ApplicationUserId { get; set; } = string.Empty;
public ApplicationUser ApplicationUser { get; set; } = null!;
    
    /// <summary>
    /// Nombre completo del usuario
    /// </summary>
    public string FullName { get; set; } = string.Empty;
    
    /// <summary>
    /// Tipo de documento
    /// </summary>
    public DocumentType DocumentType { get; set; }
    
    /// <summary>
    /// N�mero de documento
    /// </summary>
    public string DocumentNumber { get; set; } = string.Empty;
 
    /// <summary>
    /// Tel�fono de contacto
    /// </summary>
    public string Phone { get; set; } = string.Empty;
    
    /// <summary>
    /// Fecha de nacimiento (opcional)
    /// </summary>
    public DateTime? DateOfBirth { get; set; }
 
 // Campos geogr�ficos
    /// <summary>
    /// ID del pa�s
    /// </summary>
    public int? CountryId { get; set; }
    public Country? Country { get; set; }
    
    /// <summary>
    /// ID del estado/departamento
    /// </summary>
    public int? StateId { get; set; }
    public State? State { get; set; }
    
    /// <summary>
    /// ID de la ciudad
    /// </summary>
    public int? CityId { get; set; }
public City? City { get; set; }
    
    /// <summary>
    /// Direcci�n completa
    /// </summary>
    public string? Address { get; set; }
}

/// <summary>
/// Perfil de usuario administrador de entidad
/// Un usuario que administra una entidad espec�fica
/// </summary>
public class EntityUserProfile
{
    public int Id { get; set; }
  
    /// <summary>
    /// ID del usuario de Identity
    /// </summary>
    public string ApplicationUserId { get; set; } = string.Empty;
    public ApplicationUser ApplicationUser { get; set; } = null!;
    
    /// <summary>
    /// ID de la entidad que administra
    /// </summary>
    public int EntityId { get; set; }
    public Entity Entity { get; set; } = null!;
    
    /// <summary>
    /// Nombre completo del administrador
    /// </summary>
    public string FullName { get; set; } = string.Empty;
    
    /// <summary>
    /// Cargo o posici�n del administrador en la entidad
    /// </summary>
    public string? Position { get; set; }
    
    /// <summary>
    /// Tel�fono directo del administrador
    /// </summary>
    public string? DirectPhone { get; set; }
    
    /// <summary>
    /// Fecha de vinculaci�n como administrador
    /// </summary>
    public DateTime JoinedAt { get; set; } = DateTime.UtcNow;
    
    /// <summary>
    /// Indica si el administrador est� activo
    /// </summary>
    public bool IsActive { get; set; } = true;
}
    
/// <summary>
/// Perfil de profesional de una entidad (M�dico/Especialista o Psic�logo/Terapeuta)
/// </summary>
public class EntityProfessionalProfile
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del usuario de Identity
    /// </summary>
    public string ApplicationUserId { get; set; } = string.Empty;
  public ApplicationUser ApplicationUser { get; set; } = null!;
    
    /// <summary>
  /// ID de la entidad a la que pertenece
 /// </summary>
    public int EntityId { get; set; }
    public Entity Entity { get; set; } = null!;
  
    /// <summary>
    /// Nombre completo del profesional
    /// </summary>
    public string FullName { get; set; } = string.Empty;
    
    /// <summary>
    /// Tipo de documento
    /// </summary>
    public DocumentType DocumentType { get; set; }
    
    /// <summary>
    /// N�mero de documento
    /// </summary>
    public string DocumentNumber { get; set; } = string.Empty;
    
    /// <summary>
    /// Tel�fono del profesional
    /// </summary>
    public string? Phone { get; set; }
    
    /// <summary>
    /// N�mero de licencia profesional
    /// </summary>
    public string? ProfessionalLicense { get; set; }
    
    /// <summary>
  /// Especialidad m�dica o psicol�gica
    /// </summary>
    public string? Specialty { get; set; }
    
    // Campos geogr�ficos
    /// <summary>
    /// ID del pa�s
    /// </summary>
    public int? CountryId { get; set; }
    public Country? Country { get; set; }
    
    /// <summary>
    /// ID del estado/departamento
    /// </summary>
    public int? StateId { get; set; }
    public State? State { get; set; }
    
    /// <summary>
/// ID de la ciudad
    /// </summary>
  public int? CityId { get; set; }
    public City? City { get; set; }
    
    /// <summary>
 /// Direcci�n del profesional
    /// </summary>
    public string? Address { get; set; }
    
    /// <summary>
    /// Fecha de vinculaci�n a la entidad
    /// </summary>
    public DateTime JoinedAt { get; set; } = DateTime.UtcNow;
    
    /// <summary>
    /// Profesional est� activo en la entidad
    /// </summary>
    public bool IsActive { get; set; } = true;

    /// <summary>
    /// Pacientes asignados a este profesional
    /// </summary>
    public ICollection<PatientProfile> Patients { get; set; } = new List<PatientProfile>();
}

/// <summary>
/// Perfil de paciente creado por un m�dico o psic�logo
/// </summary>
public class PatientProfile
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del usuario de Identity
    /// </summary>
    public string ApplicationUserId { get; set; } = string.Empty;
    public ApplicationUser ApplicationUser { get; set; } = null!;
    
    /// <summary>
    /// ID de la entidad a la que pertenece el paciente
    /// </summary>
    public int? EntityId { get; set; }
    public Entity? Entity { get; set; }
    
    /// <summary>
    /// ID del profesional que cre�/atiende el paciente
    /// </summary>
    public int ProfessionalId { get; set; }
    public EntityProfessionalProfile Professional { get; set; } = null!;
    
    /// <summary>
    /// Indica si es un paciente de entidad (registrado por profesional/admin)
    /// </summary>
    public bool IsEntityPatient { get; set; } = false;
    
    /// <summary>
    /// Indica si el paciente ha completado su perfil en el primer inicio de sesi�n
    /// </summary>
    public bool ProfileCompleted { get; set; } = false;
    
    /// <summary>
    /// Nombre completo del paciente
    /// </summary>
    public string? FullName { get; set; }
    
    /// <summary>
    /// Tipo de documento
    /// </summary>
    public DocumentType DocumentType { get; set; }
    
    /// <summary>
    /// N�mero de documento
    /// </summary>
    public string DocumentNumber { get; set; } = string.Empty;
 
    /// <summary>
    /// Tel�fono del paciente
    /// </summary>
    public string? Phone { get; set; }
    
    /// <summary>
    /// Fecha de nacimiento
    /// </summary>
    public DateTime? DateOfBirth { get; set; }
    
    /// <summary>
    /// G�nero
    /// </summary>
    public string? Gender { get; set; }
    
    // Campos geogr�ficos
    /// <summary>
    /// ID del pa�s
    /// </summary>
    public int? CountryId { get; set; }
    public Country? Country { get; set; }
    
    /// <summary>
    /// ID del estado/departamento
    /// </summary>
    public int? StateId { get; set; }
    public State? State { get; set; }
    
    /// <summary>
    /// ID de la ciudad
    /// </summary>
    public int? CityId { get; set; }
    public City? City { get; set; }
    
    /// <summary>
    /// Direcci�n del paciente
    /// </summary>
    public string? Address { get; set; }
    
    // ========== NUEVOS CAMPOS ADICIONALES ==========
    
    /// <summary>
    /// ID de la ocupaci�n del paciente
    /// </summary>
    public int? OccupationId { get; set; }
    public Occupation? Occupation { get; set; }
    
    /// <summary>
    /// ID del estado civil del paciente
    /// </summary>
    public int? MaritalStatusId { get; set; }
    public MaritalStatus? MaritalStatus { get; set; }
    
    /// <summary>
    /// ID del nivel educativo del paciente
    /// </summary>
    public int? EducationLevelId { get; set; }
    public EducationLevel? EducationLevel { get; set; }
    
    /// <summary>
    /// Historial m�dico del paciente
    /// </summary>
    public ICollection<PatientMedicalHistory> MedicalHistories { get; set; } = new List<PatientMedicalHistory>();
    
    /// <summary>
    /// Medicaci�n actual del paciente
    /// </summary>
    public ICollection<PatientMedication> CurrentMedications { get; set; } = new List<PatientMedication>();
    
    /// <summary>
    /// Alergias del paciente
    /// </summary>
    public ICollection<PatientAllergy> Allergies { get; set; } = new List<PatientAllergy>();
    
    /// <summary>
    /// Contactos de emergencia del paciente
    /// </summary>
    public ICollection<PatientEmergencyContact> EmergencyContacts { get; set; } = new List<PatientEmergencyContact>();
    
    // ================================================
    
    /// <summary>
    /// Fecha de registro del paciente
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
  
    /// <summary>
    /// Paciente est� activo
    /// </summary>
    public bool IsActive { get; set; } = true;
    
    /// <summary>
    /// Notas m�dicas o psicol�gicas
    /// </summary>
    public string? Notes { get; set; }
}


﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Salutia_Wep_App.Migrations
{
    /// <inheritdoc />
    public partial class AddConsentInformedSystem : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ConsentDocuments",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PsychosomaticTestId = table.Column<int>(type: "int", nullable: false),
                    PatientUserId = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false),
                    DocumentName = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                    DocumentType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    DocumentUrl = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    DocumentPath = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    FileSizeBytes = table.Column<long>(type: "bigint", nullable: false),
                    FileHash = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    GeneratedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    DownloadedByUserId = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: true),
                    DownloadedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DownloadCount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ConsentDocuments", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ConsentTemplateHistories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ConsentTemplateId = table.Column<int>(type: "int", nullable: false),
                    PreviousVersion = table.Column<int>(type: "int", nullable: false),
                    PreviousContentHtml = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ModifiedByUserId = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false),
                    ChangeReason = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    ChangedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ConsentTemplateHistories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ConsentTemplates",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                    Code = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ContentHtml = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Version = table.Column<int>(type: "int", nullable: false),
                    DisplayOrder = table.Column<int>(type: "int", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    EntityId = table.Column<int>(type: "int", nullable: true),
                    ModifiedByUserId = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    IsRequired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ConsentTemplates", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PatientConsents",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PsychosomaticTestId = table.Column<int>(type: "int", nullable: false),
                    ConsentTemplateId = table.Column<int>(type: "int", nullable: false),
                    PatientUserId = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false),
                    ConsentVersion = table.Column<int>(type: "int", nullable: false),
                    ContentSnapshot = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IpAddress = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    UserAgent = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    IsAccepted = table.Column<bool>(type: "bit", nullable: false),
                    SignedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    PdfUrl = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    PdfPath = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PatientConsents", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PatientConsents_ConsentTemplates_ConsentTemplateId",
                        column: x => x.ConsentTemplateId,
                        principalTable: "ConsentTemplates",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ConsentSignatures",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PatientConsentId = table.Column<int>(type: "int", nullable: false),
                    SignatureDataBase64 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SignatureType = table.Column<int>(type: "int", nullable: false),
                    SignerFullName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    SignerDocumentNumber = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    SignedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ConsentSignatures", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ConsentSignatures_PatientConsents_PatientConsentId",
                        column: x => x.PatientConsentId,
                        principalTable: "PatientConsents",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ConsentDocuments_PatientUserId",
                table: "ConsentDocuments",
                column: "PatientUserId");

            migrationBuilder.CreateIndex(
                name: "IX_ConsentDocuments_PsychosomaticTestId",
                table: "ConsentDocuments",
                column: "PsychosomaticTestId");

            migrationBuilder.CreateIndex(
                name: "IX_ConsentSignatures_PatientConsentId",
                table: "ConsentSignatures",
                column: "PatientConsentId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ConsentTemplateHistories_ConsentTemplateId",
                table: "ConsentTemplateHistories",
                column: "ConsentTemplateId");

            migrationBuilder.CreateIndex(
                name: "IX_ConsentTemplates_Code",
                table: "ConsentTemplates",
                column: "Code");

            migrationBuilder.CreateIndex(
                name: "IX_ConsentTemplates_EntityId_Code",
                table: "ConsentTemplates",
                columns: new[] { "EntityId", "Code" });

            migrationBuilder.CreateIndex(
                name: "IX_PatientConsents_ConsentTemplateId",
                table: "PatientConsents",
                column: "ConsentTemplateId");

            migrationBuilder.CreateIndex(
                name: "IX_PatientConsents_PatientUserId",
                table: "PatientConsents",
                column: "PatientUserId");

            migrationBuilder.CreateIndex(
                name: "IX_PatientConsents_PsychosomaticTestId_ConsentTemplateId",
                table: "PatientConsents",
                columns: new[] { "PsychosomaticTestId", "ConsentTemplateId" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ConsentDocuments");

            migrationBuilder.DropTable(
                name: "ConsentSignatures");

            migrationBuilder.DropTable(
                name: "ConsentTemplateHistories");

            migrationBuilder.DropTable(
                name: "PatientConsents");

            migrationBuilder.DropTable(
                name: "ConsentTemplates");
        }
    }
}

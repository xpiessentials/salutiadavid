-- =============================================
-- Script de Actualizaci�n - Test Psicosom�tico
-- Agrega la tabla TestAges y actualiza TestMatrices
-- ?? Este script MANTIENE los datos existentes
-- =============================================

USE Salutia;
GO

PRINT '=============================================';
PRINT 'Actualizaci�n del Test Psicosom�tico';
PRINT '=============================================';
PRINT '';

-- =============================================
-- 1. Verificar si TestAges ya existe
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TestAges')
BEGIN
    PRINT '1?? Creando tabla TestAges...';
    
    CREATE TABLE TestAges (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        PsychosomaticTestId INT NOT NULL,
        WordNumber INT NOT NULL,
        Age NVARCHAR(50) NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
        CONSTRAINT FK_TestAges_PsychosomaticTests 
            FOREIGN KEY (PsychosomaticTestId) REFERENCES PsychosomaticTests(Id) ON DELETE CASCADE,
        CONSTRAINT CK_TestAges_WordNumber CHECK (WordNumber BETWEEN 1 AND 10)
    );
    
    CREATE UNIQUE NONCLUSTERED INDEX IX_TestAges_TestId_WordNumber 
        ON TestAges(PsychosomaticTestId, WordNumber);
    
    PRINT '   ? Tabla TestAges creada exitosamente';
END
ELSE
BEGIN
    PRINT '1?? Tabla TestAges ya existe';
END
GO

-- =============================================
-- 2. Verificar y agregar columna Age a TestMatrices
-- =============================================
IF NOT EXISTS (
    SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'TestMatrices' AND COLUMN_NAME = 'Age'
)
BEGIN
    PRINT '2?? Agregando columna Age a TestMatrices...';
    
    ALTER TABLE TestMatrices
    ADD Age NVARCHAR(50) NOT NULL DEFAULT '';
    
    PRINT '   ? Columna Age agregada a TestMatrices';
END
ELSE
BEGIN
    PRINT '2?? Columna Age ya existe en TestMatrices';
END
GO

-- =============================================
-- 3. Verificar estructura
-- =============================================
PRINT '';
PRINT '3?? Verificando estructura...';
PRINT '';

-- Verificar TestAges
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'TestAges')
BEGIN
    DECLARE @TestAgesColumns INT;
    SELECT @TestAgesColumns = COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'TestAges';
    
    PRINT '   ? TestAges: ' + CAST(@TestAgesColumns AS VARCHAR) + ' columnas';
END

-- Verificar TestMatrices
IF EXISTS (
    SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'TestMatrices' AND COLUMN_NAME = 'Age'
)
BEGIN
    PRINT '   ? TestMatrices incluye columna Age';
END

GO

-- =============================================
-- 4. Resumen de tablas del test
-- =============================================
PRINT '';
PRINT '4?? Resumen de tablas del Test Psicosom�tico:';
PRINT '';

SELECT 
    TABLE_NAME AS [Tabla],
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE COLUMNS.TABLE_NAME = TABLES.TABLE_NAME) AS [Columnas]
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_NAME IN (
    'PsychosomaticTests', 
    'TestWords', 
    'TestPhrases', 
    'TestEmotions', 
    'TestDiscomfortLevels', 
    'TestAges',
    'TestBodyParts', 
    'TestAssociatedPersons', 
    'TestMatrices'
)
ORDER BY TABLE_NAME;
GO

-- =============================================
-- 5. Conteo de tests existentes
-- =============================================
PRINT '';
PRINT '5?? Tests existentes en la base de datos:';
PRINT '';

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'PsychosomaticTests')
BEGIN
    DECLARE @TotalTests INT;
    DECLARE @CompletedTests INT;
    DECLARE @InProgressTests INT;
    
    SELECT @TotalTests = COUNT(*) FROM PsychosomaticTests;
    SELECT @CompletedTests = COUNT(*) FROM PsychosomaticTests WHERE IsCompleted = 1;
    SELECT @InProgressTests = COUNT(*) FROM PsychosomaticTests WHERE IsCompleted = 0;
    
    PRINT '   Total de tests: ' + CAST(@TotalTests AS VARCHAR);
    PRINT '   Completados: ' + CAST(@CompletedTests AS VARCHAR);
    PRINT '   En progreso: ' + CAST(@InProgressTests AS VARCHAR);
    
    -- Advertencia sobre tests completados sin datos de edad
    IF @CompletedTests > 0
    BEGIN
        PRINT '';
        PRINT '   ?? NOTA: Los tests completados antes de esta actualizaci�n';
        PRINT '   no tienen datos de edad. Solo los nuevos tests incluir�n';
        PRINT '   esta informaci�n.';
    END
END
ELSE
BEGIN
    PRINT '   No hay tests en la base de datos';
END
GO

-- =============================================
-- FINALIZACI�N
-- =============================================
PRINT '';
PRINT '=============================================';
PRINT '? ACTUALIZACI�N COMPLETADA';
PRINT '=============================================';
PRINT '';
PRINT 'Cambios aplicados:';
PRINT '  1. Tabla TestAges creada (almacena las edades)';
PRINT '  2. Columna Age agregada a TestMatrices';
PRINT '  3. Estructura del test actualizada a 7 preguntas';
PRINT '';
PRINT 'Total de tablas: 9';
PRINT '  - PsychosomaticTests';
PRINT '  - TestWords';
PRINT '  - TestPhrases';
PRINT '  - TestEmotions';
PRINT '  - TestDiscomfortLevels';
PRINT '  - TestAges                 ? NUEVA';
PRINT '  - TestBodyParts';
PRINT '  - TestAssociatedPersons';
PRINT '  - TestMatrices             ? ACTUALIZADA';
PRINT '';
PRINT '?? Siguiente paso:';
PRINT '   dotnet run --project ".\Salutia Wep App\Salutia Wep App.csproj"';
PRINT '';
PRINT '=============================================';
GO

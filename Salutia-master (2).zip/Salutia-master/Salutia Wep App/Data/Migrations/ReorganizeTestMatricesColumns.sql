-- =============================================
-- Reorganizar columnas de TestMatrices
-- Coloca Age en su posici�n correcta
-- =============================================

USE Salutia;
GO

PRINT '=============================================';
PRINT 'Reorganizando columnas de TestMatrices';
PRINT '=============================================';
PRINT '';

-- =============================================
-- 1. Crear tabla temporal con el orden correcto
-- =============================================
PRINT '1?? Creando tabla temporal con orden correcto...';

CREATE TABLE TestMatrices_Temp (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    PsychosomaticTestId INT NOT NULL,
    WordNumber INT NOT NULL,
    Word NVARCHAR(100) NOT NULL,
    Phrase NVARCHAR(500) NOT NULL,
    Emotion NVARCHAR(100) NOT NULL,
    DiscomfortLevel INT NOT NULL,
    Age NVARCHAR(50) NOT NULL,  -- ? Posici�n correcta
    BodyPart NVARCHAR(100) NOT NULL,
    AssociatedPerson NVARCHAR(200) NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);

PRINT '   ? Tabla temporal creada';
GO

-- =============================================
-- 2. Copiar datos a la tabla temporal
-- =============================================
PRINT '2?? Copiando datos a tabla temporal...';

SET IDENTITY_INSERT TestMatrices_Temp ON;

INSERT INTO TestMatrices_Temp (
    Id, 
    PsychosomaticTestId, 
    WordNumber, 
    Word, 
    Phrase, 
    Emotion, 
    DiscomfortLevel, 
    Age, 
    BodyPart, 
    AssociatedPerson, 
    CreatedAt
)
SELECT 
    Id, 
    PsychosomaticTestId, 
    WordNumber, 
    Word, 
    Phrase, 
    Emotion, 
    DiscomfortLevel, 
    ISNULL(Age, ''),  -- Asegurar que no hay NULL
    BodyPart, 
    AssociatedPerson, 
    CreatedAt
FROM TestMatrices;

SET IDENTITY_INSERT TestMatrices_Temp OFF;

DECLARE @RowsCopied INT = @@ROWCOUNT;
PRINT '   ? ' + CAST(@RowsCopied AS VARCHAR) + ' filas copiadas';
GO

-- =============================================
-- 3. Eliminar tabla original
-- =============================================
PRINT '3?? Eliminando tabla original...';

DROP TABLE TestMatrices;

PRINT '   ? Tabla original eliminada';
GO

-- =============================================
-- 4. Renombrar tabla temporal
-- =============================================
PRINT '4?? Renombrando tabla temporal...';

EXEC sp_rename 'TestMatrices_Temp', 'TestMatrices';

PRINT '   ? Tabla renombrada exitosamente';
GO

-- =============================================
-- 5. Recrear �ndices y restricciones
-- =============================================
PRINT '5?? Recreando �ndices y restricciones...';

-- �ndice �nico compuesto
CREATE UNIQUE NONCLUSTERED INDEX IX_TestMatrices_TestId_WordNumber 
    ON TestMatrices(PsychosomaticTestId, WordNumber);

-- Foreign key
ALTER TABLE TestMatrices
ADD CONSTRAINT FK_TestMatrices_PsychosomaticTests 
    FOREIGN KEY (PsychosomaticTestId) REFERENCES PsychosomaticTests(Id) ON DELETE CASCADE;

PRINT '   ? �ndices y restricciones recreados';
GO

-- =============================================
-- 6. Verificar estructura final
-- =============================================
PRINT '';
PRINT '6?? Verificando estructura final...';
PRINT '';

SELECT 
    ORDINAL_POSITION AS [Pos],
    COLUMN_NAME AS [Columna],
    DATA_TYPE AS [Tipo],
    CHARACTER_MAXIMUM_LENGTH AS [Tama�o],
    IS_NULLABLE AS [NULL?]
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'TestMatrices'
ORDER BY ORDINAL_POSITION;
GO

-- =============================================
-- FINALIZACI�N
-- =============================================
PRINT '';
PRINT '=============================================';
PRINT '? REORGANIZACI�N COMPLETADA';
PRINT '=============================================';
PRINT '';
PRINT 'La columna Age ahora est� en la posici�n correcta:';
PRINT '  7. DiscomfortLevel';
PRINT '  8. Age                  ? REUBICADA';
PRINT '  9. BodyPart';
PRINT ' 10. AssociatedPerson';
PRINT '';
PRINT '?? Puede ejecutar la aplicaci�n:';
PRINT '   dotnet run --project ".\Salutia Wep App\Salutia Wep App.csproj"';
PRINT '';
PRINT '=============================================';
GO

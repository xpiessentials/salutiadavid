-- =============================================
-- Script: Actualizar Roles de Usuario
-- Descripci�n: Crea roles nuevos y actualiza usuarios existentes
-- =============================================

BEGIN TRANSACTION;

PRINT 'Actualizando roles de usuario...';
PRINT '';

-- =============================================
-- PASO 1: Crear nuevos roles
-- =============================================
PRINT 'Creando roles...';

IF NOT EXISTS (SELECT 1 FROM AspNetRoles WHERE Name = 'EntityAdmin')
BEGIN
    INSERT INTO AspNetRoles (Id, Name, NormalizedName, ConcurrencyStamp) 
    VALUES (NEWID(), 'EntityAdmin', 'ENTITYADMIN', NEWID());
    PRINT '  ? Rol EntityAdmin creado';
END
ELSE
BEGIN
    PRINT '  - Rol EntityAdmin ya existe';
END

IF NOT EXISTS (SELECT 1 FROM AspNetRoles WHERE Name = 'Doctor')
BEGIN
    INSERT INTO AspNetRoles (Id, Name, NormalizedName, ConcurrencyStamp) 
    VALUES (NEWID(), 'Doctor', 'DOCTOR', NEWID());
    PRINT '  ? Rol Doctor creado';
END
ELSE
BEGIN
    PRINT '  - Rol Doctor ya existe';
END

IF NOT EXISTS (SELECT 1 FROM AspNetRoles WHERE Name = 'Psychologist')
BEGIN
    INSERT INTO AspNetRoles (Id, Name, NormalizedName, ConcurrencyStamp) 
    VALUES (NEWID(), 'Psychologist', 'PSYCHOLOGIST', NEWID());
  PRINT '  ? Rol Psychologist creado';
END
ELSE
BEGIN
    PRINT '  - Rol Psychologist ya existe';
END

IF NOT EXISTS (SELECT 1 FROM AspNetRoles WHERE Name = 'Patient')
BEGIN
    INSERT INTO AspNetRoles (Id, Name, NormalizedName, ConcurrencyStamp) 
    VALUES (NEWID(), 'Patient', 'PATIENT', NEWID());
    PRINT '  ? Rol Patient creado';
END
ELSE
BEGIN
    PRINT '  - Rol Patient ya existe';
END

PRINT '';

-- =============================================
-- PASO 2: Mostrar usuarios actuales y sus roles
-- =============================================
PRINT 'Usuarios actuales:';
PRINT '';

SELECT 
    u.Id,
    u.Email,
    u.UserType,
    CASE u.UserType
        WHEN 0 THEN 'SuperAdmin'
        WHEN 1 THEN 'EntityAdmin'
        WHEN 2 THEN 'Independent'
        WHEN 3 THEN 'Doctor'
     WHEN 4 THEN 'Psychologist'
        WHEN 5 THEN 'Patient'
     ELSE 'Unknown'
    END AS UserTypeName,
    r.Name AS CurrentRole
FROM AspNetUsers u
LEFT JOIN AspNetUserRoles ur ON u.Id = ur.UserId
LEFT JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE u.UserType IN (1, 2, 3, 4, 5) -- EntityAdmin, Independent, Doctor, Psychologist, Patient
ORDER BY u.UserType, u.Email;

PRINT '';

-- =============================================
-- PASO 3: Actualizar usuarios de Entity a EntityAdmin
-- =============================================
PRINT 'Actualizando usuarios con rol Entity a EntityAdmin...';

DECLARE @OldEntityRoleId nvarchar(450) = (SELECT Id FROM AspNetRoles WHERE Name = 'Entity');
DECLARE @EntityAdminRoleId nvarchar(450) = (SELECT Id FROM AspNetRoles WHERE Name = 'EntityAdmin');

IF @OldEntityRoleId IS NOT NULL
BEGIN
    -- Obtener usuarios con rol Entity
    DECLARE @UsersToUpdate TABLE (UserId nvarchar(450));
  
    INSERT INTO @UsersToUpdate (UserId)
    SELECT UserId 
    FROM AspNetUserRoles 
    WHERE RoleId = @OldEntityRoleId;
    
    DECLARE @UpdateCount int = (SELECT COUNT(*) FROM @UsersToUpdate);
  
    IF @UpdateCount > 0
    BEGIN
        -- Eliminar rol Entity
        DELETE FROM AspNetUserRoles 
   WHERE RoleId = @OldEntityRoleId;
        
        -- Agregar rol EntityAdmin
        INSERT INTO AspNetUserRoles (UserId, RoleId)
   SELECT UserId, @EntityAdminRoleId
 FROM @UsersToUpdate
        WHERE UserId NOT IN (
   SELECT UserId FROM AspNetUserRoles WHERE RoleId = @EntityAdminRoleId
        );
    
        PRINT '  ? ' + CAST(@UpdateCount AS nvarchar(10)) + ' usuarios actualizados de Entity a EntityAdmin';
    END
    ELSE
    BEGIN
   PRINT '  - No hay usuarios con rol Entity para actualizar';
 END
END
ELSE
BEGIN
    PRINT '  - No existe rol Entity antiguo';
END

PRINT '';

-- =============================================
-- PASO 4: Verificar usuarios sin rol
-- =============================================
PRINT 'Verificando usuarios sin rol asignado...';

DECLARE @UsersWithoutRole TABLE (
  UserId nvarchar(450),
    Email nvarchar(256),
    UserType int
);

INSERT INTO @UsersWithoutRole (UserId, Email, UserType)
SELECT u.Id, u.Email, u.UserType
FROM AspNetUsers u
LEFT JOIN AspNetUserRoles ur ON u.Id = ur.UserId
WHERE ur.UserId IS NULL
AND u.UserType IN (1, 2, 3, 4, 5);

DECLARE @UsersWithoutRoleCount int = (SELECT COUNT(*) FROM @UsersWithoutRole);

IF @UsersWithoutRoleCount > 0
BEGIN
 PRINT '  ! ADVERTENCIA: ' + CAST(@UsersWithoutRoleCount AS nvarchar(10)) + ' usuarios sin rol:';
    
    SELECT Email, 
           CASE UserType
     WHEN 1 THEN 'EntityAdmin'
               WHEN 2 THEN 'Independent'
        WHEN 3 THEN 'Doctor'
       WHEN 4 THEN 'Psychologist'
       WHEN 5 THEN 'Patient'
           END AS ExpectedRole
    FROM @UsersWithoutRole;
    
    -- Asignar roles autom�ticamente
    PRINT '';
    PRINT '  Asignando roles autom�ticamente...';
    
    -- EntityAdmin (UserType = 1)
    INSERT INTO AspNetUserRoles (UserId, RoleId)
    SELECT UserId, (SELECT Id FROM AspNetRoles WHERE Name = 'EntityAdmin')
    FROM @UsersWithoutRole
    WHERE UserType = 1;
    
    -- Independent (UserType = 2)
    INSERT INTO AspNetUserRoles (UserId, RoleId)
    SELECT UserId, (SELECT Id FROM AspNetRoles WHERE Name = 'Independent')
    FROM @UsersWithoutRole
    WHERE UserType = 2;
    
    -- Doctor (UserType = 3)
    INSERT INTO AspNetUserRoles (UserId, RoleId)
    SELECT UserId, (SELECT Id FROM AspNetRoles WHERE Name = 'Doctor')
    FROM @UsersWithoutRole
    WHERE UserType = 3;
    
    -- Psychologist (UserType = 4)
    INSERT INTO AspNetUserRoles (UserId, RoleId)
    SELECT UserId, (SELECT Id FROM AspNetRoles WHERE Name = 'Psychologist')
    FROM @UsersWithoutRole
    WHERE UserType = 4;
    
    -- Patient (UserType = 5)
    INSERT INTO AspNetUserRoles (UserId, RoleId)
 SELECT UserId, (SELECT Id FROM AspNetRoles WHERE Name = 'Patient')
    FROM @UsersWithoutRole
    WHERE UserType = 5;
    
    PRINT '  ? Roles asignados autom�ticamente';
END
ELSE
BEGIN
    PRINT '  ? Todos los usuarios tienen rol asignado';
END

PRINT '';

-- =============================================
-- PASO 5: Resultado final
-- =============================================
PRINT '==============================================';
PRINT '  Actualizaci�n de roles completada!';
PRINT '==============================================';
PRINT '';
PRINT 'Usuarios despu�s de la actualizaci�n:';
PRINT '';

SELECT 
u.Email,
    CASE u.UserType
        WHEN 0 THEN 'SuperAdmin'
        WHEN 1 THEN 'EntityAdmin'
      WHEN 2 THEN 'Independent'
     WHEN 3 THEN 'Doctor'
        WHEN 4 THEN 'Psychologist'
   WHEN 5 THEN 'Patient'
    END AS UserType,
    r.Name AS AssignedRole,
    CASE 
        WHEN u.IsActive = 1 THEN 'Activo'
   ELSE 'Inactivo'
    END AS Status
FROM AspNetUsers u
INNER JOIN AspNetUserRoles ur ON u.Id = ur.UserId
INNER JOIN AspNetRoles r ON ur.RoleId = r.Id
WHERE u.UserType IN (0, 1, 2, 3, 4, 5)
ORDER BY u.UserType, u.Email;

COMMIT TRANSACTION;

PRINT '';
PRINT 'Transacci�n confirmada. Roles actualizados.';
PRINT '';

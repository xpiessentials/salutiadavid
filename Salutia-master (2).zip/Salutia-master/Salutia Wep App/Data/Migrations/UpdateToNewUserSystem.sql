-- =============================================
-- Migraci�n: Actualizaci�n del Sistema de Usuarios
-- Descripci�n: Actualiza el sistema de usuarios para incluir:
--   - Tablas geogr�ficas (Countries, States, Cities)
--   - EntityProfessionalProfiles (reemplaza EntityMemberProfiles)
--   - PatientProfiles
--   - Campos geogr�ficos en EntityUserProfile
-- Autor: Sistema Salutia
-- Fecha: 2025-01-15
-- =============================================

BEGIN TRANSACTION;

PRINT 'Iniciando migraci�n del sistema de usuarios...';

-- =============================================
-- PASO 0: Verificar tablas base necesarias
-- =============================================
PRINT 'Verificando tablas base...';

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'AspNetUsers')
BEGIN
    PRINT '  ? ERROR: Tabla AspNetUsers no existe. Ejecuta primero la migraci�n de Identity.';
    ROLLBACK TRANSACTION;
    RETURN;
END

-- Crear EntityUserProfiles si no existe (tabla base para entidades)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'EntityUserProfiles')
BEGIN
    PRINT '  ! Creando tabla base EntityUserProfiles...';
    
    CREATE TABLE [EntityUserProfiles] (
   [Id] int NOT NULL IDENTITY(1,1),
    [ApplicationUserId] nvarchar(450) NOT NULL,
        [BusinessName] nvarchar(300) NOT NULL,
        [TaxId] nvarchar(20) NOT NULL,
        [VerificationDigit] nvarchar(1) NOT NULL,
        [Phone] nvarchar(20) NOT NULL,
 [Address] nvarchar(max) NULL,
        [Website] nvarchar(max) NULL,
        [LegalRepresentative] nvarchar(max) NULL,
        CONSTRAINT [PK_EntityUserProfiles] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_EntityUserProfiles_AspNetUsers_ApplicationUserId] 
   FOREIGN KEY ([ApplicationUserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
    );
    
    CREATE UNIQUE INDEX [IX_EntityUserProfiles_ApplicationUserId] 
        ON [EntityUserProfiles] ([ApplicationUserId]);
    CREATE UNIQUE INDEX [IX_EntityUserProfiles_TaxId] 
        ON [EntityUserProfiles] ([TaxId]);
    
    PRINT '  ? Tabla EntityUserProfiles creada';
END
ELSE
BEGIN
    PRINT '  ? Tabla EntityUserProfiles existe';
END

PRINT '';

-- =============================================
-- PASO 1: Crear tablas geogr�ficas
-- =============================================
PRINT 'Creando tablas geogr�ficas...';

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Countries')
BEGIN
    CREATE TABLE [Countries] (
      [Id] int NOT NULL IDENTITY(1,1),
        [Name] nvarchar(100) NOT NULL,
    [Code] nvarchar(3) NOT NULL,
        [IsActive] bit NOT NULL DEFAULT 1,
        CONSTRAINT [PK_Countries] PRIMARY KEY ([Id])
    );
    
    CREATE UNIQUE INDEX [IX_Countries_Code] ON [Countries] ([Code]);
    
    PRINT '  ? Tabla Countries creada';
END
ELSE
BEGIN
    PRINT '  - Tabla Countries ya existe';
END

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'States')
BEGIN
    CREATE TABLE [States] (
        [Id] int NOT NULL IDENTITY(1,1),
    [CountryId] int NOT NULL,
  [Name] nvarchar(100) NOT NULL,
        [Code] nvarchar(10) NULL,
     [IsActive] bit NOT NULL DEFAULT 1,
  CONSTRAINT [PK_States] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_States_Countries_CountryId] 
      FOREIGN KEY ([CountryId]) REFERENCES [Countries] ([Id]) ON DELETE CASCADE
    );
    
    CREATE INDEX [IX_States_CountryId] ON [States] ([CountryId]);
    
    PRINT '  ? Tabla States creada';
END
ELSE
BEGIN
    PRINT '  - Tabla States ya existe';
END

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Cities')
BEGIN
    CREATE TABLE [Cities] (
        [Id] int NOT NULL IDENTITY(1,1),
    [StateId] int NOT NULL,
        [Name] nvarchar(100) NOT NULL,
        [IsActive] bit NOT NULL DEFAULT 1,
        CONSTRAINT [PK_Cities] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_Cities_States_StateId] 
            FOREIGN KEY ([StateId]) REFERENCES [States] ([Id]) ON DELETE CASCADE
    );
    
    CREATE INDEX [IX_Cities_StateId] ON [Cities] ([StateId]);
    
    PRINT '  ? Tabla Cities creada';
END
ELSE
BEGIN
    PRINT '  - Tabla Cities ya existe';
END

PRINT '';

-- =============================================
-- PASO 2: Insertar datos geogr�ficos iniciales
-- =============================================
PRINT 'Insertando datos geogr�ficos iniciales...';

-- Insertar Colombia si no existe
IF NOT EXISTS (SELECT 1 FROM [Countries] WHERE [Code] = 'COL')
BEGIN
    INSERT INTO [Countries] ([Name], [Code], [IsActive])
 VALUES ('Colombia', 'COL', 1);
    
    DECLARE @ColombiaId int = SCOPE_IDENTITY();
    
    -- Insertar departamentos de Colombia
    INSERT INTO [States] ([CountryId], [Name], [Code], [IsActive])
    VALUES 
        (@ColombiaId, 'Bogot� D.C.', 'BOG', 1),
        (@ColombiaId, 'Antioquia', 'ANT', 1),
    (@ColombiaId, 'Valle del Cauca', 'VAC', 1),
        (@ColombiaId, 'Atl�ntico', 'ATL', 1),
        (@ColombiaId, 'Cundinamarca', 'CUN', 1);
    
    -- Insertar ciudades principales
    DECLARE @BogotaId int = (SELECT Id FROM [States] WHERE [Code] = 'BOG' AND [CountryId] = @ColombiaId);
    DECLARE @AntioquiaId int = (SELECT Id FROM [States] WHERE [Code] = 'ANT' AND [CountryId] = @ColombiaId);
  DECLARE @ValleId int = (SELECT Id FROM [States] WHERE [Code] = 'VAC' AND [CountryId] = @ColombiaId);
    
    INSERT INTO [Cities] ([StateId], [Name], [IsActive])
  VALUES 
        (@BogotaId, 'Bogot�', 1),
        (@AntioquiaId, 'Medell�n', 1),
        (@ValleId, 'Cali', 1);
    
    PRINT '  ? Datos geogr�ficos de Colombia insertados';
END
ELSE
BEGIN
    PRINT '  - Datos geogr�ficos ya existen';
END

PRINT '';

-- =============================================
-- PASO 3: Agregar campos geogr�ficos a EntityUserProfile
-- =============================================
PRINT 'Agregando campos geogr�ficos a EntityUserProfile...';

-- Verificar que la tabla existe antes de modificarla
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'EntityUserProfiles')
BEGIN
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('EntityUserProfiles') AND name = 'CountryId')
    BEGIN
        ALTER TABLE [EntityUserProfiles] ADD [CountryId] int NULL;
      PRINT '  ? Campo CountryId agregado';
    END
    ELSE
    BEGIN
    PRINT '  - Campo CountryId ya existe';
    END

    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('EntityUserProfiles') AND name = 'StateId')
    BEGIN
  ALTER TABLE [EntityUserProfiles] ADD [StateId] int NULL;
        PRINT '  ? Campo StateId agregado';
    END
    ELSE
  BEGIN
      PRINT '  - Campo StateId ya existe';
    END

    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('EntityUserProfiles') AND name = 'CityId')
    BEGIN
        ALTER TABLE [EntityUserProfiles] ADD [CityId] int NULL;
        PRINT '  ? Campo CityId agregado';
    END
    ELSE
    BEGIN
 PRINT '  - Campo CityId ya existe';
    END

    -- Agregar foreign keys
    IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_EntityUserProfiles_Countries_CountryId')
    BEGIN
    ALTER TABLE [EntityUserProfiles] 
        ADD CONSTRAINT [FK_EntityUserProfiles_Countries_CountryId] 
        FOREIGN KEY ([CountryId]) REFERENCES [Countries] ([Id]);
    
        PRINT '  ? FK EntityUserProfiles -> Countries creada';
    END

    IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_EntityUserProfiles_States_StateId')
    BEGIN
        ALTER TABLE [EntityUserProfiles] 
    ADD CONSTRAINT [FK_EntityUserProfiles_States_StateId] 
        FOREIGN KEY ([StateId]) REFERENCES [States] ([Id]);
    
        PRINT '  ? FK EntityUserProfiles -> States creada';
    END

    IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_EntityUserProfiles_Cities_CityId')
    BEGIN
        ALTER TABLE [EntityUserProfiles] 
      ADD CONSTRAINT [FK_EntityUserProfiles_Cities_CityId] 
        FOREIGN KEY ([CityId]) REFERENCES [Cities] ([Id]);
     
        PRINT '  ? FK EntityUserProfiles -> Cities creada';
 END
END
ELSE
BEGIN
    PRINT '  ! ADVERTENCIA: Tabla EntityUserProfiles no existe, campos geogr�ficos no agregados';
END

PRINT '';

-- =============================================
-- PASO 4: Crear tabla EntityProfessionalProfiles
-- =============================================
PRINT 'Creando tabla EntityProfessionalProfiles...';

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'EntityProfessionalProfiles')
BEGIN
    CREATE TABLE [EntityProfessionalProfiles] (
        [Id] int NOT NULL IDENTITY(1,1),
  [ApplicationUserId] nvarchar(450) NOT NULL,
        [EntityId] int NOT NULL,
[FullName] nvarchar(200) NOT NULL,
        [DocumentType] int NOT NULL,
 [DocumentNumber] nvarchar(50) NOT NULL,
        [ProfessionalLicense] nvarchar(50) NULL,
  [Specialty] nvarchar(100) NULL,
     [Phone] nvarchar(20) NULL,
  [CountryId] int NULL,
     [StateId] int NULL,
        [CityId] int NULL,
        [Address] nvarchar(max) NULL,
  [JoinedAt] datetime2 NOT NULL DEFAULT GETUTCDATE(),
        [IsActive] bit NOT NULL DEFAULT 1,
        CONSTRAINT [PK_EntityProfessionalProfiles] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_EntityProfessionalProfiles_AspNetUsers_ApplicationUserId] 
            FOREIGN KEY ([ApplicationUserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE,
   CONSTRAINT [FK_EntityProfessionalProfiles_EntityUserProfiles_EntityId] 
     FOREIGN KEY ([EntityId]) REFERENCES [EntityUserProfiles] ([Id]) ON DELETE NO ACTION,
        CONSTRAINT [FK_EntityProfessionalProfiles_Countries_CountryId] 
          FOREIGN KEY ([CountryId]) REFERENCES [Countries] ([Id]) ON DELETE NO ACTION,
     CONSTRAINT [FK_EntityProfessionalProfiles_States_StateId] 
    FOREIGN KEY ([StateId]) REFERENCES [States] ([Id]) ON DELETE NO ACTION,
        CONSTRAINT [FK_EntityProfessionalProfiles_Cities_CityId] 
            FOREIGN KEY ([CityId]) REFERENCES [Cities] ([Id]) ON DELETE NO ACTION
    );
    
    CREATE UNIQUE INDEX [IX_EntityProfessionalProfiles_ApplicationUserId] 
      ON [EntityProfessionalProfiles] ([ApplicationUserId]);
    CREATE UNIQUE INDEX [IX_EntityProfessionalProfiles_EntityId_DocumentNumber] 
        ON [EntityProfessionalProfiles] ([EntityId], [DocumentNumber]);
    
    PRINT '  ? Tabla EntityProfessionalProfiles creada';
END
ELSE
BEGIN
    PRINT '  - Tabla EntityProfessionalProfiles ya existe';
END

PRINT '';

-- =============================================
-- PASO 5: Crear tabla PatientProfiles
-- =============================================
PRINT 'Creando tabla PatientProfiles...';

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PatientProfiles')
BEGIN
    CREATE TABLE [PatientProfiles] (
        [Id] int NOT NULL IDENTITY(1,1),
        [ApplicationUserId] nvarchar(450) NOT NULL,
     [ProfessionalId] int NOT NULL,
        [FullName] nvarchar(200) NOT NULL,
[DocumentType] int NOT NULL,
        [DocumentNumber] nvarchar(50) NOT NULL,
   [DateOfBirth] datetime2 NULL,
        [Gender] nvarchar(20) NULL,
        [Phone] nvarchar(20) NULL,
        [EmergencyContactName] nvarchar(200) NULL,
        [EmergencyContactPhone] nvarchar(20) NULL,
  [CountryId] int NULL,
        [StateId] int NULL,
      [CityId] int NULL,
        [Address] nvarchar(max) NULL,
        [MedicalHistory] nvarchar(max) NULL,
        [Allergies] nvarchar(max) NULL,
        [CurrentMedications] nvarchar(max) NULL,
        [BloodType] nvarchar(5) NULL,
 [RegisteredAt] datetime2 NOT NULL DEFAULT GETUTCDATE(),
        [IsActive] bit NOT NULL DEFAULT 1,
 CONSTRAINT [PK_PatientProfiles] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_PatientProfiles_AspNetUsers_ApplicationUserId] 
        FOREIGN KEY ([ApplicationUserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE,
        CONSTRAINT [FK_PatientProfiles_EntityProfessionalProfiles_ProfessionalId] 
   FOREIGN KEY ([ProfessionalId]) REFERENCES [EntityProfessionalProfiles] ([Id]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PatientProfiles_Countries_CountryId] 
   FOREIGN KEY ([CountryId]) REFERENCES [Countries] ([Id]) ON DELETE NO ACTION,
CONSTRAINT [FK_PatientProfiles_States_StateId] 
      FOREIGN KEY ([StateId]) REFERENCES [States] ([Id]) ON DELETE NO ACTION,
        CONSTRAINT [FK_PatientProfiles_Cities_CityId] 
       FOREIGN KEY ([CityId]) REFERENCES [Cities] ([Id]) ON DELETE NO ACTION
    );
    
    CREATE UNIQUE INDEX [IX_PatientProfiles_ApplicationUserId] 
        ON [PatientProfiles] ([ApplicationUserId]);
    CREATE INDEX [IX_PatientProfiles_ProfessionalId] 
        ON [PatientProfiles] ([ProfessionalId]);
    CREATE UNIQUE INDEX [IX_PatientProfiles_ProfessionalId_DocumentNumber] 
      ON [PatientProfiles] ([ProfessionalId], [DocumentNumber]);
    
    PRINT '  ? Tabla PatientProfiles creada';
END
ELSE
BEGIN
    PRINT '  - Tabla PatientProfiles ya existe';
END

PRINT '';

-- =============================================
-- PASO 6: Migrar datos de EntityMemberProfiles a EntityProfessionalProfiles
-- =============================================
PRINT 'Migrando datos de EntityMemberProfiles a EntityProfessionalProfiles...';

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'EntityMemberProfiles')
BEGIN
    IF EXISTS (SELECT 1 FROM [EntityMemberProfiles])
    BEGIN
        -- Migrar datos existentes
        INSERT INTO [EntityProfessionalProfiles] 
        ([ApplicationUserId], [EntityId], [FullName], [DocumentType], [DocumentNumber], 
             [Phone], [JoinedAt], [IsActive])
        SELECT 
   [ApplicationUserId], 
      [EntityId], 
   [FullName], 
            [DocumentType], 
       [DocumentNumber],
            [Phone],
          [JoinedAt],
    [IsActive]
        FROM [EntityMemberProfiles]
      WHERE [ApplicationUserId] NOT IN (SELECT [ApplicationUserId] FROM [EntityProfessionalProfiles]);
      
        DECLARE @MigratedRows int = @@ROWCOUNT;
        PRINT '  ? ' + CAST(@MigratedRows AS nvarchar(10)) + ' registros migrados de EntityMemberProfiles';
    END
    ELSE
    BEGIN
        PRINT '  - EntityMemberProfiles est� vac�a, no hay datos para migrar';
  END
END
ELSE
BEGIN
    PRINT '  - Tabla EntityMemberProfiles no existe, no hay datos para migrar';
END

PRINT '';

-- =============================================
-- FINALIZACI�N
-- =============================================
PRINT '==============================================';
PRINT '  Migraci�n completada exitosamente!';
PRINT '==============================================';
PRINT '';
PRINT 'Resumen de cambios:';
PRINT '  ? Tablas geogr�ficas creadas (Countries, States, Cities)';
PRINT '  ? Campos geogr�ficos agregados a EntityUserProfile';
PRINT '  ? Tabla EntityProfessionalProfiles creada';
PRINT '  ? Tabla PatientProfiles creada';
PRINT '  ? Datos migrados desde EntityMemberProfiles (si exist�an)';
PRINT '';
PRINT 'IMPORTANTE:';
PRINT '  - El superusuario existente NO fue afectado';
PRINT '  - Ejecuta el seeder GeographicDataSeeder para datos geogr�ficos completos';
PRINT '  - EntityMemberProfiles puede eliminarse manualmente si ya no se usa';
PRINT '';

COMMIT TRANSACTION;

PRINT 'Transacci�n confirmada. Base de datos actualizada.';
PRINT '';

﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Salutia_Wep_App.Migrations
{
    /// <inheritdoc />
    public partial class AddEntityTableAndRefactorRelations : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EntityMemberProfiles");

            migrationBuilder.DropIndex(
                name: "IX_EntityUserProfiles_TaxId",
                table: "EntityUserProfiles");

            migrationBuilder.DropColumn(
                name: "Address",
                table: "EntityUserProfiles");

            migrationBuilder.DropColumn(
                name: "BusinessName",
                table: "EntityUserProfiles");

            migrationBuilder.DropColumn(
                name: "Phone",
                table: "EntityUserProfiles");

            migrationBuilder.DropColumn(
                name: "TaxId",
                table: "EntityUserProfiles");

            migrationBuilder.DropColumn(
                name: "VerificationDigit",
                table: "EntityUserProfiles");

            migrationBuilder.RenameColumn(
                name: "Website",
                table: "EntityUserProfiles",
                newName: "Position");

            migrationBuilder.RenameColumn(
                name: "LegalRepresentative",
                table: "EntityUserProfiles",
                newName: "DirectPhone");

            migrationBuilder.AddColumn<int>(
                name: "CityId",
                table: "IndependentUserProfiles",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CountryId",
                table: "IndependentUserProfiles",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "StateId",
                table: "IndependentUserProfiles",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "EntityId",
                table: "EntityUserProfiles",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "FullName",
                table: "EntityUserProfiles",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "IsActive",
                table: "EntityUserProfiles",
                type: "bit",
                nullable: false,
                defaultValue: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "JoinedAt",
                table: "EntityUserProfiles",
                type: "datetime2",
                nullable: false,
                defaultValueSql: "GETUTCDATE()");

            migrationBuilder.CreateTable(
                name: "Countries",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Code = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Countries", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Entities",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BusinessName = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                    TaxId = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    VerificationDigit = table.Column<string>(type: "nvarchar(1)", maxLength: 1, nullable: false),
                    Phone = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    Address = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Website = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    LegalRepresentative = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Entities", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PsychosomaticTests",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PatientUserId = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false),
                    StartedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    CompletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsCompleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PsychosomaticTests", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "States",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Code = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    CountryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_States", x => x.Id);
                    table.ForeignKey(
                        name: "FK_States_Countries_CountryId",
                        column: x => x.CountryId,
                        principalTable: "Countries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TestAges",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PsychosomaticTestId = table.Column<int>(type: "int", nullable: false),
                    WordNumber = table.Column<int>(type: "int", nullable: false),
                    Age = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestAges", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TestAges_PsychosomaticTests_PsychosomaticTestId",
                        column: x => x.PsychosomaticTestId,
                        principalTable: "PsychosomaticTests",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TestAssociatedPersons",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PsychosomaticTestId = table.Column<int>(type: "int", nullable: false),
                    WordNumber = table.Column<int>(type: "int", nullable: false),
                    PersonName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestAssociatedPersons", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TestAssociatedPersons_PsychosomaticTests_PsychosomaticTestId",
                        column: x => x.PsychosomaticTestId,
                        principalTable: "PsychosomaticTests",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TestBodyParts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PsychosomaticTestId = table.Column<int>(type: "int", nullable: false),
                    WordNumber = table.Column<int>(type: "int", nullable: false),
                    BodyPart = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestBodyParts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TestBodyParts_PsychosomaticTests_PsychosomaticTestId",
                        column: x => x.PsychosomaticTestId,
                        principalTable: "PsychosomaticTests",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TestDiscomfortLevels",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PsychosomaticTestId = table.Column<int>(type: "int", nullable: false),
                    WordNumber = table.Column<int>(type: "int", nullable: false),
                    DiscomfortLevel = table.Column<int>(type: "int", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestDiscomfortLevels", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TestDiscomfortLevels_PsychosomaticTests_PsychosomaticTestId",
                        column: x => x.PsychosomaticTestId,
                        principalTable: "PsychosomaticTests",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TestEmotions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PsychosomaticTestId = table.Column<int>(type: "int", nullable: false),
                    WordNumber = table.Column<int>(type: "int", nullable: false),
                    Emotion = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestEmotions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TestEmotions_PsychosomaticTests_PsychosomaticTestId",
                        column: x => x.PsychosomaticTestId,
                        principalTable: "PsychosomaticTests",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TestMatrices",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PsychosomaticTestId = table.Column<int>(type: "int", nullable: false),
                    WordNumber = table.Column<int>(type: "int", nullable: false),
                    Word = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Phrase = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Emotion = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    DiscomfortLevel = table.Column<int>(type: "int", nullable: false),
                    Age = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    BodyPart = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    AssociatedPerson = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestMatrices", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TestMatrices_PsychosomaticTests_PsychosomaticTestId",
                        column: x => x.PsychosomaticTestId,
                        principalTable: "PsychosomaticTests",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TestPhrases",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PsychosomaticTestId = table.Column<int>(type: "int", nullable: false),
                    WordNumber = table.Column<int>(type: "int", nullable: false),
                    Phrase = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestPhrases", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TestPhrases_PsychosomaticTests_PsychosomaticTestId",
                        column: x => x.PsychosomaticTestId,
                        principalTable: "PsychosomaticTests",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TestWords",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PsychosomaticTestId = table.Column<int>(type: "int", nullable: false),
                    WordNumber = table.Column<int>(type: "int", nullable: false),
                    Word = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestWords", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TestWords_PsychosomaticTests_PsychosomaticTestId",
                        column: x => x.PsychosomaticTestId,
                        principalTable: "PsychosomaticTests",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Cities",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    StateId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cities", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Cities_States_StateId",
                        column: x => x.StateId,
                        principalTable: "States",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "EntityProfessionalProfiles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ApplicationUserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    EntityId = table.Column<int>(type: "int", nullable: false),
                    FullName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    DocumentType = table.Column<int>(type: "int", nullable: false),
                    DocumentNumber = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ProfessionalLicense = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Specialty = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CountryId = table.Column<int>(type: "int", nullable: true),
                    StateId = table.Column<int>(type: "int", nullable: true),
                    CityId = table.Column<int>(type: "int", nullable: true),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    JoinedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EntityProfessionalProfiles", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EntityProfessionalProfiles_AspNetUsers_ApplicationUserId",
                        column: x => x.ApplicationUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_EntityProfessionalProfiles_Cities_CityId",
                        column: x => x.CityId,
                        principalTable: "Cities",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_EntityProfessionalProfiles_Countries_CountryId",
                        column: x => x.CountryId,
                        principalTable: "Countries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_EntityProfessionalProfiles_Entities_EntityId",
                        column: x => x.EntityId,
                        principalTable: "Entities",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_EntityProfessionalProfiles_States_StateId",
                        column: x => x.StateId,
                        principalTable: "States",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PatientProfiles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ApplicationUserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    EntityId = table.Column<int>(type: "int", nullable: true),
                    ProfessionalId = table.Column<int>(type: "int", nullable: false),
                    IsEntityPatient = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    ProfileCompleted = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    FullName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    DocumentType = table.Column<int>(type: "int", nullable: false),
                    DocumentNumber = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CountryId = table.Column<int>(type: "int", nullable: true),
                    StateId = table.Column<int>(type: "int", nullable: true),
                    CityId = table.Column<int>(type: "int", nullable: true),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    IsActive = table.Column<bool>(type: "bit", nullable: false, defaultValue: true),
                    Notes = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PatientProfiles", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PatientProfiles_AspNetUsers_ApplicationUserId",
                        column: x => x.ApplicationUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PatientProfiles_Cities_CityId",
                        column: x => x.CityId,
                        principalTable: "Cities",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PatientProfiles_Countries_CountryId",
                        column: x => x.CountryId,
                        principalTable: "Countries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PatientProfiles_Entities_EntityId",
                        column: x => x.EntityId,
                        principalTable: "Entities",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PatientProfiles_EntityProfessionalProfiles_ProfessionalId",
                        column: x => x.ProfessionalId,
                        principalTable: "EntityProfessionalProfiles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PatientProfiles_States_StateId",
                        column: x => x.StateId,
                        principalTable: "States",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_IndependentUserProfiles_CityId",
                table: "IndependentUserProfiles",
                column: "CityId");

            migrationBuilder.CreateIndex(
                name: "IX_IndependentUserProfiles_CountryId",
                table: "IndependentUserProfiles",
                column: "CountryId");

            migrationBuilder.CreateIndex(
                name: "IX_IndependentUserProfiles_StateId",
                table: "IndependentUserProfiles",
                column: "StateId");

            migrationBuilder.CreateIndex(
                name: "IX_EntityUserProfiles_EntityId_ApplicationUserId",
                table: "EntityUserProfiles",
                columns: new[] { "EntityId", "ApplicationUserId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Cities_StateId",
                table: "Cities",
                column: "StateId");

            migrationBuilder.CreateIndex(
                name: "IX_Countries_Code",
                table: "Countries",
                column: "Code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Entities_Email",
                table: "Entities",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Entities_TaxId",
                table: "Entities",
                column: "TaxId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_EntityProfessionalProfiles_ApplicationUserId",
                table: "EntityProfessionalProfiles",
                column: "ApplicationUserId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_EntityProfessionalProfiles_CityId",
                table: "EntityProfessionalProfiles",
                column: "CityId");

            migrationBuilder.CreateIndex(
                name: "IX_EntityProfessionalProfiles_CountryId",
                table: "EntityProfessionalProfiles",
                column: "CountryId");

            migrationBuilder.CreateIndex(
                name: "IX_EntityProfessionalProfiles_EntityId_DocumentNumber",
                table: "EntityProfessionalProfiles",
                columns: new[] { "EntityId", "DocumentNumber" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_EntityProfessionalProfiles_StateId",
                table: "EntityProfessionalProfiles",
                column: "StateId");

            migrationBuilder.CreateIndex(
                name: "IX_PatientProfiles_ApplicationUserId",
                table: "PatientProfiles",
                column: "ApplicationUserId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_PatientProfiles_CityId",
                table: "PatientProfiles",
                column: "CityId");

            migrationBuilder.CreateIndex(
                name: "IX_PatientProfiles_CountryId",
                table: "PatientProfiles",
                column: "CountryId");

            migrationBuilder.CreateIndex(
                name: "IX_PatientProfiles_EntityId",
                table: "PatientProfiles",
                column: "EntityId");

            migrationBuilder.CreateIndex(
                name: "IX_PatientProfiles_ProfessionalId_DocumentNumber",
                table: "PatientProfiles",
                columns: new[] { "ProfessionalId", "DocumentNumber" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_PatientProfiles_StateId",
                table: "PatientProfiles",
                column: "StateId");

            migrationBuilder.CreateIndex(
                name: "IX_PsychosomaticTests_PatientUserId",
                table: "PsychosomaticTests",
                column: "PatientUserId");

            migrationBuilder.CreateIndex(
                name: "IX_States_CountryId_Code",
                table: "States",
                columns: new[] { "CountryId", "Code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TestAges_PsychosomaticTestId_WordNumber",
                table: "TestAges",
                columns: new[] { "PsychosomaticTestId", "WordNumber" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TestAssociatedPersons_PsychosomaticTestId_WordNumber",
                table: "TestAssociatedPersons",
                columns: new[] { "PsychosomaticTestId", "WordNumber" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TestBodyParts_PsychosomaticTestId_WordNumber",
                table: "TestBodyParts",
                columns: new[] { "PsychosomaticTestId", "WordNumber" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TestDiscomfortLevels_PsychosomaticTestId_WordNumber",
                table: "TestDiscomfortLevels",
                columns: new[] { "PsychosomaticTestId", "WordNumber" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TestEmotions_PsychosomaticTestId_WordNumber",
                table: "TestEmotions",
                columns: new[] { "PsychosomaticTestId", "WordNumber" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TestMatrices_PsychosomaticTestId_WordNumber",
                table: "TestMatrices",
                columns: new[] { "PsychosomaticTestId", "WordNumber" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TestPhrases_PsychosomaticTestId_WordNumber",
                table: "TestPhrases",
                columns: new[] { "PsychosomaticTestId", "WordNumber" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TestWords_PsychosomaticTestId_WordNumber",
                table: "TestWords",
                columns: new[] { "PsychosomaticTestId", "WordNumber" },
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_EntityUserProfiles_Entities_EntityId",
                table: "EntityUserProfiles",
                column: "EntityId",
                principalTable: "Entities",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_IndependentUserProfiles_Cities_CityId",
                table: "IndependentUserProfiles",
                column: "CityId",
                principalTable: "Cities",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_IndependentUserProfiles_Countries_CountryId",
                table: "IndependentUserProfiles",
                column: "CountryId",
                principalTable: "Countries",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_IndependentUserProfiles_States_StateId",
                table: "IndependentUserProfiles",
                column: "StateId",
                principalTable: "States",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_EntityUserProfiles_Entities_EntityId",
                table: "EntityUserProfiles");

            migrationBuilder.DropForeignKey(
                name: "FK_IndependentUserProfiles_Cities_CityId",
                table: "IndependentUserProfiles");

            migrationBuilder.DropForeignKey(
                name: "FK_IndependentUserProfiles_Countries_CountryId",
                table: "IndependentUserProfiles");

            migrationBuilder.DropForeignKey(
                name: "FK_IndependentUserProfiles_States_StateId",
                table: "IndependentUserProfiles");

            migrationBuilder.DropTable(
                name: "PatientProfiles");

            migrationBuilder.DropTable(
                name: "TestAges");

            migrationBuilder.DropTable(
                name: "TestAssociatedPersons");

            migrationBuilder.DropTable(
                name: "TestBodyParts");

            migrationBuilder.DropTable(
                name: "TestDiscomfortLevels");

            migrationBuilder.DropTable(
                name: "TestEmotions");

            migrationBuilder.DropTable(
                name: "TestMatrices");

            migrationBuilder.DropTable(
                name: "TestPhrases");

            migrationBuilder.DropTable(
                name: "TestWords");

            migrationBuilder.DropTable(
                name: "EntityProfessionalProfiles");

            migrationBuilder.DropTable(
                name: "PsychosomaticTests");

            migrationBuilder.DropTable(
                name: "Cities");

            migrationBuilder.DropTable(
                name: "Entities");

            migrationBuilder.DropTable(
                name: "States");

            migrationBuilder.DropTable(
                name: "Countries");

            migrationBuilder.DropIndex(
                name: "IX_IndependentUserProfiles_CityId",
                table: "IndependentUserProfiles");

            migrationBuilder.DropIndex(
                name: "IX_IndependentUserProfiles_CountryId",
                table: "IndependentUserProfiles");

            migrationBuilder.DropIndex(
                name: "IX_IndependentUserProfiles_StateId",
                table: "IndependentUserProfiles");

            migrationBuilder.DropIndex(
                name: "IX_EntityUserProfiles_EntityId_ApplicationUserId",
                table: "EntityUserProfiles");

            migrationBuilder.DropColumn(
                name: "CityId",
                table: "IndependentUserProfiles");

            migrationBuilder.DropColumn(
                name: "CountryId",
                table: "IndependentUserProfiles");

            migrationBuilder.DropColumn(
                name: "StateId",
                table: "IndependentUserProfiles");

            migrationBuilder.DropColumn(
                name: "EntityId",
                table: "EntityUserProfiles");

            migrationBuilder.DropColumn(
                name: "FullName",
                table: "EntityUserProfiles");

            migrationBuilder.DropColumn(
                name: "IsActive",
                table: "EntityUserProfiles");

            migrationBuilder.DropColumn(
                name: "JoinedAt",
                table: "EntityUserProfiles");

            migrationBuilder.RenameColumn(
                name: "Position",
                table: "EntityUserProfiles",
                newName: "Website");

            migrationBuilder.RenameColumn(
                name: "DirectPhone",
                table: "EntityUserProfiles",
                newName: "LegalRepresentative");

            migrationBuilder.AddColumn<string>(
                name: "Address",
                table: "EntityUserProfiles",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BusinessName",
                table: "EntityUserProfiles",
                type: "nvarchar(300)",
                maxLength: 300,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Phone",
                table: "EntityUserProfiles",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "TaxId",
                table: "EntityUserProfiles",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "VerificationDigit",
                table: "EntityUserProfiles",
                type: "nvarchar(1)",
                maxLength: 1,
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "EntityMemberProfiles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ApplicationUserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    EntityId = table.Column<int>(type: "int", nullable: false),
                    DocumentNumber = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    DocumentType = table.Column<int>(type: "int", nullable: false),
                    FullName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    JoinedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Position = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EntityMemberProfiles", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EntityMemberProfiles_AspNetUsers_ApplicationUserId",
                        column: x => x.ApplicationUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_EntityMemberProfiles_EntityUserProfiles_EntityId",
                        column: x => x.EntityId,
                        principalTable: "EntityUserProfiles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_EntityUserProfiles_TaxId",
                table: "EntityUserProfiles",
                column: "TaxId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_EntityMemberProfiles_ApplicationUserId",
                table: "EntityMemberProfiles",
                column: "ApplicationUserId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_EntityMemberProfiles_EntityId_DocumentNumber",
                table: "EntityMemberProfiles",
                columns: new[] { "EntityId", "DocumentNumber" },
                unique: true);
        }
    }
}

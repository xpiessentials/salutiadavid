-- =============================================
-- Fix Age Column in TestMatrices
-- =============================================

USE Salutia;
GO

PRINT '=============================================';
PRINT 'Verificando columna Age en TestMatrices';
PRINT '=============================================';
PRINT '';

-- Verificar si la columna Age existe
IF NOT EXISTS (
    SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'TestMatrices' AND COLUMN_NAME = 'Age'
)
BEGIN
    PRINT '? La columna Age NO existe';
    PRINT 'Agregando columna Age...';
    
    ALTER TABLE TestMatrices
    ADD Age NVARCHAR(50) NOT NULL DEFAULT '';
    
    PRINT '? Columna Age agregada exitosamente';
END
ELSE
BEGIN
    PRINT '? La columna Age YA existe';
    
    -- Verificar si permite NULL
    DECLARE @IsNullable VARCHAR(3);
    SELECT @IsNullable = IS_NULLABLE 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'TestMatrices' AND COLUMN_NAME = 'Age';
    
    IF @IsNullable = 'YES'
    BEGIN
        PRINT '?? La columna Age permite NULL, corrigiendo...';
        
        -- Actualizar valores NULL
        UPDATE TestMatrices SET Age = '' WHERE Age IS NULL;
        
        -- Alterar columna para NO permitir NULL
        ALTER TABLE TestMatrices
        ALTER COLUMN Age NVARCHAR(50) NOT NULL;
        
        PRINT '? Columna Age corregida (NOT NULL)';
    END
    ELSE
    BEGIN
        PRINT '? La columna Age est� correctamente configurada';
    END
END
GO

-- Mostrar estructura de TestMatrices
PRINT '';
PRINT 'Estructura de TestMatrices:';
PRINT '';

SELECT 
    COLUMN_NAME AS [Columna],
    DATA_TYPE AS [Tipo],
    CHARACTER_MAXIMUM_LENGTH AS [Tama�o],
    IS_NULLABLE AS [Permite NULL]
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'TestMatrices'
ORDER BY ORDINAL_POSITION;
GO

PRINT '';
PRINT '=============================================';
PRINT '? VERIFICACI�N COMPLETADA';
PRINT '=============================================';
GO

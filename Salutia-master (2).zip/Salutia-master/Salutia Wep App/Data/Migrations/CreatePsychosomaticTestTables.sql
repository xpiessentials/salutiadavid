-- =============================================
-- Script de Migraci�n: Test Psicosom�tico
-- Fecha: 2024
-- Descripci�n: Crea las tablas necesarias para el Test Psicosom�tico
-- =============================================

USE Salutia;
GO

-- Verificar si las tablas ya existen antes de crear
PRINT 'Iniciando creaci�n de tablas para Test Psicosom�tico...';
GO

-- =============================================
-- Tabla Principal: PsychosomaticTests
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PsychosomaticTests')
BEGIN
    CREATE TABLE PsychosomaticTests (
        Id INT IDENTITY(1,1) PRIMARY KEY,
     PatientUserId NVARCHAR(450) NOT NULL,
        StartedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        CompletedAt DATETIME2 NULL,
        IsCompleted BIT NOT NULL DEFAULT 0,
  
        CONSTRAINT FK_PsychosomaticTests_AspNetUsers 
FOREIGN KEY (PatientUserId) REFERENCES AspNetUsers(Id) ON DELETE CASCADE
    );
    
 CREATE NONCLUSTERED INDEX IX_PsychosomaticTests_PatientUserId 
        ON PsychosomaticTests(PatientUserId);
    
    PRINT '? Tabla PsychosomaticTests creada exitosamente';
END
ELSE
    PRINT '? Tabla PsychosomaticTests ya existe';
GO

-- =============================================
-- Tabla: TestWords
-- Almacena las 10 palabras que causan malestar
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TestWords')
BEGIN
    CREATE TABLE TestWords (
        Id INT IDENTITY(1,1) PRIMARY KEY,
      PsychosomaticTestId INT NOT NULL,
        WordNumber INT NOT NULL,
        Word NVARCHAR(100) NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
CONSTRAINT FK_TestWords_PsychosomaticTests 
  FOREIGN KEY (PsychosomaticTestId) REFERENCES PsychosomaticTests(Id) ON DELETE CASCADE,
CONSTRAINT CK_TestWords_WordNumber CHECK (WordNumber BETWEEN 1 AND 10)
    );
    
    CREATE UNIQUE NONCLUSTERED INDEX IX_TestWords_TestId_WordNumber 
   ON TestWords(PsychosomaticTestId, WordNumber);
    
 PRINT '? Tabla TestWords creada exitosamente';
END
ELSE
    PRINT '? Tabla TestWords ya existe';
GO

-- =============================================
-- Tabla: TestPhrases
-- Almacena las 10 frases asociadas a cada palabra
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TestPhrases')
BEGIN
    CREATE TABLE TestPhrases (
        Id INT IDENTITY(1,1) PRIMARY KEY,
  PsychosomaticTestId INT NOT NULL,
        WordNumber INT NOT NULL,
        Phrase NVARCHAR(500) NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
      
      CONSTRAINT FK_TestPhrases_PsychosomaticTests 
 FOREIGN KEY (PsychosomaticTestId) REFERENCES PsychosomaticTests(Id) ON DELETE CASCADE,
        CONSTRAINT CK_TestPhrases_WordNumber CHECK (WordNumber BETWEEN 1 AND 10)
    );
    
    CREATE UNIQUE NONCLUSTERED INDEX IX_TestPhrases_TestId_WordNumber 
        ON TestPhrases(PsychosomaticTestId, WordNumber);
    
    PRINT '? Tabla TestPhrases creada exitosamente';
END
ELSE
    PRINT '? Tabla TestPhrases ya existe';
GO

-- =============================================
-- Tabla: TestEmotions
-- Almacena las 10 emociones asociadas a cada frase
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TestEmotions')
BEGIN
    CREATE TABLE TestEmotions (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        PsychosomaticTestId INT NOT NULL,
        WordNumber INT NOT NULL,
      Emotion NVARCHAR(100) NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
     CONSTRAINT FK_TestEmotions_PsychosomaticTests 
 FOREIGN KEY (PsychosomaticTestId) REFERENCES PsychosomaticTests(Id) ON DELETE CASCADE,
        CONSTRAINT CK_TestEmotions_WordNumber CHECK (WordNumber BETWEEN 1 AND 10)
    );
    
    CREATE UNIQUE NONCLUSTERED INDEX IX_TestEmotions_TestId_WordNumber 
    ON TestEmotions(PsychosomaticTestId, WordNumber);
    
    PRINT '? Tabla TestEmotions creada exitosamente';
END
ELSE
    PRINT '? Tabla TestEmotions ya existe';
GO

-- =============================================
-- Tabla: TestDiscomfortLevels
-- Almacena el nivel de malestar (1-10) para cada palabra
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TestDiscomfortLevels')
BEGIN
    CREATE TABLE TestDiscomfortLevels (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        PsychosomaticTestId INT NOT NULL,
        WordNumber INT NOT NULL,
        DiscomfortLevel INT NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
        CONSTRAINT FK_TestDiscomfortLevels_PsychosomaticTests 
            FOREIGN KEY (PsychosomaticTestId) REFERENCES PsychosomaticTests(Id) ON DELETE CASCADE,
        CONSTRAINT CK_TestDiscomfortLevels_WordNumber CHECK (WordNumber BETWEEN 1 AND 10),
        CONSTRAINT CK_TestDiscomfortLevels_Level CHECK (DiscomfortLevel BETWEEN 1 AND 10)
    );
    
    CREATE UNIQUE NONCLUSTERED INDEX IX_TestDiscomfortLevels_TestId_WordNumber 
        ON TestDiscomfortLevels(PsychosomaticTestId, WordNumber);
    
    PRINT '? Tabla TestDiscomfortLevels creada exitosamente';
END
ELSE
    PRINT '? Tabla TestDiscomfortLevels ya existe';
GO

-- =============================================
-- Tabla: TestAges
-- Almacena la edad a la que sinti� el malestar
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TestAges')
BEGIN
    CREATE TABLE TestAges (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        PsychosomaticTestId INT NOT NULL,
        WordNumber INT NOT NULL,
        Age NVARCHAR(50) NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
        CONSTRAINT FK_TestAges_PsychosomaticTests 
            FOREIGN KEY (PsychosomaticTestId) REFERENCES PsychosomaticTests(Id) ON DELETE CASCADE,
        CONSTRAINT CK_TestAges_WordNumber CHECK (WordNumber BETWEEN 1 AND 10)
    );
    
    CREATE UNIQUE NONCLUSTERED INDEX IX_TestAges_TestId_WordNumber 
        ON TestAges(PsychosomaticTestId, WordNumber);
    
    PRINT '? Tabla TestAges creada exitosamente';
END
ELSE
    PRINT '? Tabla TestAges ya existe';
GO

-- =============================================
-- Tabla: TestBodyParts
-- Almacena la parte del cuerpo donde se siente el malestar
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TestBodyParts')
BEGIN
    CREATE TABLE TestBodyParts (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        PsychosomaticTestId INT NOT NULL,
        WordNumber INT NOT NULL,
        BodyPart NVARCHAR(100) NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
        CONSTRAINT FK_TestBodyParts_PsychosomaticTests 
            FOREIGN KEY (PsychosomaticTestId) REFERENCES PsychosomaticTests(Id) ON DELETE CASCADE,
        CONSTRAINT CK_TestBodyParts_WordNumber CHECK (WordNumber BETWEEN 1 AND 10)
    );
    
    CREATE UNIQUE NONCLUSTERED INDEX IX_TestBodyParts_TestId_WordNumber 
        ON TestBodyParts(PsychosomaticTestId, WordNumber);
    
    PRINT '? Tabla TestBodyParts creada exitosamente';
END
ELSE
    PRINT '? Tabla TestBodyParts ya existe';
GO

-- =============================================
-- Tabla: TestAssociatedPersons
-- Almacena la persona asociada al malestar
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TestAssociatedPersons')
BEGIN
    CREATE TABLE TestAssociatedPersons (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        PsychosomaticTestId INT NOT NULL,
        WordNumber INT NOT NULL,
        PersonName NVARCHAR(200) NOT NULL,
   CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
  CONSTRAINT FK_TestAssociatedPersons_PsychosomaticTests 
  FOREIGN KEY (PsychosomaticTestId) REFERENCES PsychosomaticTests(Id) ON DELETE CASCADE,
   CONSTRAINT CK_TestAssociatedPersons_WordNumber CHECK (WordNumber BETWEEN 1 AND 10)
    );
    
    CREATE UNIQUE NONCLUSTERED INDEX IX_TestAssociatedPersons_TestId_WordNumber 
        ON TestAssociatedPersons(PsychosomaticTestId, WordNumber);
    
    PRINT '? Tabla TestAssociatedPersons creada exitosamente';
END
ELSE
    PRINT '? Tabla TestAssociatedPersons ya existe';
GO

-- =============================================
-- Tabla: TestMatrices
-- Matriz consolidada con todas las respuestas
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TestMatrices')
BEGIN
    CREATE TABLE TestMatrices (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        PsychosomaticTestId INT NOT NULL,
     WordNumber INT NOT NULL,
        Word NVARCHAR(100) NOT NULL,
        Phrase NVARCHAR(500) NOT NULL,
        Emotion NVARCHAR(100) NOT NULL,
        DiscomfortLevel INT NOT NULL,
        Age NVARCHAR(50) NOT NULL,
        BodyPart NVARCHAR(100) NOT NULL,
        AssociatedPerson NVARCHAR(200) NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        
CONSTRAINT FK_TestMatrices_PsychosomaticTests 
         FOREIGN KEY (PsychosomaticTestId) REFERENCES PsychosomaticTests(Id) ON DELETE CASCADE,
        CONSTRAINT CK_TestMatrices_WordNumber CHECK (WordNumber BETWEEN 1 AND 10),
   CONSTRAINT CK_TestMatrices_DiscomfortLevel CHECK (DiscomfortLevel BETWEEN 1 AND 10)
    );
    
CREATE UNIQUE NONCLUSTERED INDEX IX_TestMatrices_TestId_WordNumber 
        ON TestMatrices(PsychosomaticTestId, WordNumber);
    
    PRINT '? Tabla TestMatrices creada exitosamente';
END
ELSE
    PRINT '? Tabla TestMatrices ya existe';
GO

PRINT '';
PRINT '=============================================';
PRINT 'Migraci�n completada exitosamente';
PRINT '=============================================';
PRINT 'Tablas creadas para el Test Psicosom�tico:';
PRINT '  - PsychosomaticTests (Test principal)';
PRINT '  - TestWords (10 palabras)';
PRINT '  - TestPhrases (10 frases)';
PRINT '  - TestEmotions (10 emociones)';
PRINT '  - TestDiscomfortLevels (10 niveles)';
PRINT '  - TestAges (10 edades)';
PRINT '  - TestBodyParts (10 partes del cuerpo)';
PRINT '- TestAssociatedPersons (10 personas)';
PRINT '  - TestMatrices (Matriz consolidada)';
PRINT '=============================================';
GO

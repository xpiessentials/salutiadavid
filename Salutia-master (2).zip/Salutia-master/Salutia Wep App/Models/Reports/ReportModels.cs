namespace Salutia_Wep_App.Models.Reports;

/// <summary>
/// Modelo para el reporte completo de paciente
/// </summary>
public class PatientReportModel
{
    public string Id { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string IdNumber { get; set; } = string.Empty;
    public DateTime BirthDate { get; set; }
    public string Gender { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;
    public string BloodType { get; set; } = string.Empty;
    public List<string> Allergies { get; set; } = new();
    public string MedicalHistory { get; set; } = string.Empty;
    public DateTime RegistrationDate { get; set; }
}

/// <summary>
/// Modelo para reporte de citas m�dicas
/// </summary>
public class AppointmentReportModel
{
    public string Id { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public string Doctor { get; set; } = string.Empty;
    public string Specialty { get; set; } = string.Empty;
  public string Location { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
 public string PatientName { get; set; } = string.Empty;
}

/// <summary>
/// Modelo para reporte de registro m�dico
/// </summary>
public class MedicalRecordReportModel
{
    public string Id { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public string Diagnosis { get; set; } = string.Empty;
 public string Treatment { get; set; } = string.Empty;
    public string Doctor { get; set; } = string.Empty;
    public string Symptoms { get; set; } = string.Empty;
    public List<string> Prescriptions { get; set; } = new();
    public string Notes { get; set; } = string.Empty;
}

/// <summary>
/// Modelo para reporte de test psicosom�tico
/// </summary>
public class PsychosomaticTestReportModel
{
    public string Id { get; set; } = string.Empty;
  public string PatientName { get; set; } = string.Empty;
    public string PatientEmail { get; set; } = string.Empty;
    public DateTime TestDate { get; set; }
    public int TotalScore { get; set; }
    public string Category { get; set; } = string.Empty;
    public string Interpretation { get; set; } = string.Empty;
    public List<string> Recommendations { get; set; } = new();
    public Dictionary<string, int> QuestionScores { get; set; } = new();
}

/// <summary>
/// Modelo para reporte de medicamentos
/// </summary>
public class MedicationReportModel
{
    public string Id { get; set; } = string.Empty;
    public string PatientName { get; set; } = string.Empty;
    public string MedicationName { get; set; } = string.Empty;
    public string Dosage { get; set; } = string.Empty;
    public string Frequency { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public string PrescribedBy { get; set; } = string.Empty;
    public string Instructions { get; set; } = string.Empty;
    public List<string> SideEffects { get; set; } = new();
    public bool IsActive { get; set; }
}

/// <summary>
/// Modelo para formulario de datos del paciente
/// </summary>
public class PatientFormModel
{
    public string Id { get; set; } = string.Empty;
    
  // Informaci�n Personal
  public string FullName { get; set; } = string.Empty;
    public string IdNumber { get; set; } = string.Empty;
    public DateTime BirthDate { get; set; } = DateTime.Now.AddYears(-30);
    public string Gender { get; set; } = string.Empty;
    
    // Contacto
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
 public string Address { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string Country { get; set; } = "Colombia";
    
  // Informaci�n M�dica
    public string BloodType { get; set; } = string.Empty;
    public List<string> Allergies { get; set; } = new();
    public string MedicalHistory { get; set; } = string.Empty;
    public List<string> ChronicConditions { get; set; } = new();
    public List<string> CurrentMedications { get; set; } = new();
    
    // Contacto de Emergencia
    public string EmergencyContactName { get; set; } = string.Empty;
    public string EmergencyContactPhone { get; set; } = string.Empty;
    public string EmergencyContactRelation { get; set; } = string.Empty;
    
    // Seguro M�dico
    public string InsuranceProvider { get; set; } = string.Empty;
    public string InsurancePolicyNumber { get; set; } = string.Empty;
    
    // Metadatos
    public DateTime RegistrationDate { get; set; } = DateTime.Now;
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime? LastModified { get; set; }
}

/// <summary>
/// Modelo para formulario de cita m�dica
/// </summary>
public class AppointmentFormModel
{
    public string Id { get; set; } = string.Empty;
    public string PatientId { get; set; } = string.Empty;
    public string PatientName { get; set; } = string.Empty;
    public DateTime AppointmentDate { get; set; } = DateTime.Now.AddDays(1);
    public TimeSpan AppointmentTime { get; set; } = new TimeSpan(9, 0, 0);
  public string DoctorId { get; set; } = string.Empty;
    public string DoctorName { get; set; } = string.Empty;
 public string Specialty { get; set; } = string.Empty;
    public string Location { get; set; } = string.Empty;
    public string ReasonForVisit { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public string Status { get; set; } = "Pendiente";
    public bool SendReminder { get; set; } = true;
    public int ReminderMinutesBefore { get; set; } = 60;
}

/// <summary>
/// Modelo para formulario de historial m�dico
/// </summary>
public class MedicalHistoryFormModel
{
    public string Id { get; set; } = string.Empty;
    public string PatientId { get; set; } = string.Empty;
    public DateTime VisitDate { get; set; } = DateTime.Now;
    public string ChiefComplaint { get; set; } = string.Empty;
  public string Symptoms { get; set; } = string.Empty;
    public string PhysicalExamination { get; set; } = string.Empty;
    public string Diagnosis { get; set; } = string.Empty;
    public string Treatment { get; set; } = string.Empty;
    public List<string> Prescriptions { get; set; } = new();
    public string LabTests { get; set; } = string.Empty;
    public string FollowUpInstructions { get; set; } = string.Empty;
    public DateTime? NextAppointment { get; set; }
    public string DoctorId { get; set; } = string.Empty;
    public string DoctorName { get; set; } = string.Empty;
    public List<string> Attachments { get; set; } = new();
}

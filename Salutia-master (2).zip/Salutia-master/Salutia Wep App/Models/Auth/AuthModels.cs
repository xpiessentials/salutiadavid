namespace Salutia_Wep_App.Models.Auth;

/// <summary>
/// DTO base para registro de usuario
/// </summary>
public abstract class RegisterRequestBase
{
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string ConfirmPassword { get; set; } = string.Empty;
    
    // Campos geogr�ficos comunes
    public int? CountryId { get; set; }
    public int? StateId { get; set; }
    public int? CityId { get; set; }
    public string? Address { get; set; }
}

/// <summary>
/// DTO para registro de usuario independiente
/// </summary>
public class RegisterIndependentRequest : RegisterRequestBase
{
    public string FullName { get; set; } = string.Empty;
    public int DocumentType { get; set; }
    public string DocumentNumber { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public DateTime? DateOfBirth { get; set; }
}

/// <summary>
/// DTO para registro de entidad
/// </summary>
public class RegisterEntityRequest : RegisterRequestBase
{
    /// <summary>
    /// Nombre completo del administrador que registra la entidad
    /// </summary>
    public string? FullName { get; set; }
    
    /// <summary>
    /// Raz�n social o nombre comercial de la entidad
    /// </summary>
    public string BusinessName { get; set; } = string.Empty;
    
    /// <summary>
    /// NIT de la entidad (sin d�gito de verificaci�n)
    /// </summary>
    public string TaxId { get; set; } = string.Empty;
    
    /// <summary>
    /// D�gito de verificaci�n del NIT
    /// </summary>
    public string VerificationDigit { get; set; } = string.Empty;
    
    /// <summary>
    /// Tel�fono principal de la entidad
    /// </summary>
    public string Phone { get; set; } = string.Empty;
    
    /// <summary>
    /// Representante legal de la entidad
    /// </summary>
    public string? LegalRepresentative { get; set; }
    
    /// <summary>
    /// Sitio web de la entidad
    /// </summary>
    public string? Website { get; set; }
}

/// <summary>
/// DTO para registro de profesional de entidad (M�dico o Psic�logo)
/// </summary>
public class RegisterProfessionalRequest : RegisterRequestBase
{
    /// <summary>
    /// ID de la entidad (requerido solo para SuperAdmin, opcional para EntityAdmin)
    /// </summary>
    public int? EntityId { get; set; }
    
    public string FullName { get; set; } = string.Empty;
    public int DocumentType { get; set; }
    public string DocumentNumber { get; set; } = string.Empty;
    public string? Phone { get; set; }
    public string? ProfessionalLicense { get; set; }
    public string? Specialty { get; set; }
    public ProfessionalType ProfessionalType { get; set; } // Doctor o Psychologist
}

/// <summary>
/// DTO para registro de paciente
/// </summary>
public class RegisterPatientRequest : RegisterRequestBase
{
    public int ProfessionalId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public int DocumentType { get; set; }
    public string DocumentNumber { get; set; } = string.Empty;
    public string? Phone { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public string? Gender { get; set; }
    public string? Notes { get; set; }
}

/// <summary>
/// Tipo de profesional
/// </summary>
public enum ProfessionalType
{
    Doctor = 3,
    Psychologist = 4
}

/// <summary>
/// DTO para inicio de sesi�n
/// </summary>
public class LoginRequest
{
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public bool RememberMe { get; set; }
}

/// <summary>
/// DTO para respuesta de autenticaci�n
/// </summary>
public class AuthResponse
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public UserInfo? User { get; set; }
    public string? Token { get; set; } // Para API/Mobile
}

/// <summary>
/// Informaci�n del usuario autenticado
/// </summary>
public class UserInfo
{
    public string UserId { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string UserType { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public int? EntityId { get; set; }
    public string? EntityName { get; set; }
    public int? ProfessionalId { get; set; } // Para m�dicos y psic�logos
    public List<string> Roles { get; set; } = new();
}

/// <summary>
/// Opciones de tipo de registro
/// </summary>
public enum RegistrationType
{
    Independent = 1,
    Entity = 2
}

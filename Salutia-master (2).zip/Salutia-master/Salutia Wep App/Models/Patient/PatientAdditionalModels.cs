namespace Salutia_Wep_App.Models.Patient;

/// <summary>
/// Maestro de Ocupaciones
/// </summary>
public class Occupation
{
    public int Id { get; set; }
    
    /// <summary>
    /// Nombre de la ocupaci�n
    /// </summary>
    public string Name { get; set; } = string.Empty;
    
    /// <summary>
    /// Descripci�n de la ocupaci�n
    /// </summary>
    public string? Description { get; set; }
    
    /// <summary>
    /// Indica si est� activo
    /// </summary>
    public bool IsActive { get; set; } = true;
    
    /// <summary>
    /// Orden de visualizaci�n
    /// </summary>
    public int DisplayOrder { get; set; }
}

/// <summary>
/// Maestro de Estados Civiles
/// </summary>
public class MaritalStatus
{
    public int Id { get; set; }
    
    /// <summary>
    /// Nombre del estado civil
    /// </summary>
    public string Name { get; set; } = string.Empty;
    
    /// <summary>
    /// C�digo del estado civil
    /// </summary>
    public string Code { get; set; } = string.Empty;
    
    /// <summary>
    /// Indica si est� activo
    /// </summary>
    public bool IsActive { get; set; } = true;
    
    /// <summary>
    /// Orden de visualizaci�n
    /// </summary>
    public int DisplayOrder { get; set; }
}

/// <summary>
/// Maestro de Niveles Educativos
/// </summary>
public class EducationLevel
{
    public int Id { get; set; }
    
    /// <summary>
    /// Nombre del nivel educativo
    /// </summary>
    public string Name { get; set; } = string.Empty;
    
    /// <summary>
    /// C�digo del nivel educativo
    /// </summary>
    public string Code { get; set; } = string.Empty;
    
    /// <summary>
    /// Indica si est� activo
    /// </summary>
    public bool IsActive { get; set; } = true;
    
    /// <summary>
    /// Orden de visualizaci�n
    /// </summary>
    public int DisplayOrder { get; set; }
}

/// <summary>
/// Historial m�dico del paciente
/// </summary>
public class PatientMedicalHistory
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del perfil del paciente
    /// </summary>
    public int PatientProfileId { get; set; }
    
    /// <summary>
    /// Condici�n m�dica o diagn�stico
    /// </summary>
    public string Condition { get; set; } = string.Empty;
    
    /// <summary>
    /// Fecha de diagn�stico
    /// </summary>
    public DateTime? DiagnosisDate { get; set; }
    
    /// <summary>
    /// Notas adicionales sobre la condici�n
    /// </summary>
    public string? Notes { get; set; }
    
    /// <summary>
    /// Indica si es una condici�n actual
    /// </summary>
    public bool IsCurrent { get; set; } = true;
    
    /// <summary>
    /// Fecha de registro
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Medicaci�n actual del paciente
/// </summary>
public class PatientMedication
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del perfil del paciente
    /// </summary>
    public int PatientProfileId { get; set; }
    
    /// <summary>
    /// Nombre del medicamento
    /// </summary>
    public string MedicationName { get; set; } = string.Empty;
    
    /// <summary>
    /// Dosis del medicamento
    /// </summary>
    public string? Dosage { get; set; }
    
    /// <summary>
    /// Frecuencia de administraci�n
    /// </summary>
    public string? Frequency { get; set; }
    
    /// <summary>
    /// Fecha de inicio
    /// </summary>
    public DateTime? StartDate { get; set; }
    
    /// <summary>
    /// Fecha de finalizaci�n (si aplica)
    /// </summary>
    public DateTime? EndDate { get; set; }
    
    /// <summary>
    /// Indica si es una medicaci�n actual
    /// </summary>
    public bool IsCurrent { get; set; } = true;
    
    /// <summary>
    /// Notas adicionales
    /// </summary>
    public string? Notes { get; set; }
    
    /// <summary>
    /// Fecha de registro
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Alergias del paciente
/// </summary>
public class PatientAllergy
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del perfil del paciente
    /// </summary>
    public int PatientProfileId { get; set; }
    
    /// <summary>
    /// Nombre del al�rgeno
    /// </summary>
    public string AllergenName { get; set; } = string.Empty;
    
    /// <summary>
    /// Tipo de alergia (medicamento, alimento, ambiental, etc.)
    /// </summary>
    public string? AllergyType { get; set; }
    
    /// <summary>
    /// Reacci�n al�rgica
    /// </summary>
    public string? Reaction { get; set; }
    
    /// <summary>
    /// Severidad (leve, moderada, severa)
    /// </summary>
    public string? Severity { get; set; }
    
    /// <summary>
    /// Notas adicionales
    /// </summary>
    public string? Notes { get; set; }
    
    /// <summary>
    /// Fecha de registro
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Contacto de emergencia del paciente
/// </summary>
public class PatientEmergencyContact
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del perfil del paciente
    /// </summary>
    public int PatientProfileId { get; set; }
    
    /// <summary>
    /// Nombre completo del contacto
    /// </summary>
    public string FullName { get; set; } = string.Empty;
    
    /// <summary>
    /// Relaci�n con el paciente
    /// </summary>
    public string Relationship { get; set; } = string.Empty;
    
    /// <summary>
    /// Tel�fono principal
    /// </summary>
    public string PhoneNumber { get; set; } = string.Empty;
    
    /// <summary>
    /// Tel�fono secundario (opcional)
    /// </summary>
    public string? AlternatePhoneNumber { get; set; }
    
    /// <summary>
    /// Email del contacto (opcional)
    /// </summary>
    public string? Email { get; set; }
    
    /// <summary>
    /// Direcci�n del contacto (opcional)
    /// </summary>
    public string? Address { get; set; }
    
    /// <summary>
    /// Indica si es el contacto principal
    /// </summary>
    public bool IsPrimary { get; set; } = false;
    
    /// <summary>
    /// Fecha de registro
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

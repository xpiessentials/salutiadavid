namespace Salutia_Wep_App.Models.Consent;

/// <summary>
/// Plantilla de consentimiento informado editable por SuperAdmin y EntityAdmin
/// </summary>
public class ConsentTemplate
{
    public int Id { get; set; }
    
    /// <summary>
    /// T�tulo del consentimiento
    /// </summary>
    public string Title { get; set; } = string.Empty;
    
    /// <summary>
    /// C�digo �nico del consentimiento (ej: CONSENT_DATA_PRIVACY, CONSENT_PSYCHOLOGICAL_EVAL)
    /// </summary>
    public string Code { get; set; } = string.Empty;
    
    /// <summary>
    /// Contenido completo del consentimiento en formato HTML
    /// </summary>
    public string ContentHtml { get; set; } = string.Empty;
    
    /// <summary>
    /// Versi�n del consentimiento (se incrementa con cada cambio)
    /// </summary>
    public int Version { get; set; } = 1;
    
    /// <summary>
    /// Orden de presentaci�n al paciente (1, 2, 3, 4)
    /// </summary>
    public int DisplayOrder { get; set; }
    
    /// <summary>
    /// Indica si el consentimiento est� activo
    /// </summary>
    public bool IsActive { get; set; } = true;
    
    /// <summary>
    /// ID de la entidad (null = plantilla global para todos)
    /// </summary>
    public int? EntityId { get; set; }
    
    /// <summary>
    /// Usuario que cre�/modific� el consentimiento
    /// </summary>
    public string ModifiedByUserId { get; set; } = string.Empty;
    
    /// <summary>
    /// Fecha de creaci�n
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    
    /// <summary>
    /// Fecha de �ltima modificaci�n
    /// </summary>
    public DateTime ModifiedAt { get; set; } = DateTime.UtcNow;
    
    /// <summary>
    /// Indica si es obligatorio firmar este consentimiento
    /// </summary>
    public bool IsRequired { get; set; } = true;
}

/// <summary>
/// Registro de consentimiento firmado por un paciente para un test espec�fico
/// </summary>
public class PatientConsent
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del test psicosom�tico asociado
    /// </summary>
    public int PsychosomaticTestId { get; set; }
    
    /// <summary>
    /// ID de la plantilla de consentimiento utilizada
    /// </summary>
    public int ConsentTemplateId { get; set; }
    public ConsentTemplate ConsentTemplate { get; set; } = null!;
    
    /// <summary>
    /// ID del paciente que firm�
    /// </summary>
    public string PatientUserId { get; set; } = string.Empty;
    
    /// <summary>
    /// Versi�n del consentimiento al momento de firmarlo
    /// </summary>
    public int ConsentVersion { get; set; }
    
    /// <summary>
    /// Copia del contenido HTML al momento de firmar (para auditor�a)
    /// </summary>
    public string ContentSnapshot { get; set; } = string.Empty;
    
    /// <summary>
    /// Direcci�n IP desde donde se firm�
    /// </summary>
    public string IpAddress { get; set; } = string.Empty;
    
    /// <summary>
    /// User Agent del navegador
    /// </summary>
    public string UserAgent { get; set; } = string.Empty;
    
    /// <summary>
    /// Indica si el paciente acept� el consentimiento
    /// </summary>
    public bool IsAccepted { get; set; }
    
    /// <summary>
    /// Fecha y hora de la firma
    /// </summary>
    public DateTime SignedAt { get; set; } = DateTime.UtcNow;
    
    /// <summary>
    /// Firma digital del paciente
    /// </summary>
    public ConsentSignature? Signature { get; set; }
    
    /// <summary>
    /// URL del PDF generado
    /// </summary>
    public string? PdfUrl { get; set; }
    
    /// <summary>
    /// Ruta f�sica del PDF en el servidor
    /// </summary>
    public string? PdfPath { get; set; }
}

/// <summary>
/// Firma digital capturada del paciente
/// </summary>
public class ConsentSignature
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del consentimiento firmado
    /// </summary>
    public int PatientConsentId { get; set; }
    public PatientConsent PatientConsent { get; set; } = null!;
    
    /// <summary>
    /// Datos de la firma en formato Base64 (imagen PNG)
    /// </summary>
    public string SignatureDataBase64 { get; set; } = string.Empty;
    
    /// <summary>
    /// Tipo de firma (Drawn = dibujada, Typed = texto, Image = imagen subida)
    /// </summary>
    public SignatureType SignatureType { get; set; } = SignatureType.Drawn;
    
    /// <summary>
    /// Nombre completo del firmante (para validaci�n)
    /// </summary>
    public string SignerFullName { get; set; } = string.Empty;
    
    /// <summary>
    /// Documento de identidad del firmante
    /// </summary>
    public string SignerDocumentNumber { get; set; } = string.Empty;
    
    /// <summary>
    /// Fecha de la firma
    /// </summary>
    public DateTime SignedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Tipo de firma digital
/// </summary>
public enum SignatureType
{
    /// <summary>
    /// Firma dibujada con mouse/touch
    /// </summary>
    Drawn = 1,
    
    /// <summary>
    /// Firma generada desde texto (nombre tipografiado)
    /// </summary>
    Typed = 2,
    
    /// <summary>
    /// Imagen de firma subida
    /// </summary>
    Image = 3
}

/// <summary>
/// Registro de documentos PDF generados para auditor�a
/// </summary>
public class ConsentDocument
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del test psicosom�tico
    /// </summary>
    public int PsychosomaticTestId { get; set; }
    
    /// <summary>
    /// ID del paciente
    /// </summary>
    public string PatientUserId { get; set; } = string.Empty;
    
    /// <summary>
    /// Nombre del documento
    /// </summary>
    public string DocumentName { get; set; } = string.Empty;
    
    /// <summary>
    /// Tipo de documento (individual consent PDF o package con todos)
    /// </summary>
    public string DocumentType { get; set; } = string.Empty;
    
    /// <summary>
    /// URL del documento
    /// </summary>
    public string DocumentUrl { get; set; } = string.Empty;
    
    /// <summary>
    /// Ruta f�sica del documento
    /// </summary>
    public string DocumentPath { get; set; } = string.Empty;
    
    /// <summary>
    /// Tama�o del archivo en bytes
    /// </summary>
    public long FileSizeBytes { get; set; }
    
    /// <summary>
    /// Hash MD5 del archivo para verificaci�n de integridad
    /// </summary>
    public string FileHash { get; set; } = string.Empty;
    
    /// <summary>
    /// Fecha de generaci�n
    /// </summary>
    public DateTime GeneratedAt { get; set; } = DateTime.UtcNow;
    
    /// <summary>
    /// Usuario que descarg� el documento (null si no se ha descargado)
    /// </summary>
    public string? DownloadedByUserId { get; set; }
    
    /// <summary>
    /// Fecha de descarga
    /// </summary>
    public DateTime? DownloadedAt { get; set; }
    
    /// <summary>
    /// N�mero de veces descargado
    /// </summary>
    public int DownloadCount { get; set; } = 0;
}

/// <summary>
/// Historial de cambios en las plantillas de consentimiento (auditor�a)
/// </summary>
public class ConsentTemplateHistory
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID de la plantilla modificada
    /// </summary>
    public int ConsentTemplateId { get; set; }
    
    /// <summary>
    /// Versi�n anterior
    /// </summary>
    public int PreviousVersion { get; set; }
    
    /// <summary>
    /// Contenido HTML anterior
    /// </summary>
    public string PreviousContentHtml { get; set; } = string.Empty;
    
    /// <summary>
    /// Usuario que realiz� el cambio
    /// </summary>
    public string ModifiedByUserId { get; set; } = string.Empty;
    
    /// <summary>
    /// Raz�n del cambio
    /// </summary>
    public string ChangeReason { get; set; } = string.Empty;
    
    /// <summary>
    /// Fecha del cambio
    /// </summary>
    public DateTime ChangedAt { get; set; } = DateTime.UtcNow;
}

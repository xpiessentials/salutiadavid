namespace Salutia_Wep_App.Models.PsychosomaticTest;

/// <summary>
/// Representa un test psicosom�tico completo realizado por un paciente
/// </summary>
public class PsychosomaticTest
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del paciente que realiz� el test
    /// </summary>
    public string PatientUserId { get; set; } = string.Empty;
    
    /// <summary>
    /// Fecha de inicio del test
    /// </summary>
    public DateTime StartedAt { get; set; } = DateTime.UtcNow;
    
    /// <summary>
    /// Fecha de finalizaci�n del test
    /// </summary>
    public DateTime? CompletedAt { get; set; }
    
    /// <summary>
    /// Indica si el test fue completado
    /// </summary>
    public bool IsCompleted { get; set; }
    
    /// <summary>
    /// Palabras que causan malestar (10 palabras)
    /// </summary>
    public ICollection<TestWord> Words { get; set; } = new List<TestWord>();
    
    /// <summary>
    /// Matriz final con todas las respuestas consolidadas
    /// </summary>
    public ICollection<TestMatrix> MatrixResults { get; set; } = new List<TestMatrix>();
}

/// <summary>
/// Representa cada una de las 10 palabras y sus respuestas asociadas
/// </summary>
public class TestWord
{
    public int Id { get; set; }
    
 /// <summary>
    /// ID del test psicosom�tico
    /// </summary>
    public int PsychosomaticTestId { get; set; }
    public PsychosomaticTest PsychosomaticTest { get; set; } = null!;
 
    /// <summary>
    /// N�mero de orden de la palabra (1-10)
    /// </summary>
    public int WordNumber { get; set; }
    
    /// <summary>
    /// La palabra que causa malestar
    /// </summary>
    public string Word { get; set; } = string.Empty;
    
/// <summary>
    /// Fecha en que se registr� la palabra
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Representa la frase asociada a cada palabra
/// </summary>
public class TestPhrase
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del test psicosom�tico
    /// </summary>
    public int PsychosomaticTestId { get; set; }
    public PsychosomaticTest PsychosomaticTest { get; set; } = null!;
    
    /// <summary>
    /// N�mero de orden (1-10) que relaciona con TestWord
    /// </summary>
    public int WordNumber { get; set; }
    
    /// <summary>
    /// La frase asociada a la palabra
    /// </summary>
    public string Phrase { get; set; } = string.Empty;
    
    /// <summary>
    /// Fecha en que se registr� la frase
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Representa la emoci�n asociada a cada frase
/// </summary>
public class TestEmotion
{
    public int Id { get; set; }
    
    /// <summary>
 /// ID del test psicosom�tico
    /// </summary>
    public int PsychosomaticTestId { get; set; }
    public PsychosomaticTest PsychosomaticTest { get; set; } = null!;
    
 /// <summary>
    /// N�mero de orden (1-10) que relaciona con TestWord y TestPhrase
    /// </summary>
    public int WordNumber { get; set; }
    
    /// <summary>
    /// La emoci�n sentida
    /// </summary>
    public string Emotion { get; set; } = string.Empty;
    
    /// <summary>
  /// Fecha en que se registr� la emoci�n
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Representa el nivel de malestar (1-10) para cada palabra/frase
/// </summary>
public class TestDiscomfortLevel
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del test psicosom�tico
    /// </summary>
    public int PsychosomaticTestId { get; set; }
    public PsychosomaticTest PsychosomaticTest { get; set; } = null!;
    
    /// <summary>
    /// N�mero de orden (1-10) que relaciona con TestWord
    /// </summary>
    public int WordNumber { get; set; }
    
    /// <summary>
    /// Nivel de malestar (1-10)
    /// </summary>
    public int DiscomfortLevel { get; set; }
    
    /// <summary>
    /// Fecha en que se registr� el nivel
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Representa la edad a la que sinti� el malestar
/// </summary>
public class TestAge
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del test psicosom�tico
    /// </summary>
    public int PsychosomaticTestId { get; set; }
    public PsychosomaticTest PsychosomaticTest { get; set; } = null!;
    
    /// <summary>
    /// N�mero de orden (1-10) que relaciona con TestWord
    /// </summary>
    public int WordNumber { get; set; }
    
    /// <summary>
    /// Edad a la que sinti� el malestar
    /// </summary>
    public string Age { get; set; } = string.Empty;
    
    /// <summary>
    /// Fecha en que se registr�
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Representa la parte del cuerpo donde se siente el malestar
/// </summary>
public class TestBodyPart
{
    public int Id { get; set; }
    
    /// <summary>
    /// ID del test psicosom�tico
    /// </summary>
    public int PsychosomaticTestId { get; set; }
    public PsychosomaticTest PsychosomaticTest { get; set; } = null!;
  
    /// <summary>
    /// N�mero de orden (1-10) que relaciona con TestWord
    /// </summary>
    public int WordNumber { get; set; }
  
    /// <summary>
    /// Parte del cuerpo donde se siente el malestar
    /// </summary>
    public string BodyPart { get; set; } = string.Empty;
    
    /// <summary>
    /// Fecha en que se registr�
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Representa la persona asociada al malestar
/// </summary>
public class TestAssociatedPerson
{
 public int Id { get; set; }
    
    /// <summary>
    /// ID del test psicosom�tico
    /// </summary>
    public int PsychosomaticTestId { get; set; }
    public PsychosomaticTest PsychosomaticTest { get; set; } = null!;
    
    /// <summary>
    /// N�mero de orden (1-10) que relaciona con TestWord
    /// </summary>
    public int WordNumber { get; set; }
    
    /// <summary>
    /// Persona asociada al malestar
    /// </summary>
  public string PersonName { get; set; } = string.Empty;
    
    /// <summary>
/// Fecha en que se registr�
 /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Matriz consolidada con todas las respuestas por palabra
/// Esta es la tabla final que consolida toda la informaci�n
/// </summary>
public class TestMatrix
{
    public int Id { get; set; }
    
 /// <summary>
    /// ID del test psicosom�tico
    /// </summary>
    public int PsychosomaticTestId { get; set; }
 public PsychosomaticTest PsychosomaticTest { get; set; } = null!;
    
  /// <summary>
    /// N�mero de orden de la palabra (1-10)
    /// </summary>
    public int WordNumber { get; set; }
    
    /// <summary>
    /// Palabra que causa malestar
    /// </summary>
    public string Word { get; set; } = string.Empty;
    
    /// <summary>
    /// Frase asociada a la palabra
    /// </summary>
    public string Phrase { get; set; } = string.Empty;
    
    /// <summary>
    /// Emoci�n sentida
    /// </summary>
 public string Emotion { get; set; } = string.Empty;
    
    /// <summary>
    /// Nivel de malestar (1-10)
    /// </summary>
    public int DiscomfortLevel { get; set; }
    
    /// <summary>
    /// Edad a la que sinti� el malestar
    /// </summary>
    public string Age { get; set; } = string.Empty;
    
    /// <summary>
    /// Parte del cuerpo donde se siente
    /// </summary>
    public string BodyPart { get; set; } = string.Empty;
    
    /// <summary>
    /// Persona asociada al malestar
    /// </summary>
    public string AssociatedPerson { get; set; } = string.Empty;
    
 /// <summary>
    /// Fecha de creaci�n del registro de matriz
    /// </summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

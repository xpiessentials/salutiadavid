# Como Agregar la Imagen del Hero Banner

## Estado Actual
La pagina Home funciona con o sin la imagen. Si no encuentra la imagen, muestra un degradado de fondo.

## Pasos para Agregar la Imagen

### 1. Preparar la Imagen
- Guarda la imagen como: `hero-banner.jpg`
- Tambien puedes usar `.png` o `.webp`

### 2. Ubicacion del Archivo
Coloca la imagen en:
```
Salutia Wep App\wwwroot\images\hero-banner.jpg
```

### 3. En Visual Studio
1. Clic derecho en la carpeta `wwwroot/images/`
2. "Agregar" ? "Elemento existente..."
3. Selecciona `hero-banner.jpg`
4. Haz clic en "Agregar"

### 4. Verificar Propiedades
1. Clic derecho en `hero-banner.jpg`
2. "Propiedades"
3. Verificar:
   - "Accion de compilacion" = `Content`
   - "Copiar en directorio de salida" = `Copiar si es posterior`

## Verificacion

Ejecuta la aplicacion y navega a la pagina principal:
- Con imagen: Veras la foto de fondo con personas
- Sin imagen: Veras degradado morado/azul (tambien funciona)

## Solucion de Problemas

### Error 404
- Verifica que la carpeta sea: `wwwroot/images/`
- Verifica que el archivo se llame: `hero-banner.jpg`
- Asegurate de que este en el proyecto (visible en Explorador de Soluciones)

### La Imagen no Aparece
1. Build ? Clean Solution
2. Build ? Rebuild Solution
3. Ejecuta nuevamente (F5)
4. En el navegador: Ctrl + Shift + R (recarga forzada)

## Optimizacion Recomendada
- Dimensiones: 1920x600px o 1600x500px
- Peso: Menos de 500KB
- Formato: JPG o WebP

## Nota
La carpeta `images/` ya existe en tu proyecto. Solo necesitas copiar el archivo.

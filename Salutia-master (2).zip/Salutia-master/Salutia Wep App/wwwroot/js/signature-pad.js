// ============================================
// Signature Pad JavaScript Component
// Proyecto: Salutia - Plataforma de Salud Ocupacional
// Descripci�n: Manejo de firma digital en canvas HTML5
// ============================================

window.signaturePad = {
    canvasElement: null,
    context: null,
    isDrawing: false,
    lastX: 0,
    lastY: 0,
    hasSignature: false,

    /**
     * Inicializa el pad de firma en un canvas
     * @param {string} canvasId - ID del elemento canvas
     * @param {number} width - Ancho del canvas
     * @param {number} height - Alto del canvas
     */
    initialize: function (canvasId, width, height) {
        try {
            this.canvasElement = document.getElementById(canvasId);
            if (!this.canvasElement) {
                console.error('Canvas element not found:', canvasId);
                return false;
            }

            // Configurar tama�o del canvas
            this.canvasElement.width = width || 400;
            this.canvasElement.height = height || 200;

            this.context = this.canvasElement.getContext('2d');
            if (!this.context) {
                console.error('Could not get 2D context');
                return false;
            }

            // Configurar estilos de dibujo
            this.context.strokeStyle = '#000000';
            this.context.lineWidth = 2;
            this.context.lineCap = 'round';
            this.context.lineJoin = 'round';

            // Limpiar canvas con fondo blanco
            this.clearCanvas();

            // Registrar eventos
            this.registerEvents();

            console.log('Signature pad initialized successfully');
            return true;
        } catch (error) {
            console.error('Error initializing signature pad:', error);
            return false;
        }
    },

    /**
     * Registra los eventos de mouse y touch
     */
    registerEvents: function () {
        // Eventos de mouse
        this.canvasElement.addEventListener('mousedown', this.startDrawing.bind(this));
        this.canvasElement.addEventListener('mousemove', this.draw.bind(this));
        this.canvasElement.addEventListener('mouseup', this.stopDrawing.bind(this));
        this.canvasElement.addEventListener('mouseleave', this.stopDrawing.bind(this));

        // Eventos t�ctiles (m�viles)
        this.canvasElement.addEventListener('touchstart', this.handleTouchStart.bind(this));
        this.canvasElement.addEventListener('touchmove', this.handleTouchMove.bind(this));
        this.canvasElement.addEventListener('touchend', this.stopDrawing.bind(this));
        this.canvasElement.addEventListener('touchcancel', this.stopDrawing.bind(this));

        // Prevenir scroll en dispositivos t�ctiles mientras se dibuja
        this.canvasElement.addEventListener('touchstart', function (e) {
            if (e.target === this.canvasElement) {
                e.preventDefault();
            }
        }.bind(this), { passive: false });

        this.canvasElement.addEventListener('touchmove', function (e) {
            if (e.target === this.canvasElement) {
                e.preventDefault();
            }
        }.bind(this), { passive: false });
    },

    /**
     * Inicia el trazo de dibujo
     */
    startDrawing: function (e) {
        this.isDrawing = true;
        const coords = this.getCoordinates(e);
        this.lastX = coords.x;
        this.lastY = coords.y;

        // Iniciar un nuevo path
        this.context.beginPath();
        this.context.moveTo(this.lastX, this.lastY);
    },

    /**
     * Dibuja en el canvas
     */
    draw: function (e) {
        if (!this.isDrawing) return;

        const coords = this.getCoordinates(e);

        this.context.lineTo(coords.x, coords.y);
        this.context.stroke();

        this.lastX = coords.x;
        this.lastY = coords.y;
        this.hasSignature = true;
    },

    /**
     * Detiene el trazo de dibujo
     */
    stopDrawing: function () {
        if (this.isDrawing) {
            this.context.closePath();
            this.isDrawing = false;
        }
    },

    /**
     * Maneja el inicio de un toque t�ctil
     */
    handleTouchStart: function (e) {
        if (e.touches.length === 1) {
            const touch = e.touches[0];
            const mouseEvent = new MouseEvent('mousedown', {
                clientX: touch.clientX,
                clientY: touch.clientY
            });
            this.canvasElement.dispatchEvent(mouseEvent);
        }
    },

    /**
     * Maneja el movimiento de un toque t�ctil
     */
    handleTouchMove: function (e) {
        if (e.touches.length === 1) {
            const touch = e.touches[0];
            const mouseEvent = new MouseEvent('mousemove', {
                clientX: touch.clientX,
                clientY: touch.clientY
            });
            this.canvasElement.dispatchEvent(mouseEvent);
        }
    },

    /**
     * Obtiene las coordenadas del mouse/touch relativas al canvas
     */
    getCoordinates: function (e) {
        const rect = this.canvasElement.getBoundingClientRect();
        const scaleX = this.canvasElement.width / rect.width;
        const scaleY = this.canvasElement.height / rect.height;

        return {
            x: (e.clientX - rect.left) * scaleX,
            y: (e.clientY - rect.top) * scaleY
        };
    },

    /**
     * Limpia el canvas y reinicia
     */
    clearCanvas: function () {
        if (!this.context) return;

        // Limpiar completamente
        this.context.clearRect(0, 0, this.canvasElement.width, this.canvasElement.height);

        // Fondo blanco
        this.context.fillStyle = '#FFFFFF';
        this.context.fillRect(0, 0, this.canvasElement.width, this.canvasElement.height);

        // Restaurar estilo de trazo
        this.context.strokeStyle = '#000000';
        this.context.lineWidth = 2;
        this.context.lineCap = 'round';
        this.context.lineJoin = 'round';

        this.hasSignature = false;
        console.log('Canvas cleared');
    },

    /**
     * Verifica si hay una firma dibujada
     */
    isEmpty: function () {
        return !this.hasSignature;
    },

    /**
     * Obtiene la firma como imagen base64 PNG
     */
    getSignatureDataUrl: function () {
        if (!this.canvasElement) {
            console.error('Canvas not initialized');
            return null;
        }

        if (this.isEmpty()) {
            console.warn('Signature is empty');
            return null;
        }

        try {
            // Convertir canvas a base64 PNG
            const dataUrl = this.canvasElement.toDataURL('image/png');
            console.log('Signature captured successfully');
            return dataUrl;
        } catch (error) {
            console.error('Error capturing signature:', error);
            return null;
        }
    },

    /**
     * Carga una firma desde base64
     */
    loadSignatureFromDataUrl: function (dataUrl) {
        if (!this.canvasElement || !dataUrl) {
            console.error('Canvas not initialized or invalid data URL');
            return false;
        }

        try {
            const image = new Image();
            image.onload = function () {
                this.context.clearRect(0, 0, this.canvasElement.width, this.canvasElement.height);
                this.context.fillStyle = '#FFFFFF';
                this.context.fillRect(0, 0, this.canvasElement.width, this.canvasElement.height);
                this.context.drawImage(image, 0, 0);
                this.hasSignature = true;
                console.log('Signature loaded successfully');
            }.bind(this);

            image.onerror = function (error) {
                console.error('Error loading signature image:', error);
            };

            image.src = dataUrl;
            return true;
        } catch (error) {
            console.error('Error loading signature:', error);
            return false;
        }
    },

    /**
     * Redimensiona el canvas (�til para responsive)
     */
    resize: function (width, height) {
        if (!this.canvasElement) return false;

        // Guardar el contenido actual
        const dataUrl = this.hasSignature ? this.canvasElement.toDataURL('image/png') : null;

        // Redimensionar
        this.canvasElement.width = width;
        this.canvasElement.height = height;

        // Reconfigurar contexto
        this.context = this.canvasElement.getContext('2d');
        this.context.strokeStyle = '#000000';
        this.context.lineWidth = 2;
        this.context.lineCap = 'round';
        this.context.lineJoin = 'round';

        // Limpiar con fondo blanco
        this.context.fillStyle = '#FFFFFF';
        this.context.fillRect(0, 0, width, height);

        // Restaurar contenido si exist�a
        if (dataUrl) {
            this.loadSignatureFromDataUrl(dataUrl);
        }

        return true;
    },

    /**
     * Destruye el componente y libera recursos
     */
    destroy: function () {
        if (this.canvasElement) {
            // Remover event listeners
            const newCanvas = this.canvasElement.cloneNode(true);
            this.canvasElement.parentNode.replaceChild(newCanvas, this.canvasElement);
        }

        this.canvasElement = null;
        this.context = null;
        this.isDrawing = false;
        this.hasSignature = false;
        console.log('Signature pad destroyed');
    }
};

// Exportar para uso en m�dulos
if (typeof module !== 'undefined' && module.exports) {
    module.exports = window.signaturePad;
}

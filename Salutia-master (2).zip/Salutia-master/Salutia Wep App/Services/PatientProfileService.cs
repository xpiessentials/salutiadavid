using Microsoft.EntityFrameworkCore;
using Salutia_Wep_App.Data;
using Salutia_Wep_App.Models.Patient;

namespace Salutia_Wep_App.Services;

/// <summary>
/// Servicio para gestionar el perfil del paciente y validar su completitud
/// </summary>
public interface IPatientProfileService
{
    /// <summary>
    /// Verifica si el perfil del paciente est� completo
    /// </summary>
    Task<bool> IsProfileCompleteAsync(int patientProfileId);
    
    /// <summary>
    /// Obtiene el perfil completo del paciente con todas sus relaciones
    /// </summary>
    Task<PatientProfile?> GetCompleteProfileAsync(int patientProfileId);
    
    /// <summary>
    /// Obtiene el perfil del paciente por ID de usuario
    /// </summary>
    Task<PatientProfile?> GetProfileByUserIdAsync(string userId);
    
    /// <summary>
    /// Actualiza la informaci�n b�sica del perfil del paciente
    /// </summary>
    Task<bool> UpdateBasicInfoAsync(PatientProfile profile);
    
    /// <summary>
    /// Agrega o actualiza el historial m�dico del paciente
    /// </summary>
    Task<bool> SaveMedicalHistoryAsync(int patientProfileId, List<PatientMedicalHistory> histories);
    
    /// <summary>
    /// Agrega o actualiza las medicaciones del paciente
    /// </summary>
    Task<bool> SaveMedicationsAsync(int patientProfileId, List<PatientMedication> medications);
    
    /// <summary>
    /// Agrega o actualiza las alergias del paciente
    /// </summary>
    Task<bool> SaveAllergiesAsync(int patientProfileId, List<PatientAllergy> allergies);
    
    /// <summary>
    /// Agrega o actualiza los contactos de emergencia del paciente
    /// </summary>
    Task<bool> SaveEmergencyContactsAsync(int patientProfileId, List<PatientEmergencyContact> contacts);
    
    /// <summary>
    /// Marca el perfil del paciente como completo
    /// </summary>
    Task<bool> MarkProfileAsCompleteAsync(int patientProfileId);
    
    /// <summary>
    /// Obtiene la lista de campos faltantes en el perfil
    /// </summary>
    Task<List<string>> GetMissingFieldsAsync(int patientProfileId);
    
    /// <summary>
    /// Obtiene todos los maestros necesarios para el formulario
    /// </summary>
    Task<PatientFormMasterData> GetFormMasterDataAsync();
}

/// <summary>
/// Datos maestros para el formulario de paciente
/// </summary>
public class PatientFormMasterData
{
    public List<Occupation> Occupations { get; set; } = new();
    public List<MaritalStatus> MaritalStatuses { get; set; } = new();
    public List<EducationLevel> EducationLevels { get; set; } = new();
    public List<Country> Countries { get; set; } = new();
}

public class PatientProfileService : IPatientProfileService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<PatientProfileService> _logger;

    public PatientProfileService(
        ApplicationDbContext context,
        ILogger<PatientProfileService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<bool> IsProfileCompleteAsync(int patientProfileId)
    {
        try
        {
            var profile = await _context.PatientProfiles
                .Include(p => p.EmergencyContacts)
                .FirstOrDefaultAsync(p => p.Id == patientProfileId);

            if (profile == null) return false;

            // Validar campos obligatorios
            var isComplete = !string.IsNullOrWhiteSpace(profile.FullName) &&
                           profile.DateOfBirth.HasValue &&
                           !string.IsNullOrWhiteSpace(profile.Gender) &&
                           !string.IsNullOrWhiteSpace(profile.Phone) &&
                           !string.IsNullOrWhiteSpace(profile.Address) &&
                           profile.CountryId.HasValue &&
                           profile.StateId.HasValue &&
                           profile.CityId.HasValue &&
                           profile.OccupationId.HasValue &&
                           profile.MaritalStatusId.HasValue &&
                           profile.EducationLevelId.HasValue &&
                           profile.EmergencyContacts.Any(c => c.IsPrimary);

            return isComplete;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error verificando completitud del perfil {PatientProfileId}", patientProfileId);
            return false;
        }
    }

    public async Task<PatientProfile?> GetCompleteProfileAsync(int patientProfileId)
    {
        try
        {
            return await _context.PatientProfiles
                .Include(p => p.ApplicationUser)
                .Include(p => p.Country)
                .Include(p => p.State)
                .Include(p => p.City)
                .Include(p => p.Occupation)
                .Include(p => p.MaritalStatus)
                .Include(p => p.EducationLevel)
                .Include(p => p.MedicalHistories)
                .Include(p => p.CurrentMedications)
                .Include(p => p.Allergies)
                .Include(p => p.EmergencyContacts)
                .FirstOrDefaultAsync(p => p.Id == patientProfileId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo perfil completo {PatientProfileId}", patientProfileId);
            return null;
        }
    }

    public async Task<PatientProfile?> GetProfileByUserIdAsync(string userId)
    {
        try
        {
            return await _context.PatientProfiles
                .Include(p => p.ApplicationUser)
                .Include(p => p.Country)
                .Include(p => p.State)
                .Include(p => p.City)
                .Include(p => p.Occupation)
                .Include(p => p.MaritalStatus)
                .Include(p => p.EducationLevel)
                .Include(p => p.MedicalHistories)
                .Include(p => p.CurrentMedications)
                .Include(p => p.Allergies)
                .Include(p => p.EmergencyContacts)
                .FirstOrDefaultAsync(p => p.ApplicationUserId == userId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo perfil por UserId {UserId}", userId);
            return null;
        }
    }

    public async Task<bool> UpdateBasicInfoAsync(PatientProfile profile)
    {
        try
        {
            _context.PatientProfiles.Update(profile);
            await _context.SaveChangesAsync();
            
            _logger.LogInformation("Perfil b�sico actualizado para paciente {PatientProfileId}", profile.Id);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error actualizando perfil b�sico {PatientProfileId}", profile.Id);
            return false;
        }
    }

    public async Task<bool> SaveMedicalHistoryAsync(int patientProfileId, List<PatientMedicalHistory> histories)
    {
        try
        {
            // Eliminar historiales anteriores
            var existing = await _context.PatientMedicalHistories
                .Where(h => h.PatientProfileId == patientProfileId)
                .ToListAsync();
            
            _context.PatientMedicalHistories.RemoveRange(existing);
            
            // Agregar nuevos historiales
            if (histories.Any())
            {
                foreach (var history in histories)
                {
                    history.PatientProfileId = patientProfileId;
                }
                await _context.PatientMedicalHistories.AddRangeAsync(histories);
            }
            
            await _context.SaveChangesAsync();
            
            _logger.LogInformation("Historial m�dico guardado para paciente {PatientProfileId}", patientProfileId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error guardando historial m�dico {PatientProfileId}", patientProfileId);
            return false;
        }
    }

    public async Task<bool> SaveMedicationsAsync(int patientProfileId, List<PatientMedication> medications)
    {
        try
        {
            // Eliminar medicaciones anteriores
            var existing = await _context.PatientMedications
                .Where(m => m.PatientProfileId == patientProfileId)
                .ToListAsync();
            
            _context.PatientMedications.RemoveRange(existing);
            
            // Agregar nuevas medicaciones
            if (medications.Any())
            {
                foreach (var medication in medications)
                {
                    medication.PatientProfileId = patientProfileId;
                }
                await _context.PatientMedications.AddRangeAsync(medications);
            }
            
            await _context.SaveChangesAsync();
            
            _logger.LogInformation("Medicaciones guardadas para paciente {PatientProfileId}", patientProfileId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error guardando medicaciones {PatientProfileId}", patientProfileId);
            return false;
        }
    }

    public async Task<bool> SaveAllergiesAsync(int patientProfileId, List<PatientAllergy> allergies)
    {
        try
        {
            // Eliminar alergias anteriores
            var existing = await _context.PatientAllergies
                .Where(a => a.PatientProfileId == patientProfileId)
                .ToListAsync();
            
            _context.PatientAllergies.RemoveRange(existing);
            
            // Agregar nuevas alergias
            if (allergies.Any())
            {
                foreach (var allergy in allergies)
                {
                    allergy.PatientProfileId = patientProfileId;
                }
                await _context.PatientAllergies.AddRangeAsync(allergies);
            }
            
            await _context.SaveChangesAsync();
            
            _logger.LogInformation("Alergias guardadas para paciente {PatientProfileId}", patientProfileId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error guardando alergias {PatientProfileId}", patientProfileId);
            return false;
        }
    }

    public async Task<bool> SaveEmergencyContactsAsync(int patientProfileId, List<PatientEmergencyContact> contacts)
    {
        try
        {
            // Eliminar contactos anteriores
            var existing = await _context.PatientEmergencyContacts
                .Where(c => c.PatientProfileId == patientProfileId)
                .ToListAsync();
            
            _context.PatientEmergencyContacts.RemoveRange(existing);
            
            // Agregar nuevos contactos
            if (contacts.Any())
            {
                // Asegurar que solo haya un contacto primario
                var primaryCount = contacts.Count(c => c.IsPrimary);
                if (primaryCount == 0 && contacts.Any())
                {
                    contacts.First().IsPrimary = true;
                }
                else if (primaryCount > 1)
                {
                    var firstPrimary = contacts.First(c => c.IsPrimary);
                    foreach (var contact in contacts.Where(c => c.IsPrimary && c != firstPrimary))
                    {
                        contact.IsPrimary = false;
                    }
                }
                
                foreach (var contact in contacts)
                {
                    contact.PatientProfileId = patientProfileId;
                }
                await _context.PatientEmergencyContacts.AddRangeAsync(contacts);
            }
            
            await _context.SaveChangesAsync();
            
            _logger.LogInformation("Contactos de emergencia guardados para paciente {PatientProfileId}", patientProfileId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error guardando contactos de emergencia {PatientProfileId}", patientProfileId);
            return false;
        }
    }

    public async Task<bool> MarkProfileAsCompleteAsync(int patientProfileId)
    {
        try
        {
            var profile = await _context.PatientProfiles.FindAsync(patientProfileId);
            if (profile == null) return false;

            profile.ProfileCompleted = true;
            await _context.SaveChangesAsync();
            
            _logger.LogInformation("Perfil marcado como completo para paciente {PatientProfileId}", patientProfileId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error marcando perfil como completo {PatientProfileId}", patientProfileId);
            return false;
        }
    }

    public async Task<List<string>> GetMissingFieldsAsync(int patientProfileId)
    {
        var missingFields = new List<string>();

        try
        {
            var profile = await _context.PatientProfiles
                .Include(p => p.EmergencyContacts)
                .FirstOrDefaultAsync(p => p.Id == patientProfileId);

            if (profile == null) return missingFields;

            if (string.IsNullOrWhiteSpace(profile.FullName))
                missingFields.Add("Nombre Completo");
            
            if (!profile.DateOfBirth.HasValue)
                missingFields.Add("Fecha de Nacimiento");
            
            if (string.IsNullOrWhiteSpace(profile.Gender))
                missingFields.Add("G�nero");
            
            if (string.IsNullOrWhiteSpace(profile.Phone))
                missingFields.Add("Tel�fono");
            
            if (string.IsNullOrWhiteSpace(profile.Address))
                missingFields.Add("Direcci�n");
            
            if (!profile.CountryId.HasValue)
                missingFields.Add("Pa�s");
            
            if (!profile.StateId.HasValue)
                missingFields.Add("Estado/Departamento");
            
            if (!profile.CityId.HasValue)
                missingFields.Add("Ciudad");
            
            if (!profile.OccupationId.HasValue)
                missingFields.Add("Ocupaci�n");
            
            if (!profile.MaritalStatusId.HasValue)
                missingFields.Add("Estado Civil");
            
            if (!profile.EducationLevelId.HasValue)
                missingFields.Add("Nivel Educativo");
            
            if (!profile.EmergencyContacts.Any(c => c.IsPrimary))
                missingFields.Add("Contacto de Emergencia Principal");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo campos faltantes {PatientProfileId}", patientProfileId);
        }

        return missingFields;
    }

    public async Task<PatientFormMasterData> GetFormMasterDataAsync()
    {
        try
        {
            var masterData = new PatientFormMasterData
            {
                Occupations = await _context.Occupations
                    .Where(o => o.IsActive)
                    .OrderBy(o => o.DisplayOrder)
                    .ToListAsync(),
                
                MaritalStatuses = await _context.MaritalStatuses
                    .Where(m => m.IsActive)
                    .OrderBy(m => m.DisplayOrder)
                    .ToListAsync(),
                
                EducationLevels = await _context.EducationLevels
                    .Where(e => e.IsActive)
                    .OrderBy(e => e.DisplayOrder)
                    .ToListAsync(),
                
                Countries = await _context.Countries
                    .OrderBy(c => c.Name)
                    .ToListAsync()
            };

            return masterData;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo datos maestros del formulario");
            return new PatientFormMasterData();
        }
    }
}

using Microsoft.EntityFrameworkCore;
using Salutia_Wep_App.Data;
using Salutia_Wep_App.Models.Consent;
using System.Security.Cryptography;
using System.Text;

namespace Salutia_Wep_App.Services;

/// <summary>
/// Servicio para gestionar consentimientos informados digitales
/// </summary>
public interface IConsentService
{
    // Gesti�n de Plantillas
    Task<List<ConsentTemplate>> GetActiveTemplatesAsync(int? entityId = null);
    Task<ConsentTemplate?> GetTemplateByCodeAsync(string code, int? entityId = null);
    Task<ConsentTemplate> CreateTemplateAsync(ConsentTemplate template, string modifiedByUserId);
    Task<ConsentTemplate> UpdateTemplateAsync(int templateId, string newContent, string modifiedByUserId, string changeReason);
    Task<bool> DeactivateTemplateAsync(int templateId);
    
    // Gesti�n de Consentimientos del Paciente
    Task<List<PatientConsent>> GetConsentsByTestAsync(int psychosomaticTestId);
    Task<bool> HasSignedAllRequiredConsentsAsync(int psychosomaticTestId);
    Task<PatientConsent> SaveConsentAsync(PatientConsent consent, ConsentSignature signature);
    
    // Generaci�n de PDFs
    Task<string> GenerateConsentPdfAsync(int patientConsentId);
    Task<string> GenerateAllConsentsPdfPackageAsync(int psychosomaticTestId);
    
    // Descarga y Auditor�a
    Task<ConsentDocument?> GetDocumentAsync(int documentId);
    Task RegisterDownloadAsync(int documentId, string downloadedByUserId);
    Task<List<ConsentDocument>> GetDocumentsByTestAsync(int psychosomaticTestId);
    
    // Auditor�a
    Task<List<ConsentTemplateHistory>> GetTemplateHistoryAsync(int templateId);
    Task<bool> ValidateConsentIntegrityAsync(int documentId);
}

public class ConsentService : IConsentService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<ConsentService> _logger;
    private readonly IWebHostEnvironment _env;
    private readonly IPdfGenerationService _pdfService;
    private readonly string _consentPdfPath;

    public ConsentService(
        ApplicationDbContext context,
        ILogger<ConsentService> logger,
        IWebHostEnvironment env,
        IPdfGenerationService pdfService)
    {
        _context = context;
        _logger = logger;
        _env = env;
        _pdfService = pdfService;
        _consentPdfPath = Path.Combine(_env.WebRootPath, "consents", "pdfs");
        
        // Crear directorio si no existe
        if (!Directory.Exists(_consentPdfPath))
        {
            Directory.CreateDirectory(_consentPdfPath);
        }
    }

    #region Gesti�n de Plantillas

    public async Task<List<ConsentTemplate>> GetActiveTemplatesAsync(int? entityId = null)
    {
        try
        {
            var query = _context.ConsentTemplates
                .Where(t => t.IsActive)
                .AsQueryable();

            if (entityId.HasValue)
            {
                // Plantillas espec�ficas de la entidad O plantillas globales
                query = query.Where(t => t.EntityId == entityId || t.EntityId == null);
            }
            else
            {
                // Solo plantillas globales
                query = query.Where(t => t.EntityId == null);
            }

            return await query
                .OrderBy(t => t.DisplayOrder)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo plantillas activas para EntityId: {EntityId}", entityId);
            return new List<ConsentTemplate>();
        }
    }

    public async Task<ConsentTemplate?> GetTemplateByCodeAsync(string code, int? entityId = null)
    {
        try
        {
            var query = _context.ConsentTemplates
                .Where(t => t.Code == code && t.IsActive)
                .AsQueryable();

            if (entityId.HasValue)
            {
                query = query.Where(t => t.EntityId == entityId || t.EntityId == null);
            }
            else
            {
                query = query.Where(t => t.EntityId == null);
            }

            // Preferir plantilla de entidad sobre plantilla global
            return await query
                .OrderByDescending(t => t.EntityId)
                .FirstOrDefaultAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo plantilla con c�digo: {Code}", code);
            return null;
        }
    }

    public async Task<ConsentTemplate> CreateTemplateAsync(ConsentTemplate template, string modifiedByUserId)
    {
        try
        {
            template.Version = 1;
            template.ModifiedByUserId = modifiedByUserId;
            template.CreatedAt = DateTime.UtcNow;
            template.ModifiedAt = DateTime.UtcNow;

            _context.ConsentTemplates.Add(template);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Plantilla de consentimiento creada: {TemplateId} - {Code}", template.Id, template.Code);
            return template;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creando plantilla de consentimiento");
            throw;
        }
    }

    public async Task<ConsentTemplate> UpdateTemplateAsync(int templateId, string newContent, string modifiedByUserId, string changeReason)
    {
        try
        {
            var template = await _context.ConsentTemplates.FindAsync(templateId);
            if (template == null)
                throw new InvalidOperationException($"Plantilla {templateId} no encontrada");

            // Guardar en historial
            var history = new ConsentTemplateHistory
            {
                ConsentTemplateId = template.Id,
                PreviousVersion = template.Version,
                PreviousContentHtml = template.ContentHtml,
                ModifiedByUserId = modifiedByUserId,
                ChangeReason = changeReason,
                ChangedAt = DateTime.UtcNow
            };

            _context.ConsentTemplateHistories.Add(history);

            // Actualizar plantilla
            template.ContentHtml = newContent;
            template.Version++;
            template.ModifiedByUserId = modifiedByUserId;
            template.ModifiedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Plantilla actualizada: {TemplateId} - Nueva versi�n: {Version}", templateId, template.Version);
            return template;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error actualizando plantilla: {TemplateId}", templateId);
            throw;
        }
    }

    public async Task<bool> DeactivateTemplateAsync(int templateId)
    {
        try
        {
            var template = await _context.ConsentTemplates.FindAsync(templateId);
            if (template == null) return false;

            template.IsActive = false;
            template.ModifiedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Plantilla desactivada: {TemplateId}", templateId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error desactivando plantilla: {TemplateId}", templateId);
            return false;
        }
    }

    #endregion

    #region Gesti�n de Consentimientos del Paciente

    public async Task<List<PatientConsent>> GetConsentsByTestAsync(int psychosomaticTestId)
    {
        try
        {
            return await _context.PatientConsents
                .Include(pc => pc.ConsentTemplate)
                .Include(pc => pc.Signature)
                .Where(pc => pc.PsychosomaticTestId == psychosomaticTestId)
                .OrderBy(pc => pc.ConsentTemplate.DisplayOrder)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo consentimientos para test: {TestId}", psychosomaticTestId);
            return new List<PatientConsent>();
        }
    }

    public async Task<bool> HasSignedAllRequiredConsentsAsync(int psychosomaticTestId)
    {
        try
        {
            // Obtener el test para saber el paciente y la entidad
            var test = await _context.PsychosomaticTests.FindAsync(psychosomaticTestId);
            if (test == null) return false;

            // Obtener paciente para saber la entidad
            var patient = await _context.PatientProfiles
                .FirstOrDefaultAsync(p => p.ApplicationUserId == test.PatientUserId);

            // Obtener plantillas requeridas
            var requiredTemplates = await GetActiveTemplatesAsync(patient?.EntityId);
            var requiredCount = requiredTemplates.Count(t => t.IsRequired);

            // Contar consentimientos firmados y aceptados
            var signedCount = await _context.PatientConsents
                .Where(pc => pc.PsychosomaticTestId == psychosomaticTestId && pc.IsAccepted)
                .CountAsync();

            return signedCount >= requiredCount;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error validando consentimientos para test: {TestId}", psychosomaticTestId);
            return false;
        }
    }

    public async Task<PatientConsent> SaveConsentAsync(PatientConsent consent, ConsentSignature signature)
    {
        using var transaction = await _context.Database.BeginTransactionAsync();
        try
        {
            // Guardar consentimiento
            _context.PatientConsents.Add(consent);
            await _context.SaveChangesAsync();

            // Asignar ID del consentimiento a la firma
            signature.PatientConsentId = consent.Id;
            _context.ConsentSignatures.Add(signature);
            await _context.SaveChangesAsync();

            await transaction.CommitAsync();

            _logger.LogInformation("Consentimiento guardado: {ConsentId} para test: {TestId}", 
                consent.Id, consent.PsychosomaticTestId);
            return consent;
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            _logger.LogError(ex, "Error guardando consentimiento");
            throw;
        }
    }

    #endregion

    #region Generaci�n de PDFs

    public async Task<string> GenerateConsentPdfAsync(int patientConsentId)
    {
        try
        {
            var consent = await _context.PatientConsents
                .Include(pc => pc.ConsentTemplate)
                .Include(pc => pc.Signature)
                .FirstOrDefaultAsync(pc => pc.Id == patientConsentId);

            if (consent == null)
                throw new InvalidOperationException($"Consentimiento {patientConsentId} no encontrado");

            // Nombre del archivo
            var fileName = $"consent_{consent.Id}_{DateTime.UtcNow:yyyyMMddHHmmss}.pdf";
            var filePath = Path.Combine(_consentPdfPath, fileName);
            var fileUrl = $"/consents/pdfs/{fileName}";

            // Generar PDF con QuestPDF
            await _pdfService.GenerateConsentPdfAsync(consent, filePath);

            // Calcular hash
            var fileHash = await CalculateFileHashAsync(filePath);
            var fileInfo = new FileInfo(filePath);

            // Actualizar consentimiento con rutas
            consent.PdfUrl = fileUrl;
            consent.PdfPath = filePath;

            // Crear registro de documento
            var document = new ConsentDocument
            {
                PsychosomaticTestId = consent.PsychosomaticTestId,
                PatientUserId = consent.PatientUserId,
                DocumentName = fileName,
                DocumentType = "IndividualConsent",
                DocumentUrl = fileUrl,
                DocumentPath = filePath,
                FileSizeBytes = fileInfo.Length,
                FileHash = fileHash,
                GeneratedAt = DateTime.UtcNow
            };

            _context.ConsentDocuments.Add(document);
            await _context.SaveChangesAsync();

            _logger.LogInformation("PDF generado para consentimiento: {ConsentId}", patientConsentId);
            return fileUrl;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando PDF para consentimiento: {ConsentId}", patientConsentId);
            throw;
        }
    }

    public async Task<string> GenerateAllConsentsPdfPackageAsync(int psychosomaticTestId)
    {
        try
        {
            var consents = await GetConsentsByTestAsync(psychosomaticTestId);
            if (!consents.Any())
                throw new InvalidOperationException($"No hay consentimientos para el test {psychosomaticTestId}");

            var test = await _context.PsychosomaticTests.FindAsync(psychosomaticTestId);
            if (test == null)
                throw new InvalidOperationException($"Test {psychosomaticTestId} no encontrado");

            // Obtener nombre del paciente
            var patient = await _context.PatientProfiles
                .FirstOrDefaultAsync(p => p.ApplicationUserId == test.PatientUserId);

            var patientName = patient?.FullName ?? "Paciente";

            // Nombre del paquete
            var fileName = $"consents_package_{psychosomaticTestId}_{DateTime.UtcNow:yyyyMMddHHmmss}.pdf";
            var filePath = Path.Combine(_consentPdfPath, fileName);
            var fileUrl = $"/consents/pdfs/{fileName}";

            // Generar PDF combinado con QuestPDF
            await _pdfService.GenerateConsentPackagePdfAsync(
                consents, 
                psychosomaticTestId.ToString(), 
                patientName, 
                filePath);

            // Calcular hash
            var fileHash = await CalculateFileHashAsync(filePath);
            var fileInfo = new FileInfo(filePath);

            // Crear registro de documento
            var document = new ConsentDocument
            {
                PsychosomaticTestId = psychosomaticTestId,
                PatientUserId = test.PatientUserId,
                DocumentName = fileName,
                DocumentType = "ConsentPackage",
                DocumentUrl = fileUrl,
                DocumentPath = filePath,
                FileSizeBytes = fileInfo.Length,
                FileHash = fileHash,
                GeneratedAt = DateTime.UtcNow
            };

            _context.ConsentDocuments.Add(document);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Paquete de PDFs generado para test: {TestId}", psychosomaticTestId);
            return fileUrl;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando paquete de PDFs para test: {TestId}", psychosomaticTestId);
            throw;
        }
    }

    #endregion

    #region Descarga y Auditor�a

    public async Task<ConsentDocument?> GetDocumentAsync(int documentId)
    {
        try
        {
            return await _context.ConsentDocuments.FindAsync(documentId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo documento: {DocumentId}", documentId);
            return null;
        }
    }

    public async Task RegisterDownloadAsync(int documentId, string downloadedByUserId)
    {
        try
        {
            var document = await _context.ConsentDocuments.FindAsync(documentId);
            if (document == null) return;

            document.DownloadedByUserId = downloadedByUserId;
            document.DownloadedAt = DateTime.UtcNow;
            document.DownloadCount++;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Descarga registrada para documento: {DocumentId} por usuario: {UserId}", 
                documentId, downloadedByUserId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error registrando descarga para documento: {DocumentId}", documentId);
        }
    }

    public async Task<List<ConsentDocument>> GetDocumentsByTestAsync(int psychosomaticTestId)
    {
        try
        {
            return await _context.ConsentDocuments
                .Where(d => d.PsychosomaticTestId == psychosomaticTestId)
                .OrderByDescending(d => d.GeneratedAt)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo documentos para test: {TestId}", psychosomaticTestId);
            return new List<ConsentDocument>();
        }
    }

    #endregion

    #region Auditor�a

    public async Task<List<ConsentTemplateHistory>> GetTemplateHistoryAsync(int templateId)
    {
        try
        {
            return await _context.ConsentTemplateHistories
                .Where(h => h.ConsentTemplateId == templateId)
                .OrderByDescending(h => h.ChangedAt)
                .ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo historial de plantilla: {TemplateId}", templateId);
            return new List<ConsentTemplateHistory>();
        }
    }

    public async Task<bool> ValidateConsentIntegrityAsync(int documentId)
    {
        try
        {
            var document = await _context.ConsentDocuments.FindAsync(documentId);
            if (document == null) return false;

            if (!File.Exists(document.DocumentPath)) return false;

            var currentHash = await CalculateFileHashAsync(document.DocumentPath);
            return currentHash == document.FileHash;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error validando integridad de documento: {DocumentId}", documentId);
            return false;
        }
    }

    #endregion

    #region M�todos Auxiliares

    private async Task<string> CalculateFileHashAsync(string filePath)
    {
        using var md5 = MD5.Create();
        using var stream = File.OpenRead(filePath);
        var hash = await md5.ComputeHashAsync(stream);
        return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
    }

    #endregion
}

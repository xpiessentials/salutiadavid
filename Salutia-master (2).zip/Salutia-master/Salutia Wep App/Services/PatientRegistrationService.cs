using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.WebUtilities;
using System.Text;
using System.Text.Encodings.Web;
using Salutia_Wep_App.Data;

namespace Salutia_Wep_App.Services;

/// <summary>
/// Servicio para registrar y gestionar pacientes de entidad
/// </summary>
public class PatientRegistrationService
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly ILogger<PatientRegistrationService> _logger;
    private readonly IEmailService _emailService;
    private readonly IConfiguration _configuration;

    public PatientRegistrationService(
        ApplicationDbContext context,
        UserManager<ApplicationUser> userManager,
        ILogger<PatientRegistrationService> logger,
        IEmailService emailService,
        IConfiguration configuration)
    {
        _context = context;
        _userManager = userManager;
        _logger = logger;
        _emailService = emailService;
        _configuration = configuration;
    }

    /// <summary>
    /// Registra un nuevo paciente de entidad
    /// El paciente recibir� un correo para establecer su contrase�a
    /// </summary>
    public async Task<(bool Success, string Message, PatientProfile? Patient)> RegisterEntityPatientAsync(
        int professionalId,
        DocumentType documentType,
        string documentNumber,
        string email)
    {
        try
        {
            // Validar que el profesional existe
            var professional = await _context.EntityProfessionalProfiles
                .Include(p => p.Entity)
                .FirstOrDefaultAsync(p => p.Id == professionalId);

            if (professional == null)
            {
                return (false, "Profesional no encontrado", null);
            }

            // Validar que el documento no est� registrado en esta entidad
            var existingPatient = await _context.PatientProfiles
                .FirstOrDefaultAsync(p => p.ProfessionalId == professionalId 
                    && p.DocumentNumber == documentNumber);

            if (existingPatient != null)
            {
                return (false, "Ya existe un paciente con este documento registrado por este profesional", null);
            }

            // Validar que el email no est� en uso
            var existingUser = await _userManager.FindByEmailAsync(email);
            if (existingUser != null)
            {
                return (false, "El email ya est� registrado en el sistema", null);
            }

            // Crear usuario de Identity SIN contrase�a
            var user = new ApplicationUser
            {
                UserName = documentNumber, // Username = n�mero de documento
                Email = email,
                EmailConfirmed = false, // NO confirmado - debe hacerlo por email
                UserType = UserType.Patient,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };

            // Crear usuario SIN contrase�a
            var result = await _userManager.CreateAsync(user);

            if (!result.Succeeded)
            {
                var errors = string.Join(", ", result.Errors.Select(e => e.Description));
                _logger.LogError("Error creando usuario paciente: {Errors}", errors);
                return (false, $"Error al crear usuario: {errors}", null);
            }

            // Asignar rol Patient
            await _userManager.AddToRoleAsync(user, "Patient");

            // Crear perfil de paciente
            var patientProfile = new PatientProfile
            {
                ApplicationUserId = user.Id,
                ProfessionalId = professionalId,
                IsEntityPatient = true,
                ProfileCompleted = false,
                FullName = "",
                DocumentType = documentType,
                DocumentNumber = documentNumber,
                Phone = null,
                DateOfBirth = null,
                Gender = null,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };

            _context.PatientProfiles.Add(patientProfile);
            await _context.SaveChangesAsync();

            // Generar token para establecer contrase�a
            var passwordToken = await _userManager.GeneratePasswordResetTokenAsync(user);
            var encodedToken = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(passwordToken));

            // Construir URL para establecer contrase�a
            var baseUrl = _configuration["AppSettings:BaseUrl"] ?? "https://localhost:7213";
            var callbackUrl = $"{baseUrl}/Account/SetPassword?userId={user.Id}&code={encodedToken}";

            // Enviar email de activaci�n
            await SendPatientActivationEmailAsync(email, documentNumber, callbackUrl);

            _logger.LogInformation(
                "Paciente de entidad creado exitosamente. DocumentNumber: {DocumentNumber}, Email: {Email}, Professional: {ProfessionalId}",
                documentNumber, email, professionalId);

            return (true, "Paciente registrado exitosamente. Se ha enviado un correo electr�nico para que establezca su contrase�a.", patientProfile);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al registrar paciente de entidad");
            return (false, "Error al registrar paciente. Por favor intente nuevamente.", null);
        }
    }

    /// <summary>
    /// Env�a un email de activaci�n al paciente
    /// </summary>
    private async Task SendPatientActivationEmailAsync(string email, string documentNumber, string activationLink)
    {
        var subject = "Bienvenido a Salutia - Activa tu cuenta";

        var htmlBody = $@"
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
        .button {{ display: inline-block; padding: 15px 30px; background: #28a745; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }}
        .info-box {{ background: #e3f2fd; border-left: 4px solid #2196f3; padding: 15px; margin: 20px 0; }}
        .footer {{ text-align: center; margin-top: 20px; color: #666; font-size: 12px; }}
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h1>?? Bienvenido a Salutia</h1>
            <p>Sistema de Gesti�n de Salud</p>
        </div>
        <div class='content'>
            <h2>�Has sido registrado como paciente!</h2>
            
            <p>Se ha creado una cuenta para ti en Salutia. Para activar tu cuenta, necesitas establecer tu contrase�a.</p>
            
            <div class='info-box'>
                <strong>?? Tus credenciales de acceso:</strong>
                <ul>
                    <li><strong>Usuario:</strong> {documentNumber}</li>
                    <li><strong>Contrase�a:</strong> La establecer�s t� mismo/a</li>
                </ul>
            </div>

            <p>Haz clic en el siguiente bot�n para establecer tu contrase�a y activar tu cuenta:</p>
            
            <div style='text-align: center;'>
                <a href='{activationLink}' class='button'>Establecer mi Contrase�a</a>
            </div>

            <p>Si el bot�n no funciona, copia y pega este enlace en tu navegador:</p>
            <p style='background: #e9ecef; padding: 10px; border-radius: 5px; word-break: break-all;'>{activationLink}</p>

            <div class='info-box'>
                <strong>?? Importante:</strong>
                <ul>
                    <li>Este enlace expirar� en 24 horas</li>
                    <li>Despu�s de establecer tu contrase�a, deber�s completar tu perfil</li>
                    <li>Tu usuario ser� siempre tu n�mero de documento: <strong>{documentNumber}</strong></li>
                </ul>
            </div>

            <p>Una vez activada tu cuenta, podr�s acceder a todas las funcionalidades de Salutia.</p>
        </div>
        <div class='footer'>
            <p>Este es un correo autom�tico, por favor no respondas.</p>
            <p>&copy; 2024 Salutia. Todos los derechos reservados.</p>
        </div>
    </div>
</body>
</html>";

        await _emailService.SendEmailAsync(email, subject, htmlBody);
        _logger.LogInformation("Email de activaci�n enviado a {Email}", email);
    }

    /// <summary>
    /// Completa el perfil de un paciente de entidad en su primer inicio de sesi�n
    /// </summary>
    public async Task<(bool Success, string Message)> CompletePatientProfileAsync(
        string userId,
        string fullName,
        string? phone,
        DateTime? dateOfBirth,
        string? gender,
        int? countryId,
        int? stateId,
        int? cityId,
        string? address)
    {
        try
        {
            var patient = await _context.PatientProfiles
                .Include(p => p.ApplicationUser)
                .FirstOrDefaultAsync(p => p.ApplicationUserId == userId);

            if (patient == null)
            {
                return (false, "Perfil de paciente no encontrado");
            }

            if (patient.ProfileCompleted)
            {
                return (false, "El perfil ya ha sido completado");
            }

            // Actualizar informaci�n del paciente
            patient.FullName = fullName;
            patient.Phone = phone;
            patient.DateOfBirth = dateOfBirth;
            patient.Gender = gender;
            patient.CountryId = countryId;
            patient.StateId = stateId;
            patient.CityId = cityId;
            patient.Address = address;
            patient.ProfileCompleted = true;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Perfil de paciente completado: {UserId}", userId);

            return (true, "Perfil completado exitosamente");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al completar perfil de paciente");
            return (false, "Error al guardar la informaci�n. Por favor intente nuevamente.");
        }
    }

    /// <summary>
    /// Verifica si un paciente necesita completar su perfil
    /// </summary>
    public async Task<bool> NeedsProfileCompletionAsync(string userId)
    {
        var patient = await _context.PatientProfiles
            .FirstOrDefaultAsync(p => p.ApplicationUserId == userId);

        if (patient == null)
            return false;

        return patient.IsEntityPatient && !patient.ProfileCompleted;
    }

    /// <summary>
    /// Obtiene un paciente por UserId
    /// </summary>
    public async Task<PatientProfile?> GetPatientByUserIdAsync(string userId)
    {
        return await _context.PatientProfiles
            .Include(p => p.Professional)
            .Include(p => p.ApplicationUser)
            .FirstOrDefaultAsync(p => p.ApplicationUserId == userId);
    }
}

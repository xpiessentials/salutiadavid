using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Identity;
using Salutia_Wep_App.Data;

namespace Salutia_Wep_App.Services
{
    /// <summary>
    /// Configuraci�n para el servicio de correo electr�nico
    /// </summary>
    public class EmailSettings
    {
        public string SmtpServer { get; set; } = string.Empty;
        public int SmtpPort { get; set; }
     public string SenderName { get; set; } = string.Empty;
        public string SenderEmail { get; set; } = string.Empty;
  public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    public bool EnableSsl { get; set; } = true;
    }

    /// <summary>
  /// Interfaz para el servicio de correo electr�nico
    /// </summary>
    public interface IEmailService
 {
  Task SendEmailAsync(string toEmail, string subject, string htmlBody);
      Task SendPasswordResetEmailAsync(string toEmail, string resetLink, string userName);
     Task SendEmailConfirmationAsync(string toEmail, string confirmationLink, string userName);
 Task SendWelcomeEmailAsync(string toEmail, string userName);
    }

    /// <summary>
    /// Servicio para env�o de correos electr�nicos usando MailKit
    /// </summary>
    public class EmailService : IEmailService
    {
        private readonly EmailSettings _emailSettings;
        private readonly ILogger<EmailService> _logger;

        public EmailService(IOptions<EmailSettings> emailSettings, ILogger<EmailService> logger)
     {
      _emailSettings = emailSettings.Value;
      _logger = logger;
        }

        /// <summary>
    /// Env�a un correo electr�nico
        /// </summary>
        public async Task SendEmailAsync(string toEmail, string subject, string htmlBody)
        {
    try
        {
         var message = new MimeMessage();
    message.From.Add(new MailboxAddress(_emailSettings.SenderName, _emailSettings.SenderEmail));
    message.To.Add(new MailboxAddress("", toEmail));
 message.Subject = subject;

            var bodyBuilder = new BodyBuilder
            {
            HtmlBody = htmlBody
                };
      message.Body = bodyBuilder.ToMessageBody();

      using var client = new SmtpClient();
            
            // Conectar al servidor SMTP
            // Puerto 465 usa SSL/TLS impl�cito (SslOnConnect)
            // Puerto 587 o 25 usa STARTTLS (StartTls)
            var secureSocketOptions = _emailSettings.SmtpPort == 465 
                ? SecureSocketOptions.SslOnConnect 
                : (_emailSettings.EnableSsl ? SecureSocketOptions.StartTls : SecureSocketOptions.None);
            
            await client.ConnectAsync(_emailSettings.SmtpServer, _emailSettings.SmtpPort, secureSocketOptions);

            // Autenticar
            await client.AuthenticateAsync(_emailSettings.Username, _emailSettings.Password);

              // Enviar el mensaje
            await client.SendAsync(message);

                // Desconectar
             await client.DisconnectAsync(true);

      _logger.LogInformation("Email enviado exitosamente a {Email}", toEmail);
     }
            catch (Exception ex)
            {
     _logger.LogError(ex, "Error al enviar email a {Email}", toEmail);
           throw;
          }
        }

        /// <summary>
        /// Env�a un correo de recuperaci�n de contrase�a
        /// </summary>
        public async Task SendPasswordResetEmailAsync(string toEmail, string resetLink, string userName)
        {
       var subject = "Recuperaci�n de Contrase�a - Salutia";
            
            var htmlBody = $@"
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
    .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
    .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
        .button {{ display: inline-block; padding: 15px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }}
   .footer {{ text-align: center; margin-top: 20px; color: #666; font-size: 12px; }}
 .warning {{ background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; }}
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
      <h1>?? Recuperaci�n de Contrase�a</h1>
  <p>Salutia - Sistema de Salud</p>
        </div>
        <div class='content'>
            <h2>Hola {userName},</h2>
    <p>Hemos recibido una solicitud para restablecer tu contrase�a.</p>
<p>Haz clic en el siguiente bot�n para crear una nueva contrase�a:</p>
     <div style='text-align: center;'>
   <a href='{resetLink}' class='button'>Restablecer Contrase�a</a>
            </div>
        <div class='warning'>
              <strong>?? Importante:</strong>
      <ul>
        <li>Este enlace expirar� en 1 hora</li>
<li>Si no solicitaste este cambio, ignora este correo</li>
             <li>Nunca compartas este enlace con nadie</li>
    </ul>
            </div>
       <p>Si el bot�n no funciona, copia y pega este enlace en tu navegador:</p>
      <p style='background: #e9ecef; padding: 10px; border-radius: 5px; word-break: break-all;'>{resetLink}</p>
     </div>
        <div class='footer'>
    <p>Este es un correo autom�tico, por favor no respondas.</p>
            <p>&copy; 2024 Salutia. Todos los derechos reservados.</p>
  </div>
    </div>
</body>
</html>";

            await SendEmailAsync(toEmail, subject, htmlBody);
        }

        /// <summary>
        /// Env�a un correo de confirmaci�n de email
        /// </summary>
     public async Task SendEmailConfirmationAsync(string toEmail, string confirmationLink, string userName)
        {
   var subject = "Confirma tu correo electr�nico - Salutia";
            
            var htmlBody = $@"
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
  .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
     .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
        .button {{ display: inline-block; padding: 15px 30px; background: #28a745; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }}
        .footer {{ text-align: center; margin-top: 20px; color: #666; font-size: 12px; }}
    </style>
</head>
<body>
    <div class='container'>
     <div class='header'>
            <h1>? Confirma tu Email</h1>
      <p>Salutia - Sistema de Salud</p>
    </div>
        <div class='content'>
            <h2>�Bienvenido/a {userName}!</h2>
  <p>Gracias por registrarte en Salutia. Para completar tu registro, por favor confirma tu direcci�n de correo electr�nico.</p>
          <div style='text-align: center;'>
        <a href='{confirmationLink}' class='button'>Confirmar Email</a>
   </div>
     <p>Si el bot�n no funciona, copia y pega este enlace en tu navegador:</p>
          <p style='background: #e9ecef; padding: 10px; border-radius: 5px; word-break: break-all;'>{confirmationLink}</p>
            <p>Una vez confirmado tu email, podr�s acceder a todas las funcionalidades de Salutia.</p>
      </div>
        <div class='footer'>
            <p>Este es un correo autom�tico, por favor no respondas.</p>
            <p>&copy; 2024 Salutia. Todos los derechos reservados.</p>
        </div>
    </div>
</body>
</html>";

            await SendEmailAsync(toEmail, subject, htmlBody);
        }

        /// <summary>
        /// Env�a un correo de bienvenida
        /// </summary>
        public async Task SendWelcomeEmailAsync(string toEmail, string userName)
    {
       var subject = "�Bienvenido/a a Salutia!";
     
     var htmlBody = $@"
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
   .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
        .feature {{ background: white; padding: 15px; margin: 10px 0; border-left: 4px solid #667eea; border-radius: 5px; }}
        .footer {{ text-align: center; margin-top: 20px; color: #666; font-size: 12px; }}
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h1>?? �Bienvenido/a a Salutia!</h1>
         <p>Tu cuenta ha sido activada exitosamente</p>
        </div>
        <div class='content'>
     <h2>Hola {userName},</h2>
  <p>Nos alegra tenerte en Salutia, tu plataforma de gesti�n de salud integral.</p>
  
        <h3>�Qu� puedes hacer en Salutia?</h3>
  
            <div class='feature'>
       <strong>?? Dashboard Personalizado</strong>
                <p>Accede a tu panel de control con informaci�n relevante y estad�sticas en tiempo real.</p>
    </div>
            
     <div class='feature'>
       <strong>?? Gesti�n de Usuarios</strong>
     <p>Administra profesionales, pacientes y miembros de tu organizaci�n.</p>
 </div>
            
     <div class='feature'>
    <strong>?? Reportes y An�lisis</strong>
         <p>Genera reportes detallados y visualiza m�tricas importantes.</p>
      </div>
     
 <div class='feature'>
      <strong>?? Seguridad Avanzada</strong>
              <p>Tu informaci�n est� protegida con autenticaci�n de dos factores disponible.</p>
            </div>
            
  <p>Si tienes alguna pregunta o necesitas ayuda, no dudes en contactarnos.</p>
            
     <p><strong>�Que tengas un excelente d�a!</strong></p>
        </div>
     <div class='footer'>
            <p>Este es un correo autom�tico, por favor no respondas.</p>
     <p>&copy; 2024 Salutia. Todos los derechos reservados.</p>
        </div>
    </div>
</body>
</html>";

 await SendEmailAsync(toEmail, subject, htmlBody);
        }
    }

    /// <summary>
    /// Adaptador para integrar nuestro EmailService con IEmailSender<ApplicationUser> de Identity
    /// </summary>
    public class EmailSenderAdapter : IEmailSender<ApplicationUser>
    {
        private readonly IEmailService _emailService;
        private readonly ILogger<EmailSenderAdapter> _logger;

        public EmailSenderAdapter(IEmailService emailService, ILogger<EmailSenderAdapter> logger)
        {
   _emailService = emailService;
        _logger = logger;
     }

  public async Task SendConfirmationLinkAsync(ApplicationUser user, string email, string confirmationLink)
        {
  try
      {
     var userName = user.IndependentProfile?.FullName 
          ?? user.EntityProfile?.FullName // Ahora EntityProfile tiene FullName del administrador
      ?? user.EntityProfessionalProfile?.FullName
       ?? user.PatientProfile?.FullName
     ?? email;

 await _emailService.SendEmailConfirmationAsync(email, confirmationLink, userName);
   }
            catch (Exception ex)
  {
  _logger.LogError(ex, "Error sending confirmation email to {Email}", email);
     throw;
     }
        }

    public async Task SendPasswordResetLinkAsync(ApplicationUser user, string email, string resetLink)
     {
        try
        {
            _logger.LogInformation("=== EmailSenderAdapter: Enviando email de reseteo de contrase�a ===");
            _logger.LogInformation("Email: {Email}, UserId: {UserId}", email, user.Id);
            
            var userName = user.IndependentProfile?.FullName 
                ?? user.EntityProfile?.FullName
                ?? user.EntityProfessionalProfile?.FullName
                ?? user.PatientProfile?.FullName
                ?? email;

            _logger.LogInformation("Nombre de usuario obtenido: {UserName}", userName);
            _logger.LogInformation("Llamando a EmailService.SendPasswordResetEmailAsync...");

            await _emailService.SendPasswordResetEmailAsync(email, resetLink, userName);
            
            _logger.LogInformation("=== Email de reseteo enviado exitosamente ===");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "=== ERROR enviando email de reseteo de contrase�a ===");
            _logger.LogError("Email: {Email}", email);
            _logger.LogError("Mensaje: {Message}", ex.Message);
            throw;
        }
   }

        public async Task SendPasswordResetCodeAsync(ApplicationUser user, string email, string resetCode)
        {
      // Para c�digo de reseteo, enviar un email similar pero con c�digo
        try
        {
       var userName = user.IndependentProfile?.FullName 
        ?? user.EntityProfile?.FullName // Ahora EntityProfile tiene FullName del administrador
    ?? user.EntityProfessionalProfile?.FullName
 ?? user.PatientProfile?.FullName
        ?? email;

  var subject = "C�digo de Recuperaci�n de Contrase�a - Salutia";
       var htmlBody = $@"
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
        .code {{ background: #667eea; color: white; padding: 20px; text-align: center; font-size: 32px; letter-spacing: 5px; font-weight: bold; margin: 20px 0; border-radius: 5px; }}
   .footer {{ text-align: center; margin-top: 20px; color: #666; font-size: 12px; }}
    </style>
</head>
<body>
    <div class='container'>
   <div class='header'>
       <h1>?? C�digo de Recuperaci�n</h1>
 <p>Salutia - Sistema de Salud</p>
 </div>
        <div class='content'>
        <h2>Hola {userName},</h2>
     <p>Tu c�digo de recuperaci�n de contrase�a es:</p>
    <div class='code'>{resetCode}</div>
         <p>Ingresa este c�digo en la p�gina de recuperaci�n para continuar.</p>
            <p><strong>Este c�digo expira en 15 minutos.</strong></p>
  </div>
      <div class='footer'>
            <p>Este es un correo autom�tico, por favor no respondas.</p>
<p>&copy; 2024 Salutia. Todos los derechos reservados.</p>
        </div>
    </div>
</body>
</html>";

      await _emailService.SendEmailAsync(email, subject, htmlBody);
 }
            catch (Exception ex)
          {
       _logger.LogError(ex, "Error sending password reset code to {Email}", email);
     throw;
     }
        }
    }
}

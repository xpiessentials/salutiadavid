using Microsoft.EntityFrameworkCore;
using Salutia_Wep_App.Data;
using Salutia_Wep_App.Models.PsychosomaticTest;

namespace Salutia_Wep_App.Services;

/// <summary>
/// Servicio para gestionar el Test Psicosom�tico
/// </summary>
public class PsychosomaticTestService
{
    private readonly ApplicationDbContext _context;
    private readonly ILogger<PsychosomaticTestService> _logger;

    public PsychosomaticTestService(
        ApplicationDbContext context,
      ILogger<PsychosomaticTestService> logger)
    {
      _context = context;
        _logger = logger;
    }

    /// <summary>
    /// Verifica si un paciente ya complet� el test
 /// </summary>
    public async Task<bool> HasCompletedTestAsync(string patientUserId)
    {
        return await _context.PsychosomaticTests
            .AnyAsync(t => t.PatientUserId == patientUserId && t.IsCompleted);
    }

    /// <summary>
    /// Verifica si un paciente ya complet� el test, considerando el rol del usuario
    /// Los SuperAdmins no tienen restricciones
    /// </summary>
    public async Task<bool> HasCompletedTestAsync(string patientUserId, bool isSuperAdmin)
    {
        if (isSuperAdmin)
        {
            return false; // SuperAdmins nunca tienen restricci�n
        }

        return await HasCompletedTestAsync(patientUserId);
    }

    /// <summary>
    /// Verifica si un paciente puede realizar el test (perfil completado)
    /// </summary>
    public async Task<(bool CanTakeTest, string Message)> CanPatientTakeTestAsync(string patientUserId)
    {
        // Verificar si es un paciente de entidad
        var patient = await _context.PatientProfiles
            .FirstOrDefaultAsync(p => p.ApplicationUserId == patientUserId);

        if (patient != null && patient.IsEntityPatient)
        {
            // Los pacientes de entidad deben completar su perfil primero
            if (!patient.ProfileCompleted)
            {
                return (false, "Debes completar tu perfil antes de realizar el test");
            }
        }

        // Verificar si ya complet� el test
        var hasCompleted = await HasCompletedTestAsync(patientUserId);
        if (hasCompleted)
        {
            return (false, "Ya has completado el test psicosom�tico");
        }

        return (true, "Puede realizar el test");
    }

    /// <summary>
    /// Obtiene o crea un test en progreso para un paciente
    /// </summary>
    public async Task<PsychosomaticTest> GetOrCreateTestAsync(string patientUserId)
    {
        // Buscar test en progreso
        var existingTest = await _context.PsychosomaticTests
  .Include(t => t.Words)
    .FirstOrDefaultAsync(t => t.PatientUserId == patientUserId && !t.IsCompleted);

  if (existingTest != null)
 {
            return existingTest;
        }

        // Crear nuevo test
        var newTest = new PsychosomaticTest
        {
     PatientUserId = patientUserId,
     StartedAt = DateTime.UtcNow,
 IsCompleted = false
        };

        _context.PsychosomaticTests.Add(newTest);
    await _context.SaveChangesAsync();

     _logger.LogInformation("Nuevo test psicosom�tico creado para paciente {PatientId}", patientUserId);
        return newTest;
    }

    /// <summary>
    /// Guarda las 10 palabras (Pregunta 1)
    /// </summary>
  public async Task SaveWordsAsync(int testId, List<string> words)
    {
        if (words.Count != 10)
   throw new ArgumentException("Se requieren exactamente 10 palabras");

  var test = await _context.PsychosomaticTests.FindAsync(testId);
        if (test == null)
        throw new InvalidOperationException("Test no encontrado");

     // Eliminar palabras previas si existen
      var existingWords = await _context.TestWords
     .Where(w => w.PsychosomaticTestId == testId)
  .ToListAsync();
        _context.TestWords.RemoveRange(existingWords);

        // Guardar nuevas palabras
        for (int i = 0; i < words.Count; i++)
    {
            _context.TestWords.Add(new TestWord
            {
                PsychosomaticTestId = testId,
      WordNumber = i + 1,
            Word = words[i].Trim(),
                CreatedAt = DateTime.UtcNow
     });
   }

      await _context.SaveChangesAsync();
        _logger.LogInformation("10 palabras guardadas para test {TestId}", testId);
    }

    /// <summary>
    /// Guarda las 10 frases (Pregunta 2)
    /// </summary>
    public async Task SavePhrasesAsync(int testId, List<string> phrases)
    {
        if (phrases.Count != 10)
          throw new ArgumentException("Se requieren exactamente 10 frases");

        // Eliminar frases previas si existen
        var existingPhrases = await _context.TestPhrases
  .Where(p => p.PsychosomaticTestId == testId)
            .ToListAsync();
        _context.TestPhrases.RemoveRange(existingPhrases);

        // Guardar nuevas frases
        for (int i = 0; i < phrases.Count; i++)
        {
            _context.TestPhrases.Add(new TestPhrase
{
                PsychosomaticTestId = testId,
         WordNumber = i + 1,
             Phrase = phrases[i].Trim(),
     CreatedAt = DateTime.UtcNow
            });
      }

        await _context.SaveChangesAsync();
        _logger.LogInformation("10 frases guardadas para test {TestId}", testId);
    }

    /// <summary>
/// Guarda las 10 emociones (Pregunta 3)
  /// </summary>
    public async Task SaveEmotionsAsync(int testId, List<string> emotions)
    {
   if (emotions.Count != 10)
            throw new ArgumentException("Se requieren exactamente 10 emociones");

        // Eliminar emociones previas si existen
        var existingEmotions = await _context.TestEmotions
            .Where(e => e.PsychosomaticTestId == testId)
     .ToListAsync();
        _context.TestEmotions.RemoveRange(existingEmotions);

        // Guardar nuevas emociones
        for (int i = 0; i < emotions.Count; i++)
     {
       _context.TestEmotions.Add(new TestEmotion
  {
                PsychosomaticTestId = testId,
      WordNumber = i + 1,
                Emotion = emotions[i].Trim(),
              CreatedAt = DateTime.UtcNow
 });
 }

        await _context.SaveChangesAsync();
        _logger.LogInformation("10 emociones guardadas para test {TestId}", testId);
    }

    /// <summary>
    /// Guarda los 10 niveles de malestar (Pregunta 4)
    /// </summary>
    public async Task SaveDiscomfortLevelsAsync(int testId, List<int> levels)
  {
  if (levels.Count != 10)
      throw new ArgumentException("Se requieren exactamente 10 niveles");

   if (levels.Any(l => l < 1 || l > 10))
   throw new ArgumentException("Los niveles deben estar entre 1 y 10");

        // Eliminar niveles previos si existen
        var existingLevels = await _context.TestDiscomfortLevels
 .Where(l => l.PsychosomaticTestId == testId)
      .ToListAsync();
        _context.TestDiscomfortLevels.RemoveRange(existingLevels);

        // Guardar nuevos niveles
        for (int i = 0; i < levels.Count; i++)
 {
            _context.TestDiscomfortLevels.Add(new TestDiscomfortLevel
      {
       PsychosomaticTestId = testId,
                WordNumber = i + 1,
       DiscomfortLevel = levels[i],
        CreatedAt = DateTime.UtcNow
            });
        }

        await _context.SaveChangesAsync();
        _logger.LogInformation("10 niveles de malestar guardados para test {TestId}", testId);
  }

    /// <summary>
    /// Guarda las 10 edades (Pregunta 5)
    /// </summary>
    public async Task SaveAgesAsync(int testId, List<string> ages)
    {
        if (ages.Count != 10)
            throw new ArgumentException("Se requieren exactamente 10 edades");

        // Eliminar edades previas si existen
        var existingAges = await _context.TestAges
            .Where(a => a.PsychosomaticTestId == testId)
            .ToListAsync();
        _context.TestAges.RemoveRange(existingAges);

        // Guardar nuevas edades
        for (int i = 0; i < ages.Count; i++)
        {
            _context.TestAges.Add(new TestAge
            {
                PsychosomaticTestId = testId,
                WordNumber = i + 1,
                Age = ages[i].Trim(),
                CreatedAt = DateTime.UtcNow
            });
        }

        await _context.SaveChangesAsync();
        _logger.LogInformation("10 edades guardadas para test {TestId}", testId);
    }

    /// <summary>
    /// Guarda las 10 partes del cuerpo (Pregunta 6)
    /// </summary>
    public async Task SaveBodyPartsAsync(int testId, List<string> bodyParts)
    {
        if (bodyParts.Count != 10)
            throw new ArgumentException("Se requieren exactamente 10 partes del cuerpo");

        // Eliminar partes previas si existen
     var existingParts = await _context.TestBodyParts
            .Where(b => b.PsychosomaticTestId == testId)
        .ToListAsync();
     _context.TestBodyParts.RemoveRange(existingParts);

        // Guardar nuevas partes del cuerpo
        for (int i = 0; i < bodyParts.Count; i++)
        {
    _context.TestBodyParts.Add(new TestBodyPart
  {
           PsychosomaticTestId = testId,
           WordNumber = i + 1,
       BodyPart = bodyParts[i].Trim(),
           CreatedAt = DateTime.UtcNow
 });
        }

 await _context.SaveChangesAsync();
        _logger.LogInformation("10 partes del cuerpo guardadas para test {TestId}", testId);
    }

    /// <summary>
    /// Guarda las 10 personas asociadas y completa el test (Pregunta 7)
    /// </summary>
    public async Task SaveAssociatedPersonsAndCompleteTestAsync(int testId, List<string> persons)
{
      if (persons.Count != 10)
            throw new ArgumentException("Se requieren exactamente 10 personas");

     // Eliminar personas previas si existen
        var existingPersons = await _context.TestAssociatedPersons
            .Where(p => p.PsychosomaticTestId == testId)
.ToListAsync();
        _context.TestAssociatedPersons.RemoveRange(existingPersons);

        // Guardar nuevas personas
        for (int i = 0; i < persons.Count; i++)
        {
            _context.TestAssociatedPersons.Add(new TestAssociatedPerson
   {
        PsychosomaticTestId = testId,
WordNumber = i + 1,
        PersonName = persons[i].Trim(),
   CreatedAt = DateTime.UtcNow
            });
        }

        await _context.SaveChangesAsync();
   _logger.LogInformation("10 personas asociadas guardadas para test {TestId}", testId);

        // Ahora construir la matriz consolidada
        await BuildMatrixAsync(testId);

    // Marcar test como completado
     var test = await _context.PsychosomaticTests.FindAsync(testId);
        if (test != null)
        {
            test.IsCompleted = true;
     test.CompletedAt = DateTime.UtcNow;
 await _context.SaveChangesAsync();
_logger.LogInformation("Test {TestId} marcado como completado", testId);
        }
  }

    /// <summary>
    /// Construye la matriz consolidada con todas las respuestas
    /// </summary>
    private async Task BuildMatrixAsync(int testId)
    {
        // Obtener todas las respuestas
        var words = await _context.TestWords
            .Where(w => w.PsychosomaticTestId == testId)
            .OrderBy(w => w.WordNumber)
            .ToListAsync();

        var phrases = await _context.TestPhrases
            .Where(p => p.PsychosomaticTestId == testId)
            .OrderBy(p => p.WordNumber)
            .ToListAsync();

        var emotions = await _context.TestEmotions
            .Where(e => e.PsychosomaticTestId == testId)
            .OrderBy(e => e.WordNumber)
            .ToListAsync();

        var levels = await _context.TestDiscomfortLevels
            .Where(l => l.PsychosomaticTestId == testId)
            .OrderBy(l => l.WordNumber)
            .ToListAsync();

        var ages = await _context.TestAges
            .Where(a => a.PsychosomaticTestId == testId)
            .OrderBy(a => a.WordNumber)
            .ToListAsync();

        var bodyParts = await _context.TestBodyParts
            .Where(b => b.PsychosomaticTestId == testId)
            .OrderBy(b => b.WordNumber)
            .ToListAsync();

        var persons = await _context.TestAssociatedPersons
            .Where(p => p.PsychosomaticTestId == testId)
            .OrderBy(p => p.WordNumber)
            .ToListAsync();

        // Eliminar matriz previa si existe
        var existingMatrix = await _context.TestMatrices
            .Where(m => m.PsychosomaticTestId == testId)
            .ToListAsync();
        _context.TestMatrices.RemoveRange(existingMatrix);

        // Construir matriz
        for (int i = 0; i < 10; i++)
        {
            _context.TestMatrices.Add(new TestMatrix
            {
                PsychosomaticTestId = testId,
                WordNumber = i + 1,
                Word = words[i].Word,
                Phrase = phrases[i].Phrase,
                Emotion = emotions[i].Emotion,
                DiscomfortLevel = levels[i].DiscomfortLevel,
                Age = ages[i].Age,
                BodyPart = bodyParts[i].BodyPart,
                AssociatedPerson = persons[i].PersonName,
                CreatedAt = DateTime.UtcNow
            });
        }

        await _context.SaveChangesAsync();
        _logger.LogInformation("Matriz consolidada creada para test {TestId}", testId);
    }

    /// <summary>
    /// Obtiene las palabras guardadas para un test
    /// </summary>
    public async Task<List<TestWord>> GetWordsAsync(int testId)
    {
      return await _context.TestWords
  .Where(w => w.PsychosomaticTestId == testId)
    .OrderBy(w => w.WordNumber)
        .ToListAsync();
 }

    /// <summary>
    /// Obtiene las frases guardadas para un test
    /// </summary>
    public async Task<List<TestPhrase>> GetPhrasesAsync(int testId)
    {
        return await _context.TestPhrases
            .Where(p => p.PsychosomaticTestId == testId)
            .OrderBy(p => p.WordNumber)
            .ToListAsync();
  }

    /// <summary>
    /// Obtiene la matriz completa de un test
    /// </summary>
    public async Task<List<TestMatrix>> GetMatrixAsync(int testId)
    {
return await _context.TestMatrices
        .Where(m => m.PsychosomaticTestId == testId)
       .OrderBy(m => m.WordNumber)
            .ToListAsync();
    }

    /// <summary>
    /// Obtiene el test completo con todos los datos
    /// </summary>
    public async Task<PsychosomaticTest?> GetTestByIdAsync(int testId)
    {
    return await _context.PsychosomaticTests
         .Include(t => t.Words)
   .Include(t => t.MatrixResults)
            .FirstOrDefaultAsync(t => t.Id == testId);
    }
}

using Salutia_Wep_App.Models.Reports;

namespace Salutia_Wep_App.Services;

/// <summary>
/// Servicio para generaci�n de reportes PDF
/// NOTA: Requiere configuraci�n completa de DevExpress 22.1.
/// Ver DEVEXPRESS_INTEGRATION_GUIDE.md para instrucciones detalladas.
/// </summary>
public class PdfReportService
{
    /// <summary>
    /// Genera un reporte PDF del paciente
    /// </summary>
    public byte[] GeneratePatientReport(PatientReportModel patient)
    {
        // TODO: Implementar con DevExpress Reporting
        throw new NotImplementedException("DevExpress Reporting requiere configuraci�n adicional. Ver gu�a de integraci�n.");
    }
 
    /// <summary>
    /// Genera reporte de citas m�dicas
    /// </summary>
    public byte[] GenerateAppointmentsReport(string patientName, List<AppointmentReportModel> appointments)
    {
        // TODO: Implementar con DevExpress Reporting
        throw new NotImplementedException("DevExpress Reporting requiere configuraci�n adicional. Ver gu�a de integraci�n.");
    }
  
    /// <summary>
    /// Genera reporte del test psicosom�tico
    /// </summary>
    public byte[] GeneratePsychosomaticTestReport(PsychosomaticTestReportModel testResult)
    {
        // TODO: Implementar con DevExpress Reporting
        throw new NotImplementedException("DevExpress Reporting requiere configuraci�n adicional. Ver gu�a de integraci�n.");
    }
}

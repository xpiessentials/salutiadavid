using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.EntityFrameworkCore;
using Salutia_Wep_App.Data;
using Salutia_Wep_App.Models.Auth;
using System.Text;
using System.Text.Encodings.Web;

namespace Salutia_Wep_App.Services;

/// <summary>
/// Servicio de autenticaci�n y gesti�n de usuarios multi-tipo
/// </summary>
public class UserManagementService
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly ApplicationDbContext _context;
    private readonly ILogger<UserManagementService> _logger;
    private readonly IEmailSender<ApplicationUser> _emailSender;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public UserManagementService(
        UserManager<ApplicationUser> userManager,
        SignInManager<ApplicationUser> signInManager,
        ApplicationDbContext context,
        ILogger<UserManagementService> logger,
        IEmailSender<ApplicationUser> emailSender,
        IHttpContextAccessor httpContextAccessor)
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _context = context;
        _logger = logger;
        _emailSender = emailSender;
        _httpContextAccessor = httpContextAccessor;
    }

    /// <summary>
    /// Registra un usuario independiente
    /// </summary>
    public async Task<AuthResponse> RegisterIndependentUserAsync(RegisterIndependentRequest request)
    {
        try
        {
            // Validar que el email no exista
            if (await _userManager.FindByEmailAsync(request.Email) != null)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = "El email ya est� registrado en el sistema."
                };
            }

            // Validar que el documento no exista
            var existingDoc = await _context.IndependentUserProfiles
                .AnyAsync(p => p.DocumentNumber == request.DocumentNumber);

            if (existingDoc)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = "El n�mero de documento ya est� registrado."
                };
            }

            // Crear usuario de Identity
            var user = new ApplicationUser
            {
                UserName = request.Email,
                Email = request.Email,
                UserType = UserType.Independent,
                EmailConfirmed = false, // Requiere confirmaci�n
                IsActive = true
            };

            var result = await _userManager.CreateAsync(user, request.Password);

            if (!result.Succeeded)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = string.Join(", ", result.Errors.Select(e => e.Description))
                };
            }

            // Crear perfil independiente
            var profile = new IndependentUserProfile
            {
                ApplicationUserId = user.Id,
                FullName = request.FullName,
                DocumentType = (DocumentType)request.DocumentType,
                DocumentNumber = request.DocumentNumber,
                Phone = request.Phone,
                DateOfBirth = request.DateOfBirth
            };

            _context.IndependentUserProfiles.Add(profile);
            await _context.SaveChangesAsync();

            // Asignar rol
            await _userManager.AddToRoleAsync(user, "Independent");

            // Enviar email de confirmaci�n
            try
            {
                var code = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                code = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(code));
                
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext != null)
                {
                    var httpRequest = httpContext.Request;
                    var baseUrl = $"{httpRequest.Scheme}://{httpRequest.Host}";
                    var confirmationLink = $"{baseUrl}/Account/ConfirmEmail?userId={user.Id}&code={code}";
                    
                    await _emailSender.SendConfirmationLinkAsync(user, request.Email, HtmlEncoder.Default.Encode(confirmationLink));
                    _logger.LogInformation("Email de confirmaci�n enviado a: {Email}", request.Email);
                }
            }
            catch (Exception emailEx)
            {
                _logger.LogWarning(emailEx, "No se pudo enviar email de confirmaci�n a {Email}", request.Email);
                // No fallar el registro si el email falla
            }

            _logger.LogInformation("Usuario independiente registrado: {Email}", request.Email);

            return new AuthResponse
            {
                Success = true,
                Message = "Usuario registrado exitosamente. Por favor confirma tu email.",
                User = new UserInfo
                {
                    UserId = user.Id,
                    Email = user.Email!,
                    UserType = "Independent",
                    DisplayName = profile.FullName
                }
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error registrando usuario independiente");
            return new AuthResponse
            {
                Success = false,
                Message = "Error al registrar el usuario. Por favor intenta nuevamente."
            };
        }
    }

    /// <summary>
    /// Registra una entidad con su primer administrador
    /// </summary>
    public async Task<AuthResponse> RegisterEntityAsync(RegisterEntityRequest request)
    {
        try
        {
            // Validar email
            if (await _userManager.FindByEmailAsync(request.Email) != null)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = "El email ya est� registrado en el sistema."
                };
            }

            // Validar NIT en la tabla Entities
            var existingNit = await _context.Entities
                .AnyAsync(e => e.TaxId == request.TaxId);

            if (existingNit)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = "El NIT ya est� registrado."
                };
            }

            // 1. Crear registro de Entity (la empresa)
            var entity = new Entity
            {
                BusinessName = request.BusinessName,
                TaxId = request.TaxId,
                VerificationDigit = request.VerificationDigit,
                Phone = request.Phone,
                Email = request.Email,
                Address = request.Address,
                LegalRepresentative = request.LegalRepresentative,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };

            _context.Entities.Add(entity);
            await _context.SaveChangesAsync(); // Guardar para obtener el EntityId

            // 2. Crear usuario de Identity (el administrador)
            var user = new ApplicationUser
            {
                UserName = request.Email,
                Email = request.Email,
                UserType = UserType.EntityAdmin,
                EmailConfirmed = false,
                IsActive = true
            };

            var result = await _userManager.CreateAsync(user, request.Password);

            if (!result.Succeeded)
            {
                // Rollback: eliminar entity si no se pudo crear el usuario
                _context.Entities.Remove(entity);
                await _context.SaveChangesAsync();

                return new AuthResponse
                {
                    Success = false,
                    Message = string.Join(", ", result.Errors.Select(e => e.Description))
                };
            }

            // 3. Crear perfil de EntityUserProfile (ahora es solo administrador)
            var adminProfile = new EntityUserProfile
            {
                ApplicationUserId = user.Id,
                EntityId = entity.Id, // Referencia a la entidad
                FullName = request.FullName ?? user.Email, // Nombre del administrador
                Position = "Administrador Principal",
                DirectPhone = request.Phone,
                IsActive = true,
                JoinedAt = DateTime.UtcNow
            };

            _context.EntityUserProfiles.Add(adminProfile);
            await _context.SaveChangesAsync();

            // 4. Asignar rol
            await _userManager.AddToRoleAsync(user, "EntityAdmin");

            // 5. Enviar email de confirmaci�n
            try
            {
                var code = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                code = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(code));
                
                var httpContext = _httpContextAccessor.HttpContext;
                if (httpContext != null)
                {
                    var httpRequest = httpContext.Request;
                    var baseUrl = $"{httpRequest.Scheme}://{httpRequest.Host}";
                    var confirmationLink = $"{baseUrl}/Account/ConfirmEmail?userId={user.Id}&code={code}";
                    
                    await _emailSender.SendConfirmationLinkAsync(user, request.Email, HtmlEncoder.Default.Encode(confirmationLink));
                    _logger.LogInformation("Email de confirmaci�n enviado a: {Email}", request.Email);
                }
            }
            catch (Exception emailEx)
            {
                _logger.LogWarning(emailEx, "No se pudo enviar email de confirmaci�n a {Email}", request.Email);
                // No fallar el registro si el email falla
            }

            _logger.LogInformation(
                "Entidad registrada: {BusinessName} (EntityId: {EntityId}) con administrador {Email}",
                request.BusinessName,
                entity.Id,
                request.Email);

            return new AuthResponse
            {
                Success = true,
                Message = "Entidad y administrador registrados exitosamente. Por favor confirma tu email.",
                User = new UserInfo
                {
                    UserId = user.Id,
                    Email = user.Email!,
                    UserType = "EntityAdmin",
                    DisplayName = request.FullName ?? user.Email,
                    EntityId = entity.Id,
                    EntityName = entity.BusinessName
                }
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error registrando entidad");
            return new AuthResponse
            {
                Success = false,
                Message = "Error al registrar la entidad. Por favor intenta nuevamente."
            };
        }
    }

    /// <summary>
    /// Inicio de sesi�n
    /// </summary>
    public async Task<AuthResponse> LoginAsync(LoginRequest request)
    {
        try
        {
            var user = await _userManager.FindByEmailAsync(request.Email);

            if (user == null || !user.IsActive)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = "Email o contrase�a incorrectos."
                };
            }

            var result = await _signInManager.PasswordSignInAsync(
                user,
                request.Password,
                request.RememberMe,
                lockoutOnFailure: true);

            if (result.Succeeded)
            {
                var userInfo = await GetUserInfoAsync(user);

                _logger.LogInformation("Usuario inici� sesi�n: {Email}", request.Email);

                return new AuthResponse
                {
                    Success = true,
                    Message = "Inicio de sesi�n exitoso.",
                    User = userInfo
                };
            }

            if (result.RequiresTwoFactor)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = "Se requiere autenticaci�n de dos factores."
                };
            }

            if (result.IsLockedOut)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = "Cuenta bloqueada por m�ltiples intentos fallidos."
                };
            }

            return new AuthResponse
            {
                Success = false,
                Message = "Email o contrase�a incorrectos."
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error en inicio de sesi�n");
            return new AuthResponse
            {
                Success = false,
                Message = "Error al iniciar sesi�n."
            };
        }
    }

    /// <summary>
    /// Obtiene informaci�n completa del usuario
    /// </summary>
    private async Task<UserInfo> GetUserInfoAsync(ApplicationUser user)
    {
        var roles = await _userManager.GetRolesAsync(user);
        var userInfo = new UserInfo
        {
            UserId = user.Id,
            Email = user.Email!,
            UserType = user.UserType.ToString(),
            Roles = roles.ToList()
        };

        switch (user.UserType)
        {
            case UserType.Independent:
                var indProfile = await _context.IndependentUserProfiles
                    .FirstOrDefaultAsync(p => p.ApplicationUserId == user.Id);
                if (indProfile != null)
                {
                    userInfo.DisplayName = indProfile.FullName;
                }
                break;

            case UserType.EntityAdmin:
                var adminProfile = await _context.EntityUserProfiles
                    .Include(p => p.Entity) // Incluir Entity
                    .FirstOrDefaultAsync(p => p.ApplicationUserId == user.Id);
                if (adminProfile != null)
                {
                    userInfo.DisplayName = adminProfile.FullName;
                    userInfo.EntityId = adminProfile.EntityId; // Ahora es EntityId de Entity
                    userInfo.EntityName = adminProfile.Entity.BusinessName;
                }
                break;

            case UserType.Doctor:
            case UserType.Psychologist:
                var professionalProfile = await _context.EntityProfessionalProfiles
                    .Include(p => p.Entity) // Ahora referencia Entity directamente
                    .FirstOrDefaultAsync(p => p.ApplicationUserId == user.Id);
                if (professionalProfile != null)
                {
                    userInfo.DisplayName = professionalProfile.FullName;
                    userInfo.EntityId = professionalProfile.EntityId;
                    userInfo.EntityName = professionalProfile.Entity.BusinessName;
                    userInfo.ProfessionalId = professionalProfile.Id;
                }
                break;

            case UserType.Patient:
                var patientProfile = await _context.PatientProfiles
                    .Include(p => p.Professional)
                        .ThenInclude(p => p.Entity) // Profesional ahora referencia Entity directamente
                    .Include(p => p.Entity) // Paciente tambi�n tiene EntityId opcional
                    .FirstOrDefaultAsync(p => p.ApplicationUserId == user.Id);
                if (patientProfile != null)
                {
                    userInfo.DisplayName = patientProfile.FullName ?? "Paciente";
                    userInfo.EntityId = patientProfile.EntityId; // Puede ser null para pacientes independientes
                    userInfo.EntityName = patientProfile.Entity?.BusinessName;
                    userInfo.ProfessionalId = patientProfile.ProfessionalId;
                }
                break;

            case UserType.SuperAdmin:
                userInfo.DisplayName = "Super Administrador";
                break;
        }

        return userInfo;
    }

    /// <summary>
    /// Registra un profesional de entidad (m�dico o psic�logo) - Puede hacerlo EntityAdmin o SuperAdmin
    /// </summary>
    public async Task<AuthResponse> RegisterProfessionalAsync(RegisterProfessionalRequest request, string createdByUserId)
    {
        try
        {
            // Verificar que quien crea es un EntityAdmin o SuperAdmin
            var creatorUser = await _userManager.FindByIdAsync(createdByUserId);
            if (creatorUser == null)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = "Usuario creador no encontrado."
                };
            }

            // Validar permisos
            bool isSuperAdmin = creatorUser.UserType == UserType.SuperAdmin;
            bool isEntityAdmin = creatorUser.UserType == UserType.EntityAdmin;

            if (!isSuperAdmin && !isEntityAdmin)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = "No tienes permisos para crear profesionales."
                };
            }

            // Obtener EntityId seg�n el tipo de usuario
            int entityId;

            if (isSuperAdmin)
            {
                // SuperAdmin debe especificar la entidad mediante EntityId en el request
                if (!request.EntityId.HasValue)
                {
                    return new AuthResponse
                    {
                        Success = false,
                        Message = "Debes especificar la entidad a la que pertenece el profesional."
                    };
                }

                entityId = request.EntityId.Value;

                // Verificar que la entidad existe
                var entityExists = await _context.Entities.AnyAsync(e => e.Id == entityId);
                if (!entityExists)
                {
                    return new AuthResponse
                    {
                        Success = false,
                        Message = "La entidad especificada no existe."
                    };
                }
            }
            else // EntityAdmin
            {
                // EntityAdmin crea profesionales para su propia entidad
                var adminProfile = await _context.EntityUserProfiles
                    .FirstOrDefaultAsync(e => e.ApplicationUserId == createdByUserId);

                if (adminProfile == null)
                {
                    return new AuthResponse
                    {
                        Success = false,
                        Message = "Perfil de administrador no encontrado."
                    };
                }

                entityId = adminProfile.EntityId;
            }

            // Obtener informaci�n de la entidad
            var entity = await _context.Entities.FindAsync(entityId);
            if (entity == null)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = "Entidad no encontrada."
                };
            }

            // Validar email
            if (await _userManager.FindByEmailAsync(request.Email) != null)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = "El email ya est� registrado."
                };
            }

            // Validar documento duplicado en la misma entidad
            var existingDoc = await _context.EntityProfessionalProfiles
                .AnyAsync(p => p.EntityId == entityId && p.DocumentNumber == request.DocumentNumber);

            if (existingDoc)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = "Ya existe un profesional con ese n�mero de documento en esta entidad."
                };
            }

            // Determinar el tipo de usuario seg�n el tipo de profesional
            var userType = request.ProfessionalType == ProfessionalType.Doctor
                ? UserType.Doctor
                : UserType.Psychologist;

            // Crear usuario de Identity
            var user = new ApplicationUser
            {
                UserName = request.Email,
                Email = request.Email,
                UserType = userType,
                EmailConfirmed = false,
                IsActive = true
            };

            var result = await _userManager.CreateAsync(user, request.Password);

            if (!result.Succeeded)
            {
                return new AuthResponse
                {
                    Success = false,
                    Message = string.Join(", ", result.Errors.Select(e => e.Description))
                };
            }

            // Crear perfil de profesional (ahora referencia directamente a Entity)
            var professionalProfile = new EntityProfessionalProfile
            {
                ApplicationUserId = user.Id,
                EntityId = entityId, // Referencia directa a Entity
                FullName = request.FullName,
                DocumentType = (DocumentType)request.DocumentType,
                DocumentNumber = request.DocumentNumber,
                Phone = request.Phone,
                ProfessionalLicense = request.ProfessionalLicense,
                Specialty = request.Specialty,
                CountryId = request.CountryId,
                StateId = request.StateId,
                CityId = request.CityId,
                Address = request.Address,
                IsActive = true
            };

            _context.EntityProfessionalProfiles.Add(professionalProfile);
            await _context.SaveChangesAsync();

            // Asignar rol
            var roleName = userType == UserType.Doctor ? "Doctor" : "Psychologist";
            await _userManager.AddToRoleAsync(user, roleName);

            _logger.LogInformation(
                "Profesional registrado: {Email} para entidad {EntityId} ({EntityName}) por {CreatorId}",
                request.Email,
                entityId,
                entity.BusinessName,
                createdByUserId);

            return new AuthResponse
            {
                Success = true,
                Message = "Profesional creado exitosamente.",
                User = new UserInfo
                {
                    UserId = user.Id,
                    Email = user.Email!,
                    UserType = userType.ToString(),
                    DisplayName = professionalProfile.FullName,
                    EntityId = entityId,
                    EntityName = entity.BusinessName,
                    ProfessionalId = professionalProfile.Id
                }
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error registrando profesional");
            return new AuthResponse
            {
                Success = false,
                Message = "Error al crear el profesional."
            };
        }
    }

    /// <summary>
    /// Obtiene los profesionales de una entidad
    /// </summary>
    public async Task<List<EntityProfessionalProfile>> GetEntityProfessionalsAsync(string userId)
    {
        var user = await _userManager.FindByIdAsync(userId);
        if (user?.UserType != UserType.EntityAdmin)
        {
            return new List<EntityProfessionalProfile>();
        }

        // Obtener el perfil de administrador para saber su EntityId
        var adminProfile = await _context.EntityUserProfiles
            .FirstOrDefaultAsync(e => e.ApplicationUserId == userId);

        if (adminProfile == null)
        {
            return new List<EntityProfessionalProfile>();
        }

        // Obtener todos los profesionales de esa entidad
        return await _context.EntityProfessionalProfiles
            .Include(p => p.ApplicationUser)
            .Include(p => p.Entity) // Incluir informaci�n de la entidad
            .Where(p => p.EntityId == adminProfile.EntityId)
            .OrderBy(p => p.FullName)
            .ToListAsync();
    }

    /// <summary>
    /// Obtiene todas las entidades (solo para SuperAdmin)
    /// </summary>
    public async Task<List<Entity>> GetAllEntitiesAsync(string userId)
    {
        var user = await _userManager.FindByIdAsync(userId);
        if (user?.UserType != UserType.SuperAdmin)
        {
            return new List<Entity>();
        }

        return await _context.Entities
            .Include(e => e.Administrators) // Incluir administradores
            .Include(e => e.Professionals) // Incluir profesionales
            .OrderBy(e => e.BusinessName)
            .ToListAsync();
    }

    /// <summary>
    /// Obtiene una entidad por su ID
    /// </summary>
    public async Task<Entity?> GetEntityByIdAsync(int entityId)
    {
        return await _context.Entities
            .Include(e => e.Administrators)
                .ThenInclude(a => a.ApplicationUser)
            .Include(e => e.Professionals)
                .ThenInclude(p => p.ApplicationUser)
            .Include(e => e.Patients)
            .FirstOrDefaultAsync(e => e.Id == entityId);
    }

    /// <summary>
    /// Genera el enlace de confirmaci�n de email
    /// </summary>
    private string GenerateEmailConfirmationLink(string userId, string token)
    {
        // Obtener la URL base desde la configuraci�n
        var baseUrl = "https://tuaplicacion.com/confirmar-email"; // Cambiar por la URL de tu aplicaci�n

        // Generar el enlace completo
        var link = $"{baseUrl}?userId={userId}&token={Uri.EscapeDataString(token)}";

        return link;
    }
}

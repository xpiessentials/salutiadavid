using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using Salutia_Wep_App.Models.Consent;
using System.Text.RegularExpressions;

namespace Salutia_Wep_App.Services;

/// <summary>
/// Servicio para generar documentos PDF de consentimientos informados usando QuestPDF
/// </summary>
public interface IPdfGenerationService
{
    /// <summary>
    /// Genera un PDF para un consentimiento individual
    /// </summary>
    Task<string> GenerateConsentPdfAsync(PatientConsent consent, string outputPath);
    
    /// <summary>
    /// Genera un PDF con todos los consentimientos de un test
    /// </summary>
    Task<string> GenerateConsentPackagePdfAsync(List<PatientConsent> consents, string testId, string patientName, string outputPath);
}

public class PdfGenerationService : IPdfGenerationService
{
    private readonly ILogger<PdfGenerationService> _logger;

    public PdfGenerationService(ILogger<PdfGenerationService> logger)
    {
        _logger = logger;
        
        // Configurar licencia de QuestPDF (Community License)
        QuestPDF.Settings.License = LicenseType.Community;
    }

    public async Task<string> GenerateConsentPdfAsync(PatientConsent consent, string outputPath)
    {
        try
        {
            await Task.Run(() =>
            {
                Document.Create(container =>
                {
                    container.Page(page =>
                    {
                        page.Size(PageSizes.Letter);
                        page.Margin(40);
                        page.PageColor(Colors.White);
                        page.DefaultTextStyle(x => x.FontSize(11).FontFamily("Arial"));

                        page.Header().Element(c => ComposeHeader(c, consent));
                        page.Content().Element(c => ComposeContent(c, consent));
                        page.Footer().Element(c => ComposeFooter(c, consent));
                    });
                })
                .GeneratePdf(outputPath);
            });

            _logger.LogInformation("PDF generado exitosamente: {OutputPath}", outputPath);
            return outputPath;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando PDF para consentimiento {ConsentId}", consent.Id);
            throw;
        }
    }

    public async Task<string> GenerateConsentPackagePdfAsync(
        List<PatientConsent> consents, 
        string testId, 
        string patientName, 
        string outputPath)
    {
        try
        {
            await Task.Run(() =>
            {
                Document.Create(container =>
                {
                    container.Page(page =>
                    {
                        page.Size(PageSizes.Letter);
                        page.Margin(40);
                        page.PageColor(Colors.White);
                        page.DefaultTextStyle(x => x.FontSize(11).FontFamily("Arial"));

                        page.Header().Element(c => ComposePackageHeader(c, testId, patientName));
                        page.Content().Element(c => ComposePackageContent(c, consents));
                        page.Footer().Element(c => ComposePackageFooter(c));
                    });
                })
                .GeneratePdf(outputPath);
            });

            _logger.LogInformation("Paquete de PDFs generado exitosamente: {OutputPath}", outputPath);
            return outputPath;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando paquete de PDFs para test {TestId}", testId);
            throw;
        }
    }

    #region Composici�n de Documento Individual

    private void ComposeHeader(IContainer container, PatientConsent consent)
    {
        container.Row(row =>
        {
            // Logo y t�tulo (izquierda)
            row.RelativeItem().Column(column =>
            {
                column.Item().Text("SALUTIA")
                    .FontSize(24)
                    .Bold()
                    .FontColor(Colors.Blue.Darken2);

                column.Item().Text("Plataforma de Salud Ocupacional")
                    .FontSize(10)
                    .FontColor(Colors.Grey.Darken1);
            });

            // Informaci�n del documento (derecha)
            row.RelativeItem().AlignRight().Column(column =>
            {
                column.Item().Text($"Documento No. {consent.Id:D8}")
                    .FontSize(9)
                    .FontColor(Colors.Grey.Darken2);

                column.Item().Text($"Fecha: {consent.SignedAt:dd/MM/yyyy HH:mm}")
                    .FontSize(9)
                    .FontColor(Colors.Grey.Darken2);

                column.Item().Text($"Versi�n: {consent.ConsentVersion}")
                    .FontSize(9)
                    .FontColor(Colors.Grey.Darken2);
            });
        });

        container.PaddingTop(10).BorderBottom(2).BorderColor(Colors.Blue.Darken2);
    }

    private void ComposeContent(IContainer container, PatientConsent consent)
    {
        container.PaddingVertical(20).Column(column =>
        {
            // T�tulo del consentimiento
            column.Item().PaddingBottom(15).Text(consent.ConsentTemplate.Title)
                .FontSize(18)
                .Bold()
                .FontColor(Colors.Blue.Darken3);

            // Informaci�n del paciente
            column.Item().PaddingBottom(15).Element(c => ComposePatientInfo(c, consent));

            // Contenido del consentimiento
            column.Item().PaddingBottom(20).Element(c => ComposeHtmlContent(c, consent.ContentSnapshot));

            // Separador
            column.Item().PaddingVertical(10).LineHorizontal(1).LineColor(Colors.Grey.Lighten2);

            // Secci�n de firma
            column.Item().Element(c => ComposeSignatureSection(c, consent));

            // Informaci�n legal y auditor�a
            column.Item().PaddingTop(15).Element(c => ComposeAuditInfo(c, consent));
        });
    }

    private void ComposePatientInfo(IContainer container, PatientConsent consent)
    {
        container.Background(Colors.Grey.Lighten3)
            .Padding(10)
            .Column(column =>
            {
                column.Item().Text("INFORMACI�N DEL FIRMANTE")
                    .FontSize(10)
                    .Bold()
                    .FontColor(Colors.Grey.Darken3);

                column.Item().PaddingTop(5).Row(row =>
                {
                    row.RelativeItem().Text(text =>
                    {
                        text.Span("Nombre: ").Bold().FontSize(9);
                        text.Span(consent.Signature?.SignerFullName ?? "N/A").FontSize(9);
                    });

                    row.RelativeItem().Text(text =>
                    {
                        text.Span("Documento: ").Bold().FontSize(9);
                        text.Span(consent.Signature?.SignerDocumentNumber ?? "N/A").FontSize(9);
                    });
                });

                column.Item().PaddingTop(3).Row(row =>
                {
                    row.RelativeItem().Text(text =>
                    {
                        text.Span("Fecha de Firma: ").Bold().FontSize(9);
                        text.Span($"{consent.SignedAt:dd/MM/yyyy HH:mm:ss}").FontSize(9);
                    });

                    row.RelativeItem().Text(text =>
                    {
                        text.Span("Estado: ").Bold().FontSize(9);
                        text.Span(consent.IsAccepted ? "ACEPTADO" : "NO ACEPTADO")
                            .FontSize(9)
                            .FontColor(consent.IsAccepted ? Colors.Green.Darken2 : Colors.Red.Darken2);
                    });
                });
            });
    }

    private void ComposeHtmlContent(IContainer container, string htmlContent)
    {
        // Remover tags HTML y procesar el contenido
        var plainText = StripHtml(htmlContent);
        var sections = SplitIntoSections(plainText);

        container.Column(column =>
        {
            foreach (var section in sections)
            {
                if (section.IsHeading)
                {
                    column.Item().PaddingTop(10).PaddingBottom(5).Text(section.Content)
                        .FontSize(13)
                        .Bold()
                        .FontColor(Colors.Blue.Darken2);
                }
                else if (section.IsBullet)
                {
                    column.Item().PaddingLeft(15).PaddingBottom(3).Row(row =>
                    {
                        row.ConstantItem(15).Text("�").FontSize(10);
                        row.RelativeItem().Text(section.Content.Trim())
                            .FontSize(10)
                            .LineHeight(1.3f);
                    });
                }
                else
                {
                    column.Item().PaddingBottom(8).Text(section.Content)
                        .FontSize(10)
                        .LineHeight(1.4f)
                        .Justify();
                }
            }
        });
    }

    private void ComposeSignatureSection(IContainer container, PatientConsent consent)
    {
        container.Column(column =>
        {
            column.Item().PaddingBottom(10).Text("FIRMA DIGITAL")
                .FontSize(12)
                .Bold()
                .FontColor(Colors.Blue.Darken3);

            if (consent.Signature != null && !string.IsNullOrEmpty(consent.Signature.SignatureDataBase64))
            {
                try
                {
                    // Convertir base64 a bytes
                    var base64Data = consent.Signature.SignatureDataBase64;
                    if (base64Data.Contains(","))
                    {
                        base64Data = base64Data.Split(',')[1];
                    }

                    var imageBytes = Convert.FromBase64String(base64Data);

                    column.Item()
                        .Border(1)
                        .BorderColor(Colors.Grey.Darken1)
                        .Padding(10)
                        .Height(100)
                        .AlignCenter()
                        .AlignMiddle()
                        .Image(imageBytes);

                    column.Item().PaddingTop(5).AlignCenter().Text("Firma Digital Capturada Electr�nicamente")
                        .FontSize(8)
                        .Italic()
                        .FontColor(Colors.Grey.Darken2);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Error procesando imagen de firma");
                    column.Item().Border(1).BorderColor(Colors.Grey.Lighten2)
                        .Padding(10)
                        .Height(80)
                        .AlignCenter()
                        .AlignMiddle()
                        .Text("[Firma Digital - Error al Cargar Imagen]")
                        .FontSize(9)
                        .FontColor(Colors.Grey.Darken1);
                }
            }
            else
            {
                column.Item().Border(1).BorderColor(Colors.Grey.Lighten2)
                    .Padding(10)
                    .Height(80)
                    .AlignCenter()
                    .AlignMiddle()
                    .Text("[Sin Firma Digital]")
                    .FontSize(9)
                    .FontColor(Colors.Grey.Darken1);
            }

            // Informaci�n del tipo de firma
            column.Item().PaddingTop(5).Text(text =>
            {
                text.Span("Tipo de Firma: ").Bold().FontSize(8);
                text.Span(consent.Signature?.SignatureType.ToString() ?? "N/A").FontSize(8);
            });
        });
    }

    private void ComposeAuditInfo(IContainer container, PatientConsent consent)
    {
        container.Background(Colors.Grey.Lighten4)
            .Padding(8)
            .Column(column =>
            {
                column.Item().Text("INFORMACI�N DE AUDITOR�A Y TRAZABILIDAD")
                    .FontSize(8)
                    .Bold()
                    .FontColor(Colors.Grey.Darken3);

                column.Item().PaddingTop(5).Text(text =>
                {
                    text.Span("Direcci�n IP: ").Bold().FontSize(7);
                    text.Span(consent.IpAddress).FontSize(7).FontColor(Colors.Grey.Darken2);
                });

                column.Item().PaddingTop(2).Text(text =>
                {
                    text.Span("Navegador: ").Bold().FontSize(7);
                    text.Span(TruncateUserAgent(consent.UserAgent)).FontSize(7).FontColor(Colors.Grey.Darken2);
                });

                column.Item().PaddingTop(2).Text(text =>
                {
                    text.Span("ID del Test: ").Bold().FontSize(7);
                    text.Span(consent.PsychosomaticTestId.ToString()).FontSize(7).FontColor(Colors.Grey.Darken2);
                });

                column.Item().PaddingTop(5).Text("Este documento es una copia fiel del consentimiento informado firmado digitalmente. " +
                    "La firma electr�nica tiene la misma validez legal que una firma manuscrita seg�n la Ley 527 de 1999.")
                    .FontSize(7)
                    .Italic()
                    .FontColor(Colors.Grey.Darken2)
                    .LineHeight(1.2f);
            });
    }

    private void ComposeFooter(IContainer container, PatientConsent consent)
    {
        container.AlignCenter().Column(column =>
        {
            column.Item().LineHorizontal(1).LineColor(Colors.Grey.Lighten2);
            
            column.Item().PaddingTop(5).Text(text =>
            {
                text.Span("SALUTIA - Plataforma de Salud Ocupacional | ").FontSize(8).FontColor(Colors.Grey.Darken2);
                text.Span("www.salutia.com.co | ").FontSize(8).FontColor(Colors.Grey.Darken2);
                text.Span($"Generado: {DateTime.Now:dd/MM/yyyy HH:mm}").FontSize(8).FontColor(Colors.Grey.Darken2);
            });

            column.Item().PaddingTop(3).Row(row =>
            {
                row.RelativeItem().AlignCenter().Text(text =>
                {
                    text.CurrentPageNumber().FontSize(8).FontColor(Colors.Grey.Darken2);
                    text.Span(" / ").FontSize(8).FontColor(Colors.Grey.Darken2);
                    text.TotalPages().FontSize(8).FontColor(Colors.Grey.Darken2);
                });
            });
        });
    }

    #endregion

    #region Composici�n de Paquete

    private void ComposePackageHeader(IContainer container, string testId, string patientName)
    {
        container.Column(column =>
        {
            column.Item().Row(row =>
            {
                row.RelativeItem().Column(col =>
                {
                    col.Item().Text("SALUTIA")
                        .FontSize(24)
                        .Bold()
                        .FontColor(Colors.Blue.Darken2);

                    col.Item().Text("Plataforma de Salud Ocupacional")
                        .FontSize(10)
                        .FontColor(Colors.Grey.Darken1);
                });

                row.RelativeItem().AlignRight().Column(col =>
                {
                    col.Item().Text($"Test ID: {testId}")
                        .FontSize(9)
                        .FontColor(Colors.Grey.Darken2);

                    col.Item().Text($"Fecha: {DateTime.Now:dd/MM/yyyy HH:mm}")
                        .FontSize(9)
                        .FontColor(Colors.Grey.Darken2);
                });
            });

            column.Item().PaddingTop(10).BorderBottom(2).BorderColor(Colors.Blue.Darken2);

            column.Item().PaddingTop(15).Text("PAQUETE DE CONSENTIMIENTOS INFORMADOS")
                .FontSize(16)
                .Bold()
                .FontColor(Colors.Blue.Darken3);

            column.Item().PaddingTop(5).Text($"Paciente: {patientName}")
                .FontSize(12)
                .FontColor(Colors.Grey.Darken2);
        });
    }

    private void ComposePackageContent(IContainer container, List<PatientConsent> consents)
    {
        container.PaddingVertical(20).Column(column =>
        {
            foreach (var consent in consents.OrderBy(c => c.ConsentTemplate.DisplayOrder))
            {
                column.Item().PageBreak();
                
                column.Item().PaddingBottom(15).Text($"{consent.ConsentTemplate.DisplayOrder}. {consent.ConsentTemplate.Title}")
                    .FontSize(16)
                    .Bold()
                    .FontColor(Colors.Blue.Darken3);

                column.Item().PaddingBottom(10).Element(c => ComposePatientInfo(c, consent));
                column.Item().PaddingBottom(15).Element(c => ComposeHtmlContent(c, consent.ContentSnapshot));
                column.Item().PaddingBottom(15).Element(c => ComposeSignatureSection(c, consent));
                column.Item().PaddingBottom(20).Element(c => ComposeAuditInfo(c, consent));
            }
        });
    }

    private void ComposePackageFooter(IContainer container)
    {
        container.AlignCenter().Column(column =>
        {
            column.Item().LineHorizontal(1).LineColor(Colors.Grey.Lighten2);
            
            column.Item().PaddingTop(5).Text(text =>
            {
                text.Span("SALUTIA - Plataforma de Salud Ocupacional | ").FontSize(8).FontColor(Colors.Grey.Darken2);
                text.Span("Paquete de Consentimientos Informados").FontSize(8).FontColor(Colors.Grey.Darken2);
            });

            column.Item().PaddingTop(3).Row(row =>
            {
                row.RelativeItem().AlignCenter().Text(text =>
                {
                    text.Span("P�gina ").FontSize(8).FontColor(Colors.Grey.Darken2);
                    text.CurrentPageNumber().FontSize(8).FontColor(Colors.Grey.Darken2);
                    text.Span(" de ").FontSize(8).FontColor(Colors.Grey.Darken2);
                    text.TotalPages().FontSize(8).FontColor(Colors.Grey.Darken2);
                });
            });
        });
    }

    #endregion

    #region M�todos Auxiliares

    private string StripHtml(string html)
    {
        if (string.IsNullOrEmpty(html)) return string.Empty;

        // Remover scripts y styles
        html = Regex.Replace(html, @"<script[^>]*>[\s\S]*?</script>", string.Empty, RegexOptions.IgnoreCase);
        html = Regex.Replace(html, @"<style[^>]*>[\s\S]*?</style>", string.Empty, RegexOptions.IgnoreCase);

        // Reemplazar tags de encabezado con marcadores
        html = Regex.Replace(html, @"<h[1-6][^>]*>(.*?)</h[1-6]>", "##HEADING##$1##ENDHEADING##", RegexOptions.IgnoreCase);

        // Reemplazar items de lista con marcadores
        html = Regex.Replace(html, @"<li[^>]*>(.*?)</li>", "##BULLET##$1##ENDBULLET##", RegexOptions.IgnoreCase);

        // Reemplazar p�rrafos y breaks con saltos de l�nea
        html = Regex.Replace(html, @"<p[^>]*>", "\n", RegexOptions.IgnoreCase);
        html = Regex.Replace(html, @"</p>", "\n", RegexOptions.IgnoreCase);
        html = Regex.Replace(html, @"<br\s*/?>", "\n", RegexOptions.IgnoreCase);

        // Remover todas las dem�s tags HTML
        html = Regex.Replace(html, @"<[^>]+>", string.Empty);

        // Decodificar entidades HTML
        html = System.Net.WebUtility.HtmlDecode(html);

        // Limpiar espacios m�ltiples
        html = Regex.Replace(html, @"\s+", " ");

        return html.Trim();
    }

    private List<ContentSection> SplitIntoSections(string content)
    {
        var sections = new List<ContentSection>();
        var lines = content.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

        foreach (var line in lines)
        {
            var trimmedLine = line.Trim();
            if (string.IsNullOrWhiteSpace(trimmedLine)) continue;

            if (trimmedLine.Contains("##HEADING##"))
            {
                var text = trimmedLine.Replace("##HEADING##", "").Replace("##ENDHEADING##", "").Trim();
                sections.Add(new ContentSection { Content = text, IsHeading = true });
            }
            else if (trimmedLine.Contains("##BULLET##"))
            {
                var text = trimmedLine.Replace("##BULLET##", "").Replace("##ENDBULLET##", "").Trim();
                sections.Add(new ContentSection { Content = text, IsBullet = true });
            }
            else
            {
                sections.Add(new ContentSection { Content = trimmedLine, IsHeading = false, IsBullet = false });
            }
        }

        return sections;
    }

    private string TruncateUserAgent(string userAgent)
    {
        if (string.IsNullOrEmpty(userAgent)) return "N/A";
        return userAgent.Length > 100 ? userAgent.Substring(0, 100) + "..." : userAgent;
    }

    private class ContentSection
    {
        public string Content { get; set; } = string.Empty;
        public bool IsHeading { get; set; }
        public bool IsBullet { get; set; }
    }

    #endregion
}

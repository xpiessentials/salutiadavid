using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Salutia_Wep_App.Data;

namespace Salutia_Wep_App.Services;

/// <summary>
/// Servicio de autenticaci�n personalizado que soporta login con email o n�mero de documento
/// </summary>
public class CustomAuthenticationService
{
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly ApplicationDbContext _context;
    private readonly ILogger<CustomAuthenticationService> _logger;

    public CustomAuthenticationService(
        SignInManager<ApplicationUser> signInManager,
        UserManager<ApplicationUser> userManager,
        ApplicationDbContext context,
        ILogger<CustomAuthenticationService> logger)
    {
        _signInManager = signInManager;
        _userManager = userManager;
        _context = context;
        _logger = logger;
    }

    /// <summary>
    /// Intenta autenticar con email o n�mero de documento
    /// </summary>
    public async Task<(SignInResult Result, ApplicationUser? User, string LoginType)> SignInAsync(
        string usernameOrDocument,
        string password,
        bool rememberMe,
        bool lockoutOnFailure = true)
    {
        try
        {
            ApplicationUser? user = null;
            string loginType = "unknown";

            // Primero intentar buscar por email
            if (usernameOrDocument.Contains("@"))
            {
                user = await _userManager.FindByEmailAsync(usernameOrDocument);
                loginType = "email";
            }

            // Si no se encontr� por email, buscar por n�mero de documento (username)
            if (user == null)
            {
                user = await _userManager.FindByNameAsync(usernameOrDocument);
                loginType = "document";
            }

            // Si no se encontr� el usuario
            if (user == null)
            {
                _logger.LogWarning("Intento de login fallido: usuario no encontrado - {Username}", usernameOrDocument);
                return (SignInResult.Failed, null, loginType);
            }

            // Verificar que el usuario est� activo
            if (!user.IsActive)
            {
                _logger.LogWarning("Intento de login de usuario inactivo: {UserId}", user.Id);
                return (SignInResult.Failed, user, loginType);
            }

            // Intentar autenticaci�n
            var result = await _signInManager.PasswordSignInAsync(
                user,
                password,
                rememberMe,
                lockoutOnFailure);

            if (result.Succeeded)
            {
                _logger.LogInformation(
                    "Usuario autenticado exitosamente: {UserId}, LoginType: {LoginType}", 
                    user.Id, 
                    loginType);
            }
            else
            {
                _logger.LogWarning(
                    "Intento de login fallido para usuario {UserId}: {Result}", 
                    user.Id, 
                    result);
            }

            return (result, user, loginType);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error durante autenticaci�n");
            return (SignInResult.Failed, null, "error");
        }
    }

    /// <summary>
    /// Verifica si un usuario necesita completar su perfil
    /// </summary>
    public async Task<bool> RequiresProfileCompletionAsync(string userId)
    {
        var patient = await _context.PatientProfiles
            .FirstOrDefaultAsync(p => p.ApplicationUserId == userId);

        if (patient == null)
            return false;

        return patient.IsEntityPatient && !patient.ProfileCompleted;
    }

    /// <summary>
    /// Obtiene la URL de redirecci�n apropiada despu�s del login
    /// </summary>
    public async Task<string> GetPostLoginRedirectUrlAsync(ApplicationUser user, string? returnUrl)
    {
        // Si hay una URL de retorno espec�fica, usarla
        if (!string.IsNullOrEmpty(returnUrl) && returnUrl != "/")
        {
            return returnUrl;
        }

        // Verificar si necesita completar perfil
        if (user.UserType == UserType.Patient)
        {
            var needsCompletion = await RequiresProfileCompletionAsync(user.Id);
            if (needsCompletion)
            {
                return "/Patient/CompleteProfile";
            }
        }

        // Redirigir seg�n tipo de usuario
        return user.UserType switch
        {
            UserType.SuperAdmin => "/Admin/Dashboard",
            UserType.EntityAdmin => "/Entity/Dashboard",
            UserType.Independent => "/User/Dashboard",
            UserType.Doctor => "/Professional/Dashboard",
            UserType.Psychologist => "/Professional/Dashboard",
            UserType.Patient => "/Patient/Dashboard",
            _ => "/"
        };
    }

    /// <summary>
    /// Valida formato de documento
    /// </summary>
    public bool IsValidDocumentNumber(string documentNumber)
    {
        if (string.IsNullOrWhiteSpace(documentNumber))
            return false;

        // Documento debe tener entre 5 y 50 caracteres alfanum�ricos
        return documentNumber.Length >= 5 
            && documentNumber.Length <= 50 
            && documentNumber.All(c => char.IsLetterOrDigit(c));
    }

    /// <summary>
    /// Determina si el input es un email o n�mero de documento
    /// </summary>
    public string GetLoginInputType(string input)
    {
        if (string.IsNullOrWhiteSpace(input))
            return "invalid";

        return input.Contains("@") ? "email" : "document";
    }
}

using QRCoder;

namespace Salutia_Wep_App.Services;

/// <summary>
/// Servicio para generar c�digos QR
/// </summary>
public class QrCodeService
{
    /// <summary>
    /// Genera un c�digo QR en formato Base64 PNG a partir de un texto
    /// </summary>
    /// <param name="text">Texto a codificar en el QR</param>
    /// <param name="pixelsPerModule">Tama�o del m�dulo en p�xeles (por defecto 20)</param>
    /// <returns>String en formato Base64 de la imagen PNG del c�digo QR</returns>
    public string GenerateQrCodeBase64(string text, int pixelsPerModule = 20)
 {
        using var qrGenerator = new QRCodeGenerator();
        using var qrCodeData = qrGenerator.CreateQrCode(text, QRCodeGenerator.ECCLevel.Q);
        using var qrCode = new PngByteQRCode(qrCodeData);
        
        var qrCodeImage = qrCode.GetGraphic(pixelsPerModule);
        return Convert.ToBase64String(qrCodeImage);
    }

    /// <summary>
    /// Genera un URI de datos (data URI) completo para usar directamente en una etiqueta img
    /// </summary>
    /// <param name="text">Texto a codificar en el QR</param>
    /// <param name="pixelsPerModule">Tama�o del m�dulo en p�xeles (por defecto 20)</param>
    /// <returns>Data URI completo (data:image/png;base64,...)</returns>
    public string GenerateQrCodeDataUri(string text, int pixelsPerModule = 20)
    {
        var base64Image = GenerateQrCodeBase64(text, pixelsPerModule);
        return $"data:image/png;base64,{base64Image}";
    }
}

using Microsoft.AspNetCore.Mvc;
using Salutia_Wep_App.Services;
using Microsoft.AspNetCore.Authorization;

namespace Salutia_Wep_App.Controllers;

/// <summary>
/// Controlador para pruebas de funcionalidades del sistema
/// Solo disponible en modo Development
/// </summary>
[ApiController]
[Route("api/[controller]")]
public class TestController : ControllerBase
{
    private readonly IEmailService _emailService;
    private readonly ILogger<TestController> _logger;
    private readonly IWebHostEnvironment _environment;

    public TestController(
        IEmailService emailService,
        ILogger<TestController> logger,
        IWebHostEnvironment environment)
    {
        _emailService = emailService;
        _logger = logger;
        _environment = environment;
    }

    /// <summary>
    /// Prueba de env�o de email
    /// GET: api/Test/test-email?to=correo@ejemplo.com
    /// </summary>
    [HttpGet("test-email")]
    public async Task<IActionResult> TestEmail([FromQuery] string to)
    {
        // Solo permitir en Development
        if (!_environment.IsDevelopment())
        {
            return NotFound();
        }

        if (string.IsNullOrEmpty(to))
        {
            return BadRequest(new { 
                success = false, 
                message = "Debes proporcionar un email de destino usando el par�metro 'to'" 
            });
        }

        try
        {
            _logger.LogInformation("=== INICIANDO PRUEBA DE EMAIL ===");
            _logger.LogInformation("Destinatario: {To}", to);

            var subject = "? Prueba de Email - Salutia";
            var htmlBody = @"
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #28a745 0%, #20c997 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
        .success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .info { background: #e9ecef; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h1>? �Email de Prueba!</h1>
            <p>Salutia - Plataforma de Salud Ocupacional</p>
        </div>
        <div class='content'>
            <div class='success'>
                <strong>? �Funciona Correctamente!</strong>
                <p>Si est�s leyendo esto, significa que el servicio de correo de Salutia est� funcionando perfectamente.</p>
            </div>
            
            <h3>Detalles de la Prueba:</h3>
            <div class='info'>
                <strong>?? Servidor SMTP:</strong> mail.iaparatodospodcast.com<br>
                <strong>?? Puerto:</strong> 465 (SSL/TLS)<br>
                <strong>?? Remitente:</strong> notificaciones@iaparatodospodcast.com<br>
                <strong>?? Enviado:</strong> " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + @"
            </div>

            <h3>Sistema Configurado:</h3>
            <ul>
                <li>? Confirmaci�n de email al registrarse</li>
                <li>? Recuperaci�n de contrase�a</li>
                <li>? Email de bienvenida</li>
                <li>? Notificaciones del sistema</li>
            </ul>

            <p><strong>El sistema de correo est� listo para usarse en producci�n.</strong></p>
        </div>
        <div class='footer'>
            <p>Este es un correo de prueba autom�tico.</p>
            <p>&copy; 2024 Salutia. Todos los derechos reservados.</p>
        </div>
    </div>
</body>
</html>";

            _logger.LogInformation("Enviando email de prueba...");
            await _emailService.SendEmailAsync(to, subject, htmlBody);
            
            _logger.LogInformation("=== EMAIL ENVIADO EXITOSAMENTE ===");

            return Ok(new
            {
                success = true,
                message = $"? Email de prueba enviado exitosamente a {to}",
                details = new
                {
                    to = to,
                    subject = subject,
                    server = "mail.iaparatodospodcast.com",
                    port = 465,
                    ssl = true,
                    sentAt = DateTime.Now
                }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "=== ERROR AL ENVIAR EMAIL DE PRUEBA ===");
            _logger.LogError("Mensaje: {Message}", ex.Message);
            _logger.LogError("StackTrace: {StackTrace}", ex.StackTrace);

            if (ex.InnerException != null)
            {
                _logger.LogError("InnerException: {InnerMessage}", ex.InnerException.Message);
            }

            return StatusCode(500, new
            {
                success = false,
                message = "? Error al enviar el email de prueba",
                error = ex.Message,
                innerError = ex.InnerException?.Message,
                details = new
                {
                    to = to,
                    server = "mail.iaparatodospodcast.com",
                    port = 465,
                    ssl = true
                }
            });
        }
    }

    /// <summary>
    /// Informaci�n del sistema de email
    /// GET: api/Test/email-config
    /// </summary>
    [HttpGet("email-config")]
    public IActionResult GetEmailConfig()
    {
        // Solo permitir en Development
        if (!_environment.IsDevelopment())
        {
            return NotFound();
        }

        return Ok(new
        {
            server = "mail.iaparatodospodcast.com",
            port = 465,
            ssl = true,
            sender = "notificaciones@iaparatodospodcast.com",
            senderName = "Salutia - Plataforma de Salud Ocupacional",
            configured = true,
            environment = _environment.EnvironmentName
        });
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Salutia_Wep_App.Models.Reports;
using Salutia_Wep_App.Services;

namespace Salutia_Wep_App.Controllers;

/// <summary>
/// Controlador para generaci�n y descarga de reportes PDF
/// </summary>
[Authorize]
[ApiController]
[Route("api/[controller]")]
public class ReportController : ControllerBase
{
    private readonly PdfReportService _reportService;
    private readonly ILogger<ReportController> _logger;

    public ReportController(
        PdfReportService reportService,
   ILogger<ReportController> logger)
    {
 _reportService = reportService;
  _logger = logger;
    }

    /// <summary>
    /// Genera y descarga el reporte completo de un paciente
    /// </summary>
    [HttpGet("patient/{patientId}")]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetPatientReport(string patientId)
    {
        try
        {
   _logger.LogInformation("Generating patient report for ID: {PatientId}", patientId);

            // TODO: Obtener datos reales del paciente desde la base de datos
 var patient = await GetPatientDataAsync(patientId);
            
            if (patient == null)
    {
      _logger.LogWarning("Patient not found: {PatientId}", patientId);
         return NotFound($"Paciente con ID {patientId} no encontrado.");
 }

var pdfBytes = _reportService.GeneratePatientReport(patient);
  
            var fileName = $"Reporte-Paciente-{patient.FullName.Replace(" ", "-")}-{DateTime.Now:yyyyMMdd}.pdf";
            
            _logger.LogInformation("Patient report generated successfully for: {PatientName}", patient.FullName);
       
      return File(pdfBytes, "application/pdf", fileName);
     }
      catch (Exception ex)
        {
      _logger.LogError(ex, "Error generating patient report for ID: {PatientId}", patientId);
  return StatusCode(500, "Error al generar el reporte.");
  }
    }

    /// <summary>
    /// Genera y descarga el reporte de citas m�dicas de un paciente
    /// </summary>
    [HttpGet("appointments/{patientId}")]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAppointmentsReport(string patientId)
    {
   try
        {
      _logger.LogInformation("Generating appointments report for patient: {PatientId}", patientId);

            // TODO: Obtener citas desde la base de datos
          var patient = await GetPatientDataAsync(patientId);
      var appointments = await GetPatientAppointmentsAsync(patientId);

     if (patient == null)
       {
           return NotFound($"Paciente con ID {patientId} no encontrado.");
        }

     var pdfBytes = _reportService.GenerateAppointmentsReport(patient.FullName, appointments);
            
    var fileName = $"Historial-Citas-{patient.FullName.Replace(" ", "-")}-{DateTime.Now:yyyyMMdd}.pdf";
       
        return File(pdfBytes, "application/pdf", fileName);
        }
        catch (Exception ex)
     {
            _logger.LogError(ex, "Error generating appointments report for patient: {PatientId}", patientId);
     return StatusCode(500, "Error al generar el reporte de citas.");
        }
    }

    /// <summary>
    /// Genera y descarga el reporte del test psicosom�tico
    /// </summary>
    [HttpGet("psychosomatic-test/{testId}")]
    [AllowAnonymous] // Permitir acceso sin autenticaci�n para tests an�nimos
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetPsychosomaticTestReport(string testId)
    {
        try
        {
            _logger.LogInformation("Generating psychosomatic test report for ID: {TestId}", testId);

   // TODO: Obtener resultado del test desde la base de datos
            var testResult = await GetTestResultAsync(testId);

            if (testResult == null)
          {
       return NotFound($"Test con ID {testId} no encontrado.");
            }

     var pdfBytes = _reportService.GeneratePsychosomaticTestReport(testResult);
            
      var fileName = $"Test-Psicosomatico-{DateTime.Now:yyyyMMdd-HHmmss}.pdf";
      
    return File(pdfBytes, "application/pdf", fileName);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating psychosomatic test report for ID: {TestId}", testId);
            return StatusCode(500, "Error al generar el reporte del test.");
        }
    }

    /// <summary>
  /// Genera reporte del test psicosom�tico desde datos en POST
    /// </summary>
    [HttpPost("psychosomatic-test")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public IActionResult GeneratePsychosomaticTestReport([FromBody] PsychosomaticTestReportModel testResult)
    {
        try
        {
   _logger.LogInformation("Generating psychosomatic test report for patient: {PatientName}", testResult.PatientName);

            var pdfBytes = _reportService.GeneratePsychosomaticTestReport(testResult);
       
    var fileName = $"Test-Psicosomatico-{testResult.PatientName.Replace(" ", "-")}-{DateTime.Now:yyyyMMdd}.pdf";
          
      return File(pdfBytes, "application/pdf", fileName);
        }
        catch (Exception ex)
        {
       _logger.LogError(ex, "Error generating psychosomatic test report");
   return StatusCode(500, "Error al generar el reporte del test.");
        }
    }

    // M�todos auxiliares - TODO: Implementar con acceso real a la base de datos
    
    private async Task<PatientReportModel?> GetPatientDataAsync(string patientId)
    {
        // Simulaci�n - reemplazar con acceso real a BD
        await Task.CompletedTask;
        
     return new PatientReportModel
     {
    Id = patientId,
      FullName = "Juan P�rez Garc�a",
   IdNumber = "1234567890",
         BirthDate = new DateTime(1985, 5, 15),
    Gender = "Masculino",
          Email = "juan.perez@example.com",
      Phone = "(300) 123-4567",
   Address = "Calle 123 #45-67, Bogot�",
        BloodType = "O+",
      Allergies = new List<string> { "Penicilina", "Mariscos" },
  MedicalHistory = "Hipertensi�n controlada con medicamento. Sin cirug�as previas.",
         RegistrationDate = DateTime.Now.AddYears(-2)
        };
    }

    private async Task<List<AppointmentReportModel>> GetPatientAppointmentsAsync(string patientId)
    {
        // Simulaci�n - reemplazar con acceso real a BD
        await Task.CompletedTask;
        
        return new List<AppointmentReportModel>
        {
       new AppointmentReportModel
   {
    Id = "1",
    Date = DateTime.Now.AddDays(-30),
                Doctor = "Dr. Carlos Rodr�guez",
          Specialty = "Medicina General",
            Location = "Consultorio 101",
            Notes = "Control de rutina. Presi�n arterial normal.",
 Status = "Completada"
         },
            new AppointmentReportModel
            {
  Id = "2",
       Date = DateTime.Now.AddDays(-60),
         Doctor = "Dra. Mar�a L�pez",
  Specialty = "Cardiolog�a",
   Location = "Consultorio 205",
              Notes = "Evaluaci�n cardiovascular. Electrocardiograma normal.",
     Status = "Completada"
     }
        };
    }

    private async Task<PsychosomaticTestReportModel?> GetTestResultAsync(string testId)
    {
        // Simulaci�n - reemplazar con acceso real a BD
        await Task.CompletedTask;
        
        return new PsychosomaticTestReportModel
{
            Id = testId,
      PatientName = "Juan P�rez",
            PatientEmail = "juan.perez@example.com",
      TestDate = DateTime.Now,
            TotalScore = 12,
            Category = "Nivel Moderado de S�ntomas Psicosom�ticos",
       Interpretation = "Tus resultados muestran un nivel moderado de s�ntomas psicosom�ticos. Es posible que el estr�s y las emociones est�n comenzando a afectar tu bienestar f�sico.",
         Recommendations = new List<string>
    {
  "Incorpora t�cnicas de relajaci�n como meditaci�n o yoga",
          "Establece l�mites saludables en tu vida personal y laboral",
"Mejora tu higiene del sue�o con una rutina nocturna",
  "Considera actividades f�sicas regulares (caminar, nadar, etc.)",
  "Mant�n una alimentaci�n balanceada y horarios regulares de comida"
        }
};
    }
}

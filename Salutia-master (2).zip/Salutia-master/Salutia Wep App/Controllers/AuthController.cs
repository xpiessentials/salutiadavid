using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Salutia_Wep_App.Data;
using System.Security.Claims;

// Usings globales del proyecto compartido
using User = Salutia.Shared.Models.User;
using AuthResponse = Salutia.Shared.Models.AuthResponse;
using LoginRequest = Salutia.Shared.Models.LoginRequest;
using RegisterRequest = Salutia.Shared.Models.RegisterRequest;
using TwoFactorSetup = Salutia.Shared.Models.TwoFactorSetup;
using TwoFactorVerifyRequest = Salutia.Shared.Models.TwoFactorVerifyRequest;

namespace Salutia_Wep_App.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly UserManager<ApplicationUser> _userManager;
 private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly ILogger<AuthController> _logger;

    public AuthController(
      UserManager<ApplicationUser> userManager,
        SignInManager<ApplicationUser> signInManager,
   ILogger<AuthController> logger)
    {
        _userManager = userManager;
      _signInManager = signInManager;
        _logger = logger;
    }

    /// <summary>
    /// Endpoint de login para la aplicaci�n m�vil
    /// </summary>
    [HttpPost("login")]
    public async Task<ActionResult<AuthResponse>> Login([FromBody] LoginRequest request)
    {
        try
 {
          var user = await _userManager.FindByEmailAsync(request.Email);
     if (user == null)
        {
         return Ok(new AuthResponse
        {
    Success = false,
  Message = "Email o contrase�a incorrectos"
    });
        }

            var result = await _signInManager.CheckPasswordSignInAsync(user, request.Password, lockoutOnFailure: false);

            if (result.Succeeded)
        {
   // TODO: Generar JWT token real aqu�
    var token = GenerateSimpleToken(user);

    return Ok(new AuthResponse
   {
   Success = true,
        Message = "Login exitoso",
        Token = token,
      User = new User
   {
         Id = user.Id,
    Email = user.Email!,
   UserName = user.UserName!,
   EmailConfirmed = user.EmailConfirmed,
        TwoFactorEnabled = user.TwoFactorEnabled,
   PhoneNumber = user.PhoneNumber ?? string.Empty
  }
         });
   }
    else if (result.RequiresTwoFactor)
       {
        return Ok(new AuthResponse
     {
       Success = false,
RequiresTwoFactor = true,
      Message = "Se requiere autenticaci�n de dos factores"
 });
        }
            else if (result.IsLockedOut)
  {
     return Ok(new AuthResponse
  {
    Success = false,
    Message = "Cuenta bloqueada. Intenta m�s tarde."
  });
       }

 return Ok(new AuthResponse
            {
        Success = false,
        Message = "Email o contrase�a incorrectos"
 });
      }
     catch (Exception ex)
        {
       _logger.LogError(ex, "Error during login");
      return Ok(new AuthResponse
    {
Success = false,
      Message = "Error del servidor al intentar iniciar sesi�n"
   });
        }
    }

    /// <summary>
  /// Endpoint de registro para la aplicaci�n m�vil
    /// </summary>
    [HttpPost("register")]
  public async Task<ActionResult<AuthResponse>> Register([FromBody] RegisterRequest request)
    {
try
        {
    var existingUser = await _userManager.FindByEmailAsync(request.Email);
       if (existingUser != null)
            {
       return Ok(new AuthResponse
   {
  Success = false,
  Message = "El email ya est� registrado"
  });
            }

          var user = new ApplicationUser
    {
 UserName = request.Email,
   Email = request.Email,
    EmailConfirmed = false // En producci�n, enviar email de confirmaci�n
            };

    var result = await _userManager.CreateAsync(user, request.Password);

      if (result.Succeeded)
      {
 _logger.LogInformation($"Usuario registrado: {user.Email}");

     return Ok(new AuthResponse
         {
      Success = true,
    Message = "Registro exitoso. Por favor, confirma tu email."
    });
 }

   var errors = string.Join(", ", result.Errors.Select(e => e.Description));
     return Ok(new AuthResponse
       {
Success = false,
  Message = errors
  });
      }
        catch (Exception ex)
    {
      _logger.LogError(ex, "Error during registration");
      return Ok(new AuthResponse
  {
    Success = false,
            Message = "Error del servidor al intentar registrar"
    });
        }
    }

    /// <summary>
    /// Endpoint de logout
    /// </summary>
  [HttpPost("logout")]
    public async Task<ActionResult> Logout()
    {
 await _signInManager.SignOutAsync();
        return Ok();
    }

    /// <summary>
    /// Obtener usuario actual (requiere autenticaci�n)
 /// </summary>
    [HttpGet("me")]
    public async Task<ActionResult<User>> GetCurrentUser()
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(userId))
   {
   return Unauthorized();
 }

    var user = await _userManager.FindByIdAsync(userId);
   if (user == null)
     {
      return NotFound();
        }

        return Ok(new User
        {
 Id = user.Id,
     Email = user.Email!,
    UserName = user.UserName!,
        EmailConfirmed = user.EmailConfirmed,
            TwoFactorEnabled = user.TwoFactorEnabled,
 PhoneNumber = user.PhoneNumber ?? string.Empty
     });
}

/// <summary>
    /// Habilitar 2FA
    /// </summary>
    [HttpPost("enable-2fa")]
    public async Task<ActionResult<TwoFactorSetup>> EnableTwoFactor()
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
    if (string.IsNullOrEmpty(userId))
        {
  return Unauthorized();
  }

 var user = await _userManager.FindByIdAsync(userId);
    if (user == null)
        {
        return NotFound();
      }

        await _userManager.ResetAuthenticatorKeyAsync(user);
        var key = await _userManager.GetAuthenticatorKeyAsync(user);

        var authenticatorUri = GenerateQrCodeUri(user.Email!, key!);

 return Ok(new TwoFactorSetup
        {
   SharedKey = FormatKey(key!),
            AuthenticatorUri = authenticatorUri
});
    }

  /// <summary>
    /// Verificar c�digo 2FA
  /// </summary>
    [HttpPost("verify-2fa")]
    public async Task<ActionResult<bool>> VerifyTwoFactor([FromBody] TwoFactorVerifyRequest request)
    {
      var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
    if (string.IsNullOrEmpty(userId))
   {
            return Unauthorized();
        }

    var user = await _userManager.FindByIdAsync(userId);
        if (user == null)
        {
   return NotFound();
        }

    var verificationCode = request.Code?.Replace(" ", string.Empty).Replace("-", string.Empty) ?? string.Empty;
    var is2faTokenValid = await _userManager.VerifyTwoFactorTokenAsync(
          user,
         _userManager.Options.Tokens.AuthenticatorTokenProvider,
       verificationCode);

     if (is2faTokenValid)
        {
         await _userManager.SetTwoFactorEnabledAsync(user, true);
        return Ok(true);
      }

        return Ok(false);
    }

    /// <summary>
 /// Deshabilitar 2FA
    /// </summary>
    [HttpPost("disable-2fa")]
    public async Task<ActionResult<bool>> DisableTwoFactor()
  {
     var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
    if (string.IsNullOrEmpty(userId))
        {
          return Unauthorized();
    }

        var user = await _userManager.FindByIdAsync(userId);
      if (user == null)
        {
            return NotFound();
   }

      await _userManager.SetTwoFactorEnabledAsync(user, false);
        return Ok(true);
    }

    #region Helper Methods

    private string GenerateSimpleToken(ApplicationUser user)
{
 // TODO: Implementar generaci�n de JWT token real
        // Por ahora, generar un token simple para desarrollo
        return $"Bearer_{user.Id}_{Guid.NewGuid()}";
    }

    private string FormatKey(string unformattedKey)
    {
        var result = new System.Text.StringBuilder();
        int currentPosition = 0;
  while (currentPosition + 4 < unformattedKey.Length)
   {
  result.Append(unformattedKey.AsSpan(currentPosition, 4)).Append(' ');
  currentPosition += 4;
        }
   if (currentPosition < unformattedKey.Length)
{
         result.Append(unformattedKey.AsSpan(currentPosition));
        }
 return result.ToString().ToLowerInvariant();
    }

    private string GenerateQrCodeUri(string email, string unformattedKey)
    {
 const string AuthenticatorUriFormat = "otpauth://totp/{0}:{1}?secret={2}&issuer={0}&digits=6";
        return string.Format(
     System.Globalization.CultureInfo.InvariantCulture,
      AuthenticatorUriFormat,
  Uri.EscapeDataString("Salutia"),
 Uri.EscapeDataString(email),
   unformattedKey);
    }

    #endregion
}

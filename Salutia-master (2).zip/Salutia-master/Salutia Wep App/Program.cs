using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Salutia_Wep_App.Components;
using Salutia_Wep_App.Components.Account;
using Salutia_Wep_App.Data;
using Salutia_Wep_App.Services;

namespace Salutia_Wep_App;

public class Program
{
    public static async Task Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        builder.AddServiceDefaults();

        // Add services to the container.
        builder.Services.AddRazorComponents()
  .AddInteractiveServerComponents();

        builder.Services.AddCascadingAuthenticationState();
   builder.Services.AddScoped<IdentityUserAccessor>();
 builder.Services.AddScoped<IdentityRedirectManager>();
       builder.Services.AddScoped<AuthenticationStateProvider, IdentityRevalidatingAuthenticationStateProvider>();

   builder.Services.AddAuthentication(options =>
   {
options.DefaultScheme = IdentityConstants.ApplicationScheme;
     options.DefaultSignInScheme = IdentityConstants.ExternalScheme;
   })
.AddIdentityCookies();

  builder.Services.AddAuthorization();

  // Usar Aspire para configurar la conexi�n a SQL Server Express local
      builder.AddSqlServerDbContext<ApplicationDbContext>("sqlserver");
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

   builder.Services.AddIdentityCore<ApplicationUser>(options => {
options.SignIn.RequireConfirmedAccount = false; // Cambiado a false para desarrollo
   options.Password.RequireDigit = true;
      options.Password.RequireLowercase = true;
 options.Password.RequireUppercase = false;
      options.Password.RequireNonAlphanumeric = false;
 options.Password.RequiredLength = 6;
    })
       .AddRoles<IdentityRole>() // Agregar soporte para roles
   .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddSignInManager()
     .AddDefaultTokenProviders();

// Configurar Email Settings
builder.Services.Configure<EmailSettings>(builder.Configuration.GetSection("EmailSettings"));

// Registrar el servicio de Email
builder.Services.AddScoped<IEmailService, EmailService>();

// Reemplazar el IEmailSender por defecto con nuestro servicio
builder.Services.AddScoped<IEmailSender<ApplicationUser>, EmailSenderAdapter>();

      // Registrar el servicio de generaci�n de c�digos QR
   builder.Services.AddScoped<QrCodeService>();
 
  // Registrar el servicio de reportes PDF
   builder.Services.AddScoped<PdfReportService>();
      
  // Registrar el servicio de gesti�n de usuarios
        builder.Services.AddScoped<UserManagementService>();

// Registrar el servicio de Test Psicosom�tico
builder.Services.AddScoped<PsychosomaticTestService>();

// Registrar servicios de pacientes de entidad
builder.Services.AddScoped<PatientRegistrationService>();
builder.Services.AddScoped<CustomAuthenticationService>();

// Registrar servicio de gesti�n de perfil de paciente
builder.Services.AddScoped<IPatientProfileService, PatientProfileService>();

// Registrar servicio de gesti�n de consentimientos informados
builder.Services.AddScoped<IConsentService, ConsentService>();

// Registrar servicio de generaci�n de PDFs
builder.Services.AddScoped<IPdfGenerationService, PdfGenerationService>();

// Agregar soporte para controladores API
  builder.Services.AddControllers();
  
     // Agregar CORS para permitir requests desde la app m�vil
builder.Services.AddCors(options =>
      {
    options.AddPolicy("AllowMobileApp", policy =>
            {
      policy.AllowAnyOrigin()
   .AllowAnyMethod()
   .AllowAnyHeader();
    });
  });

   var app = builder.Build();

        app.MapDefaultEndpoints();
 
        // Inicializar base de datos (roles, SuperAdmin, datos geogr�ficos)
        await InitializeDatabaseAsync(app);

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseMigrationsEndPoint();
        }
        else
        {
            app.UseExceptionHandler("/Error");
            // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
            app.UseHsts();
        }

   app.UseHttpsRedirection();

  app.UseStaticFiles();

   // AuthZ middlewares - DEBE IR ANTES de UseAntiforgery
 app.UseAuthentication();
  app.UseAuthorization();
  
  // Antiforgery DEBE IR DESPU�S de Authentication y Authorization
  app.UseAntiforgery();

 // Habilitar CORS
        app.UseCors("AllowMobileApp");

 // Mapear controladores API
app.MapControllers();

    app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

     // Add additional endpoints required by the Identity /Account Razor components.
    app.MapAdditionalIdentityEndpoints();

     app.Run();
    }
 
    /// <summary>
    /// Inicializa la base de datos con roles, SuperAdmin y datos geogr�ficos
    /// </summary>
    private static async Task InitializeDatabaseAsync(WebApplication app)
    {
        using var scope = app.Services.CreateScope();
        var services = scope.ServiceProvider;
        var logger = services.GetRequiredService<ILogger<Program>>();

        try
        {
            logger.LogInformation("=== Iniciando inicializaci�n de base de datos ===");

            // Inicializar roles y SuperAdmin usando DbInitializer
            var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
            var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
            
            await DbInitializer.InitializeAsync(userManager, roleManager, logger);

            // Inicializar datos geogr�ficos
            var context = services.GetRequiredService<ApplicationDbContext>();
            await GeographicDataSeeder.SeedGeographicDataAsync(context);
            
            logger.LogInformation("=== Inicializaci�n de base de datos completada ===");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error durante la inicializaci�n de la base de datos");
            // No lanzar excepci�n para permitir que la app contin�e
        }
    }
}

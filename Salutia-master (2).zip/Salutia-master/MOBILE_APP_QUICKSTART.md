# ?? Gu�a R�pida - Salutia Mobile App

## ? Inicio R�pido (5 minutos)

### 1. Prerrequisitos

```powershell
# Verificar que tienes .NET 8 instalado
dotnet --version
# Deber�a mostrar 8.0.x o superior

# Verificar workloads de MAUI
dotnet workload list
# Deber�a mostrar: android, ios, maccatalyst, maui-windows
```

### 2. Abrir el Proyecto

```powershell
# Desde la ra�z del repositorio
cd D:\Desarrollos\Repos\Salutia

# Abrir Visual Studio con la soluci�n
start Salutia.sln
```

### 3. Compilar

En Visual Studio:
1. En el **Solution Explorer**, clic derecho en `Salutia.MobileApp`
2. Selecciona **"Build"**
3. Espera a que compile (primera vez puede tardar 2-3 minutos)

### 4. Ejecutar

#### En Android Emulator

1. En la barra superior, selecciona el dropdown de dispositivos
2. Elige un **Android Emulator** (ej: "Pixel 5 - API 34")
3. Presiona **F5** o clic en el bot�n ?? verde
4. �La app se abrir� en el emulador!

#### En Tu Tel�fono Android (Depuraci�n USB)

1. Habilita **"Opciones de desarrollador"** en tu Android:
   - Ve a **Ajustes ? Acerca del tel�fono**
   - Toca **"N�mero de compilaci�n"** 7 veces
   - Vuelve y entra en **"Opciones de desarrollador"**
   - Activa **"Depuraci�n USB"**

2. Conecta tu tel�fono por USB a la PC

3. En Visual Studio:
   - Selecciona tu dispositivo en el dropdown
   - Presiona **F5**

---

## ?? Estructura de la App

```
Inicio (Home)
??? Nueva Cita
??? Mi Salud
??? Medicamentos
??? Documentos

Bottom Navigation:
??? ?? Inicio
??? ?? Citas
??? ?? Salud
??? ?? Perfil
```

---

## ?? Modificar la UI

### Cambiar la P�gina de Inicio

Edita: `Salutia.MobileApp\Components\Pages\Home.razor`

```razor
@page "/"

<div class="container">
  <h1>�Hola desde Salutia!</h1>
    <!-- Tu contenido aqu� -->
</div>
```

### Cambiar Colores

Edita: `Salutia.MobileApp\wwwroot\css\app.css`

```css
:root {
    --salutia-primary: #1b6ec2; /* Cambia esto */
}
```

### Agregar un Bot�n en Home

```razor
<button class="btn btn-primary" @onclick="MiFuncion">
    <i class="bi bi-heart"></i> Clic Aqu�
</button>

@code {
    private void MiFuncion()
    {
        // Tu c�digo aqu�
    }
}
```

---

## ?? Conectar a la API Web

### 1. Ejecutar la API Web

```powershell
# En otra terminal
cd "D:\Desarrollos\Repos\Salutia"
dotnet run --project "Salutia.AppHost\Salutia.AppHost.csproj"

# Anota la URL, ej: https://localhost:7213
```

### 2. Actualizar la URL en la App M�vil

Edita: `Salutia.MobileApp\MauiProgram.cs`

```csharp
builder.Services.AddHttpClient("SalutiaAPI", client =>
{
    // Cambiar a la URL de tu API local
    client.BaseAddress = new Uri("https://localhost:7213/");
});
```

### 3. Usar el HttpClient

```csharp
@inject IHttpClientFactory HttpClientFactory

@code {
    private async Task GetData()
    {
 var client = HttpClientFactory.CreateClient("SalutiaAPI");
        var response = await client.GetAsync("/api/users/me");
        // Procesar respuesta...
    }
}
```

---

## ?? Problemas Comunes

### "No Android emulator available"

**Soluci�n**: Instalar un emulador

1. En Visual Studio: **Tools ? Android ? Android Device Manager**
2. Clic en **"+ New"**
3. Selecciona **"Pixel 5"** con **"API 34"**
4. Clic en **"Create"**
5. Espera a que descargue (puede tardar 10-15 minutos)

### "Build failed" en primera compilaci�n

**Soluci�n**: Limpiar y reconstruir

```powershell
dotnet clean
dotnet build "Salutia.MobileApp\Salutia.MobileApp.csproj"
```

### La app se abre pero muestra pantalla en blanco

**Soluci�n**: Verificar que index.html est� en wwwroot

```powershell
# Debe existir este archivo:
Test-Path "Salutia.MobileApp\wwwroot\index.html"
# Debe devolver: True
```

---

## ?? Tareas Comunes

### Agregar una Nueva P�gina

```razor
<!-- Salutia.MobileApp/Components/Pages/MiPagina.razor -->
@page "/mipagina"

<PageTitle>Mi P�gina</PageTitle>

<div class="container">
    <h1>Mi Nueva P�gina</h1>
</div>
```

### Navegar a Otra P�gina

```razor
@inject NavigationManager Nav

<button @onclick="() => Nav.NavigateTo('/mipagina')">
    Ir a Mi P�gina
</button>
```

### Mostrar un Alert

```razor
@inject IAlertService AlertService

<button @onclick="MostrarAlerta">Mostrar Alert</button>

@code {
    private void MostrarAlerta()
    {
        // TODO: Implementar AlertService
        // await AlertService.ShowAsync("T�tulo", "Mensaje");
    }
}
```

### Guardar Datos Localmente

```csharp
// Guardar
await SecureStorage.SetAsync("mi_dato", "valor");

// Leer
string valor = await SecureStorage.GetAsync("mi_dato");

// Eliminar
SecureStorage.Remove("mi_dato");
```

---

## ?? Checklist de Inicio

- [ ] .NET 8 instalado
- [ ] Visual Studio 2022 con workload MAUI
- [ ] Android emulator configurado
- [ ] Proyecto compila sin errores
- [ ] App se ejecuta en emulador
- [ ] Navega entre p�ginas correctamente

---

## ?? Ayuda

- **Documentaci�n completa**: Ver `MOBILE_APP_README.md`
- **Problemas**: Revisar `TROUBLESHOOTING.md`
- **API Web**: Ver `DATABASE_SETUP.md`

---

## ?? �Listo!

Ahora puedes empezar a desarrollar la app m�vil de Salutia.

**Pr�ximo paso**: Implementa el servicio de autenticaci�n en `Salutia.MobileApp\Services\AuthService.cs`

```csharp
// TODO: Implementar
public class AuthService : IAuthService
{
    public async Task<AuthResponse> LoginAsync(LoginRequest request)
    {
  // Tu c�digo aqu�
    }
}
```

**�Happy Coding!** ????

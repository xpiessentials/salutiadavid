# =============================================
# Verificar y Corregir Columna Age
# =============================================

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "??????????????????????????????????????????????????" -ForegroundColor Cyan
Write-Host "?   Verificar y Corregir Columna Age            ?" -ForegroundColor Cyan
Write-Host "??????????????????????????????????????????????????" -ForegroundColor Cyan
Write-Host ""

$serverName = "LAPTOP-DAVID\SQLEXPRESS"
$databaseName = "Salutia"

Write-Host "?? Verificando columna Age en TestMatrices..." -ForegroundColor Yellow
Write-Host ""

# Verificar si la columna Age existe
$checkQuery = @"
SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    CHARACTER_MAXIMUM_LENGTH,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'TestMatrices' AND COLUMN_NAME = 'Age'
"@

try {
    $result = Invoke-Sqlcmd -ServerInstance $serverName -Database $databaseName -Query $checkQuery -ErrorAction Stop
    
    if ($result) {
        Write-Host "? La columna Age EXISTE en TestMatrices" -ForegroundColor Green
        Write-Host ""
        Write-Host "Detalles de la columna:" -ForegroundColor Cyan
        Write-Host "  Nombre: $($result.COLUMN_NAME)" -ForegroundColor Gray
        Write-Host "  Tipo: $($result.DATA_TYPE)" -ForegroundColor Gray
        Write-Host "  Tama�o: $($result.CHARACTER_MAXIMUM_LENGTH)" -ForegroundColor Gray
        Write-Host "  Permite NULL: $($result.IS_NULLABLE)" -ForegroundColor Gray
        Write-Host ""
        
        # Verificar si permite NULL cuando deber�a ser NOT NULL
        if ($result.IS_NULLABLE -eq 'YES') {
            Write-Host "?? PROBLEMA: La columna Age permite NULL" -ForegroundColor Yellow
            Write-Host "   Esto puede causar problemas al guardar datos" -ForegroundColor Yellow
            Write-Host ""
            Write-Host "�Desea corregir esto? (S/N): " -NoNewline -ForegroundColor Yellow
            $confirm = Read-Host
            
            if ($confirm -eq 'S' -or $confirm -eq 's') {
                Write-Host ""
                Write-Host "?? Corrigiendo columna Age..." -ForegroundColor Yellow
                
                $fixQuery = @"
-- Primero, actualizar los valores NULL existentes a cadena vac�a
UPDATE TestMatrices SET Age = '' WHERE Age IS NULL;

-- Luego, alterar la columna para que NO permita NULL
ALTER TABLE TestMatrices
ALTER COLUMN Age NVARCHAR(50) NOT NULL;
"@
                
                Invoke-Sqlcmd -ServerInstance $serverName -Database $databaseName -Query $fixQuery -ErrorAction Stop
                Write-Host "? Columna Age corregida exitosamente" -ForegroundColor Green
            }
        } else {
            Write-Host "? La columna est� correctamente configurada" -ForegroundColor Green
        }
    } else {
        Write-Host "? La columna Age NO EXISTE en TestMatrices" -ForegroundColor Red
        Write-Host ""
        Write-Host "Agregando columna Age..." -ForegroundColor Yellow
        
        $addColumnQuery = @"
ALTER TABLE TestMatrices
ADD Age NVARCHAR(50) NOT NULL DEFAULT '';
"@
        
        Invoke-Sqlcmd -ServerInstance $serverName -Database $databaseName -Query $addColumnQuery -ErrorAction Stop
        Write-Host "? Columna Age agregada exitosamente" -ForegroundColor Green
    }
    
} catch {
    Write-Host ""
    Write-Host "? Error al verificar/corregir la columna" -ForegroundColor Red
    Write-Host "  Detalles: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    
    # Si el error es de m�dulo SqlServer, intentar con sqlcmd
    if ($_.Exception.Message -match "Invoke-Sqlcmd") {
        Write-Host "?? Intentando con sqlcmd..." -ForegroundColor Yellow
        Write-Host ""
        
        # Verificar con sqlcmd
        $checkCmd = @"
SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    CHARACTER_MAXIMUM_LENGTH,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'TestMatrices' AND COLUMN_NAME = 'Age'
"@
        
        $cmdResult = $checkCmd | sqlcmd -S $serverName -d $databaseName -E -h -1 -W 2>&1
        
        if ($cmdResult -match "Age") {
            Write-Host "? La columna Age EXISTE en TestMatrices" -ForegroundColor Green
            Write-Host ""
            Write-Host "Datos:" -ForegroundColor Cyan
            $cmdResult | ForEach-Object {
                if ($_ -match "\S") {
                    Write-Host "  $_" -ForegroundColor Gray
                }
            }
        } else {
            Write-Host "? La columna Age NO EXISTE" -ForegroundColor Red
            Write-Host ""
            Write-Host "Agregando columna con sqlcmd..." -ForegroundColor Yellow
            
            $addCmd = @"
USE $databaseName;
GO

ALTER TABLE TestMatrices
ADD Age NVARCHAR(50) NOT NULL DEFAULT '';
GO
"@
            
            $addCmd | sqlcmd -S $serverName -E -b
            
            if ($LASTEXITCODE -eq 0) {
                Write-Host "? Columna Age agregada exitosamente" -ForegroundColor Green
            } else {
                Write-Host "? Error al agregar la columna" -ForegroundColor Red
                exit 1
            }
        }
    } else {
        exit 1
    }
}

Write-Host ""
Write-Host "??????????????????????????????????????????????????" -ForegroundColor Green
Write-Host "?   ? VERIFICACI�N COMPLETADA                    ?" -ForegroundColor Green
Write-Host "??????????????????????????????????????????????????" -ForegroundColor Green
Write-Host ""
Write-Host "Ahora puede ejecutar la aplicaci�n:" -ForegroundColor Cyan
Write-Host "dotnet run --project "".\Salutia Wep App\Salutia Wep App.csproj""" -ForegroundColor Gray
Write-Host ""
Read-Host "Presione Enter para salir"

# Gu�a de Actualizaci�n del Sistema de Usuarios - Salutia

## Resumen de Cambios

Este documento describe los cambios realizados en el sistema de usuarios de Salutia para implementar una estructura m�s completa y profesional.

## 1. Nuevos Tipos de Usuario

### Antes:
- SuperAdmin
- Entity (Entidad)
- Independent (Independiente)
- EntityMember (Miembro de entidad)

### Ahora:
- **SuperAdmin**: Administrador del sistema (sin cambios)
- **EntityAdmin**: Administrador de entidad (EPS, empresa, aseguradora) - puede crear profesionales
- **Independent**: Usuario independiente que completa el cuestionario por su cuenta
- **Doctor**: M�dico/Especialista que revisa correlaci�n psicosom�tica y orienta autocuidado
- **Psychologist**: Psic�logo/Terapeuta que aplica el TBE a sus pacientes
- **Patient**: Paciente creado por un Doctor o Psychologist

## 2. Jerarqu�a del Sistema

```
SuperAdmin (Administra todo el sistema)
    ?
 ??? EntityAdmin (Administra su entidad)
    ?   ??? Doctor (Crea y gestiona pacientes)
    ?    ?      ??? Patient (Realiza tests)
    ?       ?
    ?       ??? Psychologist (Crea y gestiona pacientes)
    ?         ??? Patient (Realiza tests)
    ?
    ??? Independent (Realiza tests de forma independiente)
```

## 3. Campos Geogr�ficos Agregados

Se agregaron campos geogr�ficos a todos los perfiles de usuario:

- **Country** (Pa�s): Listado de pa�ses de Latinoam�rica
- **State** (Estado/Departamento): Estados de cada pa�s
- **City** (Ciudad): Ciudades de Colombia (expandible a otros pa�ses)
- **Address** (Direcci�n): Direcci�n completa del usuario

### Pa�ses Incluidos:
- Colombia, M�xico, Argentina, Chile, Per�, Venezuela, Ecuador, Bolivia, Paraguay, Uruguay, Costa Rica, Panam�, Guatemala, Honduras, El Salvador, Nicaragua, Rep�blica Dominicana, Cuba, Puerto Rico

### Datos de Colombia:
- **32 Departamentos** con sus c�digos
- **Ciudades principales** de los departamentos m�s importantes:
  - Antioquia (Medell�n, Bello, Itag��, etc.)
  - Cundinamarca (Bogot�, Soacha, Ch�a, etc.)
  - Valle del Cauca (Cali, Palmira, Buenaventura, etc.)
  - Atl�ntico (Barranquilla, Soledad, etc.)
  - Santander (Bucaramanga, Floridablanca, etc.)
  - Y m�s...

## 4. Nuevos Modelos de Datos

### EntityProfessionalProfile
Reemplaza a `EntityMemberProfile`. Incluye:
- Informaci�n b�sica del profesional
- **ProfessionalLicense**: N�mero de licencia profesional
- **Specialty**: Especialidad m�dica o psicol�gica
- Campos geogr�ficos
- Relaci�n con la entidad
- Lista de pacientes asignados

### PatientProfile
Nuevo modelo para pacientes creados por profesionales:
- Informaci�n b�sica del paciente
- **DateOfBirth**: Fecha de nacimiento
- **Gender**: G�nero
- **Notes**: Notas m�dicas/psicol�gicas
- Campos geogr�ficos
- Relaci�n con el profesional que lo cre�

### Modelos Geogr�ficos
- **Country**: Pa�ses disponibles
- **State**: Estados/Departamentos por pa�s
- **City**: Ciudades por estado

## 5. Cambios en la Base de Datos

### Nuevas Tablas:
- `Countries`: Almacena los pa�ses
- `States`: Almacena los estados/departamentos
- `Cities`: Almacena las ciudades
- `EntityProfessionalProfiles`: Reemplaza a EntityMemberProfiles
- `PatientProfiles`: Nueva tabla para pacientes

### Tablas Modificadas:
- `IndependentUserProfiles`: Agregados campos geogr�ficos y direcci�n
- `EntityUserProfiles`: Agregados campos geogr�ficos y Website
- `AspNetUsers`: UserType actualizado para incluir nuevos tipos

### Roles Actualizados:
- Eliminados: `Entity`, `EntityMember`
- Agregados: `EntityAdmin`, `Doctor`, `Psychologist`, `Patient`
- Mantenidos: `SuperAdmin`, `Independent`

## 6. Restricciones de Acceso al Test

**Antes**: Cualquier persona pod�a realizar el test

**Ahora**: Solo usuarios logueados pueden realizar el test:
- Independent: Acceso directo
- Doctor: Puede realizar test propio o asignar a pacientes
- Psychologist: Puede realizar test propio o asignar a pacientes
- Patient: Realiza el test asignado por su profesional
- EntityAdmin: Puede realizar test propio
- SuperAdmin: Acceso completo

## 7. C�mo Aplicar los Cambios

### Opci�n 1: Usar Script PowerShell (Recomendado)
```powershell
.\apply-user-system-migration.ps1
```

### Opci�n 2: Comandos Manuales
```bash
cd "Salutia Wep App"
dotnet ef migrations add UpdateUserSystemWithGeography
dotnet ef database update
```

### Opci�n 3: Script SQL Directo
Ejecutar el archivo `Database-Migration-UserSystem-Update.sql` en SQL Server Management Studio

## 8. Inicializaci�n Autom�tica

Al iniciar la aplicaci�n por primera vez despu�s de la migraci�n:

1. **Roles**: Se crean autom�ticamente los nuevos roles
2. **Datos Geogr�ficos**: Se cargan autom�ticamente pa�ses, estados y ciudades de Colombia

## 9. Flujos de Trabajo

### Registro de EntityAdmin:
1. Se registra como administrador de entidad
2. Proporciona datos de la empresa (NIT, raz�n social, etc.)
3. Selecciona ubicaci�n geogr�fica
4. Puede crear m�dicos y psic�logos

### EntityAdmin Crea Doctor/Psychologist:
1. EntityAdmin inicia sesi�n
2. Va a "Gestionar Profesionales"
3. Crea nuevo Doctor o Psychologist
4. Asigna especialidad y licencia profesional
5. Define ubicaci�n geogr�fica

### Doctor/Psychologist Crea Patient:
1. Doctor/Psychologist inicia sesi�n
2. Va a "Gestionar Pacientes"
3. Crea nuevo paciente
4. Completa informaci�n m�dica
5. Asigna test TBE

### Patient Realiza Test:
1. Patient inicia sesi�n con credenciales asignadas
2. Ve test asignado por su profesional
3. Completa el TBE
4. Resultados disponibles para el profesional

### Independent Realiza Test:
1. Se registra como usuario independiente
2. Completa informaci�n personal y ubicaci�n
3. Accede directamente al test
4. Recibe informe personal

## 10. Tareas Pendientes

Para completar la implementaci�n, se deben crear/actualizar:

1. **P�ginas de Registro**:
   - `RegisterEntity.razor` (actualizar con campos geogr�ficos)
   - `RegisterIndependent.razor` (actualizar con campos geogr�ficos)
   - `RegisterProfessional.razor` (nueva - para EntityAdmin)
   - `RegisterPatient.razor` (nueva - para Doctor/Psychologist)

2. **P�ginas de Gesti�n**:
   - `ManageProfessionals.razor` (nueva - para EntityAdmin)
   - `ManagePatients.razor` (nueva - para Doctor/Psychologist)
   - Actualizar `Entities.razor` para mostrar profesionales en lugar de miembros

3. **Dashboards**:
   - Actualizar `Entity/Dashboard.razor` para EntityAdmin
   - Crear `Doctor/Dashboard.razor`
   - Crear `Psychologist/Dashboard.razor`
   - Crear `Patient/Dashboard.razor`

4. **Componentes Compartidos**:
   - `GeographicSelector.razor` (selector de pa�s/estado/ciudad)
   - Servicios para cargar datos geogr�ficos din�micamente

5. **Restricciones de Acceso**:
   - Actualizar `TestPsicosomatico.razor` para requerir autenticaci�n
   - Agregar `[Authorize]` a p�ginas correspondientes

6. **Actualizar NavMenu**:
   - Mostrar opciones seg�n tipo de usuario
   - Ocultar opciones no autorizadas

## 11. Ventajas del Nuevo Sistema

1. **Claridad de Roles**: Cada tipo de usuario tiene funciones espec�ficas
2. **Jerarqu�a Profesional**: Refleja la estructura real de entidades de salud
3. **Trazabilidad**: Los pacientes est�n vinculados a su profesional
4. **Ubicaci�n Geogr�fica**: Permite an�lisis por regi�n y pa�s
5. **Escalabilidad**: F�cil agregar m�s pa�ses/estados/ciudades
6. **Compliance**: Mejor control de acceso y permisos
7. **Reportes**: Datos m�s ricos para an�lisis y reportes

## 12. Notas Importantes

- ?? **Backup**: Haga backup de la base de datos antes de aplicar la migraci�n
- ?? **Usuarios Existentes**: Los usuarios tipo "Entity" se convierten autom�ticamente a "EntityAdmin"
- ?? **EntityMembers**: Los miembros existentes se migran a EntityProfessionalProfiles
- ?? **Datos Geogr�ficos**: Se cargan solo para Colombia inicialmente
- ?? **Testing**: Probar todos los flujos despu�s de la migraci�n

## 13. Soporte

Para dudas o problemas con la migraci�n, revisar:
- Logs de la aplicaci�n
- Errores de compilaci�n
- Resultados de la migraci�n de Entity Framework
- Integridad de datos en la base de datos

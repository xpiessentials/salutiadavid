# Soluci�n de Problemas Comunes en Salutia

## Problemas Resueltos

### ? Error: "Failed to load resource: Salutia%20Wep%20App.styles.css 404"

**Causa**: El archivo CSS scoped generado por Blazor usa guiones bajos (`_`) en lugar de espacios, pero el HTML estaba referenciando el archivo con espacios.

**Soluci�n Aplicada**: 
- Corregido en `Components/App.razor`
- Cambio de: `<link rel="stylesheet" href="Salutia Wep App.styles.css" />`
- A: `<link rel="stylesheet" href="Salutia_Wep_App.styles.css" />`

**Estado**: ? RESUELTO

---

### ?? Error: "Uncaught (in promise) SyntaxError: [object Object] is not valid JSON"

**Causa Posible**: Este error puede ocurrir por varias razones:
1. Problemas con la base de datos no inicializada
2. Errores en la configuraci�n de Identity
3. Problemas con archivos est�ticos faltantes

**Soluciones a Aplicar**:

#### 1. Aplicar Migraciones de Base de Datos

La base de datos debe crearse antes de usar la aplicaci�n:

```powershell
# Desde la ra�z del proyecto
dotnet ef database update --project "Salutia Wep App" --startup-project "Salutia Wep App"
```

#### 2. Verificar que SQL Server Express est� en ejecuci�n

```powershell
# Verificar el servicio
Get-Service -Name "MSSQL$SQLEXPRESS"

# Si no est� corriendo, iniciarlo
Start-Service -Name "MSSQL$SQLEXPRESS"
```

#### 3. Limpiar y Reconstruir el Proyecto

```powershell
# Limpiar
dotnet clean

# Reconstruir
dotnet build

# Ejecutar
dotnet run --project "Salutia.AppHost\Salutia.AppHost.csproj"
```

---

## Verificaci�n de Archivos Est�ticos

Aseg�rate de que los siguientes archivos existen en `wwwroot`:

```
Salutia Wep App/wwwroot/
??? app.css ?
??? favicon.png ?
??? bootstrap/
?   ??? bootstrap.min.css ?
??? _framework/ (generado autom�ticamente)
```

---

## Pasos para Iniciar la Aplicaci�n Correctamente

### M�todo 1: Usando .NET Aspire (Recomendado)

```powershell
# 1. Aplicar migraciones (solo la primera vez)
dotnet ef database update --project "Salutia Wep App" --startup-project "Salutia Wep App"

# 2. Ejecutar desde el AppHost
dotnet run --project "Salutia.AppHost\Salutia.AppHost.csproj"
```

### M�todo 2: Ejecutar solo la aplicaci�n Blazor

```powershell
# 1. Aplicar migraciones (solo la primera vez)
dotnet ef database update --project "Salutia Wep App" --startup-project "Salutia Wep App"

# 2. Ejecutar la aplicaci�n
dotnet run --project "Salutia Wep App\Salutia Wep App.csproj"
```

### M�todo 3: Desde Visual Studio

1. **Establecer proyecto de inicio**: Clic derecho en `Salutia.AppHost` ? "Set as Startup Project"
2. **Ejecutar**: Presionar F5 o clic en el bot�n ?? "Start"
3. Se abrir� el Dashboard de Aspire en el navegador
4. Desde el dashboard, acceder a la aplicaci�n

---

## Verificaci�n de Conectividad a la Base de Datos

### Probar conexi�n con SQLCMD

```powershell
sqlcmd -S LAPTOP-DAVID\SQLEXPRESS -E -Q "SELECT @@VERSION"
```

### Verificar que la base de datos existe

```powershell
sqlcmd -S LAPTOP-DAVID\SQLEXPRESS -E -Q "SELECT name FROM sys.databases WHERE name = 'Salutia'"
```

### Ver las tablas creadas

```powershell
sqlcmd -S LAPTOP-DAVID\SQLEXPRESS -d Salutia -E -Q "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES"
```

---

## Problemas Comunes y Soluciones

### Problema: "An unhandled error has occurred" al cargar la p�gina

**Soluci�n**:
1. Verifica los logs del navegador (F12 ? Console)
2. Verifica los logs de Visual Studio (Output ? Debug)
3. Aseg�rate de que la base de datos est� creada y las migraciones aplicadas
4. Verifica que SQL Server Express est� en ejecuci�n

### Problema: Im�genes no cargan (iconos de Bootstrap)

**Causa**: Los iconos de Bootstrap est�n definidos como SVG inline en el CSS

**Verificaci�n**: 
- Abre `Components/Layout/NavMenu.razor.css`
- Los iconos deben estar definidos como `background-image: url("data:image/svg+xml,...")`

### Problema: Error 404 en archivos CSS

**Soluci�n**:
1. Limpia el proyecto: `dotnet clean`
2. Reconstruye: `dotnet build`
3. Verifica que `App.razor` usa `Salutia_Wep_App.styles.css` (con guiones bajos)

---

## Herramientas de Diagn�stico

### Verificar errores de compilaci�n

```powershell
dotnet build "Salutia Wep App\Salutia Wep App.csproj" --verbosity detailed
```

### Ver logs detallados al ejecutar

```powershell
dotnet run --project "Salutia Wep App\Salutia Wep App.csproj" --verbosity detailed
```

### Limpiar cach� de NuGet

```powershell
dotnet nuget locals all --clear
```

---

## Checklist de Verificaci�n Antes de Ejecutar

- [ ] SQL Server Express est� en ejecuci�n
- [ ] La cadena de conexi�n es correcta en `appsettings.json`
- [ ] Las migraciones est�n aplicadas (`dotnet ef database update`)
- [ ] El proyecto compila sin errores (`dotnet build`)
- [ ] Los archivos en `wwwroot` existen (bootstrap, app.css)
- [ ] El archivo `App.razor` usa `Salutia_Wep_App.styles.css`

---

## URLs de la Aplicaci�n

Cuando ejecutas con .NET Aspire:
- **Dashboard de Aspire**: https://localhost:17141 (el puerto puede variar)
- **Aplicaci�n Blazor**: https://localhost:59982 (el puerto puede variar)

Las URLs exactas se mostrar�n en la consola al iniciar la aplicaci�n.

---

## Contacto y Soporte

Para problemas adicionales, revisa:
1. Los logs en la consola de Visual Studio
2. Los logs en el navegador (F12 ? Console)
3. El archivo `DATABASE_SETUP.md` para problemas relacionados con la base de datos
4. La documentaci�n de .NET Aspire: https://learn.microsoft.com/dotnet/aspire/

---

## Notas Importantes

?? **Antes de hacer commit a Git**: Aseg�rate de no subir informaci�n sensible en `appsettings.json`. Usa `appsettings.Development.json` para configuraciones locales.

?? **Base de Datos en Desarrollo**: La base de datos actual est� configurada para desarrollo local. No uses esta configuraci�n en producci�n.

?? **Migraciones**: Siempre crea una nueva migraci�n despu�s de modificar el `ApplicationDbContext`.

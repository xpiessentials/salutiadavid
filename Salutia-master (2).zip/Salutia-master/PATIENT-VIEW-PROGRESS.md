# ?? Vista Unificada de Paciente - En Progreso

## ?? **Estado: 60% Completado**

---

## ? **Lo que se Cre�:**

### **Archivo Principal:**
`Components/Pages/Shared/ViewPatient.razor` (~650 l�neas)

**Ruta:** `/ViewPatient/{TestId:int}`

---

## ?? **Caracter�sticas Implementadas:**

### **1. Control de Acceso (CR�TICO)**

#### **Reglas de Negocio:**
```
? Profesional ? Solo tests que �L asign� al paciente
? Entidad ? Todos los pacientes de SU entidad
? Sin acceso ? Mensaje de error
```

#### **Validaci�n Implementada:**
```csharp
private async Task<bool> ValidateAccessAsync()
{
    if (isProfessional)
    {
        // Profesional solo ve pacientes de su entidad
        // TODO: Validar relaci�n espec�fica Professional-Patient-Test
        var professional = await DbContext.Professionals
            .FirstOrDefaultAsync(p => p.ApplicationUserId == currentUserId);
        
        return professional.EntityId == patientProfile.EntityId;
    }
    else if (isEntity)
    {
        // Entidad ve todos los pacientes de su entidad
        var entity = await DbContext.Entities
            .FirstOrDefaultAsync(e => e.ApplicationUserId == currentUserId);
        
        return entity.Id == patientProfile.EntityId;
    }
    
    return false;
}
```

---

### **2. Header del Paciente**

**Informaci�n Mostrada:**
- ? Avatar circular
- ? Nombre completo
- ? Documento (tipo + n�mero)
- ? Fecha de nacimiento
- ? Test ID
- ? Estado del test (Completado/En Progreso)
- ? Breadcrumb navigation

---

### **3. Tarjetas de Informaci�n**

#### **Informaci�n Personal:**
- Edad (calculada)
- Sexo ? **PENDIENTE CORRECCI�N** (usar `Gender`)
- Email ? **PENDIENTE CORRECCI�N** (viene de `ApplicationUser`)
- Tel�fono

#### **Informaci�n Laboral:** ? **PENDIENTE**
- Entidad (ya disponible)
- Cargo ? **NO EXISTE EN MODELO**
- �rea ? **NO EXISTE EN MODELO**
- Antig�edad ? **NO EXISTE EN MODELO**

#### **Informaci�n M�dica:** ? **PENDIENTE**
- EPS ? **NO EXISTE EN MODELO**
- ARL ? **NO EXISTE EN MODELO**
- Contacto Emergencia ? **Usar `EmergencyContacts` collection**
- Tel. Emergencia ? **Usar `EmergencyContacts` collection**

#### **Estado de Documentos:**
- ? Perfil completo/incompleto
- ? Consentimientos (firmados vs requeridos)
- ? Test (completado vs en progreso)

---

### **4. Sistema de Tabs**

#### **Tab 1: Consentimientos Informados** ?
**Estado:** Funcional

**Caracter�sticas:**
- ? Lista de consentimientos con cards
- ? Badge de estado (Firmado/No Firmado)
- ? Informaci�n de firma digital
- ? Vista expandible del contenido HTML
- ? Bot�n descargar PDF individual
- ? Bot�n generar/descargar paquete completo
- ? Registro de auditor�a de descargas
- ? Metadata (IP, fecha, versi�n)

**Dise�o:**
- Grid responsivo (2 columnas en desktop)
- Cards con bordes de color seg�n estado
- Vista previa de firma digital
- Informaci�n de auditor�a colapsable

#### **Tab 2: Resultados del Test** ??
**Estado:** Placeholder

**Caracter�sticas Actuales:**
- ? Mensaje de "En Progreso" si test no completado
- ? Placeholder de informe si completado
- ? Bot�n "Descargar Informe" (deshabilitado)

**Por Implementar:**
- [ ] Generaci�n de informe de resultados
- [ ] Visualizaci�n de an�lisis psicosom�tico
- [ ] Gr�ficos de resultados
- [ ] Recomendaciones
- [ ] Descarga de PDF del informe

---

## ?? **Errores a Corregir:**

### **Errores de Compilaci�n:**

#### **1. Campos del PatientProfile:**
```csharp
// ERRORES:
patientProfile.BirthDate    ? Usar: DateOfBirth
patientProfile.Sex          ? Usar: Gender
patientProfile.Email        ? Usar: ApplicationUser?.Email
patientProfile.Position     ? NO EXISTE (eliminar o agregar)
patientProfile.WorkArea     ? NO EXISTE (eliminar o agregar)
patientProfile.YearsOfService ? NO EXISTE (eliminar o agregar)
patientProfile.EPS          ? NO EXISTE (eliminar o agregar)
patientProfile.ARL          ? NO EXISTE (eliminar o agregar)
patientProfile.EmergencyContactName  ? Usar: EmergencyContacts.FirstOrDefault()?.FullName
patientProfile.EmergencyContactPhone ? Usar: EmergencyContacts.FirstOrDefault()?.PhoneNumber
```

#### **2. PatientConsents.razor:**
```csharp
// ERROR en l�nea 386:
.Include(t => t.Patient)  // NO EXISTE esta navegaci�n

// SOLUCI�N:
// No incluir Patient, cargar por separado con PatientUserId
```

#### **3. Profesionales y Entidades:**
```csharp
// ERROR:
DbContext.Professionals     // NO EXISTE este DbSet
DbContext.Entities          // NO EXISTE este DbSet

// DEBEN SER:
DbContext.EntityProfessionalProfiles
DbContext.EntityUserProfiles  // (para entidades)
```

---

## ?? **Correcciones Necesarias:**

### **Archivo: ViewPatient.razor**

```razor
<!-- CORRECCI�N 1: Informaci�n Personal -->
<p class="mb-2">
    <strong>Edad:</strong> @CalculateAge(patientProfile.DateOfBirth) a�os
</p>
<p class="mb-2">
    <strong>Sexo:</strong> @patientProfile.Gender
</p>
<p class="mb-2">
    <strong>Email:</strong> @patientProfile.ApplicationUser?.Email
</p>

<!-- CORRECCI�N 2: Informaci�n Laboral (Simplificada) -->
<div class="col-md-3">
    <div class="card h-100">
        <div class="card-body">
            <h6 class="text-muted mb-3">
                <i class="bi bi-briefcase"></i> Informaci�n Laboral
            </h6>
            <p class="mb-2">
                <strong>Entidad:</strong> @(patientProfile.Entity?.BusinessName ?? "N/A")
            </p>
            <p class="mb-2">
                <strong>Profesional Asignado:</strong> @(patientProfile.Professional?.FullName ?? "N/A")
            </p>
            <p class="mb-2">
                <strong>Ocupaci�n:</strong> @(patientProfile.Occupation?.Name ?? "N/A")
            </p>
        </div>
    </div>
</div>

<!-- CORRECCI�N 3: Informaci�n M�dica (Simplificada) -->
<div class="col-md-3">
    <div class="card h-100">
        <div class="card-body">
            <h6 class="text-muted mb-3">
                <i class="bi bi-heart-pulse"></i> Informaci�n M�dica
            </h6>
            @{
                var emergency = patientProfile.EmergencyContacts.FirstOrDefault();
            }
            @if (emergency != null)
            {
                <p class="mb-2">
                    <strong>Contacto Emergencia:</strong> @emergency.FullName
                </p>
                <p class="mb-2">
                    <strong>Relaci�n:</strong> @emergency.Relationship
                </p>
                <p class="mb-2">
                    <strong>Tel�fono:</strong> @emergency.PhoneNumber
                </p>
            }
            else
            {
                <p class="text-muted">Sin contacto de emergencia registrado</p>
            }
        </div>
    </div>
</div>

<!-- CORRECCI�N 4: Cargar test sin Include de Patient -->
test = await DbContext.PsychosomaticTests
    .FirstOrDefaultAsync(t => t.Id == TestId);

<!-- CORRECCI�N 5: Validaci�n de acceso profesional -->
var professional = await DbContext.EntityProfessionalProfiles
    .FirstOrDefaultAsync(p => p.ApplicationUserId == currentUserId);

<!-- CORRECCI�N 6: Validaci�n de acceso entidad -->
var entity = await DbContext.EntityUserProfiles
    .FirstOrDefaultAsync(e => e.ApplicationUserId == currentUserId);

return entity.EntityId == patientProfile.EntityId;
```

---

### **Archivo: PatientConsents.razor**

```csharp
// CORRECCI�N: Cargar tests sin Include de Patient
var tests = await DbContext.PsychosomaticTests
    .ToListAsync();
```

---

## ?? **Tareas Pendientes:**

### **Prioridad Alta (Ahora):**
1. ? Corregir campos de PatientProfile en ViewPatient.razor
2. ? Corregir Include de Patient en PatientConsents.razor
3. ? Corregir nombres de DbSets (Professionals ? EntityProfessionalProfiles)
4. ? Probar compilaci�n
5. ? Probar navegaci�n desde dashboard

### **Prioridad Media (Pr�xima Sesi�n):**
6. [ ] Implementar vista de resultados del test
7. [ ] Generar informe PDF de resultados
8. [ ] Agregar gr�ficos de an�lisis
9. [ ] Implementar recomendaciones

### **Prioridad Baja:**
10. [ ] Agregar campos faltantes al modelo (EPS, ARL, Position, etc.)
11. [ ] Implementar timeline de historial m�dico
12. [ ] Agregar notas del profesional

---

## ?? **Integraci�n con Dashboards:**

### **Desde Dashboard de Profesional:**
```razor
<!-- En Professional/Dashboard.razor -->
<button class="btn btn-primary" 
        @onclick='() => Navigation.NavigateTo($"/ViewPatient/{test.Id}")'>
    <i class="bi bi-eye"></i> Ver Expediente
</button>
```

### **Desde Dashboard de Entidad:**
```razor
<!-- En Entity/Dashboard.razor -->
<button class="btn btn-primary" 
        @onclick='() => Navigation.NavigateTo($"/ViewPatient/{test.Id}")'>
    <i class="bi bi-eye"></i> Ver Paciente
</button>
```

---

## ?? **Estructura del Archivo:**

```
ViewPatient.razor
??? Header
?   ??? Breadcrumb
?   ??? Avatar + Info del Paciente
?   ??? Estado del Test
??? Tarjetas de Informaci�n (4 columnas)
?   ??? Personal
?   ??? Laboral (simplificada)
?   ??? M�dica (simplificada)
?   ??? Estado de Documentos
??? Tabs
?   ??? Tab 1: Consentimientos ?
?   ?   ??? Bot�n descargar paquete
?   ?   ??? Grid de consentimientos (2 cols)
?   ?   ??? Cards por consentimiento
?   ?       ??? Header con estado
?   ?       ??? Fecha y versi�n
?   ?       ??? Firma digital
?   ?       ??? Auditor�a
?   ?       ??? Botones (Ver/PDF)
?   ??? Tab 2: Resultados ??
?       ??? Mensaje "En Progreso" (si no completado)
?       ??? Placeholder de informe (si completado)
??? Code Section
    ??? Carga de datos
    ??? Validaci�n de acceso
    ??? Gesti�n de consentimientos
    ??? M�todos auxiliares
```

---

## ?? **Pr�ximos Pasos Inmediatos:**

1. **Corregir errores de compilaci�n** (5-10 min)
2. **Probar navegaci�n** desde dashboards (5 min)
3. **Verificar permisos** de acceso (10 min)
4. **Probar descarga de PDFs** (5 min)

**Total:** ~30 minutos para tener funcional la vista de consentimientos.

---

## ?? **Mejoras Futuras:**

### **Vista de Resultados:**
- [ ] Dashboard con m�tricas del test
- [ ] Gr�fico de 10 palabras (palabra vs nivel de malestar)
- [ ] Timeline de evoluci�n emocional
- [ ] Mapa corporal de malestares
- [ ] An�lisis de emociones predominantes
- [ ] Recomendaciones personalizadas
- [ ] Bot�n "Generar Informe PDF"

### **Funcionalidades Adicionales:**
- [ ] Historial de tests del paciente
- [ ] Comparativa entre tests
- [ ] Notas del profesional
- [ ] Plan de tratamiento
- [ ] Seguimiento de evoluci�n

---

## ? **Resultado Final Esperado:**

Una vez corregidos los errores, tendremos:

```
/ViewPatient/123
    ?
???????????????????????????????????????
?  Avatar | Nombre del Paciente       ?
?  Documento | Edad | Test ID          ?
?  Estado: ? Completado               ?
???????????????????????????????????????
?  [Info Personal] [Laboral] [M�dica] ?
?  [Estado Docs]                       ?
???????????????????????????????????????
?  [Consentimientos] [Resultados]     ?
?  ?                                   ?
?  ???????????????????????????????   ?
?  ? ? Consentimiento 1          ?   ?
?  ? [Firma] [PDF] [Ver Contenido]?  ?
?  ???????????????????????????????   ?
?  ???????????????????????????????   ?
?  ? ? Consentimiento 2          ?   ?
?  ???????????????????????????????   ?
?  [Descargar Paquete Completo]      ?
???????????????????????????????????????
```

---

**?? Estado:** En Progreso (60%)  
**?? Siguiente:** Correcciones de Compilaci�n  
**?? Tiempo Estimado:** 30 minutos

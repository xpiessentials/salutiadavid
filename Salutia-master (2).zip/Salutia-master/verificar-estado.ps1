# =============================================
# Verificaci�n R�pida - Estado Actual
# =============================================

$serverName = "LAPTOP-DAVID\SQLEXPRESS"
$databaseName = "Salutia"

Write-Host ""
Write-Host "??????????????????????????????????????????????????" -ForegroundColor Cyan
Write-Host "?     Verificaci�n del Estado Actual - Salutia  ?" -ForegroundColor Cyan
Write-Host "??????????????????????????????????????????????????" -ForegroundColor Cyan
Write-Host ""

# ============================================
# 1. Verificar Conexi�n
# ============================================
Write-Host "1?? Conexi�n a SQL Server..." -ForegroundColor Yellow

$testQuery = "SELECT @@VERSION"
$connectionTest = $testQuery | sqlcmd -S $serverName -d "master" -E -h -1 -W 2>&1

if ($LASTEXITCODE -eq 0) {
    Write-Host "   ? Conexi�n exitosa" -ForegroundColor Green
} else {
    Write-Host "   ? Error de conexi�n" -ForegroundColor Red
    Write-Host "   Verifique que SQL Server Express est� corriendo" -ForegroundColor Yellow
    exit 1
}

Write-Host ""

# ============================================
# 2. Verificar Base de Datos
# ============================================
Write-Host "2?? Base de Datos Salutia..." -ForegroundColor Yellow

$dbQuery = "SELECT name FROM sys.databases WHERE name = '$databaseName'"
$dbExists = $dbQuery | sqlcmd -S $serverName -d "master" -E -h -1 -W 2>&1

if ($dbExists -match $databaseName) {
    Write-Host "   ? Base de datos existe" -ForegroundColor Green
} else {
    Write-Host "   ? Base de datos NO existe" -ForegroundColor Red
    exit 1
}

Write-Host ""

# ============================================
# 3. Verificar Usuarios
# ============================================
Write-Host "3?? Usuarios en el Sistema..." -ForegroundColor Yellow

$usersQuery = @"
SELECT 
    COUNT(*) AS Total,
    SUM(CASE WHEN EmailConfirmed = 1 THEN 1 ELSE 0 END) AS Confirmados,
    SUM(CASE WHEN LockoutEnd IS NOT NULL AND LockoutEnd > GETUTCDATE() THEN 1 ELSE 0 END) AS Bloqueados
FROM AspNetUsers
"@

$usersInfo = $usersQuery | sqlcmd -S $serverName -d $databaseName -E -h -1 -W 2>&1

if ($LASTEXITCODE -eq 0) {
 Write-Host "   ? Tabla de usuarios accesible" -ForegroundColor Green
    Write-Host "   Informaci�n:" -ForegroundColor Gray
    $usersInfo | Where-Object { $_ -match "\d+" } | ForEach-Object {
        Write-Host "   $_" -ForegroundColor Cyan
    }
    
    # Mostrar algunos usuarios
    $sampleUsersQuery = "SELECT TOP 5 Email, UserType, CreatedAt FROM AspNetUsers ORDER BY CreatedAt DESC"
    $sampleUsers = $sampleUsersQuery | sqlcmd -S $serverName -d $databaseName -E -W 2>&1

    Write-Host ""
    Write-Host "   �ltimos 5 usuarios:" -ForegroundColor Gray
    $sampleUsers | Where-Object { $_ -match "@" } | ForEach-Object {
        Write-Host "   - $_" -ForegroundColor Cyan
    }
} else {
    Write-Host "   ? No se pudo acceder a la tabla de usuarios" -ForegroundColor Yellow
}

Write-Host ""

# ============================================
# 4. Verificar Tablas del Test Psicosom�tico
# ============================================
Write-Host "4?? Tablas del Test Psicosom�tico..." -ForegroundColor Yellow

$testTablesQuery = @"
SELECT TABLE_NAME 
FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_NAME IN (
'PsychosomaticTests', 'TestWords', 'TestPhrases', 
    'TestEmotions', 'TestDiscomfortLevels', 'TestBodyParts',
    'TestAssociatedPersons', 'TestMatrices'
)
ORDER BY TABLE_NAME
"@

$testTables = $testTablesQuery | sqlcmd -S $serverName -d $databaseName -E -h -1 -W 2>&1

$testTablesList = $testTables | Where-Object { $_ -match "Test|Psycho" }

if ($testTablesList) {
    $tableCount = ($testTablesList | Measure-Object).Count
    Write-Host "   ? Encontradas $tableCount de 8 tablas" -ForegroundColor Green
    Write-Host ""
    $testTablesList | ForEach-Object {
        Write-Host "   ? $_" -ForegroundColor Green
    }
    
    if ($tableCount -eq 8) {
        Write-Host ""
        Write-Host "   ? TODAS LAS TABLAS DEL TEST EXISTEN" -ForegroundColor Green
        Write-Host "   No necesita ejecutar la migraci�n" -ForegroundColor Cyan
    } else {
        Write-Host ""
        Write-Host "   ? Faltan $([int](8 - $tableCount)) tablas" -ForegroundColor Yellow
     Write-Host "   Debe ejecutar la migraci�n: .\EJECUTAR_ESTO.ps1" -ForegroundColor Cyan
    }
} else {
    Write-Host "   ? NO se encontraron tablas del test" -ForegroundColor Red
    Write-Host ""
    Write-Host "   ?? Debe ejecutar la migraci�n:" -ForegroundColor Yellow
    Write-Host "   .\EJECUTAR_ESTO.ps1" -ForegroundColor Cyan
}

Write-Host ""

# ============================================
# 5. Verificar Tests Existentes
# ============================================
Write-Host "5?? Tests Psicosom�ticos Completados..." -ForegroundColor Yellow

if ($testTablesList -match "PsychosomaticTests") {
    $testsQuery = @"
SELECT 
COUNT(*) AS TotalTests,
    SUM(CASE WHEN IsCompleted = 1 THEN 1 ELSE 0 END) AS Completados,
    SUM(CASE WHEN IsCompleted = 0 THEN 1 ELSE 0 END) AS EnProgreso
FROM PsychosomaticTests
"@
    
$testsInfo = $testsQuery | sqlcmd -S $serverName -d $databaseName -E -h -1 -W 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        $testsData = $testsInfo | Where-Object { $_ -match "\d+" }
        if ($testsData) {
            Write-Host "   ? Tabla accesible" -ForegroundColor Green
            Write-Host "   $testsData" -ForegroundColor Cyan
        } else {
          Write-Host "   ? No hay tests registrados a�n" -ForegroundColor Gray
        }
    }
} else {
    Write-Host "   ? Tabla no existe todav�a" -ForegroundColor Yellow
}

Write-Host ""

# ============================================
# RESUMEN
# ============================================
Write-Host "??????????????????????????????????????????????????" -ForegroundColor Cyan
Write-Host "?      RESUMEN DEL ESTADO    ?" -ForegroundColor Cyan
Write-Host "??????????????????????????????????????????????????" -ForegroundColor Cyan
Write-Host ""

if ($testTablesList -and ($testTablesList | Measure-Object).Count -eq 8) {
    Write-Host "? SISTEMA LISTO PARA USAR" -ForegroundColor Green
Write-Host ""
    Write-Host "Puede ejecutar la aplicaci�n:" -ForegroundColor Cyan
    Write-Host "dotnet run --project "".\Salutia Wep App\Salutia Wep App.csproj""" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Y navegar a:" -ForegroundColor Cyan
    Write-Host "https://localhost:[puerto]/test-psicosomatico" -ForegroundColor Gray
} else {
    Write-Host "?? REQUIERE MIGRACI�N" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Ejecute el script de migraci�n:" -ForegroundColor Cyan
    Write-Host ".\EJECUTAR_ESTO.ps1" -ForegroundColor Gray
}

Write-Host ""
Write-Host "Presione Enter para salir..."
Read-Host

# ? TEST PSICOSOM�TICO - INSTRUCCIONES ACTUALIZADAS

## ?? Tu Configuraci�n Actual

**Servidor:** `LAPTOP-DAVID\SQLEXPRESS` (SQL Server Express)  
**Base de Datos:** `Salutia` (? Ya existe con usuarios)  
**Autenticaci�n:** Windows (Trusted_Connection)

---

## ?? OPCI�N 1: Verificar Estado Actual (Recomendado)

**Primero, verifica si las tablas ya existen:**

```powershell
.\verificar-estado.ps1
```

Este script te dir�:
- ? Si la conexi�n funciona
- ? Si la base de datos existe
- ? Cu�ntos usuarios hay
- ? Si las tablas del test est�n creadas (8 tablas)
- ? Si hay tests completados

### Si el script dice: "SISTEMA LISTO PARA USAR"
**�No necesitas hacer nada m�s!** Solo ejecuta:

```powershell
dotnet run --project ".\Salutia Wep App\Salutia Wep App.csproj"
```

### Si el script dice: "REQUIERE MIGRACI�N"
Contin�a con la **OPCI�N 2** abajo.

---

## ?? OPCI�N 2: Ejecutar Migraci�n

**Si las tablas NO existen, ejecuta:**

```powershell
.\EJECUTAR_ESTO.ps1
```

Este script actualizado:
- ? Usa **SQL Server Express** (no LocalDB)
- ? Verifica la conexi�n a tu servidor
- ? Comprueba que la BD `Salutia` existe
- ? Verifica cu�ntos usuarios tienes
- ? Detecta si las tablas ya existen
- ? Crea las 8 tablas necesarias
- ? Verifica que todo se cre� correctamente

---

## ?? Las 8 Tablas que se Crean

| # | Tabla | Descripci�n |
|---|-------|-------------|
| 1 | `PsychosomaticTests` | Test principal (1 por paciente) |
| 2 | `TestWords` | 10 palabras que causan malestar |
| 3 | `TestPhrases` | 10 frases asociadas |
| 4 | `TestEmotions` | 10 emociones |
| 5 | `TestDiscomfortLevels` | 10 niveles de malestar (1-10) |
| 6 | `TestBodyParts` | 10 partes del cuerpo |
| 7 | `TestAssociatedPersons` | 10 personas asociadas |
| 8 | `TestMatrices` | **Matriz consolidada** (lo m�s importante) |

---

## ?? Si Hay Problemas

### Error: "No se puede conectar"

Verifica que SQL Server Express est� corriendo:

1. Presiona `Win + R`
2. Escribe: `services.msc`
3. Busca: **SQL Server (SQLEXPRESS)**
4. Estado debe ser: **Running**
5. Si no est� corriendo, clic derecho ? **Start**

### Error: "Base de datos no existe"

El script te preguntar� si quieres crearla. Responde **S**.

O cr�ala manualmente:

```sql
USE master;
GO
CREATE DATABASE Salutia;
GO
```

### Error: "Las tablas ya existen"

El script te preguntar� si quieres recrearlas:
- **S** = Elimina y recrea (?? perder�s datos del test)
- **N** = Cancela (mantiene las tablas existentes)

---

## ? Verificaci�n Manual

Si quieres verificar manualmente que todo est� bien:

```powershell
sqlcmd -S "LAPTOP-DAVID\SQLEXPRESS" -d "Salutia" -E -Q "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE 'Test%' OR TABLE_NAME = 'PsychosomaticTests'"
```

**Deber�as ver:**
```
PsychosomaticTests
TestAssociatedPersons
TestBodyParts
TestDiscomfortLevels
TestEmotions
TestMatrices
TestPhrases
TestWords
```

---

## ?? Flujo Completo

```mermaid
graph TD
    A[Ejecutar verificar-estado.ps1] --> B{�Tablas existen?}
    B -->|S�| C[? LISTO - Ejecutar app]
    B -->|No| D[Ejecutar EJECUTAR_ESTO.ps1]
    D --> E[Migraci�n completa]
    E --> C
    C --> F[dotnet run]
    F --> G[Navegar a /test-psicosomatico]
```

---

## ?? Comandos R�pidos

```powershell
# 1. Verificar estado
.\verificar-estado.ps1

# 2. Si es necesario, ejecutar migraci�n
.\EJECUTAR_ESTO.ps1

# 3. Compilar
dotnet build

# 4. Ejecutar
dotnet run --project ".\Salutia Wep App\Salutia Wep App.csproj"

# 5. Abrir navegador en:
# https://localhost:[puerto]/test-psicosomatico
```

---

## ?? URLs del Sistema

| URL | Descripci�n | Rol Requerido |
|-----|-------------|---------------|
| `/test-psicosomatico` | Hacer el test | Cualquier usuario autenticado |
| `/patient-tests` | Ver lista de tests | Doctor, Psychologist, SuperAdmin |
| `/test-results/{id}` | Ver resultados detallados | Doctor, Psychologist, SuperAdmin |

---

## ?? Diferencias con el Script Anterior

### ? Script Anterior (No funcionaba para ti)
- Usaba: `(localdb)\MSSQLLocalDB`
- Para: LocalDB
- Tu tienes: SQL Server Express

### ? Script Actual (Actualizado)
- Usa: `LAPTOP-DAVID\SQLEXPRESS`
- Para: SQL Server Express
- Compatible con tu configuraci�n

---

## ?? Soporte

Si algo no funciona:

1. **Ejecuta primero:** `.\verificar-estado.ps1`
2. **Copia el resultado completo**
3. **Reporta el error espec�fico**

---

## ? Checklist Final

- [ ] SQL Server Express est� corriendo
- [ ] Base de datos `Salutia` existe
- [ ] `verificar-estado.ps1` ejecutado
- [ ] Si es necesario, `EJECUTAR_ESTO.ps1` ejecutado
- [ ] 8 tablas creadas correctamente
- [ ] `dotnet build` exitoso
- [ ] Aplicaci�n ejecut�ndose
- [ ] Test accesible en el navegador

---

**�Ahora todo est� configurado para tu entorno espec�fico!** ??

**EJECUTA PRIMERO:** `.\verificar-estado.ps1`

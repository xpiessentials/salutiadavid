# ?? Salutia Mobile App - Aplicaci�n M�vil Multiplataforma

## ?? Descripci�n General

Salutia Mobile App es una aplicaci�n m�vil nativa multiplataforma desarrollada con **.NET MAUI (Multi-platform App UI)** y **Blazor Hybrid**. Proporciona las mismas funcionalidades que la aplicaci�n web Salutia, optimizadas para dispositivos iOS y Android.

---

## ??? Arquitectura

### Tecnolog�as Principales

| Tecnolog�a | Versi�n | Prop�sito |
|------------|---------|-----------|
| **.NET MAUI** | 9.0+ | Framework multiplataforma |
| **Blazor Hybrid** | 9.0+ | UI con componentes Blazor reutilizables |
| **CommunityToolkit.Maui** | 12.2.0 | Componentes y funcionalidades adicionales |
| **.NET 8** | 8.0 | Runtime y librer�as base |

### Estructura del Proyecto

```
Salutia.MobileApp/
??? Components/
?   ??? Layout/
?   ?   ??? MainLayout.razor  # Layout principal con navegaci�n
?   ??? Pages/
?   ?   ??? Home.razor              # P�gina de inicio
?   ?   ??? Login.razor       # P�gina de inicio de sesi�n
?   ??? Routes.razor       # Configuraci�n de rutas
?   ??? _Imports.razor          # Imports globales
??? Pages/
?   ??? MainPage.xaml         # P�gina MAUI principal
?   ??? MainPage.xaml.cs
??? Platforms/
? ??? Android/        # C�digo espec�fico de Android
?   ??? iOS/            # C�digo espec�fico de iOS
?   ??? Windows/        # C�digo espec�fico de Windows
?   ??? MacCatalyst/         # C�digo espec�fico de macOS
??? Resources/
?   ??? Fonts/       # Fuentes personalizadas
?   ??? Images/   # Im�genes y recursos gr�ficos
?   ??? Raw/                  # Archivos raw
?   ??? Styles/# Estilos XAML
??? wwwroot/
?   ??? css/
?   ?   ??? app.css     # Estilos CSS personalizados
?   ??? index.html # HTML host para Blazor
??? App.xaml        # Aplicaci�n MAUI
??? AppShell.xaml          # Shell de navegaci�n
??? MauiProgram.cs           # Punto de entrada y configuraci�n

Salutia.Shared/
??? Models/
?   ??? AuthModels.cs      # Modelos compartidos
??? Services/
?   ??? IAuthService.cs    # Interfaces de servicios
??? GlobalUsings.cs          # Usings globales
```

---

## ?? Caracter�sticas Implementadas

### ? Funcionalidades Actuales

1. **Arquitectura Blazor Hybrid**
   - Componentes Blazor reutilizables
   - Navegaci�n entre p�ginas
   - Estados y ciclo de vida de componentes

2. **UI/UX Optimizada para M�vil**
   - Dise�o responsive
 - Soporte para Safe Areas (iOS)
   - Navegaci�n bottom bar
   - Cards y componentes touch-friendly

3. **Sistema de Navegaci�n**
   - Inicio (Home)
   - Citas M�dicas
   - Salud
   - Perfil
   - Login

4. **Integraci�n con Bootstrap**
- Bootstrap 5.3.2
   - Bootstrap Icons 1.11.1
   - Dise�o consistente con la web

5. **Preparaci�n para Servicios**
   - HttpClient configurado
   - Interfaces de servicios definidas
   - Modelos compartidos entre web y m�vil

---

## ?? Paquetes NuGet Instalados

```xml
<PackageReference Include="Microsoft.Maui.Controls" Version="9.0.90" />
<PackageReference Include="Microsoft.Maui.Controls.Compatibility" Version="9.0.90" />
<PackageReference Include="Microsoft.AspNetCore.Components.WebView.Maui" Version="9.0.120" />
<PackageReference Include="Microsoft.Extensions.Http" Version="9.0.10" />
<PackageReference Include="CommunityToolkit.Maui" Version="12.2.0" />
<PackageReference Include="Microsoft.Extensions.Logging.Debug" Version="9.0" />
```

---

## ??? Configuraci�n del Entorno

### Requisitos Previos

#### Para Desarrollo

1. **Visual Studio 2022 (17.8+)** o **Visual Studio for Mac**
   - Workload: ".NET Multi-platform App UI development"

2. **Workloads de .NET MAUI** instaladas:
   ```powershell
   dotnet workload install maui
   dotnet workload install maui-android
   dotnet workload install maui-ios
   dotnet workload install maui-maccatalyst
   dotnet workload install maui-windows
   ```

3. **SDKs Espec�ficos por Plataforma**:
   - **Android**: Android SDK 34+ (instalado con Visual Studio)
   - **iOS**: Xcode 15+ (solo en Mac)
   - **Windows**: Windows 11 SDK

#### Verificar Instalaci�n

```powershell
# Ver workloads instaladas
dotnet workload list

# Ver versi�n de .NET MAUI
dotnet --version

# Verificar que MAUI est� disponible
dotnet new maui --help
```

---

## ?? Compilar y Ejecutar

### Desde Visual Studio

#### Android

1. Selecciona **Android Emulator** o un dispositivo f�sico en el dropdown
2. Presiona **F5** o clic en el bot�n ?? "Android Emulator"
3. La primera compilaci�n puede tardar varios minutos

#### iOS (solo en Mac)

1. Selecciona **iOS Simulator** o un dispositivo f�sico
2. Presiona **F5** o clic en el bot�n ?? "iOS Simulator"
3. Puede requerir aprovisionamiento y certificados de Apple

#### Windows

1. Selecciona **Windows Machine**
2. Presiona **F5**
3. La app se ejecutar� como aplicaci�n nativa de Windows

### Desde L�nea de Comandos

#### Android

```powershell
# Compilar
dotnet build "Salutia.MobileApp\Salutia.MobileApp.csproj" -f net8.0-android

# Ejecutar en emulador
dotnet build "Salutia.MobileApp\Salutia.MobileApp.csproj" -t:Run -f net8.0-android
```

#### iOS (en Mac)

```bash
# Compilar
dotnet build Salutia.MobileApp/Salutia.MobileApp.csproj -f net8.0-ios

# Ejecutar en simulador
dotnet build Salutia.MobileApp/Salutia.MobileApp.csproj -t:Run -f net8.0-ios
```

#### Windows

```powershell
# Compilar
dotnet build "Salutia.MobileApp\Salutia.MobileApp.csproj" -f net8.0-windows10.0.19041.0

# Ejecutar
dotnet run --project "Salutia.MobileApp\Salutia.MobileApp.csproj" -f net8.0-windows10.0.19041.0
```

---

## ?? Plataformas Soportadas

| Plataforma | Versi�n M�nima | Versi�n Objetivo | Estado |
|------------|----------------|------------------|--------|
| **Android** | 5.0 (API 21) | 14.0 (API 34) | ? Soportado |
| **iOS** | 11.0 | 18.0 | ? Soportado |
| **macOS** | 10.15 | 15.0 | ? Soportado (Catalyst) |
| **Windows** | 10 (1809) | 11 (22000) | ? Soportado |

---

## ?? Dise�o y UI

### Paleta de Colores

```css
--salutia-primary: #1b6ec2    /* Azul principal */
--salutia-secondary: #6c757d  /* Gris */
--salutia-success: #28a745    /* Verde */
--salutia-danger: #dc3545  /* Rojo */
--salutia-warning: #ffc107    /* Amarillo */
--salutia-info: #17a2b8       /* Cyan */
```

### Componentes UI

#### Bottom Navigation Bar

Navegaci�n principal con 4 secciones:
- ?? **Inicio**: Dashboard principal
- ?? **Citas**: Gesti�n de citas m�dicas
- ?? **Salud**: Datos de salud y monitoreo
- ?? **Perfil**: Configuraci�n y perfil del usuario

#### Cards Interactivas

Dise�o touch-friendly con:
- M�nimo 44x44px para elementos t�ctiles
- Feedback visual al tocar
- Animaciones suaves

#### Formularios

- Inputs con padding generoso (12px)
- Validaci�n en tiempo real
- Mensajes de error claros

---

## ?? Integraci�n con la API Web

### Configuraci�n del HttpClient

```csharp
// En MauiProgram.cs
builder.Services.AddHttpClient("SalutiaAPI", client =>
{
    client.BaseAddress = new Uri("https://localhost:7213/");
    client.Timeout = TimeSpan.FromSeconds(30);
});
```

### Servicios Compartidos

Los modelos y servicios est�n definidos en **Salutia.Shared**:

```csharp
// IAuthService.cs
public interface IAuthService
{
    Task<AuthResponse> LoginAsync(LoginRequest request);
    Task<AuthResponse> RegisterAsync(RegisterRequest request);
    Task<bool> LogoutAsync();
    Task<User?> GetCurrentUserAsync();
    Task<bool> IsAuthenticatedAsync();
}
```

### Implementar Servicio de Auth (TODO)

```csharp
// En Salutia.MobileApp/Services/AuthService.cs
public class AuthService : IAuthService
{
    private readonly HttpClient _httpClient;
    
    public AuthService(IHttpClientFactory httpClientFactory)
    {
    _httpClient = httpClientFactory.CreateClient("SalutiaAPI");
  }
  
    public async Task<AuthResponse> LoginAsync(LoginRequest request)
    {
        var response = await _httpClient.PostAsJsonAsync("/api/auth/login", request);
   return await response.Content.ReadFromJsonAsync<AuthResponse>();
    }
    
    // ... implementar otros m�todos
}
```

---

## ?? Agregar Nuevas P�ginas

### Paso 1: Crear el Componente Razor

```razor
<!-- Salutia.MobileApp/Components/Pages/NewPage.razor -->
@page "/newpage"

<PageTitle>Nueva P�gina - Salutia</PageTitle>

<div class="container">
    <h1>Nueva P�gina</h1>
  <p>Contenido aqu�...</p>
</div>

@code {
    [Inject] private NavigationManager? NavigationManager { get; set; }
    
    protected override void OnInitialized()
    {
        // L�gica de inicializaci�n
    }
}
```

### Paso 2: Agregar Navegaci�n

```razor
<!-- En MainLayout.razor -->
<a href="/newpage" class="nav-link text-center">
    <i class="bi bi-star fs-4"></i>
    <div class="small">Nueva</div>
</a>
```

---

## ?? Autenticaci�n y Seguridad

### Almacenamiento Seguro

Usar **SecureStorage** de MAUI para tokens:

```csharp
// Guardar token
await SecureStorage.SetAsync("auth_token", token);

// Recuperar token
string token = await SecureStorage.GetAsync("auth_token");

// Eliminar token
SecureStorage.Remove("auth_token");
```

### Biometr�a

```csharp
// Verificar si hay biometr�a disponible
bool isBiometricAvailable = await BiometricAuthentication.IsAvailableAsync();

// Autenticar con biometr�a
var result = await BiometricAuthentication.AuthenticateAsync(
  "Autenticar para acceder a Salutia",
    "Usa tu huella o Face ID"
);

if (result.Authenticated)
{
    // Autenticaci�n exitosa
}
```

---

## ?? Funcionalidades Espec�ficas de Plataforma

### Android

#### Permisos

```xml
<!-- Platforms/Android/AndroidManifest.xml -->
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
```

#### Notificaciones

```csharp
// En Platforms/Android/MainActivity.cs
public class MainActivity : MauiAppCompatActivity
{
    protected override void OnCreate(Bundle savedInstanceState)
    {
     base.OnCreate(savedInstanceState);
  
    // Solicitar permisos de notificaci�n en Android 13+
        if (Build.VERSION.SdkInt >= BuildVersionCodes.Tiramisu)
    {
  RequestPermissions(new[] { 
                Manifest.Permission.PostNotifications 
        }, 0);
      }
    }
}
```

### iOS

#### Info.plist

```xml
<!-- Platforms/iOS/Info.plist -->
<key>NSCameraUsageDescription</key>
<string>Salutia necesita acceso a la c�mara para escanear c�digos QR</string>

<key>NSLocationWhenInUseUsageDescription</key>
<string>Salutia necesita tu ubicaci�n para encontrar centros m�dicos cercanos</string>
```

#### App Transport Security

```xml
<key>NSAppTransportSecurity</key>
<dict>
  <key>NSAllowsArbitraryLoads</key>
    <false/>
</dict>
```

---

## ?? Testing

### Unit Tests

```csharp
// Salutia.MobileApp.Tests/AuthServiceTests.cs
[Fact]
public async Task LoginAsync_ValidCredentials_ReturnsSuccess()
{
    // Arrange
    var authService = new AuthService(mockHttpClientFactory);
    var request = new LoginRequest 
    { 
        Email = "test@example.com", 
        Password = "Password123!" 
    };
    
    // Act
 var result = await authService.LoginAsync(request);
    
    // Assert
    Assert.True(result.Success);
}
```

### UI Tests

```csharp
// Usar Appium para tests de UI
[Test]
public void LoginPage_ValidCredentials_NavigatesToHome()
{
    // Arrange
    var loginPage = new LoginPage(driver);
    
  // Act
    loginPage.EnterEmail("test@example.com");
    loginPage.EnterPassword("Password123!");
    loginPage.ClickLogin();
    
// Assert
    Assert.IsTrue(homePage.IsDisplayed());
}
```

---

## ?? Publicaci�n

### Android (Google Play Store)

```powershell
# Generar AAB para producci�n
dotnet publish "Salutia.MobileApp\Salutia.MobileApp.csproj" `
  -f net8.0-android `
  -c Release `
  -p:AndroidKeyStore=true `
  -p:AndroidSigningKeyStore=salutia.keystore `
  -p:AndroidSigningKeyAlias=salutia `
  -p:AndroidSigningKeyPass=$env:KEY_PASSWORD `
  -p:AndroidSigningStorePass=$env:STORE_PASSWORD
```

El AAB se generar� en:
```
Salutia.MobileApp\bin\Release\net8.0-android\publish\
```

### iOS (App Store)

```bash
# En Mac, generar IPA para producci�n
dotnet publish Salutia.MobileApp/Salutia.MobileApp.csproj \
  -f net8.0-ios \
  -c Release \
  -p:ArchiveOnBuild=true \
  -p:RuntimeIdentifier=ios-arm64
```

Luego usar **Xcode** o **Application Loader** para subir a App Store Connect.

---

## ?? Troubleshooting

### Problema: "No suitable Android SDK found"

**Soluci�n**:
```powershell
# Instalar Android SDK
$env:ANDROID_HOME = "C:\Program Files (x86)\Android\android-sdk"
dotnet workload install maui-android
```

### Problema: Error al compilar para iOS en Windows

**Soluci�n**: iOS solo se puede compilar en Mac. Opciones:
1. Usar Mac Build Host en Visual Studio
2. Usar un servicio CI/CD con agentes Mac (Azure DevOps, GitHub Actions)
3. Compilar localmente en un Mac

### Problema: "INSTALL_FAILED_UPDATE_INCOMPATIBLE"

**Soluci�n**:
```powershell
# Desinstalar versi�n antigua del emulador/dispositivo
adb uninstall com.companyname.salutia_mobileapp

# Volver a compilar y desplegar
dotnet build -t:Run -f net8.0-android
```

### Problema: Blazor no carga en la app

**Soluci�n**:
1. Verificar que `index.html` est� en `wwwroot/`
2. Verificar que `blazor.webview.js` se carga correctamente
3. Revisar logs en Output ? Debug

```csharp
// Agregar logging detallado
#if DEBUG
builder.Logging.SetMinimumLevel(LogLevel.Debug);
#endif
```

---

## ?? Pr�ximos Pasos

### Corto Plazo
- [ ] Implementar servicio de autenticaci�n completo
- [ ] Agregar almacenamiento offline con SQLite
- [ ] Implementar notificaciones push
- [ ] Agregar escaneo de c�digos QR (para 2FA)

### Medio Plazo
- [ ] Integraci�n con APIs de salud (Apple Health, Google Fit)
- [ ] Recordatorios de medicamentos
- [ ] Chat con m�dicos
- [ ] Videollamadas

### Largo Plazo
- [ ] Modo offline completo
- [ ] Sincronizaci�n inteligente
- [ ] Wearables integration
- [ ] IA para an�lisis de salud

---

## ?? Recursos Adicionales

### Documentaci�n Oficial
- [.NET MAUI Documentation](https://learn.microsoft.com/dotnet/maui/)
- [Blazor Hybrid](https://learn.microsoft.com/aspnet/core/blazor/hybrid/)
- [CommunityToolkit.Maui](https://learn.microsoft.com/dotnet/communitytoolkit/maui/)

### Tutoriales y Gu�as
- [Getting Started with .NET MAUI](https://learn.microsoft.com/dotnet/maui/get-started/)
- [Build your first Blazor Hybrid app](https://learn.microsoft.com/aspnet/core/blazor/hybrid/tutorials/)
- [Publishing MAUI apps](https://learn.microsoft.com/dotnet/maui/deployment/)

### Comunidad
- [.NET MAUI GitHub](https://github.com/dotnet/maui)
- [Stack Overflow - maui tag](https://stackoverflow.com/questions/tagged/maui)
- [.NET Community Discord](https://aka.ms/dotnet-discord)

---

## ?? Contribuir

Para contribuir al proyecto m�vil:

1. Crea una rama feature: `git checkout -b feature/nueva-funcionalidad`
2. Haz tus cambios y commitea: `git commit -m "feat: nueva funcionalidad"`
3. Push a la rama: `git push origin feature/nueva-funcionalidad`
4. Abre un Pull Request

---

## ?? Licencia

Este proyecto es parte de Salutia y sigue la misma licencia que el proyecto principal.

---

**�ltima actualizaci�n**: 2025  
**Versi�n de la App**: 1.0.0 (Beta)  
**Plataformas**: Android, iOS, macOS, Windows

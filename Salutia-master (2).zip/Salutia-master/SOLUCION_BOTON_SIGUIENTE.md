# ?? SOLUCI�N: Bot�n "Siguiente Pregunta" No Funciona

## ? Problema

Al hacer clic en el bot�n "Siguiente Pregunta" en la Pregunta 1 del test psicosom�tico, **no pasa nada** y la p�gina no avanza.

---

## ? Causa del Problema

1. **Arrays de strings no inicializados:** Los arrays `words[]`, `phrases[]`, etc. se inicializaban con valores `null` en lugar de strings vac�os
2. **Falta de actualizaci�n de UI:** No se llamaba `StateHasChanged()` despu�s de guardar los datos

---

## ?? Soluci�n Aplicada

### 1. Inicializaci�n Correcta de Arrays

**Antes (? Incorrecto):**
```csharp
private string[] words = new string[10];  // Crea array con nulls
```

**Despu�s (? Correcto):**
```csharp
private string[] words = Enumerable.Repeat(string.Empty, 10).ToArray();
```

### 2. Actualizaci�n Forzada de UI

**Agregado en cada m�todo:**
```csharp
private async Task SaveWordsAndNext()
{
    // ...existing validation...
    
    try
    {
        isSaving = true;
        StateHasChanged(); // ? Actualizar UI
        
        await TestService.SaveWordsAsync(currentTestId, words.ToList());
        savedWords = words.ToList();
        currentQuestion = 2;
        
        StateHasChanged(); // ? Actualizar despu�s del cambio
    }
    finally
    {
        isSaving = false;
        StateHasChanged(); // ? Actualizar al finalizar
    }
}
```

---

## ?? C�mo Aplicar la Soluci�n

### Opci�n 1: Hot Reload (Recomendado)

Si tu aplicaci�n est� en **modo debug**:

1. **Los cambios ya est�n guardados** ?
2. **Det�n el debug:** `Shift + F5`
3. **Inicia nuevamente:** `F5`
4. **Navega al test:** `/test-psicosomatico`

### Opci�n 2: Reiniciar Aplicaci�n

```powershell
# Detener aplicaci�n actual (Ctrl+C si est� en consola)

# Ejecutar nuevamente
dotnet run --project ".\Salutia Wep App\Salutia Wep App.csproj"
```

---

## ?? C�mo Probar

### 1. Acceder al Test

```
https://localhost:[puerto]/test-psicosomatico
```

### 2. Probar Pregunta 1

1. **Llenar las 10 palabras:**
   ```
   Palabra 1: [miedo]
   Palabra 2: [soledad]
   Palabra 3: [ansiedad]
   ...etc
   ```

2. **Click en "Siguiente Pregunta"**

3. **Verificar que:**
   - ? Aparece el spinner de carga
   - ? La p�gina cambia a **Pregunta 2 de 7**
   - ? Se muestran las palabras guardadas

### 3. Verificaci�n Visual

**Pregunta 1:**
```
?????????????????????????????????????????
?  Pregunta 1 de 7                      ?
?????????????????????????????????????????
[Barra de progreso: 14%]

Escriba 10 palabras...
[Input 1] [Input 2] ... [Input 10]

[Siguiente Pregunta ?]
```

**Despu�s de hacer clic ? Pregunta 2:**
```
?????????????????????????????????????????
?  Pregunta 2 de 7                      ?
?????????????????????????????????????????
[Barra de progreso: 28%]

Escriba una frase para cada palabra:

1. miedo
   [Textarea para la frase]

2. soledad
   [Textarea para la frase]
```

---

## ?? Depuraci�n (Si Sigue Sin Funcionar)

### 1. Verificar en Consola del Navegador

Presiona `F12` y ve a la pesta�a **Console**.

**Busca errores como:**
- ? `NullReferenceException`
- ? `SaveWordsAsync is not defined`
- ? Errores de conexi�n a la base de datos

### 2. Verificar en Output de Visual Studio

**Busca:**
```
Error al guardar: [mensaje del error]
```

### 3. Verificar Base de Datos

```sql
-- Ver si el test se cre�
SELECT * FROM PsychosomaticTests 
WHERE PatientUserId = '[tu-user-id]';

-- Ver si las palabras se guardaron
SELECT * FROM TestWords 
WHERE PsychosomaticTestId = [test-id];
```

### 4. Verificar Servicio

Abre **Developer Tools** ? **Network** ? Reintentar

Busca la llamada a `SaveWordsAsync` y verifica:
- ? Status: 200 OK
- ? Status: 400/500 (Error)

---

## ?? Checklist de Verificaci�n

- [ ] C�digo actualizado con arrays inicializados
- [ ] `StateHasChanged()` agregado en todos los m�todos
- [ ] Aplicaci�n detenida y reiniciada
- [ ] Navegado a `/test-psicosomatico`
- [ ] Palabras escritas correctamente
- [ ] Click en "Siguiente Pregunta"
- [ ] P�gina avanza a Pregunta 2
- [ ] Palabras se muestran en Pregunta 2

---

## ?? Cambios Realizados

### Archivo Modificado
`Salutia Wep App\Components\Pages\TestPsicosomatico.razor`

### Cambios Espec�ficos

1. **L�nea ~234:** Inicializaci�n de arrays
   ```csharp
   // ANTES
   private string[] words = new string[10];
   
   // DESPU�S
   private string[] words = Enumerable.Repeat(string.Empty, 10).ToArray();
   ```

2. **M�todos SaveWordsAndNext, SavePhrasesAndNext, etc.:**
   - Agregado `StateHasChanged()` al inicio del `try`
   - Agregado `StateHasChanged()` despu�s de cambiar `currentQuestion`
   - Agregado `StateHasChanged()` en el `finally`

---

## ?? Si el Problema Persiste

### Verificar que la migraci�n est� aplicada

```powershell
.\verificar-estado.ps1
```

**Debe mostrar 9 tablas** incluyendo `TestAges`.

### Revisar el servicio

```powershell
# Abrir el servicio
code ".\Salutia Wep App\Services\PsychosomaticTestService.cs"
```

Verificar que existe el m�todo:
```csharp
public async Task SaveWordsAsync(int testId, List<string> words)
```

### Logs en tiempo real

Agregar temporalmente en `SaveWordsAndNext`:

```csharp
private async Task SaveWordsAndNext()
{
    Console.WriteLine("?? SaveWordsAndNext iniciado");
    Console.WriteLine($"?? currentTestId: {currentTestId}");
    Console.WriteLine($"?? Palabras: {string.Join(", ", words)}");
    
    // ...resto del c�digo...
}
```

Luego revisa la consola del navegador (F12).

---

## ? Soluci�n Completa

**Estado:** ? Implementada y compilada

**Siguiente paso:**
1. Reiniciar aplicaci�n
2. Probar el test
3. Verificar que avanza entre preguntas

---

## ?? Notas T�cnicas

### �Por qu� `StateHasChanged()`?

Blazor no siempre detecta autom�ticamente los cambios en propiedades. `StateHasChanged()` fuerza la re-renderizaci�n del componente.

**Casos donde es necesario:**
- Despu�s de operaciones async
- Cuando cambian propiedades que afectan la UI
- Despu�s de cambios en variables que controlan `@if`

### �Por qu� inicializar con `string.Empty`?

```csharp
// ? Esto crea nulls
new string[10] ? [null, null, null, ...]

// ? Esto crea strings vac�os
Enumerable.Repeat(string.Empty, 10).ToArray() ? ["", "", "", ...]
```

Los nulls pueden causar `NullReferenceException` al usar `@bind` en inputs.

---

**�ltima actualizaci�n:** Ahora  
**Estado de compilaci�n:** ? Exitosa  
**Hot Reload:** Habilitado (requiere reiniciar)

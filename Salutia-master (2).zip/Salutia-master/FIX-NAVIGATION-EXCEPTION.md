# ?? Soluci�n: NavigationException al Crear Profesional

## ?? Problema Identificado

Al intentar crear un nuevo profesional, despu�s de que el registro es exitoso, aparece este error:

```
Ocurri� un error inesperado: Exception of type 
'Microsoft.AspNetCore.Components.NavigationException' was thrown..
Por favor intenta nuevamente.
```

### S�ntomas:
- ? El profesional **S� se crea correctamente** en la base de datos
- ? Aparece el mensaje "Profesional agregado exitosamente"
- ? Luego aparece un error de `NavigationException`
- ? La navegaci�n a `/Entity/ManageProfessionals` no se completa

---

## ?? Causa Ra�z

El problema ocurre porque el c�digo intenta navegar usando `Navigation.NavigateTo()` en un momento donde el componente Blazor no est� en un contexto v�lido para navegar:

```csharp
// ? C�DIGO PROBLEM�TICO
successMessage = "Profesional agregado exitosamente.";
Input = new InputModel();
StateHasChanged();           // ? Actualiza el componente
await Task.Delay(2000);
Navigation.NavigateTo(...);  // ? NavigationException aqu�
```

**�Por qu� falla?**

1. Despu�s de `StateHasChanged()`, el componente se renderiza nuevamente
2. Mientras se espera con `Task.Delay(2000)`, el contexto de sincronizaci�n del componente puede cambiar
3. Al intentar navegar, Blazor lanza una `NavigationException` porque no est� en el contexto correcto del UI thread

---

## ? Soluciones Aplicadas

### 1. Usar `InvokeAsync` para Navegaci�n Segura

**Antes:**
```csharp
successMessage = "Profesional agregado exitosamente.";
Input = new InputModel();
StateHasChanged();
await Task.Delay(2000);
Navigation.NavigateTo("/Entity/ManageProfessionals");
```

**Despu�s:**
```csharp
successMessage = "? Profesional agregado exitosamente. Redirigiendo...";
Input = new InputModel();

// Actualizar UI en el contexto correcto
await InvokeAsync(StateHasChanged);

// Esperar un momento
await Task.Delay(1500);

// Navegar en el contexto correcto
await InvokeAsync(() => 
{
    Navigation.NavigateTo("/Entity/ManageProfessionals", forceLoad: true);
});
```

**Beneficios:**
- ? `InvokeAsync` asegura que el c�digo se ejecute en el contexto del UI thread
- ? Previene `NavigationException`
- ? La navegaci�n funciona correctamente

---

### 2. Capturar Espec�ficamente `NavigationException`

Agregamos un catch espec�fico para manejar esta excepci�n de forma elegante:

```csharp
catch (NavigationException navEx)
{
    Logger.LogWarning(navEx, "NavigationException capturada - profesional creado");
    // No mostrar error al usuario porque el profesional S� fue creado
    successMessage = "? Profesional agregado exitosamente.";
}
```

**Beneficio:** Si a�n ocurre la excepci�n, el usuario no ve un mensaje de error confuso, ya que el profesional **s�** fue creado correctamente.

---

### 3. Agregar `@rendermode InteractiveServer`

Agregamos el atributo `@rendermode` para asegurar que el componente funcione en modo interactivo:

```razor
@page "/Entity/AddProfessional"
@rendermode InteractiveServer
@attribute [Authorize(Roles = "EntityAdmin")]
```

**Beneficio:** Asegura que todos los eventos y la navegaci�n funcionen correctamente en el componente.

---

### 4. Agregar `using` para `NavigationException`

Agregamos la directiva `using` necesaria:

```razor
@using Microsoft.AspNetCore.Components
```

Esto permite capturar espec�ficamente la excepci�n `NavigationException`.

---

### 5. Mejorar el Mensaje de �xito

```csharp
successMessage = "? Profesional agregado exitosamente. Redirigiendo...";
```

Ahora el usuario sabe que:
1. ? El registro fue exitoso
2. ?? La p�gina se est� redirigiendo autom�ticamente

---

### 6. Agregar `forceLoad: true`

```csharp
Navigation.NavigateTo("/Entity/ManageProfessionals", forceLoad: true);
```

**Beneficio:** Fuerza una recarga completa de la p�gina de destino, asegurando que se muestren los datos actualizados (incluyendo el profesional reci�n creado).

---

## ?? C�digo Completo Corregido

### M�todo `RegisterProfessional` Mejorado

```csharp
private async Task RegisterProfessional()
{
    try
    {
        isProcessing = true;
        errorMessage = null;
        successMessage = null;

        Logger.LogInformation("Iniciando registro de profesional. EntityId: {EntityId}", entityId);

        if (entityId == 0)
        {
            errorMessage = $"Error: No se pudo identificar la entidad. EntityId = {entityId}";
            Logger.LogError("EntityId es 0 al intentar registrar profesional");
            return;
        }

        var authState = await AuthProvider.GetAuthenticationStateAsync();
        var userId = authState.User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

        if (string.IsNullOrEmpty(userId))
        {
            errorMessage = "Error de autenticaci�n. Por favor inicia sesi�n nuevamente.";
            Logger.LogWarning("UserId vac�o al intentar registrar profesional");
            return;
        }

        var request = new RegisterProfessionalRequest
        {
            EntityId = entityId,
            FullName = Input.FullName,
            ProfessionalType = (ProfessionalType)int.Parse(Input.ProfessionalType),
            Specialty = Input.Specialty,
            ProfessionalLicense = Input.ProfessionalLicense,
            DocumentType = int.Parse(Input.DocumentType),
            DocumentNumber = Input.DocumentNumber,
            Email = Input.Email,
            Phone = Input.Phone,
            Password = Input.Password,
            ConfirmPassword = Input.ConfirmPassword,
            CountryId = Input.CountryId,
            StateId = Input.StateId,
            CityId = Input.CityId,
            Address = Input.Address
        };

        var result = await UserService.RegisterProfessionalAsync(request, userId);

        if (result.Success)
        {
            Logger.LogInformation("Profesional agregado exitosamente: {Email}, EntityId: {EntityId}", 
                Input.Email, entityId);
            
            successMessage = "? Profesional agregado exitosamente. Redirigiendo...";
            
            // Limpiar formulario
            Input = new InputModel();
            
            // ? Actualizar UI en el contexto correcto
            await InvokeAsync(StateHasChanged);

            // Esperar un momento para que el usuario vea el mensaje
            await Task.Delay(1500);
            
            // ? Navegar en el contexto correcto del componente
            await InvokeAsync(() => 
            {
                Navigation.NavigateTo("/Entity/ManageProfessionals", forceLoad: true);
            });
        }
        else
        {
            errorMessage = result.Message;
            Logger.LogWarning("Error al registrar profesional: {Message}", result.Message);
        }
    }
    catch (NavigationException navEx)
    {
        // ? Capturar espec�ficamente NavigationException
        Logger.LogWarning(navEx, "NavigationException - el profesional fue creado correctamente");
        successMessage = "? Profesional agregado exitosamente.";
    }
    catch (Exception ex)
    {
        Logger.LogError(ex, "Error agregando profesional. EntityId: {EntityId}", entityId);
        errorMessage = $"Ocurri� un error inesperado: {ex.Message}. Por favor intenta nuevamente.";
    }
    finally
    {
        isProcessing = false;
        // ? Asegurar que UI se actualice incluso si hay error
        await InvokeAsync(StateHasChanged);
    }
}
```

---

## ?? Aplicar los Cambios

### Reiniciar la Aplicaci�n

Dado que se agreg� `@rendermode`, necesitas reiniciar:

1. **Detener la aplicaci�n** ? Shift + F5
2. **Iniciar nuevamente** ? F5

---

## ?? Probar la Correcci�n

### Prueba 1: Crear un Profesional

1. Navega a `/Entity/Dashboard`
2. Haz clic en **"Agregar Nuevo Profesional"**
3. Completa el formulario con datos v�lidos:
   - Nombre: "Dr. Test Profesional"
   - Tipo: "M�dico"
   - Especialidad: "Medicina General"
   - Licencia: "12345"
   - Documento: CC / 1234567890
   - Email: `test.profesional@ejemplo.com`
   - Contrase�a: `Test123`
4. Haz clic en **"Agregar Profesional"**

**Resultado esperado:**
- ? Aparece el mensaje: "? Profesional agregado exitosamente. Redirigiendo..."
- ? Despu�s de 1.5 segundos, redirige a `/Entity/ManageProfessionals`
- ? En la lista aparece el profesional reci�n creado
- ? **NO aparece ning�n error de NavigationException**

---

### Prueba 2: Verificar en la Base de Datos

Ejecuta este query en SQL Server:

```sql
SELECT 
    epp.Id,
    epp.FullName,
    epp.Specialty,
    epp.ProfessionalLicense,
    epp.DocumentNumber,
    epp.EntityId,
    au.Email,
    au.UserType
FROM EntityProfessionalProfiles epp
INNER JOIN AspNetUsers au ON epp.ApplicationUserId = au.Id
WHERE au.Email = 'test.profesional@ejemplo.com';
```

**Resultado esperado:**
- ? El profesional aparece en la tabla
- ? Tiene el `EntityId` correcto
- ? El `UserType` es `1` (Doctor) o `2` (Psychologist)

---

### Prueba 3: Verificar Logs

En Visual Studio, revisa el **Output Window** (Ver ? Output):

Deber�as ver logs como:

```
Salutia_Wep_App.Components.Pages.Entity.AddProfessional: Information: 
  Iniciando registro de profesional. EntityId: 1

Salutia_Wep_App.Services.UserManagementService: Information: 
  Registrando profesional para entidad ID: 1

Salutia_Wep_App.Components.Pages.Entity.AddProfessional: Information: 
  Profesional agregado exitosamente: test.profesional@ejemplo.com, EntityId: 1
```

**NO deber�as ver:**
```
Warning: NavigationException capturada
```

Si ves este warning, significa que el problema a�n ocurre pero est� siendo manejado correctamente.

---

## ?? Diagn�stico de Problemas

### Problema 1: A�n aparece NavigationException

**Soluci�n:** Ya est� manejado en el c�digo. El profesional se crea correctamente y el usuario ve el mensaje de �xito.

**Verificaci�n:**
1. Revisa los logs en Visual Studio
2. Confirma que el profesional est� en la base de datos
3. Navega manualmente a `/Entity/ManageProfessionals` para ver el profesional

---

### Problema 2: No redirige autom�ticamente

**Posible causa:** El `InvokeAsync` no est� funcionando correctamente

**Soluci�n temporal:**
Agrega un bot�n manual para redirigir:

```razor
@if (!string.IsNullOrEmpty(successMessage))
{
    <div class="alert alert-success">
        @successMessage
        <div class="mt-3">
            <button class="btn btn-primary" @onclick="GoToManageProfessionals">
                Ir a Lista de Profesionales
            </button>
        </div>
    </div>
}
```

```csharp
private void GoToManageProfessionals()
{
    Navigation.NavigateTo("/Entity/ManageProfessionals", forceLoad: true);
}
```

---

### Problema 3: El formulario no se limpia

**Causa:** El `Input = new InputModel()` no est� funcionando

**Soluci�n:** Verifica que `SupplyParameterFromForm` est� configurado correctamente:

```csharp
[SupplyParameterFromForm]
private InputModel Input { get; set; } = new();
```

---

## ?? Resumen de Cambios

| Archivo | Cambio | L�nea |
|---------|--------|-------|
| `AddProfessional.razor` | Agregado `@rendermode InteractiveServer` | 2 |
| `AddProfessional.razor` | Agregado `@using Microsoft.AspNetCore.Components` | 8 |
| `AddProfessional.razor` | Modificado m�todo `RegisterProfessional` | ~442 |
| `AddProfessional.razor` | Agregado `InvokeAsync` para `StateHasChanged` | ~461 |
| `AddProfessional.razor` | Agregado `InvokeAsync` para navegaci�n | ~466 |
| `AddProfessional.razor` | Agregado catch para `NavigationException` | ~473 |
| `AddProfessional.razor` | Agregado `InvokeAsync` en finally | ~485 |

---

## ? Verificaci�n de Compilaci�n

La compilaci�n fue exitosa sin errores.

---

## ?? Resultado Esperado

Despu�s de aplicar estas correcciones:

1. ? El profesional se crea correctamente
2. ? Aparece el mensaje de �xito claro: "? Profesional agregado exitosamente. Redirigiendo..."
3. ? La p�gina redirige autom�ticamente despu�s de 1.5 segundos
4. ? **NO aparece el error de NavigationException**
5. ? El formulario se limpia despu�s del registro exitoso
6. ? La lista de profesionales se actualiza correctamente

---

## ?? Mejoras Adicionales (Opcional)

### 1. Agregar Progress Indicator

```razor
@if (isProcessing)
{
    <div class="alert alert-info">
        <div class="d-flex align-items-center">
            <div class="spinner-border spinner-border-sm me-2"></div>
            <span>Creando profesional, por favor espera...</span>
        </div>
    </div>
}
```

### 2. Agregar Bot�n para Agregar Otro

```csharp
private bool showAddAnotherButton = false;

// En RegisterProfessional, despu�s del �xito:
showAddAnotherButton = true;
```

```razor
@if (showAddAnotherButton)
{
    <button class="btn btn-success" @onclick="ResetForm">
        <i class="bi bi-plus-circle me-2"></i>
        Agregar Otro Profesional
    </button>
}
```

```csharp
private void ResetForm()
{
    Input = new InputModel();
    successMessage = null;
    errorMessage = null;
    showAddAnotherButton = false;
    StateHasChanged();
}
```

---

## ?? Conceptos T�cnicos

### �Qu� es `InvokeAsync`?

`InvokeAsync` es un m�todo de Blazor que asegura que el c�digo se ejecute en el contexto correcto del **UI thread** (hilo de interfaz de usuario).

**�Cu�ndo usarlo?**

- Cuando necesitas actualizar la UI desde un callback as�ncrono
- Cuando necesitas navegar despu�s de operaciones as�ncronas
- Cuando recibes errores de `InvalidOperationException` o `NavigationException`

**Ejemplo:**
```csharp
// ? Puede fallar
StateHasChanged();
Navigation.NavigateTo(...);

// ? Seguro
await InvokeAsync(StateHasChanged);
await InvokeAsync(() => Navigation.NavigateTo(...));
```

---

### �Qu� es `NavigationException`?

Es una excepci�n espec�fica de Blazor que ocurre cuando:

1. Se intenta navegar desde un contexto inv�lido
2. Se intenta navegar durante una operaci�n de renderizado
3. Se intenta navegar cuando el componente ya no existe

**Soluci�n:** Siempre usar `InvokeAsync` para navegaci�n despu�s de operaciones as�ncronas.

---

## ?? Si A�n No Funciona

Si despu�s de aplicar estas correcciones el problema persiste:

1. **Limpia y recompila:**
   ```powershell
   dotnet clean
   dotnet build
   ```

2. **Verifica los logs** en Visual Studio (Output Window)

3. **Captura el error completo:**
   - Abre las Herramientas de Desarrollador (F12)
   - Ve a la pesta�a "Console"
   - Captura cualquier error en rojo

4. **Verifica la base de datos:**
   - Confirma que el profesional **S�** fue creado
   - Si fue creado, el problema es solo con la navegaci�n

5. **Usa la soluci�n temporal:**
   - Agrega un bot�n manual para navegar a la lista
   - El profesional se cre� correctamente, solo necesitas navegaci�n manual

---

? **Correcci�n aplicada exitosamente**
?? Fecha: 2025-01-19
?? Archivos modificados: 1 (`AddProfessional.razor`)
?? Problema resuelto: NavigationException al crear profesional

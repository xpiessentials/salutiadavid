# ?? GU�A: Cambiar Contrase�a del SuperAdmin

## �Olvidaste la contrase�a del SuperAdmin?

No te preocupes, aqu� hay **3 formas** de cambiarla:

---

## ? **M�TODO 1: Script PowerShell (RECOMENDADO)**

Este es el m�todo m�s f�cil y seguro.

### Pasos:

1. **Abre PowerShell** en el directorio del proyecto
   ```powershell
   cd "D:\Desarrollos\Repos\Salutia"
   ```

2. **Ejecuta el script**
   ```powershell
   .\reset-superadmin-password.ps1
   ```

3. **Sigue las instrucciones**:
   - Ingresa la nueva contrase�a
   - Conf�rmala
   - El script actualizar� autom�ticamente la base de datos

4. **�Listo!** Ahora puedes iniciar sesi�n con:
   - **Usuario**: `elpeco1@msn.com`
   - **Contrase�a**: [la que acabas de establecer]

### Si el script falla:

Si obtienes un error de "No se puede ejecutar scripts", ejecuta esto primero:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Luego vuelve a ejecutar el script.

---

## ? **M�TODO 2: SQL Server Management Studio**

Si prefieres usar SQL directamente:

### Pasos:

1. **Abre SQL Server Management Studio (SSMS)**

2. **Con�ctate a tu servidor**:
   - Servidor: `LAPTOP-DAVID\SQLEXPRESS`
   - Autenticaci�n: Windows

3. **Abre el archivo SQL**:
   ```
   D:\Desarrollos\Repos\Salutia\reset-superadmin-password.sql
   ```

4. **Ejecuta la primera consulta** para verificar que existe el usuario:
   ```sql
   SELECT Id, UserName, Email, EmailConfirmed
   FROM AspNetUsers
   WHERE LOWER(Email) = 'elpeco1@msn.com';
   ```

5. **Para cambiar la contrase�a**, usa el script de PowerShell (m�todo 1)
   - El SQL solo sirve para verificar, no para cambiar la contrase�a
   - Necesitas generar un hash v�lido con ASP.NET Core Identity

---

## ? **M�TODO 3: Desde la aplicaci�n (Si a�n tienes acceso)**

Si tienes acceso a la aplicaci�n como administrador:

1. Inicia sesi�n como SuperAdmin (si recuerdas la contrase�a)
2. Ve a **Account/Manage**
3. Selecciona **Cambiar contrase�a**
4. Ingresa la contrase�a actual y la nueva

---

## ?? **Verificar el cambio**

Despu�s de cambiar la contrase�a:

1. **Abre tu aplicaci�n**: `https://localhost:7142` (o tu puerto)

2. **Haz clic en "Iniciar Sesi�n"**

3. **Ingresa las credenciales**:
   - Email: `elpeco1@msn.com`
   - Contrase�a: [tu nueva contrase�a]

4. **Verifica que puedes acceder** al Dashboard Admin

---

## ? **Problemas comunes**

### Error: "El usuario no existe"

Si el script dice que no encontr� el usuario, verifica con esta consulta SQL:

```sql
USE Salutia;
GO

SELECT * FROM AspNetUsers;
```

Si no aparece ning�n SuperAdmin, necesitas crearlo. Usa este script:
```powershell
.\create-superadmin.ps1
```

### Error: "No se puede conectar a la base de datos"

Verifica que SQL Server est� corriendo:
```powershell
.\test-database-connection.ps1
```

### Error: "La contrase�a no cumple los requisitos"

La contrase�a debe tener al menos:
- 6 caracteres (m�nimo)
- Se recomienda: letras may�sculas, min�sculas, n�meros y s�mbolos
- Ejemplo: `Salutia2025!`

---

## ?? **Informaci�n del SuperAdmin**

- **Email**: `elpeco1@msn.com`
- **Username**: `elpeco1@msn.com`
- **Rol**: `SuperAdmin`
- **Permisos**: Acceso completo a toda la aplicaci�n

---

## ?? **Siguientes pasos**

Una vez que hayas recuperado el acceso:

1. **Cambia la contrase�a** a una segura que puedas recordar
2. **Gu�rdala en un lugar seguro** (gestor de contrase�as)
3. **Activa la autenticaci�n de dos factores** (2FA):
   - Ve a Account/Manage
   - Selecciona "Autenticador"
   - Escanea el c�digo QR

---

## ?? **Consejos de seguridad**

- ? Usa una contrase�a fuerte y �nica
- ? Activa 2FA para mayor seguridad
- ? No compartas las credenciales de SuperAdmin
- ? Cambia la contrase�a peri�dicamente
- ? Revisa los logs de acceso regularmente

---

## ?? **�Necesitas m�s ayuda?**

Si ninguno de estos m�todos funciona:

1. Revisa los logs de la aplicaci�n
2. Verifica que la base de datos est� funcionando
3. Consulta el archivo `TROUBLESHOOTING.md`
4. Revisa la documentaci�n en `CREATE_SUPERADMIN_GUIDE.md`

---

**�ltima actualizaci�n**: Enero 2025
